# Vera-Life Software

Reference implementation for
*Lifecycle Faithfulness for Grounded Retrieval-Augmented Generation:
Benchmarks, Evaluation, and the Vera-Life Controller*
(Yang, You, Zheng, and Peng; GroundLM 2026 Findings).

See **`../README.md`** for layout, reproduction options, and licenses.

## Directory layout

```
src/              core library
scripts/          pipelines and evaluation
results/          paper-exact JSON (see results/NOTE.md)
paper/tables/     rendered LaTeX from 09_update_tables.py
environment.yml   conda environment
requirements.txt  pip dependencies
```

Benchmark JSONL files live in **`../data/`**.

## Dependencies

Python >= 3.10.  See `requirements.txt` or `environment.yml`.
A CUDA GPU is required for the Qwen3-8B and QLoRA experiments.
