"""Merge per-system results from multiple experiment logs into llm_main.json.

Collects results from separate experiment scripts (baselines, Vera-Life
variants) and assembles the final result table in canonical system order.
"""

import json
import re
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
RESULTS = PROJECT / "results"


def parse_log(path: Path) -> list[dict]:
    rows = []
    pattern = re.compile(r"\[done\]\s+([\w_]+):\s+(\{.*?\})")
    if not path.exists():
        return rows
    for line in path.read_text(errors="ignore").splitlines():
        m = pattern.search(line)
        if not m:
            continue
        try:
            d = json.loads(m.group(2).replace("'", '"'))
        except Exception:
            continue
        rows.append(d)
    return rows


def main():
    by_name = {}
    for log_name in ["llm_exp_1500.log", "llm_exp_vera_only.log",
                     "llm_exp_baseline_only.log", "llm_exp_extra.log"]:
        for d in parse_log(PROJECT / "logs" / log_name):
            by_name[d["name"]] = d  # later overrides earlier
    # If main_table.json is fresher, prefer its values for present keys.
    main_path = RESULTS / "llm_main.json"
    if main_path.exists():
        for d in json.loads(main_path.read_text()):
            if d["name"] not in by_name:
                by_name[d["name"]] = d
    order = ["closed_book", "vanilla_rag", "long_context", "hoh_style",
             "vera_life_no_graph", "vera_life_no_policy",
             "vera_life_no_ledger", "vera_life"]
    out = [by_name[n] for n in order if n in by_name]
    main_path.write_text(json.dumps(out, indent=2))
    sys.stderr.write(f"[merge] {len(out)} systems -> llm_main.json\n")


if __name__ == "__main__":
    main()
