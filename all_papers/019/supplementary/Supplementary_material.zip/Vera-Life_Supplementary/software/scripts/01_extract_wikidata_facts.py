"""Extract lifecycle facts from Wikidata via SPARQL.

For each relation (e.g., CEO, head of government), query for entities
with multiple time-bounded statements (start time P580, end time P582).
We keep only relations whose succession is clearly time-ordered, which
forms the basis for current/past/stale/conflict QA generation.
"""

import json
import os
import sys
import time
from pathlib import Path

import orjson
from SPARQLWrapper import JSON, SPARQLWrapper
from tqdm import tqdm

ENDPOINT = "https://query.wikidata.org/sparql"
USER_AGENT = "Vera-Life-Bench/1.0 (research; contact: pengyijie@nju.edu.cn)"
DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "wikidata"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# 11 relations with high temporal validity coverage and clear succession
# semantics.  These correspond to position_held (P39) sub-roles or direct
# property links such as P488 (chairperson).
RELATIONS = [
    # name              property      qualifier_property  comments
    ("ceo",              "P169",      None),                # chief executive officer (direct prop)
    ("chairperson",      "P488",      None),
    ("head_coach",       "P286",      None),
    ("director_manager", "P1037",     None),                # director / manager
    ("position_held",    "P39",       None),                # president, governor, ministers, etc.
    ("head_of_state",    "P35",       None),                # used as country -> person
    ("head_of_government","P6",       None),
    ("member_sports_team","P54",      None),
    ("member_of_party",  "P102",      None),
    ("owned_by",         "P127",      None),
    ("parent_org",       "P749",      None),
]


def sparql_query(query: str, retries: int = 3, sleep: float = 2.0):
    sparql = SPARQLWrapper(ENDPOINT, agent=USER_AGENT)
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    sparql.setTimeout(180)
    for attempt in range(retries):
        try:
            return sparql.query().convert()
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(f"[retry {attempt+1}/{retries}] {e}\n")
            time.sleep(sleep * (attempt + 1))
    return None


def build_query(prop: str, limit: int, offset: int = 0) -> str:
    """Build a SPARQL query that returns time-bounded statements for property `prop`.

    For each subject we return one row per statement with subject/object labels,
    start/end time, and a sample reference URL when available.
    """
    return f"""
SELECT ?subject ?subjectLabel ?statement ?object ?objectLabel ?start ?end ?refURL WHERE {{
  ?subject p:{prop} ?statement .
  ?statement ps:{prop} ?object .
  OPTIONAL {{ ?statement pq:P580 ?start . }}
  OPTIONAL {{ ?statement pq:P582 ?end . }}
  OPTIONAL {{ ?statement prov:wasDerivedFrom/pr:P854 ?refURL . }}
  FILTER (BOUND(?start) || BOUND(?end))
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}}
ORDER BY ?subject ?start
LIMIT {limit} OFFSET {offset}
"""


def extract_relation(name: str, prop: str, target: int = 4000, batch: int = 500):
    out_path = DATA_DIR / f"raw_{name}.jsonl"
    if out_path.exists() and out_path.stat().st_size > 100_000:
        sys.stderr.write(f"[skip] {name}: existing file {out_path.stat().st_size} bytes\n")
        return
    rows = []
    offset = 0
    pbar = tqdm(total=target, desc=name)
    while len(rows) < target:
        q = build_query(prop, batch, offset)
        res = sparql_query(q)
        if res is None or not res.get("results", {}).get("bindings"):
            sys.stderr.write(f"[stop] {name}: no more rows at offset {offset}\n")
            break
        bindings = res["results"]["bindings"]
        for b in bindings:
            rows.append({
                "subject_qid": b["subject"]["value"].rsplit("/", 1)[-1],
                "subject_label": b.get("subjectLabel", {}).get("value", ""),
                "object_qid": b["object"]["value"].rsplit("/", 1)[-1],
                "object_label": b.get("objectLabel", {}).get("value", ""),
                "start": b.get("start", {}).get("value", ""),
                "end": b.get("end", {}).get("value", ""),
                "ref": b.get("refURL", {}).get("value", ""),
                "statement": b["statement"]["value"].rsplit("/", 1)[-1],
                "relation": name,
                "property": prop,
            })
        if len(bindings) < batch:
            break
        offset += batch
        pbar.update(min(batch, target - pbar.n))
        time.sleep(1.0)  # be polite to public endpoint
    pbar.close()

    with open(out_path, "wb") as fh:
        for r in rows:
            fh.write(orjson.dumps(r))
            fh.write(b"\n")
    sys.stderr.write(f"[done] {name}: {len(rows)} rows -> {out_path}\n")


def main():
    target_per_rel = int(os.environ.get("VERA_TARGET", 3500))
    for name, prop, _ in RELATIONS:
        extract_relation(name, prop, target=target_per_rel)


if __name__ == "__main__":
    main()
