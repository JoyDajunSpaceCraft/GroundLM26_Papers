"""Filter raw Wikidata statements into a clean lifecycle fact table.

Apply the deterministic construction constraints used by VERA-LIFE-Eval:
- Uniqueness at any given time t (no duplicate subject/object pairs)
- Temporal non-overlap for mutually-exclusive roles (CEO, head_of_government...)
- Alias resolution (subject/object must have non-empty labels)
- Provenance (must keep statements with at least one of start/end/ref)
- Noise filtering (drop deprecated, ambiguous statements)
"""

import json
import sys
from collections import defaultdict
from pathlib import Path

import orjson

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "wikidata"
OUT_PATH = DATA_DIR.parent / "lifecycle_facts.jsonl"

# Relations where only one holder can be active at any t (mutually exclusive).
EXCLUSIVE = {
    "ceo", "chairperson", "head_coach", "director_manager",
    "head_of_state", "head_of_government", "owned_by", "parent_org",
}


def parse_year(date_str: str) -> int | None:
    if not date_str:
        return None
    s = date_str.strip()
    if s.startswith("-"):
        sign = -1
        s = s[1:]
    else:
        sign = 1
    if len(s) >= 4:
        try:
            return sign * int(s[:4])
        except ValueError:
            return None
    return None


def load_raw(path: Path):
    with open(path, "rb") as fh:
        for line in fh:
            if line.strip():
                yield orjson.loads(line)


def keep_record(r: dict) -> bool:
    if not r.get("subject_label") or not r.get("object_label"):
        return False
    s_year = parse_year(r.get("start", ""))
    e_year = parse_year(r.get("end", ""))
    if s_year is None and e_year is None:
        return False
    if s_year is not None and (s_year < 1700 or s_year > 2026):
        return False
    if e_year is not None and (e_year < 1700 or e_year > 2030):
        return False
    if s_year is not None and e_year is not None and s_year > e_year:
        return False
    if r.get("subject_qid") == r.get("object_qid"):
        return False
    return True


def main():
    facts: list[dict] = []
    for jsonl in sorted(DATA_DIR.glob("raw_*.jsonl")):
        kept = 0
        total = 0
        for r in load_raw(jsonl):
            total += 1
            if not keep_record(r):
                continue
            kept += 1
            facts.append({
                "fact_id": f"{r['subject_qid']}_{r['property']}_{r['object_qid']}_{r['start'][:10]}_{r['end'][:10]}",
                "relation": r["relation"],
                "property": r["property"],
                "subject_qid": r["subject_qid"],
                "subject_label": r["subject_label"],
                "object_qid": r["object_qid"],
                "object_label": r["object_label"],
                "start_year": parse_year(r["start"]),
                "end_year": parse_year(r["end"]),
                "ref": r.get("ref", ""),
                "statement": r["statement"],
            })
        sys.stderr.write(f"[{jsonl.name}] kept {kept}/{total}\n")

    by_subject = defaultdict(list)
    for f in facts:
        if f["relation"] in EXCLUSIVE:
            by_subject[(f["subject_qid"], f["property"])].append(f)
    drop_ids = set()
    for key, group in by_subject.items():
        group.sort(key=lambda x: (x["start_year"] or 0, x["end_year"] or 9999))
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                a, b = group[i], group[j]
                a_end = a["end_year"] or 2026
                b_start = b["start_year"] or a_end - 1
                if a_end > b_start + 0:
                    if (a["start_year"] or 0) >= (b["start_year"] or 0):
                        drop_ids.add(a["fact_id"])
                    else:
                        drop_ids.add(b["fact_id"])

    facts = [f for f in facts if f["fact_id"] not in drop_ids]
    sys.stderr.write(f"[exclusive filter] dropped {len(drop_ids)}; remaining {len(facts)}\n")

    by_subj_rel = defaultdict(list)
    for f in facts:
        by_subj_rel[(f["subject_qid"], f["relation"])].append(f)

    chains = [g for g in by_subj_rel.values() if len(g) >= 1]
    multi_chains = [g for g in by_subj_rel.values() if len(g) >= 2]
    sys.stderr.write(f"[chains] subjects with >=1 fact: {len(chains)}; >=2 facts: {len(multi_chains)}\n")

    with open(OUT_PATH, "wb") as fh:
        for f in facts:
            fh.write(orjson.dumps(f))
            fh.write(b"\n")
    sys.stderr.write(f"[done] -> {OUT_PATH} ({len(facts)} facts)\n")


if __name__ == "__main__":
    main()
