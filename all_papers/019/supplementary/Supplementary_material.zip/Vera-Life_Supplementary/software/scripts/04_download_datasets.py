"""Download evaluation datasets from the HuggingFace Hub.

The list below covers the public benchmarks used by the benchmark
builder (`05_build_benchmark.py`) and the transfer-evaluation harness
(`11_transfer_eval.py`).  Each entry is fetched into the local cache
under `data/hf_cache/`; missing or private slices are skipped at
runtime.
"""

import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
CACHE = PROJECT / "data" / "hf_cache"
CACHE.mkdir(parents=True, exist_ok=True)

os.environ["HF_HOME"] = str(CACHE)
os.environ["HF_HUB_CACHE"] = str(CACHE)
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

from huggingface_hub import snapshot_download  # noqa: E402

DATASETS = [
    # name             repo_id                                         repo_type  patterns
    ("hoh_qas",        "russwest404/HoH-QAs",                          "dataset", ["*"]),
    ("hoh_full",       "SKIML-ICL/hoh_full",                           "dataset", ["*"]),
    ("hoh_10k",        "SKIML-ICL/hoh_10000_filtered",                 "dataset", ["*"]),
    ("templama",       "tner/temporal_relevance_lama",                 "dataset", ["*"]),
    ("temp_reason",    "Yarrnit/TempReasonQA",                         "dataset", ["*"]),
    ("timeqa",         "BeyondAIDev/TimeQA",                           "dataset", ["*"]),
    ("freshqa",        "freshllms/freshqa",                            "dataset", ["*"]),
    # Transfer slice A: external multi-hop temporal benchmark.
    # The HuggingFace id is read from VERA_TRANSFER_SLICE_A_HFID at runtime
    # so that proprietary slices can be plugged in without editing this
    # file; skipped when the variable is not set.
] + ([("transfer_slice_a",
       os.environ["VERA_TRANSFER_SLICE_A_HFID"],
       "dataset", ["*"])] if os.environ.get("VERA_TRANSFER_SLICE_A_HFID") else []) + [
    ("alce_asqa",      "din0s/asqa",                                   "dataset", ["*"]),
    ("alce_eli5",      "sentence-transformers/eli5",                   "dataset", ["*"]),
    ("eli5_qampari",   "kalpeshk2011/qampari",                         "dataset", ["*"]),
    ("multitq",        "chenchen-pku/MultiTQ",                         "dataset", ["*"]),
    ("nq_open",        "google-research-datasets/nq_open",             "dataset", ["*"]),
    ("triviaqa",       "trivia_qa",                                    "dataset", ["rc.*"]),
]


def main():
    for tag, repo, repo_type, patterns in DATASETS:
        sys.stderr.write(f"== downloading {tag} <- {repo} ({repo_type}) ==\n")
        try:
            path = snapshot_download(
                repo_id=repo,
                repo_type=repo_type,
                cache_dir=str(CACHE),
                resume_download=True,
                allow_patterns=patterns,
                max_workers=2,
            )
            sys.stderr.write(f"  -> {path}\n")
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(f"  ERROR {tag}: {e}\n")


if __name__ == "__main__":
    main()
