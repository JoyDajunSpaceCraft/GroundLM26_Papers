"""4-bit QLoRA fine-tuning of Qwen3-8B for ledger generation.

Settings:
  - 4-bit NF4 quantization (bitsandbytes)
  - LoRA r=16 alpha=32 dropout=0.05
  - target = q,k,v,o,gate,up,down projections
  - bs=2, grad_accum=8 (effective batch 16)
  - lr=2e-4, cosine, 1 epoch
  - max_seq_len=2048
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data" / "qlora_train.jsonl"
OUT_DIR = PROJECT / "models" / "qlora_ledger"
OUT_DIR.mkdir(parents=True, exist_ok=True)

QWEN_PATH = os.environ.get("VERALIFE_QWEN_PATH", "Qwen/Qwen3-8B")

os.environ.setdefault("HF_HUB_CACHE", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HOME", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("NCCL_P2P_DISABLE", "1")
os.environ.setdefault("NCCL_IB_DISABLE", "1")

import torch  # noqa: E402
from transformers import (AutoModelForCausalLM, AutoTokenizer,  # noqa: E402
                          BitsAndBytesConfig)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training  # noqa: E402
from datasets import load_dataset  # noqa: E402
from trl import SFTConfig, SFTTrainer  # noqa: E402


def main():
    bnb = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )

    sys.stderr.write(f"[load] tokenizer\n")
    tok = AutoTokenizer.from_pretrained(QWEN_PATH, trust_remote_code=True,
                                        local_files_only=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"

    sys.stderr.write(f"[load] model 4-bit\n")
    model = AutoModelForCausalLM.from_pretrained(
        QWEN_PATH, quantization_config=bnb, trust_remote_code=True,
        local_files_only=True,
    )
    model = prepare_model_for_kbit_training(model)
    model.config.use_cache = False
    model.gradient_checkpointing_enable()

    lora_cfg = LoraConfig(
        r=16, lora_alpha=32, lora_dropout=0.05,
        bias="none", task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora_cfg)
    model.print_trainable_parameters()

    sys.stderr.write(f"[load] dataset {DATA}\n")
    ds = load_dataset("json", data_files=str(DATA), split="train")

    cfg = SFTConfig(
        output_dir=str(OUT_DIR),
        num_train_epochs=1,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=8,
        learning_rate=2e-4,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        max_length=2048,
        bf16=True,
        gradient_checkpointing=True,
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=1,
        report_to="none",
        optim="paged_adamw_8bit",
        dataloader_num_workers=2,
        remove_unused_columns=False,
    )

    trainer = SFTTrainer(
        model=model,
        args=cfg,
        train_dataset=ds,
        processing_class=tok,
    )
    sys.stderr.write(f"[train] starting on {torch.cuda.device_count()} GPU(s)\n")
    trainer.train()
    trainer.save_model(str(OUT_DIR / "final"))
    tok.save_pretrained(str(OUT_DIR / "final"))
    sys.stderr.write(f"[done] saved to {OUT_DIR / 'final'}\n")


if __name__ == "__main__":
    main()
