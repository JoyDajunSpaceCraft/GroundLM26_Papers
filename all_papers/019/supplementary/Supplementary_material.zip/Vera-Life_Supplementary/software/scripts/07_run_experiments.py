"""Run baselines and VERA-LIFE on VERA-LIFE-Eval (no LLM generation).

This script computes the lifecycle metrics that depend only on
retrieval + graph + policy, without needing the 8B generator.  It
isolates lifecycle state and action decisions from answer extraction
(Table 9 in the paper).

Outputs:
    results/main_table.json
    results/per_qtype.json

Fairness invariant
------------------
No baseline reads ``meta.role`` or the snapshot id ``snapshot_old`` /
``snapshot_new``.  Those are gold-construction signals that are
withheld from every system at inference time, exactly as Tab. 26
(metadata isolation) requires.  The signals every system *does* see
are: timestamp, source_type, source_uri, doc_id (when available), and
the raw evidence text.  VERA-LIFE additionally uses the public
provenance field; ablations under removal of that field are reported
in Tab. 70.
"""

from __future__ import annotations

import json
import os
import random
import sys
import time
from collections import defaultdict
from pathlib import Path


# ---- Metric-routing helpers (gold-label based) ---------------------------
def _is_stale_question(item: dict) -> bool:
    return item.get("gold_action") == "warn_stale" \
        or item.get("lifecycle_state_gold") == "stale"

def _is_conflict_question(item: dict) -> bool:
    return item.get("gold_action") == "explain_conflict" \
        or item.get("lifecycle_state_gold") == "conflicting"

def _is_update_question(item: dict) -> bool:
    return bool(item.get("superseded_object")) and item.get("qtype") == "update"

def _is_answerable_question(item: dict) -> bool:
    return item.get("gold_action") == "answer"
# -------------------------------------------------------------------------


PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

os.environ.setdefault("HF_HUB_CACHE", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HOME", str(PROJECT / "models" / "hf_cache"))

sys.path.insert(0, str(PROJECT))

from src.action_policy import (Action, PolicyThresholds, RiskScores,
                               compute_risks, rule_policy)
from src.contract_selector import ContractScores, greedy_select, jaccard
from src.lifecycle_graph import LifecycleGraphBuilder
from src.metrics import (CompositeWeights, answer_f1, lifecycle_calibration_error,
                         counterfactual_update_robustness, lifecycle_em,
                         over_abstention_rate, safe_utility, stale_rejection_rate,
                         supersession_f1, temporal_evidence_f1, token_f1)
from src.retriever import HybridRetriever, RetrieverConfig
from src.types import Evidence, EdgeType


def load_jsonl(p: Path) -> list[dict]:
    rows = []
    with open(p) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


# ---------------------------------------------------------------------- #
#  Strip role from evidence before showing it to baselines.
# ---------------------------------------------------------------------- #
def public_meta(meta: dict | None) -> dict:
    """Return a copy of ``meta`` with the gold-construction ``role``
    field stripped.  ``doc_id`` and ``doc_title`` are kept because
    they are public deployment signals (document identifiers exist in
    every production RAG pipeline)."""
    if not meta:
        return {}
    return {k: v for k, v in meta.items() if k != "role"}


# ---------------------------------------------------------------------- #
#  Baseline policies (no-LLM, public-metadata only)
# ---------------------------------------------------------------------- #
def vanilla_policy(evidences, graph, builder, t_q, qtype=""):
    return Action.ANSWER


def hoh_style_policy(evidences, graph, builder, t_q, qtype=""):
    """HoH-style: stale detection via the *publicly visible* timestamp
    of the retrieved chunks plus a same-document timestamp ordering
    check.  Reads no gold-construction metadata.
    """
    if not evidences:
        return Action.ANSWER
    top = evidences[:6]
    # Use lifecycle states inferred from the graph (which itself only
    # uses timestamp / doc_id / NLI signals).
    states = [builder.lifecycle_state(graph, e.eid, t_q) for e in top]
    has_current = any(s == "current" for s in states)
    has_outdated = any(s in {"superseded", "stale"} for s in states)
    if has_outdated and not has_current:
        return Action.WARN_STALE
    return Action.ANSWER


def vera_life_policy(evidences, graph, builder, t_q, qtype="",
                     thresholds: PolicyThresholds | None = None
                     ) -> tuple[Action, RiskScores]:
    """Lifecycle-aware action policy based on graph signals."""
    thresholds = thresholds or PolicyThresholds()
    if not evidences:
        return Action.ABSTAIN, RiskScores(1.0, 1.0, 0.0)

    top = evidences[:8]
    states = [builder.lifecycle_state(graph, e.eid, t_q) for e in top]
    has_current = any(s == "current" for s in states)
    has_past = any(s == "past_valid" for s in states)
    has_stale = any(s == "stale" for s in states)
    has_super = any(s == "superseded" for s in states)
    has_conflict = any(s == "conflicting" for s in states)
    n_super = sum(1 for s in states if s == "superseded")
    n_current = sum(1 for s in states if s == "current")
    n_past = sum(1 for s in states if s == "past_valid")
    coverage = (n_current + n_past) / max(1, len(top))
    max_v = 1.0 if has_current else (0.5 if has_past else 0.0)
    max_c = max((edge.weight for edge in graph.edges if edge.rel == EdgeType.CONTRADICT), default=0.0)
    risk = compute_risks(coverage, max_v, max_c)

    # Dispatch by qtype-aware rule policy.
    action = rule_policy(risk, thresholds, qtype=qtype)
    # For *update* and *conflict* questions the contract-selector layer
    # may further refine the action (handled in `08_run_llm_experiments.py`).
    if has_conflict or n_super >= 2:
        action = Action.EXPLAIN_CONFLICT
    elif (not has_current) and (has_stale or has_super) and qtype != "past":
        action = Action.WARN_STALE
    elif not has_current and not has_past:
        action = Action.ABSTAIN
    return action, risk


# ---------------------------------------------------------------------- #
#  Predict answer
# ---------------------------------------------------------------------- #
def predict_from_evidence(evidences, graph, builder, t_q, qtype=""):
    """Pick the lifecycle-prioritised evidence snippet's text as the
    candidate answer string for retrieval-only baselines."""
    if not evidences:
        return ""
    if qtype == "past":
        priority = {"past_valid": 0, "current": 1, "stale": 2, "superseded": 3,
                    "conflicting": 4, "insufficient": 5}
    else:
        priority = {"current": 0, "past_valid": 1, "stale": 2, "superseded": 3,
                    "conflicting": 4, "insufficient": 5}
    candidates = []
    for e in evidences:
        state = builder.lifecycle_state(graph, e.eid, t_q)
        candidates.append((e, state))
    candidates.sort(key=lambda c: (priority.get(c[1], 5), -c[0].score))
    return candidates[0][0].text


def run_baseline(name, items, retriever, builder, gold_eids_per_q,
                 policy_fn, top_k=24, save_path: Path | None = None):
    predictions = []
    pred_actions = []
    pred_supersede = []
    gold_supersede = []
    pred_evid_per_q = []
    gold_valid_evid_per_q = []
    confidences = []
    correctness = []
    update_records = []

    for it in items:
        qtype = it.get("qtype", "")
        if name == "closed_book":
            evs = []
        else:
            evs = retriever.search(it["question"], k=top_k)
        graph = builder.build(evs, t_q=it.get("t_q"))

        if name == "vera_life":
            action, risk = vera_life_policy(evs, graph, builder, it.get("t_q"), qtype=qtype)
        elif name == "hoh_style":
            action = hoh_style_policy(evs, graph, builder, it.get("t_q"), qtype=qtype)
            risk = RiskScores(0.0, 0.0, 0.0)
        else:
            action = vanilla_policy(evs, graph, builder, it.get("t_q"), qtype=qtype)
            risk = RiskScores(0.0, 0.0, 0.0)

        if action == Action.ABSTAIN or name == "closed_book":
            pred_text = ""
        elif name == "vera_life":
            scores = ContractScores()
            for e in evs:
                scores.relevance[e.eid] = e.score
                state = builder.lifecycle_state(graph, e.eid, it.get("t_q"))
                scores.validity[e.eid] = (1.0 if state == "current"
                                           else (0.5 if state == "past_valid" else 0.0))
                scores.provenance[e.eid] = 0.8
                scores.not_superseded[e.eid] = 0.0 if state == "superseded" else 1.0
                scores.conflict[e.eid] = max(
                    (edge.weight for edge in graph.edges
                     if edge.rel == EdgeType.CONTRADICT and e.eid in (edge.src, edge.dst)),
                    default=0.0)
            selected = greedy_select(evs, scores, budget=8,
                                     redundancy_fn=lambda a, b: jaccard(a.text, b.text))
            pred_text = predict_from_evidence(selected, graph, builder, it.get("t_q"), qtype=qtype)
        else:
            pred_text = predict_from_evidence(evs[:6], graph, builder, it.get("t_q"), qtype=qtype)

        predictions.append(pred_text)
        pred_actions.append(action)

        gold_eids = gold_eids_per_q.get(it["qid"], set())
        pred_valid_evs = {e.eid for e in evs[:8]
                          if builder.lifecycle_state(graph, e.eid, it.get("t_q"))
                          in {"current", "past_valid"}}
        pred_evid_per_q.append(pred_valid_evs)
        gold_valid_evid_per_q.append(set(gold_eids))

        is_supersede_question = _is_update_question(it) or _is_stale_question(it)
        gold_supersede.append(is_supersede_question)
        any_supersede_pred = any(builder.lifecycle_state(graph, e.eid, it.get("t_q"))
                                 in {"superseded", "stale"} for e in evs)
        pred_supersede.append(any_supersede_pred)

        if _is_stale_question(it):
            gold_correct = int(action in (Action.WARN_STALE, Action.ABSTAIN))
        elif _is_conflict_question(it):
            gold_correct = int(action == Action.EXPLAIN_CONFLICT)
        else:
            gold_correct = int(token_f1(pred_text, it["gold_answer"]) >= 0.4)
        correctness.append(bool(gold_correct))
        confidences.append(min(1.0, max(0.0, 1.0 - risk.insufficient)))

        if _is_update_question(it):
            old_gold = it.get("superseded_object") or ""
            new_gold = it.get("gold_answer", "")
            update_records.append({
                "old_correct": (old_gold != "" and token_f1(pred_text, old_gold) >= 0.4)
                               or token_f1(pred_text, new_gold) >= 0.4,
                "new_correct": token_f1(pred_text, new_gold) >= 0.4,
            })

    # Aggregate.
    ans_f1 = answer_f1(predictions, [[it["gold_answer"]] for it in items])
    sup_f1_val = supersession_f1(pred_supersede, gold_supersede)
    temp_f1_val = temporal_evidence_f1(pred_evid_per_q, gold_valid_evid_per_q)
    stale_mask = [_is_stale_question(it) for it in items]
    answerable_mask = [_is_answerable_question(it) for it in items]
    srr_val = stale_rejection_rate(pred_actions, stale_mask)
    oar_val = over_abstention_rate(pred_actions, answerable_mask)
    cur_val = counterfactual_update_robustness(update_records)
    lce_val = lifecycle_calibration_error(confidences, correctness, bins=10)
    su_val = safe_utility(ans_f1, temp_f1_val, sup_f1_val,
                           srr_val, cur_val, oar_val, lce_val)
    return {
        "name": name,
        "n": len(items),
        "AnsF1": round(ans_f1, 4),
        "Sup-F1": round(sup_f1_val, 4),
        "Temp-Evi-F1": round(temp_f1_val, 4),
        "SRR": round(srr_val, 4),
        "OAR": round(oar_val, 4),
        "CUR": round(cur_val, 4),
        "LCE": round(lce_val, 4),
        "SafeUtility": round(su_val, 4),
    }


def main():
    items = load_jsonl(DATA / "vera_life_eval.jsonl")
    pool_rows = load_jsonl(DATA / "vera_life_evidence.jsonl")
    pool_idx = {e["eid"]: e for e in pool_rows}
    # Strip role from the public view of evidence.
    evidences = [Evidence(eid=e["eid"], text=e["text"],
                          timestamp=e["timestamp"],
                          source_type=e["source_type"],
                          snapshot_id="",   # snapshot_id withheld at inference
                          meta=public_meta(e.get("meta", {})))
                 for e in pool_rows]

    rng = random.Random(0)
    rng.shuffle(items)
    n_eval = int(os.environ.get("VERA_EVAL_N", "1500"))
    items = items[:n_eval]
    sys.stderr.write(f"[load] eval items={len(items)}\n")

    cfg = RetrieverConfig(top_k_per_snapshot=40, final_top_k=24, rerank_weight=0.0)
    retriever = HybridRetriever(evidences, cfg=cfg, device="cuda:0",
                                cache_dir=str(PROJECT / "models" / "hf_cache"),
                                lazy_dense=True)
    builder = LifecycleGraphBuilder()
    gold_eids_per_q = {it["qid"]: set(it.get("evidence_pool", [])) for it in items}

    results = []
    for name, fn in [("closed_book", vanilla_policy),
                     ("vanilla_rag", vanilla_policy),
                     ("hoh_style", hoh_style_policy),
                     ("vera_life", vera_life_policy)]:
        sys.stderr.write(f"== running {name} ==\n")
        results.append(run_baseline(name, items, retriever, builder,
                                    gold_eids_per_q, fn))
    (RESULTS / "main_table.json").write_text(json.dumps(results, indent=2))
    sys.stderr.write(f"[saved] {RESULTS}/main_table.json\n")


if __name__ == "__main__":
    main()
