"""Build VERA-LIFE-Eval benchmark from HoH-QAs.

HoH-QAs schema:
- question, answer, last_modified_time, evidence, outdated_infos, document
"""

from __future__ import annotations

import json
import os
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

import pandas as pd

PROJECT = Path(__file__).resolve().parents[1]
DATA_CACHE = PROJECT / "data" / "hf_cache"
OUT_PATH = PROJECT / "data" / "vera_life_eval.jsonl"
EVIDENCE_OUT = PROJECT / "data" / "vera_life_evidence.jsonl"
HOH_QAS_PARQUET = (DATA_CACHE / "datasets--russwest404--HoH-QAs"
                   / "snapshots" / "d4236a28e6f821af253de5cf9b5efe1a5e20cb97"
                   / "hoh_qas_240601_241201.parquet")

random.seed(42)


def normalize_year(value) -> int | None:
    if value is None:
        return None
    if isinstance(value, pd.Timestamp):
        return int(value.year)
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        s = value.strip()
        if len(s) >= 4 and s[:4].isdigit():
            return int(s[:4])
    return None


def normalize_date(value) -> str:
    if value is None:
        return ""
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, str):
        return value[:10]
    return ""


def make_past_question(question: str, year: int) -> str:
    base = question.strip().rstrip("?.! ")
    lower = base.lower()
    if "current" in lower:
        return base.replace("current", f"in {year}").replace("Current", f"In {year}") + "?"
    if "currently" in lower:
        return base.replace("currently", f"in {year}").replace("Currently", f"In {year}") + "?"
    return base + f" in {year}?"


def make_stale_verify_question(question: str, outdated_answer: str) -> str:
    base = question.strip().rstrip("?.! ")
    return f"As of today, is the answer to '{base}' still '{outdated_answer}'?"


def main():
    if not HOH_QAS_PARQUET.exists():
        sys.stderr.write(f"[error] HoH-QAs parquet missing: {HOH_QAS_PARQUET}\n")
        sys.exit(2)

    t0 = time.time()
    df = pd.read_parquet(HOH_QAS_PARQUET)
    sys.stderr.write(f"[load] HoH-QAs rows: {len(df)} ({time.time()-t0:.1f}s)\n")
    sys.stderr.flush()

    questions = df["question"].tolist()
    answers = df["answer"].tolist()
    last_times = df["last_modified_time"].tolist()
    evidences = df["evidence"].tolist()
    outdated_list = df["outdated_infos"].tolist()
    documents = df["document"].tolist()
    sys.stderr.write(f"[unpacked] columns -> python lists ({time.time()-t0:.1f}s)\n")
    sys.stderr.flush()

    indices = list(range(len(df)))
    random.Random(42).shuffle(indices)

    targets = {
        "current": 1500,
        "past": 1500,
        "update": 2000,
        "stale_verify": 1500,
        "conflict": 1000,
        "multi_hop": 1000,
    }
    used = defaultdict(int)

    items: list[dict] = []
    pool: list[dict] = []
    eid_counter = 0
    qid_counter = 0

    def emit(text, ts, src, snap, role="", doc_id="", doc_title="", answer=""):
        nonlocal eid_counter
        eid = f"e{eid_counter:08d}"
        eid_counter += 1
        pool.append({
            "eid": eid, "text": text or "", "timestamp": ts,
            "source_type": src, "snapshot_id": snap,
            "meta": {"role": role, "doc_id": doc_id, "doc_title": doc_title, "answer": answer},
        })
        return eid

    def push(item):
        nonlocal qid_counter
        item["qid"] = f"vl{qid_counter:06d}"
        qid_counter += 1
        items.append(item)

    processed = 0
    for idx in indices:
        if all(used[k] >= v for k, v in targets.items()):
            break
        outdated = outdated_list[idx]
        if outdated is None or len(outdated) == 0:
            continue
        outdated = list(outdated)
        if not outdated:
            continue
        question = questions[idx]
        gold_ans = answers[idx]
        cur_evid = evidences[idx]
        cur_time = last_times[idx]
        doc = documents[idx] or {}
        doc_id = doc.get("id", "") if isinstance(doc, dict) else ""
        doc_title = doc.get("title", "") if isinstance(doc, dict) else ""

        cur_year = normalize_year(cur_time)
        new_eid = emit(cur_evid, normalize_date(cur_time), "wiki_revision", "snapshot_new",
                       role="current", doc_id=str(doc_id), doc_title=str(doc_title),
                       answer=str(gold_ans))
        old_pairs = []
        for od in outdated:
            old_pairs.append((emit(od["evidence"], normalize_date(od["last_modified_time"]),
                                   "wiki_revision", "snapshot_old",
                                   role="superseded", doc_id=str(doc_id), doc_title=str(doc_title),
                                   answer=str(od["answer"])), od))

        oldest = outdated[0]
        old_year = normalize_year(oldest["last_modified_time"])
        old_ans = oldest["answer"]

        if used["update"] < targets["update"]:
            push({
                "qtype": "update", "question": question, "t_q": cur_year or 2024,
                "gold_answer": gold_ans, "valid_interval": [cur_year, None],
                "superseded_object": old_ans,
                "evidence_pool": [new_eid] + [eid for eid, _ in old_pairs],
                "lifecycle_state_gold": "current", "gold_action": "answer",
                "source": "HoH", "doc_id": str(doc_id), "doc_title": str(doc_title),
            })
            used["update"] += 1

        if used["current"] < targets["current"]:
            push({
                "qtype": "current", "question": question, "t_q": cur_year or 2024,
                "gold_answer": gold_ans, "valid_interval": [cur_year, None],
                "superseded_object": "",
                "evidence_pool": [new_eid],
                "lifecycle_state_gold": "current", "gold_action": "answer",
                "source": "HoH", "doc_id": str(doc_id), "doc_title": str(doc_title),
            })
            used["current"] += 1

        if used["past"] < targets["past"] and old_year:
            push({
                "qtype": "past", "question": make_past_question(question, old_year),
                "t_q": old_year, "gold_answer": old_ans,
                "valid_interval": [old_year, cur_year],
                "superseded_object": gold_ans,
                "evidence_pool": [new_eid] + [eid for eid, _ in old_pairs],
                "lifecycle_state_gold": "past_valid", "gold_action": "answer",
                "source": "HoH", "doc_id": str(doc_id), "doc_title": str(doc_title),
            })
            used["past"] += 1

        if used["stale_verify"] < targets["stale_verify"] and old_pairs:
            push({
                "qtype": "stale_verify",
                "question": make_stale_verify_question(question, old_ans),
                "t_q": cur_year or 2024,
                "gold_answer": "no",
                "valid_interval": [old_year, cur_year],
                "superseded_object": old_ans,
                "evidence_pool": [old_pairs[0][0]],
                "lifecycle_state_gold": "stale", "gold_action": "warn_stale",
                "source": "HoH", "doc_id": str(doc_id), "doc_title": str(doc_title),
                "stale_target": old_ans,
            })
            used["stale_verify"] += 1

        if used["conflict"] < targets["conflict"] and len(old_pairs) >= 2:
            (eid_a, od_a), (eid_b, od_b) = old_pairs[0], old_pairs[1]
            if str(od_a["answer"]).strip().lower() != str(od_b["answer"]).strip().lower():
                push({
                    "qtype": "conflict", "question": question, "t_q": cur_year or 2024,
                    "gold_answer": gold_ans, "valid_interval": [cur_year, None],
                    "superseded_object": f"{od_a['answer']}|{od_b['answer']}",
                    "evidence_pool": [eid_a, eid_b],
                    "lifecycle_state_gold": "conflicting", "gold_action": "explain_conflict",
                    "source": "HoH", "doc_id": str(doc_id), "doc_title": str(doc_title),
                    "conflicting_answers": [od_a["answer"], od_b["answer"]],
                })
                used["conflict"] += 1

        if used["multi_hop"] < targets["multi_hop"] and len(old_pairs) >= 2:
            push({
                "qtype": "multi_hop",
                "question": (f"Trace how the answer to '{question}' "
                             "evolved across the documented revisions."),
                "t_q": cur_year or 2024,
                "gold_answer": " -> ".join([od["answer"] for od in outdated] + [gold_ans]),
                "valid_interval": [old_year, None],
                "superseded_object": "",
                "evidence_pool": [new_eid] + [eid for eid, _ in old_pairs],
                "lifecycle_state_gold": "current", "gold_action": "answer",
                "source": "HoH", "doc_id": str(doc_id), "doc_title": str(doc_title),
            })
            used["multi_hop"] += 1

        processed += 1
        if processed % 5000 == 0:
            sys.stderr.write(f"[progress] processed={processed} items={len(items)} "
                             f"counts={dict(used)} ({time.time()-t0:.1f}s)\n")
            sys.stderr.flush()

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_PATH, "w") as fh:
        for r in items:
            fh.write(json.dumps(r) + "\n")
    with open(EVIDENCE_OUT, "w") as fh:
        for e in pool:
            fh.write(json.dumps(e) + "\n")

    counts = defaultdict(int)
    for r in items:
        counts[r["qtype"]] += 1
    sys.stderr.write(f"[done] items={len(items)} evidence={len(pool)} -> {OUT_PATH}\n")
    sys.stderr.write(f"[counts] {dict(counts)}\n")


if __name__ == "__main__":
    main()
