"""REAL-blind / REAL-blind++: source-disjoint generalisation tests.

REAL-blind        : 1,200 questions whose source URLs were withheld
                    from the authors during construction and were
                    revealed only after camera-ready freezing.
REAL-blind++      : 1,000 questions whose contributing documents are
                    *source-disjoint* from every other split in the
                    benchmark suite.

Outputs:
    results/real_blind.json
    results/real_blind_plus.json
    paper/tables/real_blind.tex
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(PROJECT))

import importlib.util
spec = importlib.util.spec_from_file_location(
    "exp08", PROJECT / "scripts" / "08_run_llm_experiments.py")
exp08 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exp08)

from src.lifecycle_graph import LifecycleGraphBuilder  # noqa: E402
from src.types import Evidence  # noqa: E402


SPLITS = [
    ("real_blind", DATA / "real_blind.jsonl", DATA / "real_blind_evidence.jsonl"),
    ("real_blind_plus", DATA / "real_blind_plus.jsonl",
     DATA / "real_blind_plus_evidence.jsonl"),
]


def load_jsonl(p: Path) -> list[dict]:
    if not p.exists():
        return []
    rows = []
    with p.open() as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def run_one(name: str, items: list[dict], pool: list[dict]):
    if not items or not pool:
        sys.stderr.write(f"[skip] {name}: file missing\n")
        return None
    builder = LifecycleGraphBuilder()
    evidences = []
    for e in pool:
        meta = {k: v for k, v in (e.get("meta") or {}).items() if k != "role"}
        evidences.append(Evidence(eid=e["eid"], text=e["text"],
                                  timestamp=e["timestamp"],
                                  source_type=e["source_type"],
                                  snapshot_id="",
                                  meta=meta))
    retriever = exp08.build_retriever(evidences, fast=True)
    llm = exp08.QwenChat(exp08.QWEN_PATH)
    per_sys = {}
    for sys_name in ["vanilla_rag", "hoh_style", "vera_life"]:
        metrics, _preds, _acts, _lems = exp08.run_system(
            sys_name, items, retriever, builder, llm, top_k=12)
        per_sys[sys_name] = metrics
        sys.stderr.write(f"  {sys_name}: {metrics}\n")
    out = {"per_system": per_sys, "n": len(items)}
    (RESULTS / f"{name}.json").write_text(json.dumps(out, indent=2))
    sys.stderr.write(f"[saved] {RESULTS}/{name}.json\n")
    return out


def main():
    for name, items_p, pool_p in SPLITS:
        sys.stderr.write(f"\n== {name} ==\n")
        items = load_jsonl(items_p)
        pool = load_jsonl(pool_p)
        sys.stderr.write(f"[load] {len(items)} items, {len(pool)} evidence pieces\n")
        run_one(name, items, pool)


if __name__ == "__main__":
    main()
