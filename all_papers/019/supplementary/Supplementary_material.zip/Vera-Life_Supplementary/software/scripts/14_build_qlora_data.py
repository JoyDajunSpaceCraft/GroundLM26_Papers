"""Build QLoRA SFT training data from VERA-LIFE-Eval.

Hold out the first 1500 (random seed 0 shuffle) used by main experiments
and the held-out eval, then take 5K from the remaining train pool.

Each sample is a chat conversation:
    system  -> task instruction
    user    -> Question + As-of + Snippets (same prompt as run_system)
    assistant -> JSON ledger + Answer line

Output: data/qlora_train.jsonl
"""
import json
import random
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
OUT = DATA / "qlora_train.jsonl"

SEED = 0
N_HELDOUT = 1500
N_TRAIN = 5000

SYS_PROMPT = (
    "You are a precise lifecycle-aware QA assistant.  First output a JSON "
    "ledger inside a fenced ```json block describing the lifecycle of each "
    "supporting claim (claim text, lifecycle state in "
    "{current,past_valid,superseded,stale,conflicting}, valid_interval, and "
    "(optional) supersedes).  Then write 'Answer: ' followed by a short "
    "answer (max 16 words).  Do not output anything else."
)


def load_jsonl(p):
    out = []
    for line in p.open():
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


def build_prompt(it: dict, pool: dict) -> str:
    evs = []
    for k, eid in enumerate(it.get("evidence_pool", [])[:6]):
        e = pool.get(eid)
        if not e:
            continue
        evs.append(f"[{k+1}] (date={e.get('timestamp','?')}) {e['text'][:300]}")
    snippets = "\n".join(evs) if evs else "(no evidence retrieved)"
    return (f"Question: {it['question']}\n"
            f"As of: {it.get('t_q', 'unknown')}\n"
            f"Snippets:\n{snippets}\nShort answer:")


def build_ledger(it: dict, pool: dict) -> str:
    """Construct a supervised ledger + answer string for fine-tuning.

    The ledger lifecycle field uses the gold lifecycle state and the
    gold action label to produce the target format; the (state, action)
    pair fully specifies the desired ledger shape."""
    state = it.get("lifecycle_state_gold", "current")
    action = it.get("gold_action", "answer")
    valid = it.get("valid_interval", [None, None])
    interval = f"{valid[0] or '?'}-{valid[1] or 'present'}"

    if action == "warn_stale":
        old = it.get("superseded_object") or "(unspecified)"
        ledger = {"claims": [
            {"claim": old, "lifecycle": "superseded",
             "valid_interval": interval,
             "evidence": it.get("evidence_pool", [])[:3]}
        ]}
        answer = f"no longer current; was {old}"
    elif action == "explain_conflict":
        ledger = {"claims": [
            {"claim": it.get("gold_answer", "?"),
             "lifecycle": "conflicting",
             "valid_interval": interval,
             "evidence": it.get("evidence_pool", [])[:3]}
        ]}
        gold = it.get("gold_answer", "")
        sup = it.get("superseded_object", "")
        answer = f"conflicting / {gold}" + (f" / {sup}" if sup and sup != gold else "")
    else:
        cl = {"claim": it.get("gold_answer", "?"),
              "lifecycle": state,
              "valid_interval": interval,
              "evidence": it.get("evidence_pool", [])[:3]}
        if it.get("superseded_object"):
            cl["supersedes"] = it["superseded_object"]
        ledger = {"claims": [cl]}
        answer = it.get("gold_answer", "?")
    return ("```json\n" + json.dumps(ledger, ensure_ascii=False) + "\n```\n"
            f"Answer: {answer}")


def main():
    items = load_jsonl(DATA / "vera_life_eval.jsonl")
    pool_rows = load_jsonl(DATA / "vera_life_evidence.jsonl")
    pool = {e["eid"]: e for e in pool_rows}

    rng = random.Random(SEED)
    rng.shuffle(items)
    heldout_qids = {it["qid"] for it in items[:N_HELDOUT]}

    train_pool = [it for it in items if it["qid"] not in heldout_qids]
    rng.shuffle(train_pool)
    train = train_pool[:N_TRAIN]

    samples = []
    for it in train:
        user = build_prompt(it, pool)
        target = build_ledger(it, pool)
        samples.append({"messages": [
            {"role": "system", "content": SYS_PROMPT},
            {"role": "user", "content": user},
            {"role": "assistant", "content": target},
        ]})

    with OUT.open("w") as fh:
        for s in samples:
            fh.write(json.dumps(s, ensure_ascii=False) + "\n")
    print(f"Wrote {len(samples)} samples to {OUT}")
    # Quick stats by qtype
    from collections import Counter
    qtypes = Counter(it["qtype"] for it in train)
    for k, v in qtypes.most_common():
        print(f"  {k:15s} {v}")


if __name__ == "__main__":
    main()
