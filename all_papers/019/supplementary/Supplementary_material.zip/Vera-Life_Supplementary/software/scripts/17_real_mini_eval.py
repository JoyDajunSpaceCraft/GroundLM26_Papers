"""REAL-mini: 650-question evaluation across four real-world domains
(product / API, policy / legal, scientific / medical, news +
correction).  Each domain ships with its own evidence pool sourced
from publicly visible release notes, court rulings, paper retractions
and editorial corrections, with the gold-construction metadata
(``meta.role``) stripped before the retriever sees it.

Outputs:
    results/real_mini.json
    results/real_mini_per_domain.json
    paper/tables/real_mini.tex
"""
from __future__ import annotations

import json
import os
import sys
from collections import defaultdict
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(PROJECT))

import importlib.util
spec = importlib.util.spec_from_file_location(
    "exp08", PROJECT / "scripts" / "08_run_llm_experiments.py")
exp08 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exp08)

from src.types import Evidence  # noqa: E402
from src.lifecycle_graph import LifecycleGraphBuilder  # noqa: E402
from src.metrics import token_f1  # noqa: E402


DOMAINS = ["product_api", "policy_legal", "scientific_medical", "news_correction"]


def load_jsonl(p: Path) -> list[dict]:
    if not p.exists():
        return []
    rows = []
    with p.open() as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def main():
    items = load_jsonl(DATA / "real_mini.jsonl")
    pool = load_jsonl(DATA / "real_mini_evidence.jsonl")
    if not items or not pool:
        sys.stderr.write(f"[error] real_mini.jsonl or real_mini_evidence.jsonl missing in {DATA}\n")
        sys.exit(2)

    pool_idx = {e["eid"]: e for e in pool}
    by_domain = defaultdict(list)
    for it in items:
        by_domain[it.get("domain", "other")].append(it)

    sys.stderr.write(f"[load] {len(items)} questions across {len(by_domain)} domains\n")
    for d in DOMAINS:
        sys.stderr.write(f"  {d}: {len(by_domain[d])}\n")

    builder = LifecycleGraphBuilder()
    llm = exp08.QwenChat(exp08.QWEN_PATH)

    # Build retriever on the union of evidence (role stripped).
    evidences = []
    for e in pool:
        meta = {k: v for k, v in (e.get("meta") or {}).items() if k != "role"}
        evidences.append(Evidence(eid=e["eid"], text=e["text"],
                                  timestamp=e["timestamp"],
                                  source_type=e["source_type"],
                                  snapshot_id="",
                                  meta=meta))
    retriever = exp08.build_retriever(evidences, fast=True)

    out_per_domain = {}
    systems = ["hoh_style", "vera_life"]
    for d in DOMAINS:
        slice_items = by_domain.get(d, [])
        if not slice_items:
            continue
        sys.stderr.write(f"\n== domain {d}: {len(slice_items)} items ==\n")
        per_sys = {}
        for name in systems:
            metrics, _preds, _acts, _lems = exp08.run_system(
                name, slice_items, retriever, builder, llm, top_k=12)
            per_sys[name] = metrics
        out_per_domain[d] = per_sys
        # Delta LifeEM (vera_life - hoh_style).
        out_per_domain[d]["delta_life_em"] = round(
            per_sys["vera_life"]["LifeEM"] - per_sys["hoh_style"]["LifeEM"], 4)

    # Aggregate.
    avg = defaultdict(float)
    total_n = 0
    for d, per_sys in out_per_domain.items():
        n = per_sys.get("vera_life", {}).get("n", 0)
        if n == 0:
            continue
        for k, v in per_sys["vera_life"].items():
            if isinstance(v, (int, float)):
                avg[k] += v * n
        total_n += n
    if total_n > 0:
        for k in avg:
            avg[k] = round(avg[k] / total_n, 4)
    avg["n"] = total_n

    (RESULTS / "real_mini_per_domain.json").write_text(json.dumps(out_per_domain, indent=2))
    (RESULTS / "real_mini.json").write_text(json.dumps({
        "per_domain": out_per_domain,
        "avg_vera_life": dict(avg),
    }, indent=2))
    sys.stderr.write(f"[saved] {RESULTS}/real_mini.json\n")


if __name__ == "__main__":
    main()
