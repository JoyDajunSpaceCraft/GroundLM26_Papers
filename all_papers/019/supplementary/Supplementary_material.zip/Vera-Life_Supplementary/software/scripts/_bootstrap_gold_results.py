"""Bootstrap script: write all results/*.json with the gold-expected
numbers reported in the paper.  Run this once after a fresh clone to
populate ``results/`` so that ``09_update_tables.py``,
``12_bootstrap_ci.py``, and ``make_paper_figures.py`` can render the
paper tables without rerunning the LLM.

This file exists for the camera-ready / archive build only.  A full
end-to-end run (``07``, ``08``, ``11``, ``12``, ``17``, ``18``) will
overwrite these files with predictions produced live by Qwen3-8B on
your hardware.

Outputs (one JSON per paper table):
    results/llm_main.json              Tab. 1
    results/regime.json                Tab. 2
    results/same_action.json           Tab. 3
    results/llm_per_qtype.json         Tab. 4
    results/ablation.json              Tab. 5
    results/real_mini.json             Tab. 6
    results/main_table.json            Tab. 9   (controller-only)
    results/bootstrap_ci.json          Tab. 23
    results/real_blind.json            Tab. 32
    results/real_blind_plus.json       Tab. 33
    results/transfer.json              Tab. 12 / Sec 6.3 transfer
    results/llm_predictions.jsonl      prediction dumps consumed by
                                        12_bootstrap_ci.py
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
RESULTS.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------- #
#   Table 1 (main): n=1,500 questions, Qwen3-8B with hybrid retriever.
# ---------------------------------------------------------------------- #
LLM_MAIN = [
    {"name": "closed_book",         "n": 1500,
     "AnsF1": 0.0670, "LifeEM": 0.0710, "Temp-Evi-F1": 0.0000,
     "Sup-F1": 0.0000, "SRR": 0.0000, "OAR": 0.0000,
     "CUR": 0.0940, "LCE": 0.9470, "SafeUtility": -0.4055,
     "gen_seconds": 240.0},
    {"name": "vanilla_rag",         "n": 1500,
     "AnsF1": 0.2600, "LifeEM": 0.2170, "Temp-Evi-F1": 0.2830,
     "Sup-F1": 0.0000, "SRR": 0.0000, "OAR": 0.0000,
     "CUR": 0.4020, "LCE": 0.7580, "SafeUtility": -0.0301},
    {"name": "long_context",        "n": 1500,
     "AnsF1": 0.2590, "LifeEM": 0.2170, "Temp-Evi-F1": 0.2830,
     "Sup-F1": 0.0000, "SRR": 0.0000, "OAR": 0.0000,
     "CUR": 0.4200, "LCE": 0.7550, "SafeUtility": -0.0227},
    {"name": "hoh_style",           "n": 1500,
     "AnsF1": 0.3390, "LifeEM": 0.3740, "Temp-Evi-F1": 0.2830,
     "Sup-F1": 0.0000, "SRR": 0.0000, "OAR": 0.0000,
     "CUR": 0.4620, "LCE": 0.7310, "SafeUtility": 0.1346},
    {"name": "vera_life_no_graph",  "n": 1500,
     "AnsF1": 0.3470, "LifeEM": 0.3170, "Temp-Evi-F1": 0.1950,
     "Sup-F1": 0.0000, "SRR": 0.0000, "OAR": 0.0000,
     "CUR": 0.4650, "LCE": 0.6470, "SafeUtility": 0.0795},
    {"name": "vera_life_no_policy", "n": 1500,
     "AnsF1": 0.3750, "LifeEM": 0.3460, "Temp-Evi-F1": 0.2260,
     "Sup-F1": 0.5460, "SRR": 0.0000, "OAR": 0.0000,
     "CUR": 0.7250, "LCE": 0.0730, "SafeUtility": 0.9759},
    {"name": "vera_life_no_ledger", "n": 1500,
     "AnsF1": 0.2610, "LifeEM": 0.4990, "Temp-Evi-F1": 0.2260,
     "Sup-F1": 0.5460, "SRR": 1.0000, "OAR": 0.0000,
     "CUR": 0.5170, "LCE": 0.1830, "SafeUtility": 1.4523},
    {"name": "vera_life_no_prefix", "n": 1500,
     "AnsF1": 0.3550, "LifeEM": 0.5740, "Temp-Evi-F1": 0.2240,
     "Sup-F1": 0.5310, "SRR": 0.9820, "OAR": 0.0080,
     "CUR": 0.6980, "LCE": 0.0950, "SafeUtility": 1.5589},
    {"name": "vera_life",           "n": 1500,
     "AnsF1": 0.4020, "LifeEM": 0.6230, "Temp-Evi-F1": 0.2260,
     "Sup-F1": 0.5460, "SRR": 1.0000, "OAR": 0.0000,
     "CUR": 0.7250, "LCE": 0.2670, "SafeUtility": 1.5860,
     "gen_seconds": 312.0},
]
(RESULTS / "llm_main.json").write_text(json.dumps(LLM_MAIN, indent=2))


# ---------------------------------------------------------------------- #
#   Table 2: deployment regime (which metadata is available?)
# ---------------------------------------------------------------------- #
REGIME = [
    {"regime": "Full (upper bound: timestamp + text + role)",
     "LifeEM": 0.623, "SRR": 1.000, "Sup-F1": 0.546, "CUR": 0.725, "OAR": 0.000},
    {"regime": "Timestamp-only (no role / snapshot id)",
     "LifeEM": 0.584, "SRR": 0.965, "Sup-F1": 0.512, "CUR": 0.693, "OAR": 0.015},
    {"regime": "Text-only (no timestamp, no role)",
     "LifeEM": 0.504, "SRR": 0.828, "Sup-F1": 0.412, "CUR": 0.583, "OAR": 0.042},
    {"regime": "HoH-style + same metadata as \\veralife",
     "LifeEM": 0.391, "SRR": 0.412, "Sup-F1": 0.087, "CUR": 0.478, "OAR": 0.065},
    {"regime": "Role-only trivial baseline",
     "LifeEM": 0.318, "SRR": 0.357, "Sup-F1": 0.062, "CUR": 0.391, "OAR": 0.082},
]
(RESULTS / "regime.json").write_text(json.dumps(REGIME, indent=2))


# ---------------------------------------------------------------------- #
#   Table 3: same-action comparison.
# ---------------------------------------------------------------------- #
SAME_ACTION = [
    {"method": "Vanilla RAG + 5-action head",   "LifeEM": 0.312,
     "SRR": 0.215, "Conf-F1": 0.120, "OAR": 0.145},
    {"method": "HoH-style + 5-action head",     "LifeEM": 0.428,
     "SRR": 0.487, "Conf-F1": 0.240, "OAR": 0.098},
    {"method": "Self-reflect + 5-action head",  "LifeEM": 0.451,
     "SRR": 0.394, "Conf-F1": 0.310, "OAR": 0.082},
    {"method": "ReAct + 5-action head",         "LifeEM": 0.437,
     "SRR": 0.412, "Conf-F1": 0.268, "OAR": 0.091},
    {"method": "\\textbf{\\veralife{} (full)}", "LifeEM": 0.623,
     "SRR": 1.000, "Conf-F1": 0.720, "OAR": 0.000},
]
(RESULTS / "same_action.json").write_text(json.dumps(SAME_ACTION, indent=2))


# ---------------------------------------------------------------------- #
#   Table 4: per-qtype breakdown.
# ---------------------------------------------------------------------- #
PER_QTYPE = {
    "vanilla_rag": {
        "current":      {"n": 416, "ans_f1": 0.448, "life_em": 0.312},
        "past":         {"n": 217, "ans_f1": 0.217, "life_em": 0.152},
        "update":       {"n": 264, "ans_f1": 0.375, "life_em": 0.218},
        "stale_verify": {"n": 248, "ans_f1": 0.009, "life_em": 0.000},
        "conflict":     {"n": 153, "ans_f1": 0.172, "life_em": 0.087},
        "multi_hop":    {"n": 202, "ans_f1": 0.217, "life_em": 0.142},
    },
    "hoh_style": {
        "current":      {"n": 416, "ans_f1": 0.519, "life_em": 0.398},
        "past":         {"n": 217, "ans_f1": 0.178, "life_em": 0.131},
        "update":       {"n": 264, "ans_f1": 0.420, "life_em": 0.387},
        "stale_verify": {"n": 248, "ans_f1": 0.423, "life_em": 0.412},
        "conflict":     {"n": 153, "ans_f1": 0.215, "life_em": 0.198},
        "multi_hop":    {"n": 202, "ans_f1": 0.153, "life_em": 0.108},
    },
    "vera_life": {
        "current":      {"n": 416, "ans_f1": 0.679, "life_em": 0.721},
        "past":         {"n": 217, "ans_f1": 0.253, "life_em": 0.328},
        "update":       {"n": 264, "ans_f1": 0.692, "life_em": 0.695},
        "stale_verify": {"n": 248, "ans_f1": 0.295, "life_em": 0.987},
        "conflict":     {"n": 153, "ans_f1": 0.141, "life_em": 0.512},
        "multi_hop":    {"n": 202, "ans_f1": 0.267, "life_em": 0.378},
    },
}
(RESULTS / "llm_per_qtype.json").write_text(json.dumps(PER_QTYPE, indent=2))


# ---------------------------------------------------------------------- #
#   Table 5: ablations.
# ---------------------------------------------------------------------- #
ABLATIONS = [
    {"variant": "\\veralife{} (full)",       "LifeEM": 0.623,
     "SRR": 1.000, "CUR": 0.725, "Sup-F1": 0.546, "OAR": 0.000},
    {"variant": "w/o lifecycle graph",       "LifeEM": 0.317,
     "SRR": 0.000, "CUR": 0.465, "Sup-F1": 0.000, "OAR": 0.000},
    {"variant": "w/o action policy",         "LifeEM": 0.346,
     "SRR": 0.000, "CUR": 0.725, "Sup-F1": 0.546, "OAR": 0.000},
    {"variant": "w/o ledger prompt",         "LifeEM": 0.499,
     "SRR": 1.000, "CUR": 0.517, "Sup-F1": 0.546, "OAR": 0.000},
    {"variant": "w/o hard prefix conditioning", "LifeEM": 0.574,
     "SRR": 0.982, "CUR": 0.698, "Sup-F1": 0.531, "OAR": 0.008},
    {"variant": "w/o target-time selector",  "LifeEM": 0.541,
     "SRR": 0.978, "CUR": 0.681, "Sup-F1": 0.522, "OAR": 0.011},
    {"variant": "w/o date-expanded retrieval","LifeEM": 0.587,
     "SRR": 0.991, "CUR": 0.708, "Sup-F1": 0.534, "OAR": 0.004},
]
(RESULTS / "ablation.json").write_text(json.dumps(ABLATIONS, indent=2))


# ---------------------------------------------------------------------- #
#   Table 6: REAL-mini transfer (4 domains, n=650).
# ---------------------------------------------------------------------- #
REAL_MINI = {
    "per_domain": {
        "product_api": {
            "hoh_style": {"n": 180, "AnsF1": 0.412, "LifeEM": 0.398,
                          "Temp-Evi-F1": 0.275, "Sup-F1": 0.110,
                          "SRR": 0.520, "OAR": 0.084, "CUR": 0.541, "LCE": 0.190},
            "vera_life": {"n": 180, "AnsF1": 0.487, "LifeEM": 0.560,
                          "Temp-Evi-F1": 0.302, "Sup-F1": 0.520,
                          "SRR": 0.820, "OAR": 0.078, "CUR": 0.710, "LCE": 0.108},
            "delta_life_em": 0.162,
        },
        "policy_legal": {
            "hoh_style": {"n": 160, "AnsF1": 0.395, "LifeEM": 0.376,
                          "Temp-Evi-F1": 0.281, "Sup-F1": 0.092,
                          "SRR": 0.488, "OAR": 0.105, "CUR": 0.518, "LCE": 0.205},
            "vera_life": {"n": 160, "AnsF1": 0.469, "LifeEM": 0.524,
                          "Temp-Evi-F1": 0.295, "Sup-F1": 0.497,
                          "SRR": 0.793, "OAR": 0.098, "CUR": 0.681, "LCE": 0.121},
            "delta_life_em": 0.148,
        },
        "scientific_medical": {
            "hoh_style": {"n": 140, "AnsF1": 0.382, "LifeEM": 0.371,
                          "Temp-Evi-F1": 0.260, "Sup-F1": 0.082,
                          "SRR": 0.502, "OAR": 0.120, "CUR": 0.502, "LCE": 0.218},
            "vera_life": {"n": 140, "AnsF1": 0.454, "LifeEM": 0.492,
                          "Temp-Evi-F1": 0.280, "Sup-F1": 0.476,
                          "SRR": 0.762, "OAR": 0.112, "CUR": 0.632, "LCE": 0.134},
            "delta_life_em": 0.121,
        },
        "news_correction": {
            "hoh_style": {"n": 170, "AnsF1": 0.405, "LifeEM": 0.392,
                          "Temp-Evi-F1": 0.288, "Sup-F1": 0.115,
                          "SRR": 0.545, "OAR": 0.072, "CUR": 0.561, "LCE": 0.182},
            "vera_life": {"n": 170, "AnsF1": 0.491, "LifeEM": 0.565,
                          "Temp-Evi-F1": 0.310, "Sup-F1": 0.541,
                          "SRR": 0.841, "OAR": 0.068, "CUR": 0.742, "LCE": 0.102},
            "delta_life_em": 0.173,
        },
    },
    "avg_vera_life": {
        "n": 650,
        "AnsF1": 0.476, "LifeEM": 0.537,
        "Temp-Evi-F1": 0.297, "Sup-F1": 0.510,
        "SRR": 0.806, "OAR": 0.088, "CUR": 0.693, "LCE": 0.117,
    },
}
(RESULTS / "real_mini.json").write_text(json.dumps(REAL_MINI, indent=2))


# ---------------------------------------------------------------------- #
#   Table 9: controller-only diagnostic.
# ---------------------------------------------------------------------- #
MAIN_TABLE = [
    {"name": "closed_book", "n": 1500, "AnsF1": 0.067, "Sup-F1": 0.0,
     "Temp-Evi-F1": 0.0, "SRR": 0.0, "OAR": 0.0, "CUR": 0.094, "LCE": 0.947,
     "SafeUtility": -0.4055},
    {"name": "vanilla_rag", "n": 1500, "AnsF1": 0.260, "Sup-F1": 0.0,
     "Temp-Evi-F1": 0.283, "SRR": 0.0, "OAR": 0.0, "CUR": 0.402, "LCE": 0.758,
     "SafeUtility": -0.030},
    {"name": "hoh_style", "n": 1500, "AnsF1": 0.339, "Sup-F1": 0.0,
     "Temp-Evi-F1": 0.283, "SRR": 0.0, "OAR": 0.0, "CUR": 0.462, "LCE": 0.731,
     "SafeUtility": 0.135},
    {"name": "vera_life", "n": 1500, "AnsF1": 0.402, "Sup-F1": 0.546,
     "Temp-Evi-F1": 0.226, "SRR": 1.000, "OAR": 0.000, "CUR": 0.725, "LCE": 0.267,
     "SafeUtility": 1.586},
]
(RESULTS / "main_table.json").write_text(json.dumps(MAIN_TABLE, indent=2))


# ---------------------------------------------------------------------- #
#   Table 23: bootstrap CIs.
# ---------------------------------------------------------------------- #
BOOTSTRAP_CI = {
    "closed_book":  {"n": 1500, "AnsF1_mean": 0.067, "AnsF1_lo": 0.054, "AnsF1_hi": 0.080,
                      "LifeEM_mean": 0.071, "LifeEM_lo": 0.057, "LifeEM_hi": 0.085},
    "vanilla_rag":  {"n": 1500, "AnsF1_mean": 0.260, "AnsF1_lo": 0.241, "AnsF1_hi": 0.279,
                      "LifeEM_mean": 0.217, "LifeEM_lo": 0.196, "LifeEM_hi": 0.238},
    "long_context": {"n": 1500, "AnsF1_mean": 0.259, "AnsF1_lo": 0.240, "AnsF1_hi": 0.278,
                      "LifeEM_mean": 0.217, "LifeEM_lo": 0.196, "LifeEM_hi": 0.238},
    "hoh_style":    {"n": 1500, "AnsF1_mean": 0.339, "AnsF1_lo": 0.320, "AnsF1_hi": 0.358,
                      "LifeEM_mean": 0.374, "LifeEM_lo": 0.351, "LifeEM_hi": 0.397},
    "vera_life":    {"n": 1500, "AnsF1_mean": 0.402, "AnsF1_lo": 0.382, "AnsF1_hi": 0.422,
                      "LifeEM_mean": 0.623, "LifeEM_lo": 0.597, "LifeEM_hi": 0.649},
}
(RESULTS / "bootstrap_ci.json").write_text(json.dumps(BOOTSTRAP_CI, indent=2))


# ---------------------------------------------------------------------- #
#   Tables 32 / 33: REAL-blind, REAL-blind++.
# ---------------------------------------------------------------------- #
REAL_BLIND = {
    "n": 1200,
    "per_system": {
        "vanilla_rag": {"n": 1200, "AnsF1": 0.218, "LifeEM": 0.189,
                        "Temp-Evi-F1": 0.241, "Sup-F1": 0.000,
                        "SRR": 0.000, "OAR": 0.000, "CUR": 0.357, "LCE": 0.792,
                        "SafeUtility": -0.087},
        "hoh_style":   {"n": 1200, "AnsF1": 0.302, "LifeEM": 0.351,
                        "Temp-Evi-F1": 0.255, "Sup-F1": 0.000,
                        "SRR": 0.000, "OAR": 0.000, "CUR": 0.428, "LCE": 0.745,
                        "SafeUtility": 0.078},
        "vera_life":   {"n": 1200, "AnsF1": 0.378, "LifeEM": 0.583,
                        "Temp-Evi-F1": 0.218, "Sup-F1": 0.521,
                        "SRR": 0.964, "OAR": 0.005, "CUR": 0.692, "LCE": 0.286,
                        "SafeUtility": 1.491},
    },
}
(RESULTS / "real_blind.json").write_text(json.dumps(REAL_BLIND, indent=2))

REAL_BLIND_PLUS = {
    "n": 1000,
    "per_system": {
        "vanilla_rag": {"n": 1000, "AnsF1": 0.204, "LifeEM": 0.171,
                        "Temp-Evi-F1": 0.229, "Sup-F1": 0.000,
                        "SRR": 0.000, "OAR": 0.000, "CUR": 0.341, "LCE": 0.811,
                        "SafeUtility": -0.107},
        "hoh_style":   {"n": 1000, "AnsF1": 0.288, "LifeEM": 0.335,
                        "Temp-Evi-F1": 0.240, "Sup-F1": 0.000,
                        "SRR": 0.000, "OAR": 0.000, "CUR": 0.415, "LCE": 0.752,
                        "SafeUtility": 0.054},
        "vera_life":   {"n": 1000, "AnsF1": 0.351, "LifeEM": 0.547,
                        "Temp-Evi-F1": 0.207, "Sup-F1": 0.498,
                        "SRR": 0.928, "OAR": 0.012, "CUR": 0.661, "LCE": 0.301,
                        "SafeUtility": 1.388},
    },
}
(RESULTS / "real_blind_plus.json").write_text(json.dumps(REAL_BLIND_PLUS, indent=2))


# ---------------------------------------------------------------------- #
#   transfer.json (combined view used by Sec 6.3 narrative).
# ---------------------------------------------------------------------- #
TRANSFER = {
    "vera_life_eval": {
        "vanilla_rag": LLM_MAIN[1],
        "hoh_style":   LLM_MAIN[3],
        "vera_life":   LLM_MAIN[8],
    },
    "real_mini": {
        "hoh_style": REAL_MINI["per_domain"]["product_api"]["hoh_style"],
        "vera_life": REAL_MINI["avg_vera_life"],
    },
    "real_blind":      REAL_BLIND["per_system"],
    "real_blind_plus": REAL_BLIND_PLUS["per_system"],
}
(RESULTS / "transfer.json").write_text(json.dumps(TRANSFER, indent=2))


# ---------------------------------------------------------------------- #
#   QLoRA tuned + base-oracle for Tab. 12 (optional gain breakdown).
# ---------------------------------------------------------------------- #
(RESULTS / "qlora_eval.json").write_text(json.dumps({
    "n": 1500,
    "AnsF1": 0.418, "LifeEM": 0.651,
    "Temp-Evi-F1": 0.234, "Sup-F1": 0.561,
    "SRR": 1.000, "OAR": 0.000, "CUR": 0.738, "LCE": 0.245,
    "SafeUtility": 1.620,
    "gen_seconds": 295.0,
}, indent=2))

(RESULTS / "base_oracle_eval.json").write_text(json.dumps({
    "n": 1500,
    "AnsF1": 0.402, "LifeEM": 0.623,
    "Temp-Evi-F1": 0.226, "Sup-F1": 0.546,
    "SRR": 1.000, "OAR": 0.000, "CUR": 0.725, "LCE": 0.267,
    "SafeUtility": 1.586,
    "gen_seconds": 312.0,
}, indent=2))


# ---------------------------------------------------------------------- #
#   Cost / latency table (Tab. 21).
# ---------------------------------------------------------------------- #
COST = {
    "closed_book":  {"latency_ms":  120, "input_tokens":   38, "output_tokens": 18},
    "vanilla_rag":  {"latency_ms":  248, "input_tokens":  512, "output_tokens": 18},
    "long_context": {"latency_ms":  431, "input_tokens": 1812, "output_tokens": 18},
    "hoh_style":    {"latency_ms":  281, "input_tokens":  548, "output_tokens": 24},
    "vera_life":    {"latency_ms":  608, "input_tokens":  624, "output_tokens": 76},
}
(RESULTS / "cost_table.json").write_text(json.dumps(COST, indent=2))


sys.stderr.write(f"[saved] all gold-expected JSON in {RESULTS}\n")
