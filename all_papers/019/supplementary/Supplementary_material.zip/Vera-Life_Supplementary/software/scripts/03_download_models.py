"""Download models from the HuggingFace Hub."""

import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
CACHE = PROJECT / "models" / "hf_cache"
CACHE.mkdir(parents=True, exist_ok=True)

os.environ["HF_HOME"] = str(CACHE)
os.environ["HF_HUB_CACHE"] = str(CACHE)
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

from huggingface_hub import snapshot_download  # noqa: E402

MODELS = [
    ("qwen3_emb_0p6b",  "Qwen/Qwen3-Embedding-0.6B",  ["*.json", "*.txt", "*.safetensors", "tokenizer*", "*.py", "*.md"]),
    ("qwen3_rer_0p6b",  "Qwen/Qwen3-Reranker-0.6B",   ["*.json", "*.txt", "*.safetensors", "tokenizer*", "*.py", "*.md"]),
    ("bge_small_en",    "BAAI/bge-small-en-v1.5",     ["*.json", "*.txt", "*.safetensors", "tokenizer*", "*.md"]),
    ("bge_reranker",    "BAAI/bge-reranker-base",     ["*.json", "*.txt", "*.safetensors", "tokenizer*", "*.md"]),
    ("qwen3_8b_inst",   "Qwen/Qwen3-8B",              ["*.json", "*.txt", "*.safetensors", "tokenizer*", "*.py", "*.md", "generation_config.json"]),
]


def main():
    for tag, repo, patterns in MODELS:
        sys.stderr.write(f"== downloading {tag} <- {repo} ==\n")
        try:
            path = snapshot_download(
                repo_id=repo,
                cache_dir=str(CACHE),
                resume_download=True,
                allow_patterns=patterns,
                max_workers=4,
            )
            sys.stderr.write(f"  -> {path}\n")
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(f"  ERROR {tag}: {e}\n")


if __name__ == "__main__":
    main()
