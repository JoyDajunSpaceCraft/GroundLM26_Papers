"""Bootstrap 10,000x resample 95% CIs on existing 1,500-question
predictions, using the *canonical* LifeEM defined in
``src.metrics.lifecycle_em``.

Reads ``results/llm_predictions.jsonl`` (one row per (system, qid))
and computes per-system mean +/- bootstrap CI for AnsF1 and LifeEM
under the same definitions as ``08_run_llm_experiments.py``.

Outputs:
    results/bootstrap_ci.json
    paper/tables/bootstrap_ci.tex
"""
from __future__ import annotations

import json
import math
import random
import re
import sys
from collections import defaultdict
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))

from src.metrics import lifecycle_em, token_f1  # noqa: E402

PRED = PROJECT / "results" / "llm_predictions.jsonl"
OUT_JSON = PROJECT / "results" / "bootstrap_ci.json"
OUT_TEX = PROJECT / "paper" / "tables" / "bootstrap_ci.tex"

N_BOOT = 10_000
SEED = 0


def _action_to_state(action: str, gold_qtype: str = "") -> str:
    if action == "explain_conflict":
        return "conflicting"
    if action == "warn_stale":
        return "stale"
    if action == "abstain":
        return "insufficient"
    return "past_valid" if gold_qtype == "past" else "current"


def _gold_answer_for_metric(d: dict) -> str:
    if d.get("gold_action") == "warn_stale":
        return "no longer current"
    if d.get("gold_action") == "explain_conflict":
        return "conflicting"
    return d["gold"]


def _build_records(d: dict) -> tuple[dict, dict]:
    pred_state = _action_to_state(d.get("action", "answer"), d.get("qtype", ""))
    pred_record = {
        "answer": d["pred"],
        "interval": tuple(d.get("valid_interval", [None, None])),
        "state": pred_state,
    }
    gold_record = {
        "answer": _gold_answer_for_metric(d),
        "interval": tuple(d.get("valid_interval", [None, None])),
        "state": d.get("gold_state", "current"),
    }
    return pred_record, gold_record


def _life_em_per_row(d: dict) -> float:
    p, g = _build_records(d)
    return lifecycle_em([p], [g])


def _ans_per_row(d: dict) -> float:
    return token_f1(d["pred"], d["gold"])


def _bootstrap_ci(values: list[float], n_boot: int, seed: int) -> tuple[float, float, float]:
    rng = random.Random(seed)
    n = len(values)
    if n == 0:
        return 0.0, 0.0, 0.0
    mean = sum(values) / n
    sample_means = []
    for _ in range(n_boot):
        s = sum(values[rng.randrange(n)] for _ in range(n))
        sample_means.append(s / n)
    sample_means.sort()
    lo = sample_means[int(0.025 * n_boot)]
    hi = sample_means[int(0.975 * n_boot)]
    return mean, lo, hi


def main():
    if not PRED.exists():
        sys.stderr.write(f"[error] {PRED} missing\n")
        sys.exit(2)

    by_sys: dict[str, list[dict]] = defaultdict(list)
    with PRED.open() as fh:
        for line in fh:
            d = json.loads(line)
            by_sys[d["system"]].append(d)

    sys.stderr.write(f"systems: {sorted(by_sys.keys())}\n")
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_TEX.parent.mkdir(parents=True, exist_ok=True)

    rows = {}
    for sysname, preds in by_sys.items():
        ans_vals = [_ans_per_row(d) for d in preds]
        life_vals = [_life_em_per_row(d) for d in preds]
        ans_mean, ans_lo, ans_hi = _bootstrap_ci(ans_vals, N_BOOT, SEED)
        life_mean, life_lo, life_hi = _bootstrap_ci(life_vals, N_BOOT, SEED + 1)
        rows[sysname] = {
            "n": len(preds),
            "AnsF1_mean": round(ans_mean, 4),
            "AnsF1_lo": round(ans_lo, 4),
            "AnsF1_hi": round(ans_hi, 4),
            "LifeEM_mean": round(life_mean, 4),
            "LifeEM_lo": round(life_lo, 4),
            "LifeEM_hi": round(life_hi, 4),
        }
        sys.stderr.write(f"  {sysname:24s}  AnsF1={ans_mean:.4f} [{ans_lo:.4f},{ans_hi:.4f}]  "
                         f"LifeEM={life_mean:.4f} [{life_lo:.4f},{life_hi:.4f}]\n")

    OUT_JSON.write_text(json.dumps(rows, indent=2))

    PRETTY = {
        "closed_book": "Closed-book Qwen3-8B",
        "vanilla_rag": "Vanilla RAG (Hybrid)",
        "long_context": "Long-context RAG (20 ev)",
        "hoh_style": "HoH-style stale-aware",
        "vera_life": r"\textbf{\veralife (full)}",
    }
    order = ["closed_book", "vanilla_rag", "long_context", "hoh_style", "vera_life"]
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lcc}", r"\toprule",
             r"Method & AnsF1 [95\% CI] & LifeEM [95\% CI] \\",
             r"\midrule"]
    for s in order:
        if s not in rows:
            continue
        r = rows[s]
        lines.append(
            f"{PRETTY.get(s, s)} & {r['AnsF1_mean']:.3f} "
            f"[{r['AnsF1_lo']:.3f}, {r['AnsF1_hi']:.3f}] & "
            f"{r['LifeEM_mean']:.3f} [{r['LifeEM_lo']:.3f}, {r['LifeEM_hi']:.3f}] \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  r"\caption{Bootstrap 10{,}000$\times$ resample 95\% CIs on "
                  r"$n=1{,}500$ \bench questions, using the canonical "
                  r"\textsc{LifeEM} defined in \texttt{src/metrics.py}.}",
                  r"\label{tab:bootstrap}", r"\end{table}"])
    OUT_TEX.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {OUT_JSON.name}, {OUT_TEX.name}\n")


if __name__ == "__main__":
    main()
