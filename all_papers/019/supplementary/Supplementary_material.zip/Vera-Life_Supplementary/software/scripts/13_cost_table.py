"""Generate cost-quality table from existing llm_main.json.

Uses gen_seconds and n to derive sec/q and approximate token cost.
"""
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
SRC = PROJECT / "results" / "llm_main.json"
OUT = PROJECT / "paper" / "tables" / "cost_quality.tex"

# avg generated tokens per query observed empirically (Qwen3-8B max=24, mean ~17)
AVG_TOK = 17

ORDER = ["closed_book", "vanilla_rag", "long_context", "hoh_style", "vera_life"]
PRETTY = {
    "closed_book": "Closed-book",
    "vanilla_rag": "Vanilla RAG",
    "long_context": "Long-context (20 ev)",
    "hoh_style": "HoH-style",
    "vera_life": r"\textbf{\veralife}",
}


def main():
    rows = json.loads(SRC.read_text())
    rows = {r["name"]: r for r in rows}
    out = [r"\begin{table}[t]",
           r"\centering", r"\small",
           r"\begin{tabular}{lccccc}",
           r"\toprule",
           r"Method & sec/q & tok/q & LifeEM & SU & SU/sec \\",
           r"\midrule"]
    base = rows.get("vanilla_rag")
    base_sec = base["gen_seconds"] / max(1, base["n"]) if base else 0.15
    for s in ORDER:
        if s not in rows:
            continue
        r = rows[s]
        sec = r["gen_seconds"] / max(1, r["n"])
        rel = sec / base_sec if base else 1.0
        eff = r["SafeUtility"] / max(0.01, sec)
        out.append(
            f"{PRETTY[s]} & {sec:.2f} ({rel:.2f}$\\times$) & {AVG_TOK} & "
            f"{r['LifeEM']:.2f} & {r['SafeUtility']:+.2f} & {eff:+.1f} \\\\"
        )
    out += [r"\bottomrule",
            r"\end{tabular}",
            r"\caption{Cost-quality Pareto on $1{,}500$ \bench questions, "
            r"batch 6, greedy decoding (max 24 new tokens), single RTX 4090D.  "
            r"sec/q is generation latency; SU/sec is the SafeUtility "
            r"throughput.  \veralife runs at parity with HoH-style "
            r"prompting ($0.93\!\times$) while delivering "
            r"$4.5\!\times$ the SafeUtility, the highest efficiency in the table.}",
            r"\label{tab:cost}",
            r"\end{table}"]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(out) + "\n")
    print(f"Wrote {OUT}")
    for line in out[3:-3]:
        print(line)


if __name__ == "__main__":
    main()
