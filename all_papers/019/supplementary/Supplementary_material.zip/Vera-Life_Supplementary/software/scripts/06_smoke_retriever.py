"""Smoke-test the retrieval + lifecycle graph pipeline on VERA-LIFE-Eval.

Loads:
- 200 random questions from each split
- corresponding evidence pool entries
Runs:
- BM25 + dense (BGE-small) + reranker (BGE-reranker-base)
- Builds lifecycle graph
- Greedy contract selection
- Reports retrieval recall@k and lifecycle state distribution.
"""

from __future__ import annotations

import json
import os
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"

os.environ.setdefault("HF_HUB_CACHE", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HOME", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("TRANSFORMERS_CACHE", str(PROJECT / "models" / "hf_cache"))

sys.path.insert(0, str(PROJECT))

from src.contract_selector import ContractScores, greedy_select, jaccard
from src.lifecycle_graph import LifecycleGraphBuilder
from src.retriever import HybridRetriever, RetrieverConfig
from src.types import Evidence, EdgeType


def load_jsonl(p: Path) -> list[dict]:
    rows = []
    with open(p) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def main():
    items = load_jsonl(DATA / "vera_life_eval.jsonl")
    pool = load_jsonl(DATA / "vera_life_evidence.jsonl")
    pool_idx = {e["eid"]: e for e in pool}
    sys.stderr.write(f"[load] items={len(items)} pool={len(pool)}\n")

    by_qtype = defaultdict(list)
    for it in items:
        by_qtype[it["qtype"]].append(it)

    sample: list[dict] = []
    rng = random.Random(123)
    for qt, lst in by_qtype.items():
        rng.shuffle(lst)
        sample.extend(lst[:30])
    sys.stderr.write(f"[sample] {len(sample)} questions across {len(by_qtype)} types\n")

    needed_eids: set[str] = set()
    for it in sample:
        needed_eids.update(it["evidence_pool"])
    distractor_count = max(2000, 5 * len(needed_eids))
    distractors = rng.sample([e["eid"] for e in pool if e["eid"] not in needed_eids],
                             min(distractor_count, len(pool) - len(needed_eids)))
    target_pool = sorted(needed_eids | set(distractors))
    sys.stderr.write(f"[pool] needed={len(needed_eids)} distractors={len(distractors)} total={len(target_pool)}\n")

    evidences = [Evidence(eid=eid, text=pool_idx[eid]["text"],
                          timestamp=pool_idx[eid]["timestamp"],
                          source_type=pool_idx[eid]["source_type"],
                          snapshot_id=pool_idx[eid]["snapshot_id"],
                          meta=pool_idx[eid]["meta"]) for eid in target_pool]

    cache_dir = str(PROJECT / "models" / "hf_cache")
    cfg = RetrieverConfig(top_k_per_snapshot=80, final_top_k=24,
                          embedding_model="BAAI/bge-small-en-v1.5",
                          reranker_model="BAAI/bge-reranker-base")
    t0 = time.time()
    retriever = HybridRetriever(evidences, cfg=cfg, device="cuda:0", cache_dir=cache_dir)
    sys.stderr.write(f"[retriever ready] in {time.time()-t0:.1f}s ({len(evidences)} docs)\n")

    builder = LifecycleGraphBuilder()

    recall = []
    state_counts = defaultdict(int)
    contracted = []
    for it in sample:
        evs = retriever.search(it["question"], k=24)
        retrieved_ids = {e.eid for e in evs}
        gold_ids = set(it["evidence_pool"])
        if gold_ids:
            recall.append(len(retrieved_ids & gold_ids) / len(gold_ids))
        graph = builder.build(evs, t_q=it.get("t_q"))
        for e in evs:
            state_counts[builder.lifecycle_state(graph, e.eid, it.get("t_q"))] += 1
        scores = ContractScores()
        for e in evs:
            scores.relevance[e.eid] = e.score
            state = builder.lifecycle_state(graph, e.eid, it.get("t_q"))
            scores.validity[e.eid] = 1.0 if state == "current" else (0.5 if state == "past_valid" else 0.0)
            scores.provenance[e.eid] = 0.8
            scores.not_superseded[e.eid] = 0.0 if state == "superseded" else 1.0
            scores.conflict[e.eid] = max((edge.weight for edge in graph.edges
                                          if edge.rel == EdgeType.CONTRADICT and e.eid in (edge.src, edge.dst)),
                                         default=0.0)
        selected = greedy_select(evs, scores, budget=8,
                                 redundancy_fn=lambda a, b: jaccard(a.text, b.text))
        contracted.append(len(selected))

    sys.stderr.write(f"[recall@24] mean={sum(recall)/len(recall):.3f} n={len(recall)}\n")
    sys.stderr.write(f"[state distribution] {dict(state_counts)}\n")
    sys.stderr.write(f"[contracted size] avg={sum(contracted)/len(contracted):.2f}\n")


if __name__ == "__main__":
    main()
