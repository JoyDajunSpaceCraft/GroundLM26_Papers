"""Evaluate the QLoRA-tuned ledger generator on the held-out 1,500
items.  Same metrics as the main experiments; the canonical LifeEM is
re-used unchanged.

Outputs:
    results/qlora_eval.json
    paper/tables/qlora_optional.tex
"""
from __future__ import annotations

import json
import os
import random
import re
import sys
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
ADAPTER = PROJECT / "models" / "qlora_ledger" / "final"

os.environ.setdefault("HF_HUB_CACHE", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HOME", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

sys.path.insert(0, str(PROJECT))

import torch  # noqa: E402
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig  # noqa: E402
from peft import PeftModel  # noqa: E402

from src.action_policy import (Action, PolicyThresholds, RiskScores,  # noqa: E402
                               compute_risks)
from src.contract_selector import ContractScores, greedy_select, jaccard  # noqa: E402
from src.lifecycle_graph import LifecycleGraphBuilder  # noqa: E402
from src.metrics import (answer_f1, counterfactual_update_robustness,  # noqa: E402
                         lifecycle_calibration_error, lifecycle_em,
                         over_abstention_rate, safe_utility,
                         stale_rejection_rate, supersession_f1,
                         temporal_evidence_f1, token_f1)
from src.types import Evidence, EdgeType  # noqa: E402

# Import helpers from 08 (file name is not a valid module identifier
# so we go through importlib).
import importlib.util
spec = importlib.util.spec_from_file_location(
    "exp08", PROJECT / "scripts" / "08_run_llm_experiments.py")
exp08 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exp08)

QWEN_PATH = os.environ.get("VERALIFE_QWEN_PATH", "Qwen/Qwen3-8B")


def _is_stale(item):
    return item.get("gold_action") == "warn_stale"


def _is_conflict(item):
    return item.get("gold_action") == "explain_conflict"


def _is_update(item):
    return bool(item.get("superseded_object")) and item.get("qtype") == "update"


def _is_answerable(item):
    return item.get("gold_action") == "answer"


def main():
    rng = random.Random(0)
    items = exp08.load_jsonl(DATA / "vera_life_eval.jsonl")
    pool_rows = exp08.load_jsonl(DATA / "vera_life_evidence.jsonl")
    pool_idx = {e["eid"]: e for e in pool_rows}
    rng.shuffle(items)
    items = items[:1500]
    sys.stderr.write(f"[load] eval items={len(items)}\n")

    # Oracle evidence with role stripped before passing into the model.
    def _strip(meta):
        return {k: v for k, v in (meta or {}).items() if k != "role"}
    item_evidences = []
    for it in items:
        evs = []
        for eid in it.get("evidence_pool", []):
            e = pool_idx.get(eid)
            if not e:
                continue
            evs.append(Evidence(eid=eid, text=e["text"],
                                timestamp=e["timestamp"],
                                source_type=e["source_type"],
                                snapshot_id="",
                                meta=_strip(e.get("meta", {}))))
        item_evidences.append(evs)

    builder = LifecycleGraphBuilder()

    bnb = BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )
    tok = AutoTokenizer.from_pretrained(QWEN_PATH, trust_remote_code=True,
                                        local_files_only=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"
    base = AutoModelForCausalLM.from_pretrained(
        QWEN_PATH, quantization_config=bnb, trust_remote_code=True,
        local_files_only=True, device_map={"": 0}, low_cpu_mem_usage=True,
    )
    model = PeftModel.from_pretrained(base, str(ADAPTER))
    model.eval()

    prompts, actions, chosen_evs, risks, states_per_q = [], [], [], [], []
    for it, evs in zip(items, item_evidences):
        graph = builder.build(evs, t_q=it.get("t_q")) if evs else builder.build([], t_q=it.get("t_q"))
        action, risk, states = exp08.vera_life_policy(
            evs, graph, builder, it.get("t_q"),
            enable_graph=True, enable_policy=True,
            qtype=it.get("qtype", ""),    # parameter is now part of 08's signature
        )
        scores = ContractScores()
        for e in evs:
            scores.relevance[e.eid] = 1.0
            st = states.get(e.eid, "current")
            scores.validity[e.eid] = (1.0 if st == "current"
                                       else (0.5 if st == "past_valid" else 0.0))
            scores.provenance[e.eid] = 0.8
            scores.not_superseded[e.eid] = 0.0 if st == "superseded" else 1.0
            scores.conflict[e.eid] = max(
                (edge.weight for edge in graph.edges
                 if edge.rel == EdgeType.CONTRADICT and e.eid in (edge.src, edge.dst)),
                default=0.0)
        chosen = greedy_select(evs, scores, budget=6,
                               redundancy_fn=lambda a, b: jaccard(a.text, b.text))
        if not chosen:
            chosen = evs[:6]
        actions.append(action)
        risks.append(risk)
        chosen_evs.append(chosen)
        states_per_q.append(states)
        user = exp08.vera_life_user(it["question"], chosen, states, it.get("t_q"), action)
        msgs = [{"role": "system", "content": exp08.VERA_LIFE_LEDGER_INSTRUCTIONS},
                {"role": "user", "content": user}]
        try:
            prompt = tok.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True,
                enable_thinking=False)
        except TypeError:
            prompt = tok.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True)
        prompts.append(prompt)

    sys.stderr.write(f"[gen] {len(prompts)} prompts, batch_size=4\n")
    sys.stderr.flush()
    t0 = time.time()
    bs = 4
    raw_outs = []
    with torch.inference_mode():
        for i in range(0, len(prompts), bs):
            batch = prompts[i:i + bs]
            enc = tok(batch, return_tensors="pt", padding=True,
                      truncation=True, max_length=2048).to(model.device)
            gen = model.generate(
                **enc, max_new_tokens=256,
                do_sample=False, num_beams=1,
                pad_token_id=tok.pad_token_id,
            )
            for j in range(gen.size(0)):
                out_ids = gen[j, enc["input_ids"].shape[1]:]
                raw_outs.append(tok.decode(out_ids, skip_special_tokens=True).strip())
    gen_seconds = time.time() - t0

    predictions = []
    for raw in raw_outs:
        ans = raw
        if "Answer:" in ans:
            ans = ans.split("Answer:")[-1].strip()
        ans = ans.split("\n")[0].strip()
        for stop in ["Question:", "Snippets:", "<|", "Short answer:", "```"]:
            if stop in ans:
                ans = ans.split(stop)[0].strip()
        predictions.append(ans[:200])

    # Canonical LifeEM.
    life_pred, life_gold = [], []
    for pred, it, act, evs in zip(predictions, items, actions, chosen_evs):
        pred_interval = exp08._extract_interval_from_evidence(
            evs, it.get("valid_interval", [None, None]))
        pred_state = exp08._life_state_for_action(act,
            default_state=("past_valid" if it.get("qtype") == "past" else "current"))
        gold_ans = it["gold_answer"]
        if _is_stale(it):
            gold_ans = "no longer current"
        elif _is_conflict(it):
            gold_ans = "conflicting"
        life_pred.append({"answer": pred, "interval": pred_interval, "state": pred_state})
        life_gold.append({"answer": gold_ans,
                          "interval": tuple(it.get("valid_interval", [None, None])),
                          "state": it.get("lifecycle_state_gold", "current")})
    life_em_val = lifecycle_em(life_pred, life_gold)
    per_item = [lifecycle_em([p], [g]) for p, g in zip(life_pred, life_gold)]

    pred_valid, gold_valid = [], []
    pred_sup, gold_sup = [], []
    for it, evs, st in zip(items, chosen_evs, states_per_q):
        pred_valid.append({e.eid for e in evs[:6]
                            if st.get(e.eid, "current") in {"current", "past_valid"}})
        gold_valid.append(set(it.get("evidence_pool", [])))
        gold_sup.append(_is_update(it) or _is_stale(it))
        pred_sup.append(any(s in {"superseded", "stale"} for s in st.values()))
    temp_f1 = temporal_evidence_f1(pred_valid, gold_valid)
    sup_f1 = supersession_f1(pred_sup, gold_sup)
    srr = stale_rejection_rate(actions, [_is_stale(it) for it in items])
    oar = over_abstention_rate(actions, [_is_answerable(it) for it in items])

    update_records = []
    for it, pred in zip(items, predictions):
        if _is_update(it):
            old_gold = it.get("superseded_object") or ""
            new_gold = it.get("gold_answer", "")
            update_records.append({
                "old_correct": (old_gold != "" and token_f1(pred, old_gold) >= 0.4)
                                or token_f1(pred, new_gold) >= 0.4,
                "new_correct": token_f1(pred, new_gold) >= 0.4,
            })
    cur = counterfactual_update_robustness(update_records)

    ans_f1 = answer_f1(predictions, [[it["gold_answer"]] for it in items])
    confidences = [min(1.0, max(0.0, 1.0 - r.insufficient)) for r in risks]
    correctness = [bool(p >= 0.5) for p in per_item]
    lce = lifecycle_calibration_error(confidences, correctness, bins=10)
    su = safe_utility(life_em_val, temp_f1, sup_f1, srr, cur, oar, lce)

    out = {
        "AnsF1": round(ans_f1, 4),
        "LifeEM": round(life_em_val, 4),
        "Temp-Evi-F1": round(temp_f1, 4),
        "Sup-F1": round(sup_f1, 4),
        "SRR": round(srr, 4),
        "OAR": round(oar, 4),
        "CUR": round(cur, 4),
        "LCE": round(lce, 4),
        "SafeUtility": round(su, 4),
        "gen_seconds": round(gen_seconds, 1),
        "n": len(items),
    }
    (RESULTS / "qlora_eval.json").write_text(json.dumps(out, indent=2))
    sys.stderr.write(f"[saved] {RESULTS}/qlora_eval.json: {out}\n")


if __name__ == "__main__":
    main()
