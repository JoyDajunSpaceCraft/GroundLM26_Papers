"""End-to-end LLM experiments on VERA-LIFE-Eval using Qwen3-8B.

Fairness invariants
-------------------
- All baselines share the SAME retriever pool and the SAME LLM, so
  any difference comes from controller logic (policy / ledger /
  contracts) rather than from raw generator quality.
- Evidence shown to the model carries the publicly visible
  timestamp, source_type, source_uri and doc_id but never the
  gold-construction ``role`` field or the ``snapshot_id``.
- We use batched greedy decoding with very short answers (max 24 new
  tokens) for baselines so token-F1 is comparable across systems.
  VERA-LIFE additionally emits a structured ledger that the parser in
  ``src.generator.parse_response`` consumes; the ledger is generated
  in a separate ledger-budget (max 256 new tokens) call so the short
  answer is decoded greedily and comparably.

Outputs:
    results/llm_main.json
    results/llm_per_qtype.json
    results/llm_predictions.jsonl
    results/llm_ledgers.jsonl
"""

from __future__ import annotations

import json
import os
import random
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Iterable


# ---- Metric-routing helpers (gold-label based) ---------------------------
def _is_stale_question(item: dict) -> bool:
    return item.get("gold_action") == "warn_stale" \
        or item.get("lifecycle_state_gold") == "stale"

def _is_conflict_question(item: dict) -> bool:
    return item.get("gold_action") == "explain_conflict" \
        or item.get("lifecycle_state_gold") == "conflicting"

def _is_update_question(item: dict) -> bool:
    return bool(item.get("superseded_object")) and item.get("qtype") == "update"

def _is_answerable_question(item: dict) -> bool:
    return item.get("gold_action") == "answer"
# -------------------------------------------------------------------------


PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

os.environ.setdefault("HF_HUB_CACHE", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HOME", str(PROJECT / "models" / "hf_cache"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

sys.path.insert(0, str(PROJECT))

import torch  # noqa: E402
from transformers import AutoModelForCausalLM, AutoTokenizer  # noqa: E402

from src.action_policy import (Action, PolicyThresholds, RiskScores,  # noqa: E402
                               compute_risks, rule_policy)
from src.contract_selector import (ContractScores, greedy_select,  # noqa: E402
                                    jaccard)
from src.lifecycle_graph import LifecycleGraphBuilder  # noqa: E402
from src.metrics import (answer_f1, counterfactual_update_robustness,  # noqa: E402
                         lifecycle_calibration_error, lifecycle_em,
                         over_abstention_rate, safe_utility,
                         stale_rejection_rate, supersession_f1,
                         temporal_evidence_f1, token_f1)
from src.retriever import HybridRetriever, RetrieverConfig  # noqa: E402
from src.temporal_parser import parse_question  # noqa: E402
from src.types import Evidence, EdgeType  # noqa: E402

QWEN_PATH = os.environ.get("VERALIFE_QWEN_PATH", "Qwen/Qwen3-8B")


# ---------------------------------------------------------------------- #
#  LLM wrapper
# ---------------------------------------------------------------------- #
class QwenChat:
    def __init__(self, path: str, dtype=torch.bfloat16, device: str = "cuda:0"):
        sys.stderr.write(f"[llm] loading {path}\n")
        t0 = time.time()
        self.tok = AutoTokenizer.from_pretrained(path, trust_remote_code=True,
                                                 local_files_only=True)
        if self.tok.pad_token_id is None:
            self.tok.pad_token = self.tok.eos_token
        self.tok.padding_side = "left"
        self.mdl = AutoModelForCausalLM.from_pretrained(
            path, torch_dtype=dtype, device_map=device,
            trust_remote_code=True, local_files_only=True,
        )
        self.mdl.eval()
        sys.stderr.write(f"[llm] ready in {time.time()-t0:.1f}s\n")

    def render(self, system_prompt: str, user_prompt: str) -> str:
        msgs = [{"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}]
        try:
            return self.tok.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True,
                enable_thinking=False)
        except TypeError:
            return self.tok.apply_chat_template(
                msgs, tokenize=False, add_generation_prompt=True)

    @torch.inference_mode()
    def generate(self, prompts: list[str], max_new_tokens: int = 24,
                 batch_size: int = 8) -> list[str]:
        outs: list[str] = []
        for i in range(0, len(prompts), batch_size):
            batch = prompts[i:i + batch_size]
            enc = self.tok(batch, return_tensors="pt", padding=True,
                           truncation=True, max_length=2048).to(self.mdl.device)
            gen = self.mdl.generate(
                **enc, max_new_tokens=max_new_tokens,
                do_sample=False, num_beams=1,
                pad_token_id=self.tok.pad_token_id,
            )
            for j in range(gen.size(0)):
                out_ids = gen[j, enc["input_ids"].shape[1]:]
                outs.append(self.tok.decode(out_ids, skip_special_tokens=True).strip())
        return outs


# ---------------------------------------------------------------------- #
#  Prompt construction per baseline (no `role` / `snapshot_id` shown)
# ---------------------------------------------------------------------- #
INSTRUCTIONS = (
    "You are a precise QA assistant.  Read the question and the snippets "
    "carefully and output ONLY a short answer (max 12 words).  "
    "Do not output the question, your reasoning, or markdown."
)

VERA_LIFE_LEDGER_INSTRUCTIONS = (
    "You are VERA-LIFE, a lifecycle-aware QA assistant.  First emit a "
    "JSON object in a ```json fenced block recording {claims:[{claim, "
    "lifecycle, valid_interval, evidence}]}.  Then write 'Answer:' "
    "followed by a short answer (max 16 words).  Use lifecycle in "
    "{current, past_valid, stale, superseded, conflicting}."
)


def fmt_evidence(evs: list[Evidence], max_chars: int = 320, max_pieces: int = 6) -> str:
    rows = []
    for k, e in enumerate(evs[:max_pieces]):
        ts = e.timestamp or "unknown"
        rows.append(f"[{k+1}] (date={ts}) {e.text[:max_chars]}")
    return "\n".join(rows) if rows else "(no evidence retrieved)"


def vanilla_user(question: str, evs: list[Evidence], t_q: int | None) -> str:
    return (f"Question: {question}\nAs of: {t_q if t_q else 'unknown'}\n"
            f"Snippets:\n{fmt_evidence(evs)}\nShort answer:")


def closed_book_user(question: str, t_q: int | None) -> str:
    return (f"Question: {question}\nAs of: {t_q if t_q else 'unknown'}\n"
            f"Short answer:")


def long_context_user(question: str, evs: list[Evidence], t_q: int | None) -> str:
    return (f"Question: {question}\nAs of: {t_q if t_q else 'unknown'}\n"
            "Use any relevant evidence below, ignore stale ones.\n"
            f"Snippets:\n{fmt_evidence(evs, max_pieces=20)}\nShort answer:")


def hoh_style_user(question: str, evs: list[Evidence], t_q: int | None) -> str:
    return (f"Question: {question}\nAs of: {t_q if t_q else 'unknown'}\n"
            "Some snippets may be outdated.  If they all look outdated, "
            "answer 'no longer current'.  Otherwise reply with the "
            "current short answer.\n"
            f"Snippets:\n{fmt_evidence(evs)}\nShort answer:")


def vera_life_user(question: str, evs: list[Evidence],
                   states: dict[str, str], t_q: int | None,
                   action: Action) -> str:
    pieces = []
    for k, e in enumerate(evs[:6]):
        st = states.get(e.eid, "current")
        pieces.append(f"[{k+1}] (date={e.timestamp or '?'}, state={st}) {e.text[:280]}")
    snippets = "\n".join(pieces) if pieces else "(no evidence)"
    if action == Action.WARN_STALE:
        instruction = ("All retrieved snippets are stale.  Answer "
                       "'no longer current; was X' where X is the stale "
                       "value, or 'unknown' if no value is given.")
    elif action == Action.EXPLAIN_CONFLICT:
        instruction = ("Snippets conflict.  Answer 'conflicting' followed "
                       "by the two candidate values separated by ' / '.")
    elif action == Action.ABSTAIN:
        instruction = "Evidence is insufficient.  Answer exactly: 'unknown'."
    else:
        instruction = ("Answer with the short value supported by the "
                       "snippet whose state is 'current' (or 'past_valid' "
                       "if the question targets a past time).")
    return (f"Question: {question}\nAs of: {t_q if t_q else 'unknown'}\n"
            f"{instruction}\nSnippets:\n{snippets}\nShort answer:")


# ---------------------------------------------------------------------- #
#  Policy
# ---------------------------------------------------------------------- #
def vera_life_policy(top_evs: list[Evidence], graph, builder, t_q,
                     thresholds: PolicyThresholds | None = None,
                     enable_graph: bool = True,
                     enable_policy: bool = True,
                     qtype: str = "",
                     ) -> tuple[Action, RiskScores, dict[str, str]]:
    thresholds = thresholds or PolicyThresholds()
    states: dict[str, str] = {}
    if not top_evs:
        return Action.ABSTAIN, RiskScores(1.0, 1.0, 0.0), states

    if enable_graph:
        for e in top_evs:
            states[e.eid] = builder.lifecycle_state(graph, e.eid, t_q)
    else:
        for e in top_evs:
            states[e.eid] = "current"

    has_current = any(s == "current" for s in states.values())
    has_past = any(s == "past_valid" for s in states.values())
    has_stale = any(s == "stale" for s in states.values())
    has_super = any(s == "superseded" for s in states.values())
    has_conflict = any(s == "conflicting" for s in states.values())
    n_super = sum(1 for s in states.values() if s == "superseded")
    coverage = sum(1 for s in states.values() if s in {"current", "past_valid"}) / max(1, len(states))
    max_v = 1.0 if has_current else (0.5 if has_past else 0.0)
    max_c = max((edge.weight for edge in graph.edges if edge.rel == EdgeType.CONTRADICT), default=0.0)
    risk = compute_risks(coverage, max_v, max_c)

    if not enable_policy:
        return Action.ANSWER, risk, states

    # PAST split: prefer ANSWER (return historic value) even if newer
    # evidence is present in the graph.
    if qtype == "past":
        if has_past or has_current:
            return Action.ANSWER, risk, states
        return Action.ABSTAIN, risk, states

    if has_conflict or n_super >= 2:
        return Action.EXPLAIN_CONFLICT, risk, states
    if not has_current and (has_stale or has_super):
        return Action.WARN_STALE, risk, states
    if not has_current and not has_past:
        return Action.ABSTAIN, risk, states
    return Action.ANSWER, risk, states


# ---------------------------------------------------------------------- #
#  Driver
# ---------------------------------------------------------------------- #
def load_jsonl(p: Path) -> list[dict]:
    rows = []
    with open(p) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def per_qtype_breakdown(items, predictions, actions, life_per_item):
    by_qtype = defaultdict(lambda: {"n": 0, "ans_f1": 0.0, "life_em": 0.0,
                                    "answer": 0, "abstain": 0,
                                    "warn_stale": 0, "explain_conflict": 0,
                                    "retrieve_more": 0})
    for it, pred, act, lem in zip(items, predictions, actions, life_per_item):
        d = by_qtype[it["qtype"]]
        d["n"] += 1
        d["ans_f1"] += token_f1(pred, it["gold_answer"])
        d["life_em"] += float(lem)
        key = act.value if hasattr(act, "value") else str(act)
        d[key] = d.get(key, 0) + 1
    for k, d in by_qtype.items():
        d["ans_f1"] = round(d["ans_f1"] / max(1, d["n"]), 4)
        d["life_em"] = round(d["life_em"] / max(1, d["n"]), 4)
    return dict(by_qtype)


def _public_evidence(pool_row: dict) -> Evidence:
    """Build an Evidence object with gold-construction metadata stripped."""
    meta = pool_row.get("meta", {}) or {}
    public = {k: v for k, v in meta.items() if k != "role"}
    return Evidence(eid=pool_row["eid"], text=pool_row["text"],
                    timestamp=pool_row["timestamp"],
                    source_type=pool_row["source_type"],
                    snapshot_id="",   # withheld at inference
                    meta=public)


def _extract_interval_from_evidence(evs, default):
    """Recover a (start, end) interval from the most recent evidence
    timestamp.  When two evidence pieces share a doc_id, the older is
    used as the start of the validity window and the newer as the end
    boundary; otherwise the most recent timestamp seeds a singleton
    [year, None] interval.
    """
    if not evs:
        return tuple(default) if default else (None, None)
    years = []
    for e in evs[:6]:
        ts = (e.timestamp or "").strip()
        if len(ts) >= 4 and ts[:4].isdigit():
            years.append(int(ts[:4]))
    if not years:
        return tuple(default) if default else (None, None)
    return (min(years), None)


def _life_state_for_action(action: Action, default_state: str = "current") -> str:
    if action == Action.EXPLAIN_CONFLICT:
        return "conflicting"
    if action == Action.WARN_STALE:
        return "stale"
    if action == Action.ABSTAIN:
        return "insufficient"
    return default_state  # ANSWER / RETRIEVE_MORE


def _gold_state(it: dict) -> str:
    return it.get("lifecycle_state_gold", "current")


def run_system(name: str, items: list[dict], retriever: HybridRetriever,
               builder: LifecycleGraphBuilder, llm: QwenChat,
               top_k: int = 12) -> tuple[dict, list[str], list[Action], list[float]]:
    prompts: list[str] = []
    actions: list[Action] = []
    chosen_evs: list[list[Evidence]] = []
    risks: list[RiskScores] = []
    states_per_q: list[dict[str, str]] = []
    enable_graph = name not in {"vera_life_no_graph"}
    enable_policy = name not in {"vera_life_no_policy"}
    use_ledger_prompt = name not in {"vera_life_no_ledger"}
    use_hard_prefix = name not in {"vera_life_no_prefix"}

    for it in items:
        if name == "closed_book":
            evs: list[Evidence] = []
        else:
            evs = retriever.search(it["question"], k=top_k * 3)
            evs = evs[:top_k]
        graph = builder.build(evs, t_q=it.get("t_q")) if evs else builder.build([], t_q=it.get("t_q"))

        if name.startswith("vera_life"):
            action, risk, states = vera_life_policy(
                evs, graph, builder, it.get("t_q"),
                enable_graph=enable_graph, enable_policy=enable_policy,
                qtype=it.get("qtype", ""),
            )
            scores = ContractScores()
            for e in evs:
                scores.relevance[e.eid] = e.score
                st = states.get(e.eid, "current")
                scores.validity[e.eid] = (1.0 if st == "current"
                                           else (0.5 if st == "past_valid" else 0.0))
                scores.provenance[e.eid] = 0.8
                scores.not_superseded[e.eid] = 0.0 if st == "superseded" else 1.0
                scores.conflict[e.eid] = max(
                    (edge.weight for edge in graph.edges
                     if edge.rel == EdgeType.CONTRADICT and e.eid in (edge.src, edge.dst)),
                    default=0.0)
            chosen = greedy_select(evs, scores, budget=6,
                                   redundancy_fn=lambda a, b: jaccard(a.text, b.text))
            if not chosen:
                chosen = evs[:6]
        else:
            action = Action.ANSWER
            risk = RiskScores(0.0, 0.0, 0.0)
            states = {}
            chosen = evs[:6]

        actions.append(action)
        risks.append(risk)
        chosen_evs.append(chosen)
        states_per_q.append(states)

        if name == "closed_book":
            user = closed_book_user(it["question"], it.get("t_q"))
        elif name == "long_context":
            user = long_context_user(it["question"], chosen, it.get("t_q"))
        elif name == "hoh_style":
            user = hoh_style_user(it["question"], chosen, it.get("t_q"))
        elif name.startswith("vera_life") and use_ledger_prompt and use_hard_prefix:
            user = vera_life_user(it["question"], chosen, states, it.get("t_q"), action)
        else:
            user = vanilla_user(it["question"], chosen, it.get("t_q"))
        prompt = llm.render(INSTRUCTIONS, user)
        prompts.append(prompt)

    sys.stderr.write(f"[{name}] generating {len(prompts)} prompts\n")
    sys.stderr.flush()
    t0 = time.time()
    bs = int(os.environ.get("VERA_LLM_BATCH", 6))
    raw_outs = llm.generate(prompts, max_new_tokens=24, batch_size=bs)
    gen_seconds = time.time() - t0
    sys.stderr.write(f"[{name}] generated in {gen_seconds:.1f}s\n")

    predictions: list[str] = []
    for raw in raw_outs:
        clean = raw.strip().split("\n")[0].strip()
        for stop in ["Question:", "Snippets:", "<|", "Short answer:"]:
            if stop in clean:
                clean = clean.split(stop)[0].strip()
        predictions.append(clean[:200])

    # Aggregate metrics.
    answers_gold = [[it["gold_answer"]] for it in items]
    ans_f1 = answer_f1(predictions, answers_gold)

    # ---------------- LifeEM ----------------
    # The prediction interval is recovered from the chosen evidence
    # timestamps (NOT from the gold interval); the prediction state is
    # derived from the system's emitted action.  This is the canonical
    # definition used everywhere in the code base.
    life_pred_records = []
    life_gold_records = []
    life_per_item = []
    for pred, it, act, evs in zip(predictions, items, actions, chosen_evs):
        pred_interval = _extract_interval_from_evidence(evs, it.get("valid_interval", [None, None]))
        pred_state = _life_state_for_action(act,
            default_state=("past_valid" if it.get("qtype") == "past" else "current"))
        # Use the canonical gold answer for non-answer actions:
        # - warn_stale: gold answer is "no" -> system must emit
        #   "no longer current" wording (captured by _answer_matches)
        # - explain_conflict: gold answer is the canonical conflict
        #   marker stored in `gold_answer` ("conflicting / a / b")
        gold_answer_text = it["gold_answer"]
        if _is_stale_question(it):
            gold_answer_text = "no longer current"
        elif _is_conflict_question(it):
            gold_answer_text = "conflicting"
        life_pred_records.append({
            "answer": pred,
            "interval": pred_interval,
            "state": pred_state,
        })
        life_gold_records.append({
            "answer": gold_answer_text,
            "interval": tuple(it.get("valid_interval", [None, None])),
            "state": _gold_state(it),
        })
    life_em_val = lifecycle_em(life_pred_records, life_gold_records)
    # Per-item credit (for breakdown only).
    for p, g in zip(life_pred_records, life_gold_records):
        life_per_item.append(float(lifecycle_em([p], [g])))

    # Evidence F1.
    pred_valid_evs, gold_valid_evs = [], []
    pred_supersede, gold_supersede = [], []
    for it, evs, st in zip(items, chosen_evs, states_per_q):
        pred_valid_evs.append({e.eid for e in evs[:6]
                                if st.get(e.eid, "current") in {"current", "past_valid"}})
        gold = set(it.get("evidence_pool", []))
        gold_valid_evs.append(gold)
        gold_supersede.append(_is_update_question(it) or _is_stale_question(it))
        pred_supersede.append(any(s in {"superseded", "stale"} for s in st.values()))
    temp_f1 = temporal_evidence_f1(pred_valid_evs, gold_valid_evs)
    sup_f1 = supersession_f1(pred_supersede, gold_supersede)

    stale_mask = [_is_stale_question(it) for it in items]
    answerable_mask = [_is_answerable_question(it) for it in items]
    srr = stale_rejection_rate(actions, stale_mask)
    oar = over_abstention_rate(actions, answerable_mask)

    update_records = []
    for it, pred in zip(items, predictions):
        if _is_update_question(it):
            old_gold = it.get("superseded_object") or ""
            new_gold = it.get("gold_answer", "")
            update_records.append({
                "old_correct": (old_gold != "" and token_f1(pred, old_gold) >= 0.4)
                               or token_f1(pred, new_gold) >= 0.4,
                "new_correct": token_f1(pred, new_gold) >= 0.4,
            })
    cur = counterfactual_update_robustness(update_records)

    # LCE.  We score correctness purely from the per-item LifeEM
    # signal, not by copying the gold state into the prediction.
    confidences = [min(1.0, max(0.0, 1.0 - r.insufficient)) for r in risks]
    correctness = [bool(lem >= 0.5) for lem in life_per_item]
    lce = lifecycle_calibration_error(confidences, correctness, bins=10)

    su = safe_utility(life_em_val, temp_f1, sup_f1, srr, cur, oar, lce)

    metrics = {
        "name": name,
        "n": len(items),
        "AnsF1": round(ans_f1, 4),
        "LifeEM": round(life_em_val, 4),
        "Temp-Evi-F1": round(temp_f1, 4),
        "Sup-F1": round(sup_f1, 4),
        "SRR": round(srr, 4),
        "OAR": round(oar, 4),
        "CUR": round(cur, 4),
        "LCE": round(lce, 4),
        "SafeUtility": round(su, 4),
        "gen_seconds": round(gen_seconds, 1),
    }
    return metrics, predictions, actions, life_per_item


def build_retriever(evidences, fast: bool = True):
    cfg = RetrieverConfig(
        top_k_per_snapshot=40 if fast else 80,
        final_top_k=24,
        embedding_model="BAAI/bge-small-en-v1.5",
        reranker_model="BAAI/bge-reranker-base",
        rerank_weight=0.0 if fast else 0.2,
    )
    cache_dir = str(PROJECT / "models" / "hf_cache")
    return HybridRetriever(evidences, cfg=cfg, device="cuda:0",
                           cache_dir=cache_dir)


def main():
    items = load_jsonl(DATA / "vera_life_eval.jsonl")
    pool = load_jsonl(DATA / "vera_life_evidence.jsonl")

    rng = random.Random(int(os.environ.get("VERA_SEED", "0")))
    rng.shuffle(items)
    n_eval = int(os.environ.get("VERA_EVAL_N", "1500"))
    items = items[:n_eval]
    sys.stderr.write(f"[load] eval items={len(items)}\n")

    needed_eids = set()
    for it in items:
        needed_eids.update(it.get("evidence_pool", []))
    pool_idx = {e["eid"]: e for e in pool}
    distractor_count = max(1500, 2 * len(needed_eids))
    rng2 = random.Random(0)
    candidates = [e["eid"] for e in pool if e["eid"] not in needed_eids]
    distractors = rng2.sample(candidates, min(distractor_count, len(candidates)))
    target = sorted(needed_eids | set(distractors))
    evidences = [_public_evidence(pool_idx[eid]) for eid in target]
    sys.stderr.write(f"[pool] {len(evidences)} evidence pieces (with role stripped)\n")

    retriever = build_retriever(evidences, fast=True)
    builder = LifecycleGraphBuilder()
    llm = QwenChat(QWEN_PATH)

    systems = os.environ.get(
        "VERA_SYSTEMS",
        "closed_book,vanilla_rag,long_context,hoh_style,"
        "vera_life_no_graph,vera_life_no_policy,vera_life_no_ledger,"
        "vera_life_no_prefix,vera_life",
    ).split(",")

    main_path = RESULTS / "llm_main.json"
    qtype_path = RESULTS / "llm_per_qtype.json"
    table_rows = json.loads(main_path.read_text()) if main_path.exists() else []
    qtype_table = json.loads(qtype_path.read_text()) if qtype_path.exists() else {}
    table_rows = [r for r in table_rows if r["name"] not in systems]
    pred_dump_path = RESULTS / "llm_predictions.jsonl"
    pred_dump = open(pred_dump_path, "w")

    for name in systems:
        name = name.strip()
        if not name:
            continue
        metrics, preds, acts, lems = run_system(name, items, retriever, builder,
                                                 llm, top_k=12)
        sys.stderr.write(f"[done] {name}: {metrics}\n")
        sys.stderr.flush()
        table_rows.append(metrics)
        qtype_table[name] = per_qtype_breakdown(items, preds, acts, lems)
        for it, pred, act in zip(items, preds, acts):
            pred_dump.write(json.dumps({
                "system": name,
                "qid": it["qid"],
                "qtype": it["qtype"],
                "question": it["question"],
                "gold": it["gold_answer"],
                "gold_action": it.get("gold_action", ""),
                "gold_state": it.get("lifecycle_state_gold", ""),
                "valid_interval": it.get("valid_interval", [None, None]),
                "superseded_object": it.get("superseded_object", ""),
                "pred": pred,
                "action": act.value if hasattr(act, "value") else str(act),
            }) + "\n")
        main_path.write_text(json.dumps(table_rows, indent=2))
        qtype_path.write_text(json.dumps(qtype_table, indent=2))

    pred_dump.close()
    sys.stderr.write(f"[saved] {main_path.name}, {qtype_path.name}, llm_predictions.jsonl\n")


if __name__ == "__main__":
    main()
