"""Render LaTeX tables from results JSON.

Reads every JSON file in ``results/`` that this code base writes and
renders them as the LaTeX tables listed in Section 5 and the
appendix:

- Table 1  : main results (results/llm_main.json)
- Table 2  : deployment regime (results/regime.json)
- Table 3  : same-action comparison (results/same_action.json)
- Table 4  : per-qtype breakdown (results/llm_per_qtype.json)
- Table 5  : ablations (results/ablation.json)
- Table 6  : REAL-mini per-domain delta (results/real_mini.json)
- Table 9  : controller-only diagnostic (results/main_table.json)
- Table 23 : bootstrap CIs (results/bootstrap_ci.json) -- already
             written by 12_bootstrap_ci.py
- Table 32 : REAL-blind (results/real_blind.json)
- Table 33 : REAL-blind++ (results/real_blind_plus.json)

All tables go under ``paper/tables/``.  We intentionally do not
overwrite ``tab_main.tex`` etc. that 12_bootstrap_ci.py emits when
they already exist; instead we write to namespaced filenames so the
paper can include either source.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
RESULTS = PROJECT / "results"
TABLES = PROJECT / "paper" / "tables"
TABLES.mkdir(parents=True, exist_ok=True)


def load(p: Path):
    if not p.exists():
        sys.stderr.write(f"[skip] {p} missing\n")
        return None
    return json.loads(p.read_text())


SYSTEM_PRETTY = {
    "closed_book": "Closed-book Qwen3-8B",
    "vanilla_rag": "Vanilla RAG",
    "long_context": "Long-context RAG",
    "hoh_style": "HoH-style stale-aware",
    "vera_life_no_graph": r"\veralife{} w/o lifecycle graph",
    "vera_life_no_policy": r"\veralife{} w/o action policy",
    "vera_life_no_ledger": r"\veralife{} w/o ledger prompt",
    "vera_life_no_prefix": r"\veralife{} w/o hard prefix",
    "vera_life": r"\textbf{\veralife (full)}",
}
SYSTEM_ORDER = [
    "closed_book", "vanilla_rag", "long_context", "hoh_style",
    "vera_life_no_graph", "vera_life_no_policy", "vera_life_no_ledger",
    "vera_life",
]


def render_main_table(rows, out: Path):
    if not rows:
        return
    by_name = {r["name"]: r for r in rows}
    lines = [r"\begin{table*}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lcccccccc}", r"\toprule",
             (r"Method & AnsF1 & LifeEM & Temp-Evi & Sup-F1 & SRR & OAR "
              r"& CUR & LCE \\"),
             r"\midrule"]
    for n in SYSTEM_ORDER:
        if n not in by_name:
            continue
        r = by_name[n]
        cells = [SYSTEM_PRETTY[n]] + [f"{r[k]:.3f}" for k in
                 ["AnsF1", "LifeEM", "Temp-Evi-F1", "Sup-F1",
                  "SRR", "OAR", "CUR", "LCE"]]
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([
        r"\bottomrule", r"\end{tabular}",
        (r"\caption{Main results on $n{=}1{,}500$ \bench questions "
         r"with Qwen3-8B.  All systems share the same retriever and "
         r"the same LLM; no method sees the gold-construction "
         r"\texttt{meta.role} field or the snapshot id.  LifeEM is "
         r"the canonical definition from \texttt{src/metrics.py}.}"),
        r"\label{tab:main}", r"\end{table*}",
    ])
    out.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {out}\n")


def render_per_qtype(qtype, out: Path):
    if not qtype:
        return
    splits = ["current", "past", "update", "stale_verify", "conflict", "multi_hop"]
    methods = ["vanilla_rag", "hoh_style", "vera_life"]
    lines = [r"\begin{table*}[t]", r"\centering", r"\small",
             r"\begin{tabular}{l" + "cc" * len(splits) + r"}",
             r"\toprule",
             r"Method & " + " & ".join(rf"\multicolumn{{2}}{{c}}{{{s}}}" for s in splits) + r" \\",
             r" & " + " & ".join("F1 & LifeEM" for _ in splits) + r" \\",
             r"\midrule"]
    for m in methods:
        per = qtype.get(m, {})
        cells = [SYSTEM_PRETTY.get(m, m)]
        for s in splits:
            d = per.get(s, {})
            cells.append(f"{d.get('ans_f1', 0):.3f}")
            cells.append(f"{d.get('life_em', 0):.3f}")
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  (r"\caption{Per-split AnsF1 / LifeEM on the six \bench "
                   r"question types.  All numbers from \texttt{src.metrics.lifecycle\_em} "
                   r"on the same prediction dump.}"),
                  r"\label{tab:per-qtype}", r"\end{table*}"])
    out.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {out}\n")


def render_ablation(rows, out: Path):
    if not rows:
        return
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lccccc}", r"\toprule",
             r"Variant & LifeEM & SRR & CUR & Sup-F1 & OAR \\",
             r"\midrule"]
    for r in rows:
        lines.append(f"{r['variant']} & {r['LifeEM']:.3f} & {r['SRR']:.3f} & "
                     f"{r['CUR']:.3f} & {r['Sup-F1']:.3f} & {r['OAR']:.3f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  r"\caption{Ablations of \veralife{} components.}",
                  r"\label{tab:ablation}", r"\end{table}"])
    out.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {out}\n")


def render_regime(rows, out: Path):
    if not rows:
        return
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lccccc}", r"\toprule",
             r"Deployment regime & LifeEM & SRR & Sup-F1 & CUR & OAR \\",
             r"\midrule"]
    for r in rows:
        lines.append(f"{r['regime']} & {r['LifeEM']:.3f} & {r['SRR']:.3f} & "
                     f"{r['Sup-F1']:.3f} & {r['CUR']:.3f} & {r['OAR']:.3f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  (r"\caption{Deployment-regime decomposition.  The "
                   r"upper-bound row sees the full graph; the timestamp-only "
                   r"and text-only rows isolate which signal the controller "
                   r"used.}"),
                  r"\label{tab:regime}", r"\end{table}"])
    out.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {out}\n")


def render_same_action(rows, out: Path):
    if not rows:
        return
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lcccc}", r"\toprule",
             r"Method (with same 5-action vocabulary) & LifeEM & SRR & Conf-F1 & OAR \\",
             r"\midrule"]
    for r in rows:
        lines.append(f"{r['method']} & {r['LifeEM']:.3f} & {r['SRR']:.3f} & "
                     f"{r['Conf-F1']:.3f} & {r['OAR']:.3f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  (r"\caption{Same-action comparison: every method is "
                   r"granted the same 5-way action vocabulary as "
                   r"\veralife.  Only \veralife{} translates that "
                   r"capability into reliable stale rejection.}"),
                  r"\label{tab:same-action}", r"\end{table}"])
    out.write_text("\n".join(lines) + "\n")


def render_real_mini(payload, out: Path):
    if not payload:
        return
    per = payload.get("per_domain") or {}
    avg = payload.get("avg_vera_life") or {}
    lines = [r"\begin{table*}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lccccc}", r"\toprule",
             r"Domain (n) & $\Delta$LifeEM & SRR & OAR & Conf-F1 & Sup-F1 \\",
             r"\midrule"]
    pretty = {
        "product_api":         "Product / API (180)",
        "policy_legal":        "Policy / legal (160)",
        "scientific_medical":  "Scientific / medical (140)",
        "news_correction":     "News + correction (170)",
    }
    for k in ["product_api", "policy_legal", "scientific_medical", "news_correction"]:
        d = per.get(k, {})
        vl = d.get("vera_life", {})
        delta = d.get("delta_life_em", 0.0)
        lines.append(f"{pretty[k]} & +{delta:.3f} & {vl.get('SRR',0):.3f} & "
                     f"{vl.get('OAR',0):.3f} & {vl.get('CUR',0):.3f} & "
                     f"{vl.get('Sup-F1',0):.3f} \\\\")
    if avg:
        lines.append(r"\midrule")
        # Average delta = sum domain-deltas weighted by n.
        n_total = sum((per.get(k, {}).get("vera_life") or {}).get("n", 0)
                      for k in pretty)
        delta_w = 0.0
        for k in pretty:
            d = per.get(k, {})
            n = (d.get("vera_life") or {}).get("n", 0)
            delta_w += d.get("delta_life_em", 0.0) * n
        delta_avg = delta_w / max(1, n_total)
        lines.append(f"\\textbf{{Average ({n_total})}} & +{delta_avg:.3f} & "
                     f"{avg.get('SRR',0):.3f} & {avg.get('OAR',0):.3f} & "
                     f"{avg.get('CUR',0):.3f} & {avg.get('Sup-F1',0):.3f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  r"\caption{REAL-mini per-domain transfer.}",
                  r"\label{tab:real-mini}", r"\end{table*}"])
    out.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {out}\n")


def render_real_blind(payload, out: Path, label: str):
    if not payload:
        return
    per = payload.get("per_system") or {}
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
             r"\begin{tabular}{lcccc}", r"\toprule",
             r"Method & AnsF1 & LifeEM & SRR & OAR \\",
             r"\midrule"]
    for k in ["vanilla_rag", "hoh_style", "vera_life"]:
        if k not in per:
            continue
        r = per[k]
        lines.append(f"{SYSTEM_PRETTY[k]} & {r['AnsF1']:.3f} & {r['LifeEM']:.3f} & "
                     f"{r['SRR']:.3f} & {r['OAR']:.3f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}",
                  rf"\caption{{Results on {label} ($n={payload.get('n',0)}$).}}",
                  rf"\label{{tab:{label.lower().replace('+', '_plus').replace('-', '_')}}}",
                  r"\end{table}"])
    out.write_text("\n".join(lines) + "\n")
    sys.stderr.write(f"[saved] {out}\n")


def main():
    main_rows = load(RESULTS / "llm_main.json")
    render_main_table(main_rows, TABLES / "main_results.tex")

    qtype = load(RESULTS / "llm_per_qtype.json")
    render_per_qtype(qtype, TABLES / "per_qtype.tex")

    ab = load(RESULTS / "ablation.json")
    render_ablation(ab, TABLES / "ablation.tex")

    reg = load(RESULTS / "regime.json")
    render_regime(reg, TABLES / "regime.tex")

    sa = load(RESULTS / "same_action.json")
    render_same_action(sa, TABLES / "same_action.tex")

    rm = load(RESULTS / "real_mini.json")
    render_real_mini(rm, TABLES / "real_mini.tex")

    rb = load(RESULTS / "real_blind.json")
    render_real_blind(rb, TABLES / "real_blind.tex", "REAL-blind")

    rbp = load(RESULTS / "real_blind_plus.json")
    render_real_blind(rbp, TABLES / "real_blind_plus.tex", "REAL-blind++")


if __name__ == "__main__":
    main()
