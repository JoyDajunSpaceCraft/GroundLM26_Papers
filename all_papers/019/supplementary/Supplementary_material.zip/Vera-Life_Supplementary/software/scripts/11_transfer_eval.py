"""Transfer evaluation across multiple benchmarks.

Reads each benchmark file (FRAMES, HoH, REAL-mini, REAL-blind,
REAL-blind++) under ``data/`` and runs VERA-LIFE plus the published
HoH-style baseline on each.  All systems share the same retriever
and the same LLM; the *only* difference is the data they see.

REAL-mini       : 650 questions, four real-world domains
                  (product / API, policy / legal, scientific /
                  medical, news + correction).
REAL-blind      : 1,200 questions whose source URLs were withheld
                  from the authors during construction.
REAL-blind++    : 1,000 source-disjoint questions, none of whose
                  contributing pages appear in any other split.

Outputs:
    results/transfer.json
    results/real_mini.json
    results/real_blind.json
    results/real_blind_plus.json
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
RESULTS = PROJECT / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(PROJECT))

import importlib.util
spec = importlib.util.spec_from_file_location(
    "exp08", PROJECT / "scripts" / "08_run_llm_experiments.py")
exp08 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exp08)


BENCHMARK_FILES = {
    "frames_subset":    DATA / "frames_subset.jsonl",     # optional
    "hoh_subset":       DATA / "hoh_subset.jsonl",        # optional
    "vera_life_eval":   DATA / "vera_life_eval.jsonl",
    "real_mini":        DATA / "real_mini.jsonl",
    "real_blind":       DATA / "real_blind.jsonl",
    "real_blind_plus":  DATA / "real_blind_plus.jsonl",
}


def load_split(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open() as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def evaluate_split(items, evidence_pool, *, systems, top_k):
    """Wrap exp08.run_system on a slice of items and a custom pool."""
    if not items:
        return {}
    # Build a public-evidence list for the retriever; we use only the
    # evidence pieces that appear in the (per-item) evidence_pool field
    # plus a small distractor budget drawn from the same file.
    needed_eids = set()
    pool_idx = {e["eid"]: e for e in evidence_pool}
    for it in items:
        needed_eids.update(it.get("evidence_pool", []))
    candidates = [e["eid"] for e in evidence_pool if e["eid"] not in needed_eids]
    import random
    rng = random.Random(0)
    extras = rng.sample(candidates, min(len(candidates), max(800, 2 * len(needed_eids))))
    target = sorted(needed_eids | set(extras))
    from src.types import Evidence
    evidences = []
    for eid in target:
        e = pool_idx.get(eid)
        if not e:
            continue
        meta = {k: v for k, v in (e.get("meta") or {}).items() if k != "role"}
        evidences.append(Evidence(eid=eid, text=e["text"],
                                  timestamp=e["timestamp"],
                                  source_type=e["source_type"],
                                  snapshot_id="",
                                  meta=meta))
    retriever = exp08.build_retriever(evidences, fast=True)
    from src.lifecycle_graph import LifecycleGraphBuilder
    builder = LifecycleGraphBuilder()
    llm = exp08.QwenChat(exp08.QWEN_PATH)
    out = {}
    for name in systems:
        m, _preds, _acts, _lems = exp08.run_system(
            name, items, retriever, builder, llm, top_k=top_k)
        out[name] = m
        sys.stderr.write(f"  {name}: {m}\n")
    return out


def main():
    full_pool = load_split(DATA / "vera_life_evidence.jsonl")
    real_pools = {
        "real_mini":       load_split(DATA / "real_mini_evidence.jsonl"),
        "real_blind":      load_split(DATA / "real_blind_evidence.jsonl"),
        "real_blind_plus": load_split(DATA / "real_blind_plus_evidence.jsonl"),
    }

    systems = os.environ.get("VERA_SYSTEMS", "hoh_style,vera_life").split(",")

    all_results = {}
    for name, path in BENCHMARK_FILES.items():
        items = load_split(path)
        if not items:
            sys.stderr.write(f"[skip] {name}: file not found\n")
            continue
        sys.stderr.write(f"\n== {name}: {len(items)} items ==\n")
        pool = real_pools.get(name, full_pool)
        all_results[name] = evaluate_split(items, pool, systems=systems, top_k=12)
        out_path = RESULTS / f"{name}.json"
        out_path.write_text(json.dumps(all_results[name], indent=2))
        sys.stderr.write(f"[saved] {out_path}\n")

    (RESULTS / "transfer.json").write_text(json.dumps(all_results, indent=2))
    sys.stderr.write(f"[saved] {RESULTS}/transfer.json\n")


if __name__ == "__main__":
    main()
