"""Generate publication-quality figures (Fig3/4/5) for VERA-LIFE.

Outputs vector PDFs into software/paper/figures/:
  - figure3.pdf : end-to-end / weakened metadata / same-action (3 panels)
  - figure4.pdf : per-split dumbbell + component ablations (2 panels)
  - figure5.pdf : REAL-mini domain gains + safety trade-off + REAL-blind stress

Numbers are the values reported in paper/tables/*.tex.  Do not invent new scores.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

OUT = Path(__file__).resolve().parents[1] / "paper" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Canonical numbers (must match paper/tables/*.tex)
# ---------------------------------------------------------------------------
E2E_LABELS = ["Closed-\nbook", "Vanilla", "Long-\nctx", "HoH", "VERA-\nLIFE"]
E2E_VALS = [0.071, 0.217, 0.217, 0.374, 0.623]

META_X = [0, 1, 2]
META_Y = [0.623, 0.584, 0.504]
META_HOH = 0.391          # tab:metadata-stress "HoH + same metadata"
META_ROLE = 0.318         # tab:metadata-stress "Role-only trivial"

SAME_LABELS = ["Vanilla", "HoH", "Self-\nreflect", "ReAct", "VERA-\nLIFE"]
SAME_VALS = [0.312, 0.428, 0.451, 0.437, 0.623]

SPLITS = ["Current", "Past", "Update", "Stale-only", "Conflict", "Multi-hop"]
SPLIT_VANILLA = [0.312, 0.152, 0.218, 0.000, 0.087, 0.142]
SPLIT_BEST = [0.398, 0.131, 0.387, 0.412, 0.198, 0.108]
SPLIT_VERA = [0.721, 0.328, 0.695, 0.987, 0.512, 0.378]

ABL_LABELS = [
    "VERA-LIFE\n(full)",
    "w/o lifecycle\ngraph",
    "w/o action\npolicy",
    "w/o ledger\nprompt",
    "w/o hard\nprefix",
]
ABL_VALS = [0.623, 0.317, 0.346, 0.499, 0.574]
ABL_DROPS = [None, -0.306, -0.277, -0.124, -0.049]

REAL_DOMAINS = ["News corr.", "Product/API", "Policy/legal", "Sci./med."]
REAL_GAINS = [0.173, 0.162, 0.148, 0.121]
REAL_NS = [170, 180, 160, 140]
REAL_AVG = 0.152

# (SRR, OAR) from tab:real-mini, not rounded approximations
SAFETY = {
    "Sci/med": (0.762, 0.112, "^"),
    "Legal":   (0.793, 0.098, "s"),
    "API":     (0.820, 0.078, "o"),
    "News":    (0.841, 0.068, "D"),
}
SAFETY_AVG = (0.806, 0.088)

BLIND_LABELS = ["REAL-blind\nfull", "Timestamp\nonly", "Marker\nremoved", "Text\nonly"]
BLIND_GAINS = [0.128, 0.109, 0.112, 0.068]

# ---------------------------------------------------------------------------
# Style
# ---------------------------------------------------------------------------
C_VERA = "#1a1a1a"
C_BEST = "#7d7d7d"
C_OTHER = "#c8c8c8"
C_REF = "#c0392b"
C_HILITE = "#f6ece8"
C_INK = "#1a1a1a"
C_MUTED = "#555555"

plt.rcParams.update({
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "font.family": "serif",
    "font.serif": ["Liberation Serif", "Nimbus Roman", "Times"],
    "mathtext.fontset": "stix",
    "font.size": 8.0,
    "axes.titlesize": 8.6,
    "axes.labelsize": 8.0,
    "xtick.labelsize": 7.1,
    "ytick.labelsize": 7.1,
    "legend.fontsize": 7.2,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.6,
    "axes.edgecolor": C_INK,
    "xtick.major.width": 0.5,
    "ytick.major.width": 0.5,
    "xtick.color": C_INK,
    "ytick.color": C_INK,
    "text.color": C_INK,
    "grid.linewidth": 0.35,
    "grid.alpha": 0.38,
    "grid.color": "#b4b4b4",
    "hatch.linewidth": 0.35,
})


def dot(x: float, prec: int = 3) -> str:
    """Leading-dot format used in the paper tables (.623, not 0.623)."""
    s = f"{x:.{prec}f}"
    if s.startswith("-0."):
        return "-" + s[2:]
    if s.startswith("0."):
        return s[1:]
    return s


def signed(x: float, prec: int = 3) -> str:
    return f"{x:+.{prec}f}".replace("+0.", "+.").replace("-0.", "-.")


def style_ax(ax, ygrid=True, xgrid=False):
    ax.set_axisbelow(True)
    if ygrid:
        ax.grid(axis="y", linestyle=":", alpha=0.45)
    if xgrid:
        ax.grid(axis="x", linestyle=":", alpha=0.45)
    ax.tick_params(length=2.4, pad=1.6)


def bar_labels(ax, bars, vals, dy=0.014, fs=7.0, fmt=None):
    fmt = fmt or (lambda v: dot(v))
    for b, v in zip(bars, vals):
        ax.text(
            b.get_x() + b.get_width() / 2.0,
            v + dy,
            fmt(v),
            ha="center",
            va="bottom",
            fontsize=fs,
        )


def gain_bracket(ax, x0, x1, y, text, dy=0.018):
    ax.plot([x0, x1], [y, y], color=C_REF, linewidth=0.75, clip_on=False)
    ax.plot([x0, x0], [y - dy, y], color=C_REF, linewidth=0.75, clip_on=False)
    ax.plot([x1, x1], [y - dy, y], color=C_REF, linewidth=0.75, clip_on=False)
    ax.text(0.5 * (x0 + x1), y + 0.012, text, color=C_REF,
            fontsize=7.6, fontweight="bold", ha="center", va="bottom")


def legend_patches():
    return [
        mpatches.Patch(facecolor=C_VERA, edgecolor="black", linewidth=0.5,
                       label="VERA-LIFE"),
        mpatches.Patch(facecolor=C_BEST, edgecolor="black", linewidth=0.5,
                       hatch="////", label="best baseline"),
        mpatches.Patch(facecolor=C_OTHER, edgecolor="black", linewidth=0.5,
                       label="other baselines"),
    ]


# ---------------------------------------------------------------------------
# Figure 3
# ---------------------------------------------------------------------------
def make_fig3():
    fig = plt.figure(figsize=(7.12, 2.48))
    gs = fig.add_gridspec(
        1, 3, width_ratios=[1.02, 0.88, 1.18], wspace=0.42,
        left=0.055, right=0.995, bottom=0.28, top=0.76,
    )

    # (A)
    ax = fig.add_subplot(gs[0, 0])
    colors = [C_OTHER, C_OTHER, C_OTHER, C_BEST, C_VERA]
    hatches = [None, None, None, "////", None]
    bars = ax.bar(range(5), E2E_VALS, color=colors, edgecolor="black",
                  linewidth=0.5, width=0.68, zorder=3)
    for b, h in zip(bars, hatches):
        if h:
            b.set_hatch(h)
    for i, (b, v) in enumerate(zip(bars, E2E_VALS)):
        xc = b.get_x() + b.get_width() / 2.0
        # Vanilla and long-ctx share .217; nudge labels apart.
        if i == 1:
            xc -= 0.20
        elif i == 2:
            xc += 0.20
        ax.text(xc, v + 0.014, dot(v), ha="center", va="bottom", fontsize=6.8)
    ax.set_xticks(range(5))
    ax.set_xticklabels(E2E_LABELS, fontsize=6.6)
    ax.set_ylabel("LifeEM")
    ax.set_ylim(0, 0.86)
    ax.set_title("(A) End-to-end generation", pad=3)
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax)
    gain_bracket(ax, 3, 4, 0.755, signed(0.249))

    # (B)
    ax = fig.add_subplot(gs[0, 1])
    ax.plot(META_X, META_Y, "-o", color=C_VERA, linewidth=1.25, markersize=4.8,
            markerfacecolor=C_VERA, markeredgecolor=C_VERA, zorder=3)
    offsets = [(0, 7), (0, 7), (0, 7)]
    for (xi, yi), off in zip(zip(META_X, META_Y), offsets):
        ax.annotate(
            dot(yi), xy=(xi, yi), xytext=off, textcoords="offset points",
            ha="center", fontsize=7.0,
        )
    ax.axhline(META_HOH, color=C_BEST, linestyle="--", linewidth=0.7, zorder=1)
    ax.text(2.02, META_HOH - 0.028, "HoH + same metadata",
            color=C_MUTED, fontsize=6.4, ha="right", va="top")
    ax.axhline(META_ROLE, color=C_OTHER, linestyle=":", linewidth=0.8, zorder=1)
    ax.text(2.02, META_ROLE - 0.028, "role-only trivial",
            color="#777777", fontsize=6.4, ha="right", va="top")
    ax.set_xticks(META_X)
    ax.set_xticklabels(["Full", "TS-only", "Text-only"])
    ax.set_ylabel("LifeEM")
    ax.set_ylim(0.0, 0.86)
    ax.set_xlim(-0.18, 2.18)
    ax.set_title("(B) Weakened metadata", pad=3)
    ax.text(0.98, 0.72, "graceful\ndegradation", ha="center",
            color=C_REF, fontsize=6.6, fontweight="bold", linespacing=1.05)
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax)

    # (C)
    ax = fig.add_subplot(gs[0, 2])
    colors = [C_OTHER, C_OTHER, C_BEST, C_OTHER, C_VERA]
    hatches = [None, None, "////", None, None]
    bars = ax.bar(range(5), SAME_VALS, color=colors, edgecolor="black",
                  linewidth=0.5, width=0.68, zorder=3)
    for b, h in zip(bars, hatches):
        if h:
            b.set_hatch(h)
    bar_labels(ax, bars, SAME_VALS, dy=0.014, fs=6.8)
    ax.set_xticks(range(5))
    ax.set_xticklabels(SAME_LABELS, fontsize=6.6)
    ax.set_ylabel("LifeEM")
    ax.set_ylim(0, 0.86)
    ax.set_title("(C) Same-action control", pad=3)
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax)
    gain_bracket(ax, 2, 4, 0.755, signed(0.172))

    fig.legend(
        handles=legend_patches(), loc="upper center",
        bbox_to_anchor=(0.50, 0.995), ncol=3, frameon=False,
        handlelength=1.35, columnspacing=1.6, fontsize=7.2,
    )

    out = OUT / "figure3.pdf"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.015)
    plt.close(fig)
    print(f"wrote {out}")


# ---------------------------------------------------------------------------
# Figure 4
# ---------------------------------------------------------------------------
def make_fig4():
    fig = plt.figure(figsize=(7.12, 2.82))
    gs = fig.add_gridspec(
        1, 2, width_ratios=[1.18, 1.0], wspace=0.30,
        left=0.09, right=0.995, bottom=0.14, top=0.80,
    )

    # (A) Per-split dumbbell
    ax = fig.add_subplot(gs[0, 0])
    n = len(SPLITS)
    ys = np.arange(n)[::-1]
    for highlight in (ys[2], ys[3], ys[4]):  # Update, Stale-only, Conflict
        ax.axhspan(highlight - 0.42, highlight + 0.42, color=C_HILITE,
                   alpha=0.85, zorder=0)
    for y, v0, vb, vv in zip(ys, SPLIT_VANILLA, SPLIT_BEST, SPLIT_VERA):
        ax.plot([v0, vv], [y, y], "-", color="#9a9a9a", linewidth=0.85, zorder=1)
        ax.plot(v0, y, "o", markersize=4.6, color=C_OTHER,
                markeredgecolor="black", markeredgewidth=0.45, zorder=3)
        ax.plot(vb, y, "o", markersize=4.6, color=C_BEST,
                markeredgecolor="black", markeredgewidth=0.45, zorder=3)
        ax.plot(vv, y, "o", markersize=5.1, color=C_VERA,
                markeredgecolor="black", markeredgewidth=0.45, zorder=4)
        ax.text(min(vv + 0.055, 1.02), y + 0.28, dot(vv), ha="center",
                fontsize=6.6, fontweight="bold")
        ax.text(1.055, y, signed(vv - v0), color=C_REF, fontsize=7.0,
                fontweight="bold", va="center", ha="left")
    ax.set_yticks(ys)
    ax.set_yticklabels(SPLITS)
    ax.set_xlim(-0.03, 1.24)
    ax.set_ylim(-0.55, n - 0.25)
    ax.set_xlabel("LifeEM")
    ax.set_title("(A) Per-split LifeEM", pad=3)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax, ygrid=False, xgrid=True)
    handles = [
        plt.Line2D([0], [0], marker="o", color="none", markerfacecolor=C_OTHER,
                   markeredgecolor="black", markersize=5, label="Vanilla"),
        plt.Line2D([0], [0], marker="o", color="none", markerfacecolor=C_BEST,
                   markeredgecolor="black", markersize=5, label="best baseline"),
        plt.Line2D([0], [0], marker="o", color="none", markerfacecolor=C_VERA,
                   markeredgecolor="black", markersize=5.4, label="VERA-LIFE"),
    ]
    fig.legend(
        handles=handles, loc="upper center", bbox_to_anchor=(0.50, 0.995),
        ncol=3, frameon=False, handlelength=1.4, columnspacing=1.8,
        fontsize=7.0,
    )

    # (B) Component ablations
    ax = fig.add_subplot(gs[0, 1])
    colors = [C_VERA] + [C_OTHER] * 4
    ys2 = np.arange(len(ABL_LABELS))[::-1]
    bars = ax.barh(ys2, ABL_VALS, color=colors, edgecolor="black",
                   linewidth=0.5, height=0.58, zorder=3)
    for b, v in zip(bars, ABL_VALS):
        ax.text(v + 0.012, b.get_y() + b.get_height() / 2.0, dot(v),
                va="center", ha="left", fontsize=7.0)
    for y, d in zip(ys2, ABL_DROPS):
        if d is None:
            continue
        ax.text(0.855, y, signed(d), va="center", ha="right",
                fontsize=7.0, color=C_REF, fontweight="bold")
    ax.set_yticks(ys2)
    ax.set_yticklabels(ABL_LABELS)
    ax.set_xlim(0, 0.90)
    ax.set_xlabel("LifeEM")
    ax.set_title("(B) Component ablations", pad=3)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax, ygrid=False, xgrid=True)

    out = OUT / "figure4.pdf"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.015)
    plt.close(fig)
    print(f"wrote {out}")


# ---------------------------------------------------------------------------
# Figure 5
# ---------------------------------------------------------------------------
def make_fig5():
    fig = plt.figure(figsize=(7.12, 2.52))
    gs = fig.add_gridspec(
        1, 3, width_ratios=[1.08, 0.98, 1.18], wspace=0.40,
        left=0.07, right=0.995, bottom=0.20, top=0.88,
    )

    # (A) All four bars are VERA-LIFE domain gains — same fill, no hatch.
    ax = fig.add_subplot(gs[0, 0])
    ys = np.arange(len(REAL_DOMAINS))[::-1]
    ax.barh(ys, REAL_GAINS, color=C_VERA, edgecolor="black",
            linewidth=0.5, height=0.52, zorder=3)
    for y, g, n in zip(ys, REAL_GAINS, REAL_NS):
        ax.text(g + 0.004, y, f"{signed(g)}  (n={n})", va="center",
                ha="left", fontsize=6.7)
    ax.axvline(REAL_AVG, color=C_REF, linestyle="--", linewidth=0.8, zorder=2)
    ax.text(REAL_AVG + 0.004, -0.62, f"avg {signed(REAL_AVG)}",
            color=C_REF, fontsize=6.6, ha="left", fontweight="bold")
    ax.set_yticks(ys)
    ax.set_yticklabels(REAL_DOMAINS)
    ax.set_xlim(0, 0.275)
    ax.set_ylim(-0.85, len(REAL_DOMAINS) - 0.35)
    ax.set_xlabel("LifeEM gain vs. best same-action")
    ax.set_title("(A) REAL-mini domain gains", pad=3)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.05))
    style_ax(ax, ygrid=False, xgrid=True)

    # (B) Exact (SRR, OAR) from tab:real-mini
    ax = fig.add_subplot(gs[0, 1])
    offsets = {
        "Sci/med": (5, 6),
        "Legal":   (5, 5),
        "API":     (5, -7),
        "News":    (-28, -8),
    }
    for name, (srr, oar, mk) in SAFETY.items():
        ax.scatter(srr, oar, marker=mk, s=38, color=C_BEST,
                   edgecolor="black", linewidth=0.55, zorder=3)
        ax.annotate(name, (srr, oar), xytext=offsets[name],
                    textcoords="offset points", fontsize=6.6, va="center")
    ax.scatter(*SAFETY_AVG, marker="*", s=105, color=C_VERA,
               edgecolor="black", linewidth=0.6, zorder=4)
    ax.annotate("Avg", SAFETY_AVG, xytext=(-18, 7),
                textcoords="offset points", fontsize=6.6,
                fontweight="bold", va="center")
    ax.annotate(
        "", xy=(0.848, 0.062), xytext=(0.768, 0.110),
        arrowprops=dict(arrowstyle="-|>", color=C_REF, lw=0.9),
    )
    ax.text(0.852, 0.056, "safer", fontsize=6.5, color=C_REF,
            fontweight="bold", ha="left", va="top")
    ax.set_xlabel("SRR (stale rejection)")
    ax.set_ylabel("OAR")
    ax.set_xlim(0.748, 0.875)
    ax.set_ylim(0.052, 0.124)
    ax.set_title("(B) Safety trade-off", pad=3)
    style_ax(ax, ygrid=True, xgrid=True)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.04))
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.02))

    # (C)
    ax = fig.add_subplot(gs[0, 2])
    colors = [C_VERA, C_OTHER, C_OTHER, C_OTHER]
    hatches = [None, "////", "...", "xx"]
    bars = ax.bar(range(4), BLIND_GAINS, color=colors, edgecolor="black",
                  linewidth=0.5, width=0.64, zorder=3)
    for b, h in zip(bars, hatches):
        if h:
            b.set_hatch(h)
    for i, g in enumerate(BLIND_GAINS):
        ax.text(i, g + 0.004, signed(g), ha="center", va="bottom",
                fontsize=7.0, fontweight="bold")
    ax.annotate(
        "marker removal\nkeeps 87.5%",
        xy=(2.0, 0.118), xytext=(2.55, 0.168),
        color=C_REF, fontsize=6.4, fontweight="bold",
        ha="center", linespacing=1.05,
        arrowprops=dict(arrowstyle="-|>", color=C_REF, lw=0.65,
                        connectionstyle="arc3,rad=0.18"),
    )
    ax.set_xticks(range(4))
    ax.set_xticklabels(BLIND_LABELS, fontsize=6.6)
    ax.set_ylabel("LifeEM gain")
    ax.set_ylim(0, 0.215)
    ax.set_title("(C) REAL-blind stress", pad=3)
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.04))
    style_ax(ax)

    out = OUT / "figure5.pdf"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.015)
    plt.close(fig)
    print(f"wrote {out}")


# ---------------------------------------------------------------------------
# Combined 4+5 (not included in the paper; kept for local layout experiments)
# ---------------------------------------------------------------------------
def make_fig_results():
    fig = plt.figure(figsize=(7.12, 5.85))
    outer = fig.add_gridspec(
        2, 1, height_ratios=[1.0, 0.95], hspace=0.42,
        left=0.08, right=0.995, bottom=0.06, top=0.97,
    )
    top = outer[0].subgridspec(1, 2, width_ratios=[1.18, 1.0], wspace=0.30)
    bot = outer[1].subgridspec(1, 3, width_ratios=[1.08, 0.98, 1.18], wspace=0.42)

    ax = fig.add_subplot(top[0, 0])
    n = len(SPLITS)
    ys = np.arange(n)[::-1]
    for highlight in (ys[2], ys[3], ys[4]):
        ax.axhspan(highlight - 0.42, highlight + 0.42, color=C_HILITE,
                   alpha=0.85, zorder=0)
    for y, v0, vb, vv in zip(ys, SPLIT_VANILLA, SPLIT_BEST, SPLIT_VERA):
        ax.plot([v0, vv], [y, y], "-", color="#9a9a9a", linewidth=0.85, zorder=1)
        ax.plot(v0, y, "o", markersize=4.6, color=C_OTHER,
                markeredgecolor="black", markeredgewidth=0.45, zorder=3)
        ax.plot(vb, y, "o", markersize=4.6, color=C_BEST,
                markeredgecolor="black", markeredgewidth=0.45, zorder=3)
        ax.plot(vv, y, "o", markersize=5.1, color=C_VERA,
                markeredgecolor="black", markeredgewidth=0.45, zorder=4)
        ax.text(min(vv + 0.055, 1.02), y + 0.28, dot(vv), ha="center",
                fontsize=6.6, fontweight="bold")
        ax.text(1.055, y, signed(vv - v0), color=C_REF, fontsize=7.0,
                fontweight="bold", va="center", ha="left")
    ax.set_yticks(ys)
    ax.set_yticklabels(SPLITS)
    ax.set_xlim(-0.03, 1.24)
    ax.set_ylim(-0.55, n - 0.25)
    ax.set_xlabel("LifeEM")
    ax.set_title("(A) Per-split LifeEM", pad=3)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax, ygrid=False, xgrid=True)

    ax = fig.add_subplot(top[0, 1])
    colors = [C_VERA] + [C_OTHER] * 4
    ys2 = np.arange(len(ABL_LABELS))[::-1]
    bars = ax.barh(ys2, ABL_VALS, color=colors, edgecolor="black",
                   linewidth=0.5, height=0.58, zorder=3)
    for b, v in zip(bars, ABL_VALS):
        ax.text(v + 0.012, b.get_y() + b.get_height() / 2.0, dot(v),
                va="center", ha="left", fontsize=7.0)
    for y, d in zip(ys2, ABL_DROPS):
        if d is None:
            continue
        ax.text(0.855, y, signed(d), va="center", ha="right",
                fontsize=7.0, color=C_REF, fontweight="bold")
    ax.set_yticks(ys2)
    ax.set_yticklabels(ABL_LABELS)
    ax.set_xlim(0, 0.90)
    ax.set_xlabel("LifeEM")
    ax.set_title("(B) Component ablations", pad=3)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.2))
    style_ax(ax, ygrid=False, xgrid=True)

    ax = fig.add_subplot(bot[0, 0])
    ys3 = np.arange(len(REAL_DOMAINS))[::-1]
    ax.barh(ys3, REAL_GAINS, color=C_VERA, edgecolor="black",
            linewidth=0.5, height=0.52, zorder=3)
    for y, g, nn in zip(ys3, REAL_GAINS, REAL_NS):
        ax.text(g + 0.004, y, f"{signed(g)}  (n={nn})", va="center",
                ha="left", fontsize=6.7)
    ax.axvline(REAL_AVG, color=C_REF, linestyle="--", linewidth=0.8)
    ax.text(REAL_AVG + 0.004, -0.62, f"avg {signed(REAL_AVG)}",
            color=C_REF, fontsize=6.6, ha="left", fontweight="bold")
    ax.set_yticks(ys3)
    ax.set_yticklabels(REAL_DOMAINS)
    ax.set_xlim(0, 0.275)
    ax.set_ylim(-0.85, len(REAL_DOMAINS) - 0.35)
    ax.set_xlabel("LifeEM gain vs. best same-action")
    ax.set_title("(C) REAL-mini domain gains", pad=3)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.05))
    style_ax(ax, ygrid=False, xgrid=True)

    ax = fig.add_subplot(bot[0, 1])
    offsets = {
        "Sci/med": (5, 6),
        "Legal":   (5, 5),
        "API":     (5, -7),
        "News":    (-28, -8),
    }
    for name, (srr, oar, mk) in SAFETY.items():
        ax.scatter(srr, oar, marker=mk, s=38, color=C_BEST,
                   edgecolor="black", linewidth=0.55, zorder=3)
        ax.annotate(name, (srr, oar), xytext=offsets[name],
                    textcoords="offset points", fontsize=6.6, va="center")
    ax.scatter(*SAFETY_AVG, marker="*", s=105, color=C_VERA,
               edgecolor="black", linewidth=0.6, zorder=4)
    ax.annotate("Avg", SAFETY_AVG, xytext=(-18, 7),
                textcoords="offset points", fontsize=6.6,
                fontweight="bold", va="center")
    ax.annotate(
        "", xy=(0.848, 0.062), xytext=(0.768, 0.110),
        arrowprops=dict(arrowstyle="-|>", color=C_REF, lw=0.9),
    )
    ax.text(0.852, 0.056, "safer", fontsize=6.5, color=C_REF,
            fontweight="bold", ha="left", va="top")
    ax.set_xlabel("SRR (stale rejection)")
    ax.set_ylabel("OAR")
    ax.set_xlim(0.748, 0.875)
    ax.set_ylim(0.052, 0.124)
    ax.set_title("(D) Safety trade-off", pad=3)
    style_ax(ax, ygrid=True, xgrid=True)
    ax.xaxis.set_major_locator(plt.MultipleLocator(0.04))
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.02))

    ax = fig.add_subplot(bot[0, 2])
    colors = [C_VERA, C_OTHER, C_OTHER, C_OTHER]
    hatches = [None, "////", "...", "xx"]
    bars = ax.bar(range(4), BLIND_GAINS, color=colors, edgecolor="black",
                  linewidth=0.5, width=0.64, zorder=3)
    for b, h in zip(bars, hatches):
        if h:
            b.set_hatch(h)
    for i, g in enumerate(BLIND_GAINS):
        ax.text(i, g + 0.004, signed(g), ha="center", va="bottom",
                fontsize=7.0, fontweight="bold")
    ax.annotate(
        "marker removal\nkeeps 87.5%",
        xy=(2.0, 0.118), xytext=(2.55, 0.168),
        color=C_REF, fontsize=6.4, fontweight="bold",
        ha="center", linespacing=1.05,
        arrowprops=dict(arrowstyle="-|>", color=C_REF, lw=0.65,
                        connectionstyle="arc3,rad=0.18"),
    )
    ax.set_xticks(range(4))
    ax.set_xticklabels(BLIND_LABELS, fontsize=6.6)
    ax.set_ylabel("LifeEM gain")
    ax.set_ylim(0, 0.215)
    ax.set_title("(E) REAL-blind stress", pad=3)
    ax.yaxis.set_major_locator(plt.MultipleLocator(0.04))
    style_ax(ax)

    out = OUT / "figure_results.pdf"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    make_fig3()
    make_fig4()
    make_fig5()
    make_fig_results()
