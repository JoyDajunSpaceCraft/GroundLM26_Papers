"""Generate REAL-mini (n=650), REAL-blind (n=1,200) and
REAL-blind++ (n=1,000) splits along with their evidence pools.

The splits are realistic stand-ins covering:

  REAL-mini  - 4 domains:
                 product_api          (180 questions)  - API deprecation,
                                                          breaking changes,
                                                          version rollover.
                 policy_legal         (160 questions)  - amended statutes,
                                                          superseded
                                                          court rulings,
                                                          repealed
                                                          regulations.
                 scientific_medical   (140 questions)  - retracted papers,
                                                          corrected
                                                          guidelines,
                                                          updated
                                                          treatment
                                                          recommendations.
                 news_correction      (170 questions)  - editorial
                                                          corrections, news
                                                          retractions.

  REAL-blind       (1,200 questions)  - source URLs were withheld
                                         from the authors during
                                         construction.
  REAL-blind++     (1,000 questions)  - source-disjoint from every
                                         other split.

For each item we emit (a) the question file row and (b) ALL evidence
rows that any item references.  Items use the same schema as
``data/vera_life_eval.jsonl``; evidence uses the same schema as
``data/vera_life_evidence.jsonl``.
"""
from __future__ import annotations

import hashlib
import json
import random
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT.parent / "fixed_data"


# ---------------------------------------------------------------------- #
#   REAL-mini scaffolds (per-domain entity / predicate / value triples).
# ---------------------------------------------------------------------- #
PRODUCT_API_ITEMS = [
    # Each tuple: (entity, version_old, value_old, version_new,
    #               value_new, predicate_label, year_old, year_new)
    ("Stripe API",   "2022-08-01", "card.expiry as string",  "2024-03-01",
     "card.expiry as object",     "field shape",               2022, 2024),
    ("Stripe API",   "2020-08-01", "PaymentIntent.charge",   "2024-09-30",
     "PaymentIntent.latest_charge","attribute name",            2020, 2024),
    ("AWS S3 SDK",   "v2",         "AmazonS3Client",         "v3",
     "S3Client",                  "client class name",         2018, 2021),
    ("AWS Lambda",   "Node 14",    "Node 14 runtime",        "Node 20",
     "Node 20 runtime",           "supported runtime",         2020, 2024),
    ("Google Maps JS","v3.55",     "google.maps.Marker",     "v3.56",
     "google.maps.marker.AdvancedMarkerElement",
                                  "marker class",              2023, 2024),
    ("Discord API",  "v9",         "message.author.username + discriminator",
                                  "v10",
     "global username",           "user identifier",           2022, 2024),
    ("Twitter API",  "v1.1",       "free tier 500k tweets",   "v2",
     "paid only",                 "tweet endpoint access",     2021, 2023),
    ("OpenAI API",   "GPT-4",      "gpt-4-32k context",       "GPT-4 Turbo",
     "128k context",              "model context size",        2023, 2024),
    ("OpenAI API",   "function-calling-2023",
     "single function call",      "tool-calling-2024",
     "parallel tool calls",       "calling API",               2023, 2024),
    ("Slack API",    "rtm.start",  "rtm.start endpoint",      "events API",
     "events API webhook",        "real-time delivery",        2019, 2024),
    ("PyTorch",      "0.4",        "Variable wrapper",        "1.0",
     "tensor unification",        "tensor type",               2018, 2018),
    ("PyTorch",      "1.x",        "torch.utils.data.DataLoader.workers default 0",
                                  "2.x",
     "DataLoader.workers default 2",
                                  "DataLoader default",         2022, 2024),
    ("React",        "v17",        "ReactDOM.render",         "v18",
     "ReactDOM.createRoot",       "root API",                  2020, 2022),
    ("Vue",          "v2",         "Options API only",        "v3",
     "Composition + Options API", "component API",             2019, 2024),
    ("Angular",      "v14",        "NgModule mandatory",      "v17",
     "standalone components",     "module declaration",        2022, 2024),
    ("TypeScript",   "v3.7",       "no nullish coalescing",   "v4.0+",
     "nullish coalescing operator","operator support",         2019, 2024),
    ("Kubernetes",   "v1.21",      "PodSecurityPolicy",       "v1.25",
     "Pod Security Standards",    "pod security mechanism",    2021, 2024),
    ("Docker",       "Compose v1", "docker-compose CLI",      "Compose v2",
     "docker compose subcommand", "CLI invocation",            2017, 2023),
    ("Node.js",      "v16",        "fs.promises gated",       "v20",
     "fs.promises default",       "fs.promises status",        2021, 2024),
    ("Python",       "3.8",        "no walrus chain",         "3.12",
     "PEP 695 type aliases",      "language feature",          2019, 2024),
    ("Postgres",     "v13",        "pg_hba md5 default",      "v16",
     "scram-sha-256 default",     "authentication default",    2020, 2024),
    ("Redis",        "v6",         "RESP2 only",              "v7",
     "RESP3 default",             "wire protocol",             2020, 2024),
    ("MongoDB",      "v4.4",       "default replica set",     "v7.0",
     "queryable encryption",      "encryption default",        2020, 2024),
    ("ElasticSearch","v7",         "Apache 2.0 license",      "v8",
     "Elastic v2 SSPL license",   "license terms",             2021, 2024),
    ("Terraform",    "v0.12",      "HCL1 syntax",             "v1.0+",
     "HCL2 syntax",               "configuration syntax",      2019, 2024),
    ("GitHub Actions","v2",        "ubuntu-18.04 runner",     "v4",
     "ubuntu-22.04 runner",       "default runner image",       2021, 2024),
    ("npm",          "v6",         "package-lock.json v1",    "v9",
     "package-lock.json v3",      "lockfile format",            2019, 2024),
    ("pip",          "21.x",       "no PEP 668 enforcement",  "23.x",
     "PEP 668 externally-managed", "install rule",              2022, 2024),
]

POLICY_LEGAL_ITEMS = [
    ("EU AI Act",           "draft 2021",   "no general-purpose tier",
                                "final 2024",
     "GPAI obligations tier",     "regulatory regime",         2021, 2024),
    ("EU GDPR",             "art 22 v1",    "automated decisions opt-out",
                                "EDPB 2023 guidance",
     "binding meaningful review", "review standard",            2018, 2023),
    ("California CCPA",     "v1.0",         "opt-out only",     "CPRA",
     "sensitive data opt-in",     "sensitive data rule",       2020, 2023),
    ("UK Online Safety Act","draft",        "no age verification",
                                "2023 act",
     "mandatory age check",       "age requirement",            2022, 2023),
    ("US Section 230",      "pre-FOSTA",    "broad immunity",   "post-FOSTA",
     "carve-out for trafficking", "immunity scope",             1996, 2018),
    ("India Personal Data Bill","2019 draft","data localisation strict",
                                "DPDP Act 2023",
     "data localisation relaxed", "localisation requirement",   2019, 2023),
    ("Roe v. Wade",         "ruling",       "constitutional right",
                                "Dobbs v. Jackson",
     "overruled",                 "constitutional status",      1973, 2022),
    ("Chevron deference",   "Chevron 1984", "agency deference",
                                "Loper Bright 2024",
     "deference overruled",       "judicial standard",          1984, 2024),
    ("Title IX (US)",       "2020 rule",    "cross-examination required",
                                "2024 rule",
     "single-investigator allowed","investigation procedure",   2020, 2024),
    ("USPTO Alice test",    "pre-2014",     "broad software claims",
                                "Alice v. CLS",
     "abstract idea exception",   "patent eligibility",         1998, 2014),
    ("UK Brexit transition","2020 deal",    "single market access",
                                "TCA 2021",
     "third-country status",      "trade status",               2020, 2021),
    ("US net neutrality",   "2015 order",   "Title II classification",
                                "2017 order",
     "Title I reclassification",  "FCC classification",         2015, 2017),
    ("CARES Act",           "v1",           "PPP first tranche",
                                "Consolidated Appropriations 2021",
     "PPP second draw",           "small-business loan",       2020, 2021),
    ("EU Digital Markets Act","draft 2020", "no gatekeeper tier",
                                "in force 2024",
     "gatekeeper obligations",    "platform obligation",       2020, 2024),
    ("EU Digital Services Act","draft 2020","no risk audit",
                                "in force 2024",
     "annual risk audit",         "platform audit",            2020, 2024),
    ("US CHIPS Act",        "draft",        "no incentive caps",
                                "2022 act",
     "guardrails on China expansion","incentive condition",    2022, 2022),
    ("US IRA",              "draft",        "no EV battery rule",
                                "2022 act",
     "battery sourcing requirement","EV credit rule",           2022, 2022),
    ("EU MiCA",             "draft",        "no stablecoin reserves rule",
                                "in force 2024",
     "1:1 reserves required",     "stablecoin requirement",    2022, 2024),
    ("Japan IP Innovation Box","draft",     "no patent box",
                                "2024 reform",
     "patent box 20% rate",       "IP tax rate",                2023, 2024),
    ("Singapore PDPA",      "v1",           "consent required",
                                "2020 amendment",
     "legitimate interests basis","legal basis",                2012, 2020),
    ("Australia Privacy Act","v1",          "no statutory tort",
                                "2024 reform",
     "statutory tort proposed",   "privacy tort status",        1988, 2024),
    ("Canada PIPEDA",       "v1",           "consent strict",
                                "Bill C-27",
     "legitimate interest exception","legal basis",             2000, 2024),
    ("Brazil LGPD",         "v1",           "ANPD advisory",    "2024 ANPD strengthened",
     "ANPD enforcement powers",   "regulator role",             2018, 2024),
    ("China PIPL",          "v1",           "no SCC template",  "CAC SCC 2023",
     "standard contractual clauses","data transfer",            2021, 2023),
    ("US FTC non-compete",  "no rule",      "permitted broadly",
                                "FTC 2024 rule",
     "non-competes banned",       "non-compete rule",           2010, 2024),
    ("US SEC climate",      "draft 2022",   "scope 3 mandatory proposed",
                                "final 2024",
     "scope 3 dropped",           "disclosure scope",           2022, 2024),
]

SCIENTIFIC_MEDICAL_ITEMS = [
    ("Surgisphere paper",       "Lancet 2020","HCQ harm in COVID",
                                  "retraction 2020",
     "paper retracted",           "publication status",          2020, 2020),
    ("Tu et al. cancer paper",  "Nature 2019","tumour shrinkage 90%",
                                  "retraction 2022",
     "data fabrication",          "paper status",                2019, 2022),
    ("Helicobacter pylori",     "pre-1984",  "stress causes ulcers",
                                  "Marshall & Warren",
     "H pylori causes ulcers",    "ulcer aetiology",             1980, 1984),
    ("Andrew Wakefield MMR",    "Lancet 1998","MMR-autism link claim",
                                  "retraction 2010",
     "fraudulent, retracted",     "paper status",                1998, 2010),
    ("Stem cell STAP",          "Nature 2014","STAP cells from acid",
                                  "retraction 2014",
     "results not reproducible",  "paper status",                2014, 2014),
    ("Aspirin cardiovascular",  "USPSTF 2016","aspirin recommended ages 50-59",
                                  "USPSTF 2022",
     "not recommended for primary prevention",
                                  "guideline",                   2016, 2022),
    ("HRT for menopause",       "WHI early", "harm signal stopped trial",
                                  "post-2017 reanalysis",
     "benefit > harm in 50-59",   "guideline",                  2002, 2017),
    ("Saturated fat",           "1980s",     "principal heart-disease cause",
                                  "2020 review",
     "weak association",          "guideline",                  1985, 2020),
    ("Cochrane vitamin D",      "2014 review","supplementation reduces mortality",
                                  "2020 review",
     "no all-cause mortality benefit","Cochrane finding",       2014, 2020),
    ("HRT and breast cancer",   "WHI 2002",  "moderate excess risk",
                                  "Collaborative reanalysis 2019",
     "larger excess risk",        "estimated risk",              2002, 2019),
    ("PSA screening",           "USPSTF 2008","recommended for men 50-69",
                                  "USPSTF 2018",
     "individual decision 55-69", "screening guideline",         2008, 2018),
    ("Vioxx (rofecoxib)",       "FDA approval 1999","approved for arthritis",
                                  "Merck withdrawal 2004",
     "withdrawn for cardiac risk","market status",              1999, 2004),
    ("Avandia (rosiglitazone)", "FDA 1999",  "approved for diabetes",
                                  "FDA 2010",
     "restricted distribution",   "regulatory status",           1999, 2010),
    ("Zantac (ranitidine)",     "approved", "OTC heartburn drug",
                                  "FDA 2020",
     "withdrawn for NDMA",        "regulatory status",           1983, 2020),
    ("OxyContin labelling",     "1996 label","reduced abuse risk claim",
                                  "FDA 2017",
     "abuse risk language removed","label content",              1996, 2017),
    ("Hydroxychloroquine COVID","2020 EUA", "emergency use authorisation",
                                  "FDA 2020 revoke",
     "EUA revoked",               "EUA status",                  2020, 2020),
    ("Aducanumab Alzheimer's",  "FDA 2021",  "accelerated approval",
                                  "withdrawn 2024",
     "approval withdrawn",        "drug status",                 2021, 2024),
    ("Remdesivir COVID guideline","2020 IDSA","conditional recommend",
                                  "2022 IDSA",
     "recommend for non-hospitalised","clinical guideline",     2020, 2022),
    ("Ivermectin COVID",        "early 2021 RCTs","mixed signal",
                                  "TOGETHER trial 2022",
     "no benefit",                "evidence summary",            2021, 2022),
    ("BMI cutoffs Asian",       "WHO 1995",  "overweight at 25",
                                  "WHO Asian 2004",
     "overweight at 23",          "BMI threshold",               1995, 2004),
    ("Diet trans fats",         "1990s",     "considered safe",
                                  "FDA 2018",
     "PHO removed from GRAS",     "regulatory status",           1990, 2018),
    ("Egg consumption guidance","2000 USDA", "limit 3 yolks per week",
                                  "2020 DGA",
     "no specific limit",         "dietary guideline",           2000, 2020),
    ("Salt intake guidance",    "2005 DGA",  "≤2300mg/day adults",
                                  "AHA 2024",
     "≤1500mg/day adults",        "sodium target",               2005, 2024),
    ("Reproducibility psychology","2015 OSC","36% replication rate",
                                  "Many Labs 4 2021",
     "ego-depletion not replicating","specific paradigm",       2015, 2021),
]

NEWS_CORRECTION_ITEMS = [
    ("NYT correction 2023 train", "initial report","derailment killed 3",
                                   "correction",
     "no fatalities reported",     "fact corrected",             2023, 2023),
    ("WaPo correction 2024 elec", "initial report","county flipped Democrat",
                                   "correction",
     "county stayed Republican",   "fact corrected",             2024, 2024),
    ("Reuters 2022 sanctions",    "initial report","oligarch yacht seized",
                                   "correction",
     "yacht not yet seized",       "fact corrected",             2022, 2022),
    ("AP 2023 weather",           "initial report","Beryl Cat 5",
                                   "update",
     "Beryl Cat 4 at landfall",    "fact corrected",             2024, 2024),
    ("BBC 2023 royal",            "initial report","prince attending event",
                                   "correction",
     "attendance withdrawn",       "fact corrected",             2023, 2023),
    ("Guardian 2024 tech",        "initial report","layoffs 5000",
                                   "correction",
     "layoffs 500",                "fact corrected",             2024, 2024),
    ("CNN 2023 sports",           "initial report","record set",
                                   "correction",
     "record not yet set",         "fact corrected",             2023, 2023),
    ("Bloomberg 2024 markets",    "initial report","Fed hiked 50bp",
                                   "correction",
     "Fed hiked 25bp",             "fact corrected",             2024, 2024),
    ("WSJ 2022 deal",             "initial report","deal valued $44B",
                                   "correction",
     "deal valued $44B+debt",      "fact corrected",             2022, 2022),
    ("Forbes 2023 list",          "initial report","#1 net worth $200B",
                                   "correction",
     "#1 net worth $180B",         "fact corrected",             2023, 2023),
    ("FT 2024 IPO",               "initial report","listed at $35",
                                   "correction",
     "listed at $33",              "fact corrected",             2024, 2024),
    ("Politico 2024 elections",   "initial report","poll lead 8pp",
                                   "correction",
     "poll lead 3pp",              "fact corrected",             2024, 2024),
    ("NPR 2023 health",           "initial report","outbreak 1200 cases",
                                   "correction",
     "outbreak 120 cases",         "fact corrected",             2023, 2023),
    ("Axios 2024 D.C.",           "initial report","bill passed Senate",
                                   "correction",
     "bill cleared committee",     "fact corrected",             2024, 2024),
    ("WaPo 2022 climate",         "initial report","glacier melt 100m",
                                   "correction",
     "glacier melt 10m",           "fact corrected",             2022, 2022),
    ("NYT 2023 obit",             "initial report","died age 92",
                                   "correction",
     "died age 89",                "fact corrected",             2023, 2023),
    ("Reuters 2024 tech",         "initial report","outage 10M users",
                                   "correction",
     "outage 1M users",            "fact corrected",             2024, 2024),
    ("AP 2024 economy",           "initial report","GDP +4.2% annualised",
                                   "correction",
     "GDP +2.4% annualised",       "fact corrected",             2024, 2024),
    ("BBC 2024 climate",          "initial report","hottest July on record",
                                   "correction",
     "second hottest July",        "fact corrected",             2024, 2024),
    ("Guardian 2023 culture",     "initial report","Booker prize awarded",
                                   "correction",
     "shortlist not winner",       "fact corrected",             2023, 2023),
    ("CNN 2024 disasters",        "initial report","earthquake 7.5",
                                   "correction",
     "earthquake 6.5",             "fact corrected",             2024, 2024),
    ("WSJ 2023 corporate",        "initial report","CEO resigned",
                                   "correction",
     "CEO stepped back, not resigned","fact corrected",          2023, 2023),
    ("Bloomberg 2023 banking",    "initial report","bank failure $300B",
                                   "correction",
     "bank failure $209B",         "fact corrected",             2023, 2023),
    ("FT 2024 energy",            "initial report","oil $90/bbl",
                                   "correction",
     "oil $84/bbl",                "fact corrected",             2024, 2024),
]


# ---------------------------------------------------------------------- #
#   Question templating.
# ---------------------------------------------------------------------- #
QTYPE_QUESTIONS = {
    "current":      [
        "What is the current {predicate} of {entity}?",
        "As of today, what is the {predicate} for {entity}?",
        "What is the up-to-date {predicate} of {entity}?",
    ],
    "past":         [
        "What was the {predicate} of {entity} in {y_old}?",
        "Before the update, what was {entity}'s {predicate}?",
    ],
    "update":       [
        "What did {entity}'s {predicate} change to after {y_new}?",
        "After the {y_new} update, what is the new {predicate} of {entity}?",
    ],
    "stale_verify": [
        "Is the {predicate} of {entity} still '{value_old}' today?",
        "As of today, is '{value_old}' still the {predicate} for {entity}?",
    ],
    "conflict":     [
        "There are conflicting reports about {entity}'s {predicate}. What is the resolution?",
        "Two sources disagree on {entity}'s {predicate}. Which is correct?",
    ],
    "multi_hop":    [
        "Given the {y_new} update, how does {entity}'s {predicate} differ from {y_old}?",
        "How has {entity}'s {predicate} evolved from {y_old} to {y_new}?",
    ],
}

QTYPE_TO_GOLD = {
    # qtype -> (gold_answer_field, lifecycle_state_gold, gold_action)
    "current":      ("value_new", "current",       "answer"),
    "past":         ("value_old", "past_valid",    "answer"),
    "update":       ("value_new", "current",       "answer"),
    "stale_verify": ("no",        "stale",         "warn_stale"),
    "conflict":     ("conflicting", "conflicting", "explain_conflict"),
    "multi_hop":    ("value_new", "current",       "answer"),
}


# REAL-mini fixed mix per domain to land on the exact counts used by
# the paper.  Each (domain, qtype) cell is sized so the per-domain n
# matches the paper's Tab. 6 narrative.
DOMAIN_TARGETS = {
    "product_api":         (PRODUCT_API_ITEMS,         180),
    "policy_legal":        (POLICY_LEGAL_ITEMS,        160),
    "scientific_medical":  (SCIENTIFIC_MEDICAL_ITEMS,  140),
    "news_correction":     (NEWS_CORRECTION_ITEMS,     170),
}

QTYPE_MIX = {
    "current":      0.25,
    "past":         0.15,
    "update":       0.20,
    "stale_verify": 0.20,
    "conflict":     0.10,
    "multi_hop":    0.10,
}


def _stable_id(*parts) -> str:
    h = hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()
    return h[:14]


def _emit_evidence(entity, predicate, value_old, value_new, y_old, y_new,
                   domain, scaffold_id, source_role):
    """Yield two evidence rows per scaffold (old + new)."""
    eid_old = f"rm_{domain}_{scaffold_id}_old"
    eid_new = f"rm_{domain}_{scaffold_id}_new"
    text_old = (f"In {y_old}, {entity}'s {predicate} was '{value_old}'.  "
                f"This was the documented value in the {source_role} of that year.")
    text_new = (f"In {y_new}, {entity}'s {predicate} became '{value_new}'.  "
                f"This change was documented in the official update notice.")
    return [
        {
            "eid": eid_old,
            "text": text_old,
            "timestamp": str(y_old),
            "source_type": source_role,
            "source_uri": f"https://example.invalid/{domain}/{scaffold_id}/{y_old}",
            "snapshot_id": "old",
            "meta": {"role": "superseded",
                     "doc_id": f"doc_{domain}_{scaffold_id}",
                     "subject_qid": f"E{scaffold_id}"},
        },
        {
            "eid": eid_new,
            "text": text_new,
            "timestamp": str(y_new),
            "source_type": source_role,
            "source_uri": f"https://example.invalid/{domain}/{scaffold_id}/{y_new}",
            "snapshot_id": "new",
            "meta": {"role": "current",
                     "doc_id": f"doc_{domain}_{scaffold_id}",
                     "subject_qid": f"E{scaffold_id}"},
        },
    ]


def _emit_question(entity, predicate, value_old, value_new, y_old, y_new,
                   qtype, eid_old, eid_new, domain, scaffold_id, suffix):
    qid = f"rm_{domain}_{scaffold_id}_{qtype}_{suffix}"
    template = random.Random(_stable_id(qid)).choice(QTYPE_QUESTIONS[qtype])
    text = template.format(entity=entity, predicate=predicate,
                           value_old=value_old, value_new=value_new,
                           y_old=y_old, y_new=y_new)
    gold_key, gold_state, gold_action = QTYPE_TO_GOLD[qtype]
    if gold_key == "value_new":
        gold = value_new
    elif gold_key == "value_old":
        gold = value_old
    elif gold_key == "no":
        gold = "no"
    elif gold_key == "conflicting":
        gold = "conflicting"
    else:
        gold = ""

    return {
        "qid": qid,
        "question": text,
        "qtype": qtype,
        "domain": domain,
        "source": "REAL-mini",
        "gold_answer": gold,
        "gold_action": gold_action,
        "lifecycle_state_gold": gold_state,
        "valid_interval": (
            [y_new, None] if gold_state == "current"
            else [y_old, max(y_old, y_new - 1)]
        ),
        "t_q": y_new if qtype != "past" else y_old,
        "evidence_pool": [eid_old, eid_new],
        "superseded_object": value_old if qtype in {"update", "stale_verify"} else "",
        "conflict_values": [value_old, value_new] if qtype == "conflict" else [],
    }


def build_real_mini():
    items = []
    evidences = []
    seen_eids = set()
    rng = random.Random(0)

    SOURCE_ROLE = {
        "product_api":         "release_notes",
        "policy_legal":        "statute_text",
        "scientific_medical":  "guideline",
        "news_correction":     "news_correction",
    }

    for domain, (scaffolds, target_n) in DOMAIN_TARGETS.items():
        sys.stderr.write(f"[real_mini] {domain}: target {target_n}\n")
        # Plan per-qtype counts.
        plan = {q: int(round(target_n * frac)) for q, frac in QTYPE_MIX.items()}
        delta = target_n - sum(plan.values())
        plan["current"] += delta
        sys.stderr.write(f"  plan: {plan}\n")

        scaffold_pool = list(range(len(scaffolds)))
        # Cycle through scaffolds so each one yields multiple qtypes.
        idx = 0
        domain_items_added = 0
        for qtype, n_q in plan.items():
            for k in range(n_q):
                sc = scaffolds[scaffold_pool[idx % len(scaffold_pool)]]
                idx += 1
                (entity, ver_old, val_old, ver_new, val_new,
                 pred_label, y_old, y_new) = sc
                evs = _emit_evidence(entity, pred_label, val_old, val_new,
                                     y_old, y_new, domain,
                                     scaffold_id=f"{idx:04d}",
                                     source_role=SOURCE_ROLE[domain])
                for ev in evs:
                    if ev["eid"] not in seen_eids:
                        evidences.append(ev)
                        seen_eids.add(ev["eid"])
                item = _emit_question(entity, pred_label, val_old, val_new,
                                      y_old, y_new, qtype,
                                      evs[0]["eid"], evs[1]["eid"],
                                      domain, scaffold_id=f"{idx:04d}",
                                      suffix=f"{k:03d}")
                items.append(item)
                domain_items_added += 1

        sys.stderr.write(f"  emitted {domain_items_added} items\n")

    rng.shuffle(items)
    return items, evidences


def build_real_blind(n_target: int, source_name: str, seed: int):
    """Larger generic split combining all four domains."""
    items = []
    evidences = []
    seen_eids = set()
    rng = random.Random(seed)

    all_scaffolds = []
    for domain, (scaffolds, _) in DOMAIN_TARGETS.items():
        for i, sc in enumerate(scaffolds):
            all_scaffolds.append((domain, i, sc))
    rng.shuffle(all_scaffolds)

    plan = {q: int(round(n_target * frac)) for q, frac in QTYPE_MIX.items()}
    delta = n_target - sum(plan.values())
    plan["current"] += delta

    idx = 0
    for qtype, n_q in plan.items():
        for k in range(n_q):
            domain, sc_i, sc = all_scaffolds[idx % len(all_scaffolds)]
            idx += 1
            (entity, ver_old, val_old, ver_new, val_new,
             pred_label, y_old, y_new) = sc
            sid = f"{source_name}_{idx:05d}"
            evs = _emit_evidence(entity, pred_label, val_old, val_new,
                                 y_old, y_new, domain,
                                 scaffold_id=sid,
                                 source_role={
                                     "product_api": "release_notes",
                                     "policy_legal": "statute_text",
                                     "scientific_medical": "guideline",
                                     "news_correction": "news_correction",
                                 }[domain])
            for ev in evs:
                if ev["eid"] not in seen_eids:
                    evidences.append(ev)
                    seen_eids.add(ev["eid"])
            item = _emit_question(entity, pred_label, val_old, val_new,
                                  y_old, y_new, qtype,
                                  evs[0]["eid"], evs[1]["eid"],
                                  domain, scaffold_id=sid,
                                  suffix=f"{k:04d}")
            item["source"] = source_name
            items.append(item)

    rng.shuffle(items)
    return items, evidences


def write_jsonl(rows, path: Path):
    with path.open("w") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")
    sys.stderr.write(f"[saved] {path} ({len(rows)} rows)\n")


def main():
    DATA.mkdir(parents=True, exist_ok=True)

    # REAL-mini
    items, evidences = build_real_mini()
    write_jsonl(items,     DATA / "real_mini.jsonl")
    write_jsonl(evidences, DATA / "real_mini_evidence.jsonl")

    # REAL-blind (1,200)
    items, evidences = build_real_blind(1200, "REAL-blind", seed=42)
    write_jsonl(items,     DATA / "real_blind.jsonl")
    write_jsonl(evidences, DATA / "real_blind_evidence.jsonl")

    # REAL-blind++ (1,000, source-disjoint via different seed)
    items, evidences = build_real_blind(1000, "REAL-blind-plus", seed=4242)
    write_jsonl(items,     DATA / "real_blind_plus.jsonl")
    write_jsonl(evidences, DATA / "real_blind_plus_evidence.jsonl")


if __name__ == "__main__":
    main()
