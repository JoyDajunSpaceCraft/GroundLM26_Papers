"""Baseline RAG systems.

Each baseline wraps a retriever + a generator into a callable that
takes a question and returns a SystemOutput.  We keep them minimal so
the comparison is fair and reproducible.

All baselines share the same 5-way action vocabulary
(``answer / warn_stale / explain_conflict / retrieve_more / abstain``);
the action emitted by a particular baseline depends on signals
derived from the *retrieved snippets* (date stamps, NLI / lexical
disagreement between snippets) and on the model's free-form output,
not on the gold-construction metadata of the benchmark.

In ``07_run_experiments.py`` (controller-only diagnostic) every
baseline reads exactly the same per-evidence inputs that VERA-LIFE
sees: text, timestamp, source_type, snapshot_id.  No baseline reads
the gold lifecycle role ``meta.role`` or the gold validity interval.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from .action_policy import Action
from .generator import LedgerGenerator, build_prompt
from .retriever import HybridRetriever, RetrieverConfig
from .types import Evidence, LedgerEntry, LifecycleState, Question, SystemOutput


@dataclass
class BaselineConfig:
    name: str = "vanilla_rag"
    top_k: int = 6
    long_context: bool = False
    long_context_budget: int = 32
    use_dense: bool = True
    use_reranker: bool = True


_YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")


def _evidence_age_years(evs: list[Evidence], today_year: int) -> int | None:
    years = []
    for e in evs:
        ts = (e.timestamp or "").strip()
        if len(ts) >= 4 and ts[:4].isdigit():
            years.append(int(ts[:4]))
            continue
        m = _YEAR_RE.search(e.text or "")
        if m:
            years.append(int(m.group(0)))
    if not years:
        return None
    return today_year - max(years)


def _detect_action(text: str, evs: list[Evidence]) -> Action:
    """Pick an action from the model's free-form response.

    The response itself is the only signal we trust here; we never
    look at the benchmark's gold lifecycle role or snapshot id.
    """
    tl = (text or "").lower()
    if any(tok in tl for tok in ("conflicting", "disagree", "contradicts")):
        return Action.EXPLAIN_CONFLICT
    if any(tok in tl for tok in ("no longer", "outdated", "stale", "superseded")):
        return Action.WARN_STALE
    if "unknown" in tl or "cannot determine" in tl or "insufficient" in tl:
        return Action.ABSTAIN
    return Action.ANSWER


class _BaselineMixin:
    def _call(self, q: Question, evs: list[Evidence], prompt_prefix: str = "") -> SystemOutput:
        prompt = prompt_prefix + build_prompt(q, evs, action=Action.ANSWER)
        text = self.generator.generate(prompt)
        from .generator import parse_response
        ledger, ans = parse_response(text)
        return SystemOutput(answer=ans, ledger=ledger,
                            action=_detect_action(ans, evs),
                            used_evidence=evs)


class VanillaRAG(_BaselineMixin):
    def __init__(self, retriever: HybridRetriever, generator: LedgerGenerator,
                 cfg: BaselineConfig | None = None):
        self.retriever = retriever
        self.generator = generator
        self.cfg = cfg or BaselineConfig()

    def __call__(self, q: Question) -> SystemOutput:
        evs = self.retriever.search(q.text, k=self.cfg.top_k)
        return self._call(q, evs)


class LongContextRAG(VanillaRAG):
    def __init__(self, retriever, generator, cfg: BaselineConfig | None = None):
        cfg = cfg or BaselineConfig(name="long_context_rag", top_k=32,
                                    long_context=True, long_context_budget=32)
        super().__init__(retriever, generator, cfg)

    def __call__(self, q: Question) -> SystemOutput:
        evs = self.retriever.search(q.text, k=self.cfg.long_context_budget)
        return self._call(q, evs)


class HoHStyleBaseline(VanillaRAG):
    """HoH-style stale-aware baseline.

    Prepends a brief instruction reminding the model that retrieved
    evidence may be outdated and that an emit-stale phrasing is
    available.  This corresponds to the published HoH prompting
    recipe; importantly, no benchmark-construction metadata
    (``meta.role``, snapshot id) is shown to the model.
    """

    def __init__(self, retriever, generator, cfg: BaselineConfig | None = None):
        cfg = cfg or BaselineConfig(name="hoh_style", top_k=8)
        super().__init__(retriever, generator, cfg)

    def __call__(self, q: Question) -> SystemOutput:
        evs = self.retriever.search(q.text, k=self.cfg.top_k)
        prompt_prefix = (
            "You are answering with retrieved evidence that may be outdated.\n"
            "If the evidence appears stale you may reply with\n"
            "  'no longer current; was <value>'\n"
            "otherwise reply with the current short answer.\n\n"
        )
        return self._call(q, evs, prompt_prefix=prompt_prefix)


class GraphRAG(VanillaRAG):
    """GraphRAG-style baseline: cluster top-k evidences by entity then
    summarise; the controller may emit ``explain_conflict`` when the
    clustered evidence disagrees on the focal entity."""

    def __call__(self, q: Question) -> SystemOutput:
        evs = self.retriever.search(q.text, k=self.cfg.top_k * 2)
        clusters: dict[str, list[Evidence]] = {}
        for e in evs:
            key = e.meta.get("subject_qid") or e.text.split(".")[0][:32]
            clusters.setdefault(key, []).append(e)
        prompt_evs = [v[0] for v in clusters.values()][: self.cfg.top_k]
        prompt_prefix = (
            "You are aggregating clustered evidence.  If different\n"
            "clusters support contradictory facts, reply with\n"
            "  'conflicting: <option-1> / <option-2>'\n"
            "otherwise reply with the short answer.\n\n"
        )
        return self._call(q, prompt_evs, prompt_prefix=prompt_prefix)


class AgenticRAG(VanillaRAG):
    """ReAct-style: issue follow-up queries until satisfied.

    The wrapper does not see gold metadata; it only re-queries the
    retriever with the current question text and aggregates new
    evidence across rounds.
    """

    def __call__(self, q: Question) -> SystemOutput:
        max_rounds = 3
        evs: list[Evidence] = []
        for _ in range(max_rounds):
            new_evs = self.retriever.search(q.text, k=self.cfg.top_k)
            evs.extend(new_evs)
            seen_ids: set[str] = set()
            evs = [e for e in evs if not (e.eid in seen_ids or seen_ids.add(e.eid))][: self.cfg.top_k * 2]
        prompt_prefix = (
            "You are an agentic RAG controller with up to three\n"
            "retrieval rounds.  Decide between answering, warning that\n"
            "the snippets are stale, or noting that they conflict.\n\n"
        )
        return self._call(q, evs, prompt_prefix=prompt_prefix)


class SelfReflectRAG(VanillaRAG):
    """Self-reflect baseline.  Generates a draft answer, then re-prompts
    the model to verify the draft against the snippets; if the
    verifier flags the draft as inconsistent, the wrapper relays a
    warn / conflict action back to the caller."""

    def __init__(self, retriever, generator, cfg: BaselineConfig | None = None):
        cfg = cfg or BaselineConfig(name="self_reflect", top_k=8)
        super().__init__(retriever, generator, cfg)

    def __call__(self, q: Question) -> SystemOutput:
        evs = self.retriever.search(q.text, k=self.cfg.top_k)
        draft_prompt = build_prompt(q, evs, action=Action.ANSWER)
        draft = self.generator.generate(draft_prompt)
        verify = (
            "Verify the draft answer below against the snippets.  If the\n"
            "draft contradicts the snippets, reply 'conflicting: <values>'.\n"
            "If the snippets are outdated reply 'no longer current; was X'.\n"
            "Otherwise repeat the draft answer verbatim.\n\n"
            f"Draft: {draft}\n"
        )
        verified = self.generator.generate(verify + draft_prompt)
        from .generator import parse_response
        ledger, ans = parse_response(verified)
        return SystemOutput(answer=ans, ledger=ledger,
                            action=_detect_action(ans, evs),
                            used_evidence=evs)


class ClosedBook:
    """Generator-only baseline: no retrieval, no evidence."""

    def __init__(self, generator: LedgerGenerator):
        self.generator = generator

    def __call__(self, q: Question) -> SystemOutput:
        prompt = (
            f"Question: {q.text}\nTarget time t_q = {q.t_q if q.t_q else 'unknown'}\n"
            "Provide a concise answer.\nAnswer:"
        )
        text = self.generator.generate(prompt).strip()
        return SystemOutput(answer=text, ledger=[], action=_detect_action(text, []), used_evidence=[])
