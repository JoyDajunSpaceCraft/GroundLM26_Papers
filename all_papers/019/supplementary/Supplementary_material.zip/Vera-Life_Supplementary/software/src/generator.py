"""Ledger-Grounded Generator.

We define a thin abstraction so the same controller can plug into:

- vLLM for fast batched inference
- transformers AutoModelForCausalLM (slower fallback)
- a remote OpenAI-compatible endpoint (for emergencies)

The generator emits either a structured ledger + short answer pair
(used by VERA-LIFE) or a free-form short answer (used by baselines).
``parse_response`` is robust to both shapes -- if no ledger is
present the prediction is returned verbatim as the short answer.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from .types import Action, Claim, Evidence, LedgerEntry, LifecycleState, Question, SystemOutput


SYSTEM_PROMPT = (
    "You are VERA-LIFE, a retrieval-augmented assistant that produces "
    "answers grounded by a lifecycle ledger.  Always emit:\n"
    "1. A 'Ledger:' JSON list with claim, evidence_ids, interval, state, confidence.\n"
    "2. A short natural language answer that mentions explicit time validity "
    "and warns about superseded or conflicting evidence.\n"
    "Never make claims without a backing evidence id.\n"
)

ACTION_INSTRUCTIONS = {
    Action.ANSWER:           "Provide the answer with explicit valid interval.",
    Action.WARN_STALE:       "Provide answer but warn that supporting evidence may be stale.",
    Action.EXPLAIN_CONFLICT: "Do not assert a single answer; explain the conflicting sources.",
    Action.RETRIEVE_MORE:    "Indicate that more retrieval is needed; produce a partial ledger.",
    Action.ABSTAIN:          "Decline to answer; explain the missing or untrustworthy evidence.",
}


def _format_evidence(evs: list[Evidence], max_chars: int = 480) -> str:
    parts = []
    for e in evs:
        snippet = e.text.strip().replace("\n", " ")[:max_chars]
        parts.append(f"[{e.eid} | t={e.timestamp or '?'} | src={e.source_type}] {snippet}")
    return "\n".join(parts)


def build_prompt(question: Question, evidences: list[Evidence], action: Action) -> str:
    return (
        f"Question: {question.text}\n"
        f"Target time t_q = {question.t_q if question.t_q is not None else 'unknown'}\n"
        f"System action: {action.value} ({ACTION_INSTRUCTIONS[action]})\n"
        "Evidence (each line is one piece):\n"
        f"{_format_evidence(evidences)}\n\n"
        "Respond strictly in this format:\n"
        "Ledger: <JSON list>\nAnswer: <natural language>"
    )


_LEDGER_RE = re.compile(r"Ledger\s*:\s*(\[.*?\])\s*Answer\s*:\s*(.*)", re.S | re.I)
_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```\s*Answer\s*:\s*(.*)", re.S | re.I)


def parse_response(text: str) -> tuple[list[LedgerEntry], str]:
    """Best-effort parser for both ``Ledger: [...] Answer: ...`` and
    ```json{...}``` Answer: ... shapes.

    Returns an empty ledger and the raw text when no recognised
    structure is found.
    """
    ledger: list[LedgerEntry] = []
    ans = text or ""
    data: Any = []

    m = _LEDGER_RE.search(ans)
    fenced = _JSON_FENCE_RE.search(ans) if m is None else None
    if m:
        try:
            data = json.loads(m.group(1))
        except Exception:  # noqa: BLE001
            data = []
        ans = m.group(2).strip()
    elif fenced:
        try:
            parsed = json.loads(fenced.group(1))
            if isinstance(parsed, dict) and "claims" in parsed:
                data = parsed["claims"]
            elif isinstance(parsed, list):
                data = parsed
        except Exception:  # noqa: BLE001
            data = []
        ans = fenced.group(2).strip()

    if isinstance(data, list):
        for i, row in enumerate(data):
            if not isinstance(row, dict):
                continue
            interval = row.get("interval") or row.get("valid_interval") or [None, None]
            if isinstance(interval, str):
                # "2018-present" / "2018-2024" / "2018"
                m2 = re.match(r"(\d{4})(?:\s*[-/]\s*(\d{4}|present|now))?", interval.lower())
                if m2:
                    s = int(m2.group(1))
                    e = m2.group(2)
                    e_int = None if (e is None or e in {"present", "now"}) else int(e)
                    interval = [s, e_int]
                else:
                    interval = [None, None]
            state_val = (row.get("state") or row.get("lifecycle") or "current").lower()
            try:
                state = LifecycleState(state_val)
            except ValueError:
                state = LifecycleState.CURRENT
            ledger.append(LedgerEntry(
                claim=Claim(cid=f"c{i}", text=row.get("claim", "")),
                evidence_ids=row.get("evidence_ids") or row.get("evidence", []),
                interval=tuple(interval[:2]) if isinstance(interval, (list, tuple)) else (None, None),
                state=state,
                confidence=float(row.get("confidence", 0.5)),
            ))
    # Trim trailing whitespace / generator boilerplate.
    ans = ans.split("Question:")[0].split("Snippets:")[0].strip()
    return ledger, ans


@dataclass
class GeneratorConfig:
    model_path: str
    max_new_tokens: int = 384
    temperature: float = 0.0
    top_p: float = 1.0
    backend: str = "vllm"   # vllm / hf / openai
    dtype: str = "bfloat16"


class LedgerGenerator:
    """Wrapper around vLLM (preferred) or transformers."""

    def __init__(self, cfg: GeneratorConfig):
        self.cfg = cfg
        self._engine = None

    def _ensure(self):
        if self._engine is not None:
            return
        if self.cfg.backend == "vllm":
            try:
                from vllm import LLM, SamplingParams  # noqa: F401
                self._engine = ("vllm", LLM(model=self.cfg.model_path, dtype=self.cfg.dtype, max_model_len=8192))
            except Exception:
                self.cfg.backend = "hf"
        if self.cfg.backend == "hf":
            from transformers import AutoTokenizer, AutoModelForCausalLM
            tok = AutoTokenizer.from_pretrained(self.cfg.model_path)
            mdl = AutoModelForCausalLM.from_pretrained(self.cfg.model_path,
                                                       torch_dtype="auto",
                                                       device_map="auto")
            self._engine = ("hf", tok, mdl)

    def generate(self, prompt: str) -> str:
        self._ensure()
        if self._engine[0] == "vllm":
            from vllm import SamplingParams
            params = SamplingParams(max_tokens=self.cfg.max_new_tokens,
                                    temperature=self.cfg.temperature,
                                    top_p=self.cfg.top_p)
            out = self._engine[1].generate([prompt], params, use_tqdm=False)
            return out[0].outputs[0].text
        if self._engine[0] == "hf":
            _, tok, mdl = self._engine
            inputs = tok(prompt, return_tensors="pt").to(mdl.device)
            outputs = mdl.generate(**inputs, max_new_tokens=self.cfg.max_new_tokens,
                                   temperature=max(self.cfg.temperature, 1e-3),
                                   top_p=self.cfg.top_p,
                                   do_sample=self.cfg.temperature > 0)
            return tok.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        raise RuntimeError("generator engine unavailable")
