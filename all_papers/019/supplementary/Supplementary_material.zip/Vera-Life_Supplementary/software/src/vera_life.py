"""VERA-LIFE end-to-end controller.

Wires the components together:
1. Temporal Intent Parser
2. Multi-Snapshot Retriever
3. Lifecycle State Graph
4. Evidence Contract Selector
5. Risk-Calibrated Action Policy
6. Ledger-Grounded Generator
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .action_policy import (Action, LearnedPolicy, PolicyThresholds,
                            RiskScores, compute_risks, rule_policy)
from .contract_selector import ContractScores, contract_score, greedy_select, jaccard
from .generator import LedgerGenerator, build_prompt, parse_response
from .lifecycle_graph import LifecycleGraph, LifecycleGraphBuilder
from .retriever import HybridRetriever, MultiSnapshotRetriever, RetrieverConfig
from .temporal_parser import parse_question
from .types import Evidence, EdgeType, Fact, LedgerEntry, LifecycleState, Question, SystemOutput, QuestionType


@dataclass
class VeraLifeConfig:
    retrieval_top_k: int = 24
    contract_budget: int = 8
    use_learned_policy: bool = False
    rerank_evidence: bool = True
    abstain_on_no_evidence: bool = True
    thresholds: PolicyThresholds = field(default_factory=PolicyThresholds)


class VERALIFE:
    def __init__(self,
                 retriever: MultiSnapshotRetriever | HybridRetriever,
                 generator: LedgerGenerator,
                 graph_builder: LifecycleGraphBuilder | None = None,
                 facts: dict[str, Fact] | None = None,
                 cfg: VeraLifeConfig | None = None,
                 learned_policy: LearnedPolicy | None = None):
        self.retriever = retriever
        self.generator = generator
        self.graph_builder = graph_builder or LifecycleGraphBuilder()
        self.facts = facts or {}
        self.cfg = cfg or VeraLifeConfig()
        self.learned_policy = learned_policy

    # ------------------------------------------------------------------ #
    #   Risk computation helpers
    # ------------------------------------------------------------------ #
    def _coverage(self, evidences: list[Evidence], graph: LifecycleGraph,
                  t_q: int | None) -> float:
        if not evidences:
            return 0.0
        weights = []
        for e in evidences:
            state = self.graph_builder.lifecycle_state(graph, e.eid, t_q)
            # Past-valid evidence still counts as "covering" the
            # question -- past split questions explicitly ask about
            # historical state.
            weights.append(1.0 if state in {"current", "past_valid"} else 0.0)
        return sum(weights) / max(1, len(weights))

    def _max_validity(self, evidences: list[Evidence], graph: LifecycleGraph,
                      t_q: int | None) -> float:
        states = [self.graph_builder.lifecycle_state(graph, e.eid, t_q) for e in evidences]
        if any(s == "current" for s in states):
            return 1.0
        if any(s == "past_valid" for s in states):
            return 0.5
        return 0.0

    def _max_contradict(self, graph: LifecycleGraph) -> float:
        weights = [edge.weight for edge in graph.edges if edge.rel == EdgeType.CONTRADICT]
        return max(weights) if weights else 0.0

    def _provenance(self, e: Evidence) -> float:
        if e.source_uri:
            return 1.0
        if e.source_type in {"wiki", "wikidata", "openalex"}:
            return 0.8
        return 0.3

    # ------------------------------------------------------------------ #
    #   Pipeline
    # ------------------------------------------------------------------ #
    def __call__(self, question_text: str, qid: str = "", t_eval: int = 2024,
                 relation: str = "", retrieval_iter: int = 0,
                 qtype_hint: str | None = None) -> SystemOutput:
        q = parse_question(question_text, qid=qid, t_eval=t_eval, relation=relation)
        # Honour an explicit caller-supplied qtype (used by harnesses
        # that already know the split label).
        if qtype_hint:
            try:
                q.qtype = QuestionType(qtype_hint)
            except ValueError:
                pass

        if isinstance(self.retriever, MultiSnapshotRetriever):
            evs = self.retriever.search(q.text, k_per_snapshot=8, total_k=self.cfg.retrieval_top_k)
        else:
            evs = self.retriever.search(q.text, k=self.cfg.retrieval_top_k)

        graph = self.graph_builder.build(evs, facts=self.facts, t_q=q.t_q)

        scores = ContractScores()
        for e in evs:
            state = self.graph_builder.lifecycle_state(graph, e.eid, q.t_q)
            scores.relevance[e.eid] = e.score
            # past_valid is given a 0.5 weight in the contract score,
            # so past-time questions can still select historical evidence.
            scores.validity[e.eid] = (1.0 if state == "current"
                                       else (0.5 if state == "past_valid" else 0.0))
            scores.provenance[e.eid] = self._provenance(e)
            scores.not_superseded[e.eid] = 0.0 if state == "superseded" else 1.0
            scores.conflict[e.eid] = max(
                (edge.weight for edge in graph.edges
                 if edge.rel == EdgeType.CONTRADICT and (edge.src == e.eid or edge.dst == e.eid)),
                default=0.0,
            )

        selected = greedy_select(evs, scores, budget=self.cfg.contract_budget,
                                 redundancy_fn=lambda a, b: jaccard(a.text, b.text))

        coverage = self._coverage(selected, graph, q.t_q)
        max_v = self._max_validity(selected, graph, q.t_q)
        max_c = self._max_contradict(graph)
        risk = compute_risks(coverage, max_v, max_c)

        if self.learned_policy is not None and self.cfg.use_learned_policy:
            import numpy as np
            x = np.array([risk.insufficient, risk.stale, risk.conflict,
                          coverage, max_v,
                          sum(1 for ed in graph.edges if ed.rel == EdgeType.UPDATE),
                          sum(1 for ed in graph.edges if ed.rel == EdgeType.CONTRADICT),
                          len({e.snapshot_id for e in selected if e.snapshot_id}),
                          float(retrieval_iter)], dtype=float)
            action = self.learned_policy.predict(x)
        else:
            action = rule_policy(risk, self.cfg.thresholds,
                                 retrieval_iter=retrieval_iter,
                                 qtype=q.qtype.value if hasattr(q.qtype, "value") else str(q.qtype))

        if action == Action.RETRIEVE_MORE and retrieval_iter < self.cfg.thresholds.max_retrieval_iters:
            return self.__call__(question_text, qid=qid, t_eval=t_eval, relation=relation,
                                 retrieval_iter=retrieval_iter + 1, qtype_hint=qtype_hint)

        if action == Action.ABSTAIN and self.cfg.abstain_on_no_evidence:
            return SystemOutput(
                answer="I do not have sufficient up-to-date evidence to answer.",
                ledger=[],
                action=Action.ABSTAIN,
                used_evidence=selected,
                risks={"insuf": risk.insufficient, "stale": risk.stale, "conflict": risk.conflict},
            )

        prompt = build_prompt(q, selected, action=action)
        text = self.generator.generate(prompt)
        ledger, answer = parse_response(text)

        return SystemOutput(
            answer=answer,
            ledger=ledger,
            action=action,
            used_evidence=selected,
            risks={"insuf": risk.insufficient, "stale": risk.stale, "conflict": risk.conflict},
        )
