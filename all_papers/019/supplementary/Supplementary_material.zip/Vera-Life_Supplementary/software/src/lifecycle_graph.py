"""Lifecycle State Graph construction.

For a query q we receive a candidate set V_q of evidence pieces (each
already paired with extracted structured fact and timestamp).  We then
build directed edges using deterministic rules + cheap NLI weights.

Edge types implemented (see the lifecycle state graph appendix):

- support  : evidence semantically supports the same claim
- update   : same (s, p) but newer timestamp and different o
- supersede: stronger update with explicit override evidence
- contradict: NLI contradiction between pieces
- expire   : timestamp beyond known end of validity
- duplicate: paraphrase / near-identical text

The per-node lifecycle state assignment uses the rules described in
Section 3 of the paper:

- ``current``    : an evidence whose validity interval covers ``t_q``
                   (or which is the newest peer in its doc and is not
                   superseded by any same-doc newer revision before
                   ``t_q``).
- ``past_valid`` : the evidence covers a time window strictly before
                   ``t_q`` *and* the user's target time falls inside
                   that interval (i.e. the question explicitly asks
                   about a historical state).
- ``stale``      : the evidence was current at some past time but is
                   no longer valid at ``t_q`` (a newer peer is missing
                   from the retrieval pool, so the system must warn).
- ``superseded`` : a newer same-doc peer exists in the graph that
                   carries a different object value before ``t_q``.
- ``conflicting``: the evidence is in an NLI / lexical contradiction
                   edge with another retrieved evidence at the same
                   target time.
- ``insufficient``: no evidence was retrieved or all evidence falls
                   outside the validity window.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from .types import Evidence, EdgeType, Fact


def jaccard_overlap(a: str, b: str) -> float:
    """Cheap word-level Jaccard for paraphrase / UPDATE candidate detection."""
    sa = set((a or "").lower().split())
    sb = set((b or "").lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


@dataclass
class GraphNode:
    eid: str
    evidence: Evidence
    fact: Fact | None = None


@dataclass
class GraphEdge:
    src: str
    dst: str
    rel: EdgeType
    weight: float = 1.0


@dataclass
class LifecycleGraph:
    nodes: dict[str, GraphNode] = field(default_factory=dict)
    edges: list[GraphEdge] = field(default_factory=list)

    def neighbors(self, eid: str, rel: EdgeType | None = None) -> list[str]:
        return [e.dst for e in self.edges if e.src == eid and (rel is None or e.rel == rel)]


def _ts_year(ts: str) -> int | None:
    if not ts:
        return None
    s = str(ts).strip()
    if s.startswith("-"):
        s = s[1:]
        sign = -1
    else:
        sign = 1
    if len(s) >= 4 and s[:4].isdigit():
        return sign * int(s[:4])
    return None


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


class LifecycleGraphBuilder:
    """Cheap, training-free graph builder.

    Optionally accepts an embedder (callable str->np.ndarray) for
    duplicate detection and an NLI scorer (callable (a, b)->dict)
    that returns probabilities for support/contradict.  Both are
    optional; if absent we fall back to lexical heuristics.
    """

    def __init__(self,
                 embedder=None,
                 nli=None,
                 dup_threshold: float = 0.92,
                 contradict_threshold: float = 0.55,
                 support_threshold: float = 0.55):
        self.embedder = embedder
        self.nli = nli
        self.dup_threshold = dup_threshold
        self.contradict_threshold = contradict_threshold
        self.support_threshold = support_threshold

    # ------------------------------------------------------------------ #
    #   Graph construction
    # ------------------------------------------------------------------ #
    def build(self,
              evidences: list[Evidence],
              facts: dict[str, Fact] | None = None,
              t_q: int | None = None) -> LifecycleGraph:
        graph = LifecycleGraph()
        for e in evidences:
            graph.nodes[e.eid] = GraphNode(eid=e.eid, evidence=e, fact=(facts or {}).get(e.eid))

        embs = None
        if self.embedder is not None:
            try:
                embs = np.asarray([self.embedder(e.text) for e in evidences])
            except Exception:  # noqa: BLE001
                embs = None

        for i, ei in enumerate(evidences):
            for j, ej in enumerate(evidences):
                if i == j:
                    continue
                yi = _ts_year(ei.timestamp)
                yj = _ts_year(ej.timestamp)
                fi = (facts or {}).get(ei.eid)
                fj = (facts or {}).get(ej.eid)

                if embs is not None:
                    sim = cosine(embs[i], embs[j])
                    if sim >= self.dup_threshold and i < j:
                        graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.DUPLICATE, weight=sim))

                # Structured-fact supersession (when facts are present).
                if (fi and fj and fi.subject == fj.subject
                        and fi.predicate == fj.predicate and fi.obj != fj.obj):
                    if yi is not None and yj is not None and yj > yi:
                        graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.UPDATE, weight=1.0))
                        if t_q is not None and yj <= t_q:
                            graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.SUPERSEDE, weight=1.0))

                # Same-document timestamp ordering: when two snippets
                # share a doc_id and one is strictly older, treat the
                # older as a candidate UPDATE source.
                meta_i = ei.meta if isinstance(ei.meta, dict) else {}
                meta_j = ej.meta if isinstance(ej.meta, dict) else {}
                same_doc = bool(meta_i.get("doc_id")) and meta_i.get("doc_id") == meta_j.get("doc_id")
                if same_doc and yi is not None and yj is not None and yj > yi:
                    overlap = jaccard_overlap(ei.text, ej.text)
                    if overlap >= 0.25:
                        graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.UPDATE, weight=0.7))
                        if t_q is None or yj <= t_q:
                            graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.SUPERSEDE, weight=0.7))

                # NLI contradiction.
                if self.nli is not None and i < j:
                    try:
                        probs = self.nli(ei.text, ej.text)
                    except Exception:  # noqa: BLE001
                        probs = None
                    if probs:
                        if probs.get("contradiction", 0.0) >= self.contradict_threshold:
                            graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.CONTRADICT,
                                                         weight=probs["contradiction"]))
                        if probs.get("entailment", 0.0) >= self.support_threshold:
                            graph.edges.append(GraphEdge(ei.eid, ej.eid, EdgeType.SUPPORT,
                                                         weight=probs["entailment"]))

                if fi and fi.t_end is not None and t_q is not None and t_q > fi.t_end:
                    graph.edges.append(GraphEdge(ei.eid, ei.eid, EdgeType.EXPIRE, weight=1.0))
        return graph

    # ------------------------------------------------------------------ #
    #   Lifecycle-state inference
    # ------------------------------------------------------------------ #
    def lifecycle_state(self, graph: LifecycleGraph, eid: str, t_q: int | None) -> str:
        """Decide the lifecycle state of a single evidence node.

        The state takes a *single* per-node label.  The fallback when
        no signal is present is ``insufficient``, not ``current`` --
        the controller must justify a "current" label rather than
        receive it for free.
        """
        node = graph.nodes.get(eid)
        if node is None:
            return "insufficient"

        is_superseded = False
        in_conflict = False
        in_expire = False
        for edge in graph.edges:
            if edge.src == eid and edge.rel == EdgeType.SUPERSEDE:
                is_superseded = True
            if (edge.src == eid or edge.dst == eid) and edge.rel == EdgeType.CONTRADICT:
                in_conflict = True
            if edge.src == eid and edge.dst == eid and edge.rel == EdgeType.EXPIRE:
                in_expire = True

        # 1. Structured fact wins when present.
        fact = node.fact
        if fact is not None and t_q is not None:
            ts_lo = fact.t_start if fact.t_start is not None else -10**9
            ts_hi = fact.t_end if fact.t_end is not None else 10**9
            if ts_lo <= t_q <= ts_hi:
                return "current"
            if t_q < ts_lo:
                return "past_valid"  # asking about a time before this fact became valid
            if t_q > ts_hi:
                return "stale"

        # 2. Conflict wins over supersession.
        if in_conflict:
            return "conflicting"

        # 3. Same-doc supersession.
        ts = _ts_year(node.evidence.timestamp)
        if is_superseded:
            has_newer_peer = False
            for other_id, other in graph.nodes.items():
                if other_id == eid:
                    continue
                other_ts = _ts_year(other.evidence.timestamp)
                if ts is not None and other_ts is not None and other_ts > ts:
                    has_newer_peer = True
                    break
            return "superseded" if has_newer_peer else "stale"

        # 4. Role-as-published-signal: in versioned corpora a chunk's
        #    snapshot role ("current" / "superseded") is a public
        #    deployment signal (analogous to deprecation banners on
        #    API docs, retraction notices on papers, correction tags on
        #    news).  We treat it as such and downstream metadata-
        #    isolation tables (Tab. 2, 26, 29-31, 37) re-evaluate
        #    without this field.
        role = (node.evidence.meta or {}).get("role") if isinstance(node.evidence.meta, dict) else None
        if role == "superseded":
            return "stale"
        if role == "current":
            return "current"

        # 5. Timestamp-versus-target-time heuristic.
        if ts is not None and t_q is not None:
            # If the evidence is *older* than the user's target time
            # by more than a tolerance, consider it potentially stale
            # but only when no newer peer is in the graph.
            if ts <= t_q:
                return "current"

        if in_expire:
            return "stale"

        # 6. Default: no signal -> insufficient.
        return "insufficient"
