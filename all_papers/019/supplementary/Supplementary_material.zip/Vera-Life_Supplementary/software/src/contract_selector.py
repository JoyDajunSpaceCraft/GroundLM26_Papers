"""Evidence Contract Selector (greedy submodular)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .types import Evidence


@dataclass
class ContractScores:
    relevance: dict[str, float] = field(default_factory=dict)
    validity: dict[str, float] = field(default_factory=dict)         # V(e_i, t_q)
    provenance: dict[str, float] = field(default_factory=dict)
    not_superseded: dict[str, float] = field(default_factory=dict)   # U(e_i)
    conflict: dict[str, float] = field(default_factory=dict)         # K(e_i)


def contract_score(eid: str, scores: ContractScores,
                   alpha: float = 0.45, beta: float = 0.25,
                   gamma: float = 0.10, delta: float = 0.15,
                   eta: float = 0.10) -> float:
    return (alpha * scores.relevance.get(eid, 0.0)
            + beta * scores.validity.get(eid, 0.0)
            + gamma * scores.provenance.get(eid, 0.0)
            + delta * scores.not_superseded.get(eid, 0.0)
            - eta * scores.conflict.get(eid, 0.0))


def greedy_select(evidences: list[Evidence],
                  scores: ContractScores,
                  budget: int = 8,
                  redundancy_fn: Callable[[Evidence, Evidence], float] | None = None,
                  conflict_fn: Callable[[Evidence, Evidence], float] | None = None,
                  redundancy_lambda: float = 0.5,
                  conflict_mu: float = 0.4) -> list[Evidence]:
    """F(E,q) ~ sum coverage - lambda * redundancy - mu * conflict.

    Greedy approximation: at each step pick the evidence that maximizes
    incremental marginal gain.
    """
    selected: list[Evidence] = []
    candidates = list(evidences)

    def gain(e: Evidence) -> float:
        base = contract_score(e.eid, scores)
        if not selected:
            return base
        red = max(redundancy_fn(e, s) for s in selected) if redundancy_fn else 0.0
        con = max(conflict_fn(e, s) for s in selected) if conflict_fn else 0.0
        return base - redundancy_lambda * red - conflict_mu * con

    while candidates and len(selected) < budget:
        candidates.sort(key=gain, reverse=True)
        best = candidates[0]
        if gain(best) <= 0 and selected:
            break
        selected.append(best)
        candidates = candidates[1:]
    return selected


def jaccard(a: str, b: str) -> float:
    sa = set(a.lower().split())
    sb = set(b.lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)
