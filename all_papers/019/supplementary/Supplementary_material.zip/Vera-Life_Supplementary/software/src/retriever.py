"""Multi-Snapshot Retriever (BM25 + Dense + Reranker).

We support the formula
    R(e_i, q) = lambda_b * BM25 + lambda_d * Dense + lambda_r * Rerank
with optional per-snapshot retrieval that returns time-stratified Top-K
candidates so downstream lifecycle reasoning can compare evidence across
versions.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np

from .types import Evidence


@dataclass
class RetrieverConfig:
    bm25_weight: float = 0.4
    dense_weight: float = 0.4
    rerank_weight: float = 0.2
    top_k_per_snapshot: int = 50
    final_top_k: int = 16
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    reranker_model: str = "BAAI/bge-reranker-base"


class BM25Index:
    """Lightweight BM25 backed by rank_bm25 (no Java dependency)."""

    def __init__(self, docs: list[str]):
        from rank_bm25 import BM25Okapi
        self.tokens = [d.lower().split() for d in docs]
        self.bm25 = BM25Okapi(self.tokens)
        self.docs = docs

    def search(self, query: str, k: int = 50) -> list[tuple[int, float]]:
        q = query.lower().split()
        scores = self.bm25.get_scores(q)
        idx = np.argsort(scores)[-k:][::-1]
        return [(int(i), float(scores[i])) for i in idx if scores[i] > 0]


class DenseIndex:
    """Dense embedding index using sentence-transformers + FAISS."""

    def __init__(self, model_name: str, docs: list[str], device: str = "cuda:0",
                 cache_dir: str | None = None):
        import faiss
        from sentence_transformers import SentenceTransformer
        kwargs = {"device": device}
        if cache_dir:
            kwargs["cache_folder"] = cache_dir
        self.model = SentenceTransformer(model_name, **kwargs)
        self.docs = docs
        embs = self.model.encode(docs, batch_size=64, show_progress_bar=False, convert_to_numpy=True, normalize_embeddings=True)
        self.embs = embs.astype("float32")
        self.index = faiss.IndexFlatIP(self.embs.shape[1])
        self.index.add(self.embs)

    def search(self, query: str, k: int = 50) -> list[tuple[int, float]]:
        q = self.model.encode([query], normalize_embeddings=True, convert_to_numpy=True).astype("float32")
        D, I = self.index.search(q, k)
        return [(int(i), float(d)) for d, i in zip(D[0], I[0]) if i >= 0]


class Reranker:
    def __init__(self, model_name: str, device: str = "cuda:0", cache_dir: str | None = None):
        from sentence_transformers import CrossEncoder
        kwargs = {"device": device}
        if cache_dir:
            kwargs["cache_folder"] = cache_dir
        self.model = CrossEncoder(model_name, **kwargs)

    def score(self, query: str, docs: list[str]) -> list[float]:
        if not docs:
            return []
        return [float(s) for s in self.model.predict([(query, d) for d in docs], show_progress_bar=False, batch_size=32)]


class HybridRetriever:
    """Combines BM25, dense, and reranker for one corpus.

    For multi-snapshot retrieval we instantiate one HybridRetriever per
    snapshot id and merge the candidate sets in :class:`MultiSnapshotRetriever`.
    """

    def __init__(self, evidences: list[Evidence], cfg: RetrieverConfig | None = None,
                 device: str = "cuda:0", cache_dir: str | None = None,
                 lazy_dense: bool = False):
        self.cfg = cfg or RetrieverConfig()
        self.evidences = evidences
        self.docs = [e.text for e in evidences]
        self.bm25 = BM25Index(self.docs)
        self.dense: DenseIndex | None = None
        self.reranker: Reranker | None = None
        self.cache_dir = cache_dir
        self.device = device
        if not lazy_dense:
            self.ensure_dense()

    def ensure_dense(self):
        if self.dense is None:
            self.dense = DenseIndex(self.cfg.embedding_model, self.docs, device=self.device, cache_dir=self.cache_dir)

    def ensure_reranker(self):
        if self.reranker is None:
            self.reranker = Reranker(self.cfg.reranker_model, device=self.device, cache_dir=self.cache_dir)

    def _normalize(self, scored: list[tuple[int, float]]) -> dict[int, float]:
        if not scored:
            return {}
        max_s = max(s for _, s in scored) or 1.0
        return {i: s / max_s for i, s in scored}

    def search(self, query: str, k: int | None = None) -> list[Evidence]:
        k = k or self.cfg.final_top_k
        bm = self._normalize(self.bm25.search(query, k=self.cfg.top_k_per_snapshot))
        self.ensure_dense()
        de = self._normalize(self.dense.search(query, k=self.cfg.top_k_per_snapshot))
        candidate_ids = sorted(set(bm) | set(de))
        candidates = [(i, self.cfg.bm25_weight * bm.get(i, 0.0) + self.cfg.dense_weight * de.get(i, 0.0)) for i in candidate_ids]
        candidates.sort(key=lambda x: x[1], reverse=True)
        candidates = candidates[: max(k * 4, self.cfg.top_k_per_snapshot)]

        if self.cfg.rerank_weight > 0 and candidates:
            self.ensure_reranker()
            sub_docs = [self.docs[i] for i, _ in candidates]
            rer_scores = self.reranker.score(query, sub_docs)
            max_r = max(rer_scores) if rer_scores else 1.0
            min_r = min(rer_scores) if rer_scores else 0.0
            denom = (max_r - min_r) or 1.0
            candidates = [
                (i, hyb + self.cfg.rerank_weight * (rs - min_r) / denom)
                for (i, hyb), rs in zip(candidates, rer_scores)
            ]
            candidates.sort(key=lambda x: x[1], reverse=True)

        out: list[Evidence] = []
        for i, score in candidates[:k]:
            ev = self.evidences[i]
            ev.score = float(score)
            out.append(ev)
        return out


class MultiSnapshotRetriever:
    """Holds per-snapshot retrievers and merges by union or per-snapshot top-K."""

    def __init__(self, retrievers: dict[str, HybridRetriever], snapshot_order: list[str] | None = None):
        self.retrievers = retrievers
        self.order = snapshot_order or list(retrievers.keys())

    def search(self, query: str, k_per_snapshot: int = 8, total_k: int | None = None) -> list[Evidence]:
        per: list[Evidence] = []
        for snap_id in self.order:
            ret = self.retrievers[snap_id]
            evs = ret.search(query, k=k_per_snapshot)
            for e in evs:
                e.snapshot_id = snap_id
            per.extend(evs)
        per.sort(key=lambda e: e.score, reverse=True)
        if total_k:
            per = per[:total_k]
        return per
