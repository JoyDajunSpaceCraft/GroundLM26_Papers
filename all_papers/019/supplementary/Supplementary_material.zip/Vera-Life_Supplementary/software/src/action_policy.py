"""Risk-Calibrated Action Policy.

Implements the three risk dimensions used by VERA-LIFE
(insufficiency, stale, conflict) together with a policy head that
maps a feature vector to an action.

Two parallel paths:

- :func:`rule_policy`     : deterministic thresholds (default at inference)
- :class:`LearnedPolicy`  : light-weight LR/MLP/LightGBM trained from
                            oracle data (the optional <= 200-parameter
                            head referenced in the paper)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from .types import Action, QuestionType


@dataclass
class RiskScores:
    insufficient: float
    stale: float
    conflict: float


@dataclass
class PolicyThresholds:
    theta_insuf: float = 0.4
    theta_stale: float = 0.5
    theta_conf: float = 0.5
    max_retrieval_iters: int = 2


def compute_risks(coverage: float, max_validity: float, max_contradict: float) -> RiskScores:
    """Build the three risk components from system signals."""
    risk_insuf = 1.0 - max(min(coverage, 1.0), 0.0)
    risk_stale = 1.0 - max(min(max_validity, 1.0), 0.0)
    risk_conf = max(min(max_contradict, 1.0), 0.0)
    return RiskScores(risk_insuf, risk_stale, risk_conf)


def rule_policy(risk: RiskScores,
                thresholds: PolicyThresholds,
                retrieval_iter: int = 0,
                qtype: str | None = None) -> Action:
    """Map risk signals + question type to one of the five actions.

    ``qtype`` (when provided) is used to disambiguate ``past`` and
    ``stale_verify`` questions, which both involve historical
    evidence but require different surface actions:

    - ``past``         -> ANSWER (return the historic value at t_q)
    - ``stale_verify`` -> WARN_STALE (warn that the cited value is no
                                       longer current)
    """
    qtype = (qtype or "").lower()
    # 1. Strong conflict trumps everything.
    if risk.conflict >= thresholds.theta_conf:
        return Action.EXPLAIN_CONFLICT

    # 2. STALE_VERIFY questions: warn whenever the user-cited value is
    #    not the current value.
    if qtype in {"stale_verify", "stale"}:
        if risk.stale >= thresholds.theta_stale:
            return Action.WARN_STALE
        return Action.ANSWER

    # 3. PAST questions: answer the historic value when evidence is
    #    sufficient; abstain only if the retrieval pool is empty.
    if qtype in {"past", "past_valid"}:
        if risk.insufficient < thresholds.theta_insuf:
            return Action.ANSWER
        if retrieval_iter < thresholds.max_retrieval_iters:
            return Action.RETRIEVE_MORE
        return Action.ABSTAIN

    # 4. Standard policy.
    if (risk.insufficient < thresholds.theta_insuf and
            risk.stale < thresholds.theta_stale and
            risk.conflict < thresholds.theta_conf):
        return Action.ANSWER
    if risk.stale >= thresholds.theta_stale and risk.conflict < thresholds.theta_conf:
        return Action.WARN_STALE
    if risk.insufficient >= thresholds.theta_insuf and retrieval_iter < thresholds.max_retrieval_iters:
        return Action.RETRIEVE_MORE
    return Action.ABSTAIN


@dataclass
class LearnedPolicy:
    """Lightweight wrapper that loads either LR / LightGBM / MLP.

    The default backend is LR with 9 features x 5 actions = 45 weights
    + 5 biases = 50 parameters, well below the <=200 parameter budget
    quoted in the paper.
    """

    backend: str = "lr"
    model: Any = None
    feature_names: list[str] = field(default_factory=list)
    actions: list[str] = field(default_factory=lambda: [a.value for a in Action])

    def fit(self, X: np.ndarray, y: np.ndarray):
        if self.backend == "lr":
            from sklearn.linear_model import LogisticRegression
            self.model = LogisticRegression(max_iter=2000, multi_class="auto")
            self.model.fit(X, y)
        elif self.backend == "lgbm":
            import lightgbm as lgb
            self.model = lgb.LGBMClassifier(num_leaves=31, n_estimators=200, learning_rate=0.05)
            self.model.fit(X, y)
        elif self.backend == "mlp":
            from sklearn.neural_network import MLPClassifier
            self.model = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=300, random_state=0)
            self.model.fit(X, y)
        else:
            raise ValueError(f"unknown backend {self.backend}")
        return self

    def predict(self, x: np.ndarray) -> Action:
        if self.model is None:
            raise RuntimeError("policy not fitted")
        idx = int(self.model.predict(x.reshape(1, -1))[0])
        return Action(self.actions[idx])

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        if hasattr(self.model, "predict_proba"):
            return self.model.predict_proba(x.reshape(1, -1))[0]
        return np.ones(len(self.actions)) / len(self.actions)
