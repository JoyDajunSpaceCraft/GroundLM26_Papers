"""Temporal Intent Parser.

Lightweight parser that extracts t_q, question type, entities, and
knowledge velocity from a natural-language question.  Combines:

1. deterministic regex (years, "current", "as of X", "between X and
   Y", "in 2020", "still", "no longer", ...)
2. lexicon-based knowledge-velocity classifier
3. LLM-based JSON extraction (optional fallback)

In the paper's controller, the parser additionally emits a
question-type hint that the policy uses to decide whether the user's
target is a *historical* state (past split) or the current state.
This module makes that hint explicit so that downstream callers do
not have to re-derive it from the question text.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass

from .types import Question, QuestionType


YEAR_RE = re.compile(r"\b(1[5-9]\d{2}|20\d{2}|21\d{2})\b")
RANGE_RE = re.compile(r"between\s+(\d{4})\s+and\s+(\d{4})", re.I)
AS_OF_RE = re.compile(r"as\s+of\s+(\d{4})", re.I)
IN_YEAR_RE = re.compile(r"\bin\s+(\d{4})\b", re.I)
DURING_YEAR_RE = re.compile(r"\bduring\s+(\d{4})\b", re.I)
BY_YEAR_RE = re.compile(r"\bby\s+(\d{4})\b", re.I)

CURRENT_TOKENS = {"current", "currently", "now", "today", "present",
                  "this year", "right now", "latest"}
PAST_TOKENS = {"was", "were", "former", "previous", "previously",
               "history", "during", "until", "at the time"}
CHANGE_TOKENS = {"change", "changed", "succeed", "replace", "after", "before"}
STALE_VERIFY_TOKENS = {"still", "remain", "remains", "stay", "stays",
                       "valid", "no longer"}
CONFLICT_TOKENS = {"conflict", "disagree", "contradict"}


@dataclass
class ParsedIntent:
    t_q: int | None
    qtype: QuestionType
    knowledge_velocity: str
    entities: list[str]


def detect_year(text: str, t_eval: int = 2024) -> int | None:
    """Return the most likely target year referenced by the question.

    Priority order: explicit ``as of YYYY`` -> ``in YYYY`` ->
    ``during YYYY`` -> ``by YYYY`` -> last bare year in the question.
    Falls back to ``t_eval`` (the evaluation snapshot) when the
    question contains a "current"/"now"/"today" token; returns ``None``
    when no explicit year and no current-token is present.
    """
    m = AS_OF_RE.search(text)
    if m:
        return int(m.group(1))
    m = IN_YEAR_RE.search(text)
    if m:
        return int(m.group(1))
    m = DURING_YEAR_RE.search(text)
    if m:
        return int(m.group(1))
    m = BY_YEAR_RE.search(text)
    if m:
        return int(m.group(1))
    matches = YEAR_RE.findall(text)
    if matches:
        return int(matches[-1])
    if any(tok in text.lower() for tok in CURRENT_TOKENS):
        return t_eval
    return t_eval  # default to evaluation snapshot (implicit "now")


def detect_qtype(text: str) -> QuestionType:
    low = text.lower()
    # Stale-verify takes precedence over PAST since "still"-style
    # questions almost always carry a past-cited value to verify.
    if any(tok in low for tok in STALE_VERIFY_TOKENS) and ("still" in low or low.startswith("is ")):
        return QuestionType.STALE_VERIFY
    if any(tok in low for tok in CONFLICT_TOKENS):
        return QuestionType.CONFLICT
    if RANGE_RE.search(low):
        return QuestionType.CHANGE
    if any(tok in low for tok in CHANGE_TOKENS):
        return QuestionType.CHANGE
    if any(tok in low for tok in PAST_TOKENS):
        return QuestionType.PAST
    # If the text contains a "in YYYY" anchored to a non-current year
    # we treat it as a past-time-of-interest question.
    m = IN_YEAR_RE.search(text)
    if m:
        try:
            yr = int(m.group(1))
            if yr <= 2023:  # any pre-snapshot year => past-style
                return QuestionType.PAST
        except ValueError:
            pass
    return QuestionType.CURRENT


def detect_velocity(text: str, relation: str = "") -> str:
    low = text.lower()
    if any(tok in low for tok in {"ceo", "president", "chairperson",
                                   "head coach", "minister", "prime minister"}):
        return "fast"
    if any(tok in low for tok in {"capital", "founding", "born", "founded"}):
        return "static"
    if any(tok in relation for tok in {"sports_team", "head_coach", "ceo"}):
        return "fast"
    return "unknown"


def parse_question(text: str, qid: str = "", t_eval: int = 2024,
                   relation: str = "") -> Question:
    qtype = detect_qtype(text)
    # For STALE_VERIFY we anchor t_q on the evaluation snapshot ("today")
    # regardless of any year string that appears inside the quoted
    # original question.
    if qtype == QuestionType.STALE_VERIFY:
        t_q = t_eval
    else:
        t_q = detect_year(text, t_eval=t_eval)
    velocity = detect_velocity(text, relation)
    return Question(
        qid=qid or text[:32],
        text=text,
        t_q=t_q,
        qtype=qtype,
        knowledge_velocity=velocity,
        entities=[],
        relation=relation,
    )


PROMPT = """Extract temporal intent of the question.
Return JSON only with keys: t_q (int or null), qtype (current/past/stale_verify/change/conflict/multi_hop), velocity (static/slow/fast/versioned/unknown), entities (list of strings).
Question: {q}
JSON:"""


def parse_with_llm(question_text: str, llm_call) -> dict:
    """Optional LLM-based parser; llm_call is a function (str)->str."""
    raw = llm_call(PROMPT.format(q=question_text))
    try:
        return json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
    except Exception:  # noqa: BLE001
        return {}
