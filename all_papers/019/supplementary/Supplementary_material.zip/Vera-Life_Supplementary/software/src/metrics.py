"""Evaluation metrics for VERA-LIFE.

Implements the lifecycle-faithfulness metric family reported in the
paper:

- AnswerF1
- LifecycleEM (LifeEM)
- TemporalEvidenceF1
- SupersessionDetectionF1
- StaleRejectionRate (SRR)
- OverAbstentionRate (OAR)
- CounterfactualUpdateRobustness (CUR)
- LifecycleCalibrationError (LCE)
- SafeUtility (composite)

A single ``lifecycle_em`` implementation is used everywhere in the code
base (``08_run_llm_experiments.py``, ``12_bootstrap_ci.py``,
``16_eval_qlora_ledger.py``, ``17_real_mini_eval.py``,
``18_real_blind_eval.py``).  All four callers serialise their per-row
predictions to the same ``{answer, interval, state}`` record schema and
delegate the comparison to :func:`lifecycle_em` defined below.
"""

from __future__ import annotations

import math
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable, Sequence

import numpy as np

from .types import Action, LedgerEntry, LifecycleState


# ---------------------------------------------------------------------- #
#   Token / answer level helpers
# ---------------------------------------------------------------------- #
def _norm_tokens(s: str) -> list[str]:
    return re.findall(r"\w+", (s or "").lower())


def token_f1(pred: str, gold: str) -> float:
    p = _norm_tokens(pred)
    g = _norm_tokens(gold)
    if not p or not g:
        return 0.0
    common: dict[str, int] = {}
    for t in p:
        common[t] = common.get(t, 0) + 1
    overlap = 0
    for t in g:
        if common.get(t, 0) > 0:
            common[t] -= 1
            overlap += 1
    if overlap == 0:
        return 0.0
    pr = overlap / len(p)
    rc = overlap / len(g)
    return 2 * pr * rc / (pr + rc) if (pr + rc) else 0.0


def answer_f1(predictions: Sequence[str], gold_answers: Sequence[Sequence[str]]) -> float:
    if not predictions:
        return 0.0
    return float(np.mean([
        max((token_f1(pred, g) for g in golds), default=0.0)
        for pred, golds in zip(predictions, gold_answers)
    ]))


def loose_em(pred: str, gold: str) -> float:
    p = re.sub(r"\W+", " ", (pred or "").lower()).strip()
    g = re.sub(r"\W+", " ", (gold or "").lower()).strip()
    if not p or not g:
        return 0.0
    return 1.0 if g in p or p == g else 0.0


# ---------------------------------------------------------------------- #
#   Interval IoU
# ---------------------------------------------------------------------- #
def _coerce_interval(iv):
    """Normalise an interval representation into a (start, end) int pair.

    Open-ended intervals (``None`` upper bound) are interpreted as
    extending to ``9999``; ``None`` lower bounds are interpreted as
    ``0``.  Returns ``None`` if the interval is fundamentally invalid
    (both endpoints missing or non-coercible).
    """
    if iv is None:
        return None
    if isinstance(iv, dict):
        iv = (iv.get("start"), iv.get("end"))
    if not isinstance(iv, (tuple, list)) or len(iv) < 2:
        return None
    s, e = iv[0], iv[1]
    if s is None and e is None:
        return None
    try:
        s_int = 0 if s is None else int(s)
        e_int = 9999 if e is None else int(e)
    except (TypeError, ValueError):
        return None
    if e_int < s_int:
        s_int, e_int = e_int, s_int
    return s_int, e_int


def interval_iou(pred, gold) -> float:
    p = _coerce_interval(pred)
    g = _coerce_interval(gold)
    if p is None or g is None:
        return 0.0
    ps, pe = p
    gs, ge = g
    inter_s = max(ps, gs)
    inter_e = min(pe, ge)
    union_s = min(ps, gs)
    union_e = max(pe, ge)
    if inter_e < inter_s:
        return 0.0
    if union_e <= union_s:
        return 1.0
    return (inter_e - inter_s) / (union_e - union_s)


# ---------------------------------------------------------------------- #
#   LifeEM (canonical definition; used by every caller)
# ---------------------------------------------------------------------- #
def _norm_state(s) -> str:
    if s is None:
        return ""
    if hasattr(s, "value"):
        return str(s.value)
    return str(s).strip().lower()


def _answer_matches(pred_ans: str, gold_ans: str) -> bool:
    """Lifecycle answer-equivalence test.

    Accepts an answer when (i) it exactly matches the gold up to
    whitespace and case, (ii) the gold appears verbatim in the
    prediction, or (iii) token-F1 with the gold is at least 0.5.
    The third condition is needed because action-conditioned
    surface forms (e.g. "no longer current; was Person A")
    legitimately contain extra tokens around the gold answer.
    """
    if pred_ans is None or gold_ans is None:
        return False
    p = re.sub(r"\W+", " ", str(pred_ans).lower()).strip()
    g = re.sub(r"\W+", " ", str(gold_ans).lower()).strip()
    if not p or not g:
        return False
    if p == g or g in p:
        return True
    return token_f1(pred_ans, gold_ans) >= 0.5


def lifecycle_em(predictions: Sequence[dict],
                 golds: Sequence[dict],
                 iou_thresh: float = 0.5) -> float:
    """Lifecycle Exact-Match score (canonical implementation).

    Each prediction / gold record must be a ``dict`` with three keys:

    - ``answer`` (str)        : surface answer string
    - ``interval`` (tuple)    : (start_year_or_None, end_year_or_None)
    - ``state``  (str or enum): one of {current, past_valid, stale,
                                superseded, conflicting, insufficient}

    A prediction is credited when all three conditions hold:
    semantic answer match, interval IoU >= ``iou_thresh``, and an
    exact state match.
    """
    if not predictions:
        return 0.0
    matches = 0
    for p, g in zip(predictions, golds):
        p_state = _norm_state(p.get("state", ""))
        g_state = _norm_state(g.get("state", ""))
        if p_state != g_state:
            continue
        if interval_iou(p.get("interval"), g.get("interval")) < iou_thresh:
            continue
        if not _answer_matches(p.get("answer", ""), g.get("answer", "")):
            continue
        matches += 1
    return matches / len(predictions)


# ---------------------------------------------------------------------- #
#   Evidence / supersession F1
# ---------------------------------------------------------------------- #
def prf(pred: set, gold: set) -> tuple[float, float, float]:
    if not pred or not gold:
        return 0.0, 0.0, 0.0
    inter = pred & gold
    p = len(inter) / len(pred)
    r = len(inter) / len(gold)
    f = 2 * p * r / (p + r) if (p + r) else 0.0
    return p, r, f


def temporal_evidence_f1(pred_evs: Sequence[set], gold_valid_evs: Sequence[set]) -> float:
    f1s = [prf(p, g)[2] for p, g in zip(pred_evs, gold_valid_evs)]
    return float(np.mean(f1s)) if f1s else 0.0


def supersession_f1(pred_super: Sequence[bool], gold_super: Sequence[bool]) -> float:
    tp = sum(1 for p, g in zip(pred_super, gold_super) if p and g)
    fp = sum(1 for p, g in zip(pred_super, gold_super) if p and not g)
    fn = sum(1 for p, g in zip(pred_super, gold_super) if not p and g)
    p = tp / max(1, tp + fp)
    r = tp / max(1, tp + fn)
    return 2 * p * r / (p + r) if (p + r) else 0.0


# ---------------------------------------------------------------------- #
#   Action-conditioned rates
# ---------------------------------------------------------------------- #
def stale_rejection_rate(actions: Sequence[Action], stale_mask: Sequence[bool]) -> float:
    n = sum(stale_mask)
    if n == 0:
        return 0.0
    hits = sum(1 for a, m in zip(actions, stale_mask)
               if m and a in (Action.WARN_STALE, Action.ABSTAIN))
    return hits / n


def over_abstention_rate(actions: Sequence[Action], answerable_mask: Sequence[bool]) -> float:
    n = sum(answerable_mask)
    if n == 0:
        return 0.0
    hits = sum(1 for a, m in zip(actions, answerable_mask) if m and a == Action.ABSTAIN)
    return hits / n


def counterfactual_update_robustness(predictions: Sequence[dict]) -> float:
    n = len(predictions)
    if n == 0:
        return 0.0
    return sum(1 for p in predictions
               if p.get("old_correct") and p.get("new_correct")) / n


# ---------------------------------------------------------------------- #
#   Calibration
# ---------------------------------------------------------------------- #
def lifecycle_calibration_error(confidences: Sequence[float],
                                correctness: Sequence[bool],
                                bins: int = 10) -> float:
    if not confidences:
        return 0.0
    confidences = np.asarray(confidences, dtype=float)
    correctness = np.asarray(correctness, dtype=float)
    n = len(confidences)
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for i in range(bins):
        mask = (confidences > edges[i]) & (confidences <= edges[i + 1])
        if mask.sum() == 0:
            continue
        acc = correctness[mask].mean()
        conf = confidences[mask].mean()
        ece += (mask.sum() / n) * abs(acc - conf)
    return float(ece)


# ---------------------------------------------------------------------- #
#   Composite SafeUtility
# ---------------------------------------------------------------------- #
@dataclass
class CompositeWeights:
    lambda_temp: float = 0.5
    lambda_sup: float = 0.4
    lambda_srr: float = 0.4
    lambda_cur: float = 0.4
    lambda_oar: float = 0.5
    lambda_lce: float = 0.5


def safe_utility(life_em: float, temp_f1: float, sup_f1: float,
                 srr: float, cur: float, oar: float, lce: float,
                 w: CompositeWeights | None = None) -> float:
    w = w or CompositeWeights()
    return (life_em
            + w.lambda_temp * temp_f1
            + w.lambda_sup * sup_f1
            + w.lambda_srr * srr
            + w.lambda_cur * cur
            - w.lambda_oar * oar
            - w.lambda_lce * lce)
