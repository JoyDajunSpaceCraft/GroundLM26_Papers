"""Core data types for VERA-LIFE."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class LifecycleState(str, Enum):
    CURRENT = "current"
    PAST_VALID = "past_valid"
    STALE = "stale"
    SUPERSEDED = "superseded"
    CONFLICTING = "conflicting"
    INSUFFICIENT = "insufficient"


class Action(str, Enum):
    ANSWER = "answer"
    WARN_STALE = "warn_stale"
    EXPLAIN_CONFLICT = "explain_conflict"
    RETRIEVE_MORE = "retrieve_more"
    ABSTAIN = "abstain"


class EdgeType(str, Enum):
    SUPPORT = "support"
    UPDATE = "update"
    SUPERSEDE = "supersede"
    CONTRADICT = "contradict"
    EXPIRE = "expire"
    DUPLICATE = "duplicate"


class QuestionType(str, Enum):
    CURRENT = "current"
    PAST = "past"
    STALE_VERIFY = "stale_verify"
    CHANGE = "change"
    CONFLICT = "conflict"
    MULTI_HOP = "multi_hop"


@dataclass
class Evidence:
    """A piece of evidence drawn from the corpus."""
    eid: str
    text: str
    timestamp: str = ""           # ISO date or year string (e.g. "2024-04-01")
    source_type: str = "wiki"     # wiki / wikidata / openalex / news
    source_uri: str = ""
    snapshot_id: str = ""
    score: float = 0.0            # retrieval score
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Fact:
    """Structured lifecycle fact (s, p, o, [t_start, t_end], provenance)."""
    fact_id: str
    subject: str
    predicate: str
    obj: str
    t_start: int | None = None    # year
    t_end: int | None = None
    provenance: str = ""
    relation: str = ""
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class Claim:
    """Atomic claim extracted from the model answer."""
    cid: str
    text: str
    subject: str = ""
    predicate: str = ""
    obj: str = ""
    t_start: int | None = None
    t_end: int | None = None


@dataclass
class LedgerEntry:
    """One row of the lifecycle ledger that backs the answer."""
    claim: Claim
    evidence_ids: list[str]
    interval: tuple[int | None, int | None] = (None, None)
    state: LifecycleState = LifecycleState.INSUFFICIENT
    confidence: float = 0.0


@dataclass
class Question:
    """User question with its temporal intent."""
    qid: str
    text: str
    t_q: int | None = None                   # target year
    qtype: QuestionType = QuestionType.CURRENT
    knowledge_velocity: str = "unknown"      # static/slow/fast/versioned/unknown
    entities: list[str] = field(default_factory=list)
    relation: str = ""
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class SystemOutput:
    answer: str
    ledger: list[LedgerEntry]
    action: Action
    used_evidence: list[Evidence] = field(default_factory=list)
    risks: dict[str, float] = field(default_factory=dict)
