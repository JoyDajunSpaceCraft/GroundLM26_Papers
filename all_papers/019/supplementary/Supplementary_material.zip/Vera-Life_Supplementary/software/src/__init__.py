"""VERA-LIFE: Versioned Evidence Reliability Assessment and Lifecycle Intervention."""

__version__ = "0.1.0"
