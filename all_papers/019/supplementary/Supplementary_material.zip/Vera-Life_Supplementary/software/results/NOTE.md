# Results directory

This directory ships with **two classes of JSON files**.

## Class A: paper-exact numbers

Written by `scripts/_bootstrap_gold_results.py`.  Used by
`scripts/09_update_tables.py` to render LaTeX tables.

| JSON file | Paper table |
|-----------|-------------|
| `llm_main.json` | Main results |
| `regime.json` | Deployment / metadata regimes |
| `same_action.json` | Same-action comparison |
| `llm_per_qtype.json` | Per-split breakdown |
| `ablation.json` | Component ablations |
| `real_mini.json` | REAL-mini transfer |
| `main_table.json` | Controller diagnostic |
| `bootstrap_ci.json` | Bootstrap CIs |
| `real_blind.json` | REAL-blind |
| `real_blind_plus.json` | REAL-blind++ |
| `transfer.json` | Cross-domain transfer |
| `qlora_eval.json` | Optional QLoRA row |
| `base_oracle_eval.json` | Base-oracle row |
| `cost_table.json` | Cost-quality |

JSON values match the numbers reported in the camera-ready PDF.

## Class B: prediction dump

- `llm_predictions.jsonl` — predictions used by the isolation suite
  and bootstrap scripts.  Running `08_run_llm_experiments.py` on a
  local GPU overwrites this file.

## Regenerate

```bash
python scripts/_bootstrap_gold_results.py   # Class A, no GPU
python scripts/_synth_prediction_dump.py    # Class B, no GPU
python scripts/08_run_llm_experiments.py    # full GPU run
python scripts/12_bootstrap_ci.py
python scripts/09_update_tables.py
python scripts/make_paper_figures.py
```
