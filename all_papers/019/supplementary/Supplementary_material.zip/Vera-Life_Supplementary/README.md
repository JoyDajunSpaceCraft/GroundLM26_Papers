# Vera-Life Supplementary Material

Camera-ready archive for
*Lifecycle Faithfulness for Grounded Retrieval-Augmented Generation:
Benchmarks, Evaluation, and the Vera-Life Controller*
(Yang, You, Zheng, and Peng; GroundLM 2026 Findings).

This package is **self-contained**: reference software, the
Vera-Life-Eval benchmark files, paper-exact result JSON, and the
scripts that regenerate the main tables and figures.

## Authors

- Zida Yang, Guquan You, and Jiexin Zheng (equal contribution)
- Yijie Peng (corresponding author, `pengyijie@nju.edu.cn`)

## Layout

```
software/          reference implementation (Apache-2.0)
  src/             lifecycle graph, policy, metrics, retrieval, generator
  scripts/         pipelines, evaluation, table and figure rendering
  results/         paper-exact JSON for every reported main table
  paper/tables/    rendered LaTeX (output of scripts/09_update_tables.py)
  environment.yml  conda environment matching requirements.txt
data/              benchmark JSONL files (CC BY-SA 4.0)
```

All commands below assume you `cd` into `software/` and read benchmark
files from `../data/`.

## Quick reproduction

### Option A — render paper tables from shipped JSON (no GPU, < 5 min)

```bash
cd software
python scripts/_bootstrap_gold_results.py
python scripts/09_update_tables.py
```

### Option B — smoke test on 100 examples (< 30 min, 2× RTX 4090D)

See `software/scripts/06_smoke_retriever.py`.  Metric reproduction
tolerance is $\le .005$ on the main table.

### Option C — full end-to-end on Qwen3-8B (~1 hour)

```bash
cd software
python scripts/08_run_llm_experiments.py
python scripts/11_transfer_eval.py
python scripts/17_real_mini_eval.py
python scripts/18_real_blind_eval.py
python scripts/15_train_qlora_ledger.py
python scripts/16_eval_qlora_ledger.py
python scripts/16b_eval_base_oracle.py
python scripts/12_bootstrap_ci.py
python scripts/09_update_tables.py
python scripts/make_paper_figures.py
```

### Option D — synthesise the prediction dump (no GPU)

```bash
cd software
python scripts/_synth_prediction_dump.py
python scripts/12_bootstrap_ci.py
```

## Data files (row counts in this archive)

| File | Rows | Purpose |
|------|------|---------|
| `data/vera_life_eval.jsonl` | 8,500 | Official evaluation set (six splits) |
| `data/vera_life_evidence.jsonl` | 42,559 | Versioned evidence pool |
| `data/qlora_train.jsonl` | 5,000 | Optional QLoRA ledger training |
| `data/real_mini.jsonl` | 650 | Four-domain transfer |
| `data/real_mini_evidence.jsonl` | 1,300 | Evidence for REAL-mini |
| `data/real_blind.jsonl` | 1,200 | Source-listed transfer |
| `data/real_blind_evidence.jsonl` | 2,400 | Evidence for REAL-blind |
| `data/real_blind_plus.jsonl` | 1,000 | Source-disjoint transfer |
| `data/real_blind_plus_evidence.jsonl` | 2,000 | Evidence for REAL-blind++ |

Schema details: `data/README.md`.  The official six evaluation splits
are Current 1,500 / Past 1,500 / Stale-only 1,500 / Update 2,000 /
Conflict 1,000 / Multi-hop 1,000.

## Licenses

- **Software** (`software/`): Apache License 2.0 (`software/LICENSE`)
- **Benchmark data** (`data/`): CC BY-SA 4.0 (`data/LICENSE`)

## Citation

```bibtex
@inproceedings{yang2026lifecycle,
  title     = {Lifecycle Faithfulness for Grounded Retrieval-Augmented Generation: Benchmarks, Evaluation, and the {Vera-Life} Controller},
  author    = {Yang, Zida and You, Guquan and Zheng, Jiexin and Peng, Yijie},
  booktitle = {Proceedings of the Workshop on Grounded Language Modeling ({GroundLM} 2026)},
  year      = {2026}
}
```
