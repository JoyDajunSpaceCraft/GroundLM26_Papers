# Vera-Life Benchmark Data

Versioned evaluation data for
*Lifecycle Faithfulness for Grounded Retrieval-Augmented Generation:
Benchmarks, Evaluation, and the Vera-Life Controller*
(Yang, You, Zheng, and Peng; GroundLM 2026 Findings).

Licensed under **CC BY-SA 4.0** (see `LICENSE`).
Package overview: **`../README.md`**.

## Files

| File | Rows | Purpose |
|------|------|---------|
| `vera_life_eval.jsonl` | 8,500 | Official evaluation set (six splits) |
| `vera_life_evidence.jsonl` | 42,559 | Versioned evidence pool |
| `qlora_train.jsonl` | 5,000 | Optional QLoRA ledger training |
| `real_mini.jsonl` | 650 | Four-domain transfer |
| `real_mini_evidence.jsonl` | 1,300 | Evidence for REAL-mini |
| `real_blind.jsonl` | 1,200 | Source-listed transfer |
| `real_blind_evidence.jsonl` | 2,400 | Evidence for REAL-blind |
| `real_blind_plus.jsonl` | 1,000 | Source-disjoint transfer |
| `real_blind_plus_evidence.jsonl` | 2,000 | Evidence for REAL-blind++ |

## REAL-mini domains

| Domain | n | Sources |
|--------|---|---------|
| product_api | 180 | Release notes (Stripe, AWS, OpenAI, React, \ldots) |
| policy_legal | 160 | Amended statutes, repealed regulations, overruled cases |
| scientific_medical | 140 | Retracted papers, guideline reversals, withdrawn drugs |
| news_correction | 170 | Editorial corrections (NYT, WaPo, Reuters, AP, BBC, \ldots) |

## Schema (question row)

```jsonc
{
  "qid": "rm_news_correction_0023_update_007",
  "question": "After the 2024 update, what is the new ...",
  "qtype": "update",
  "gold_answer": "outage 1M users",
  "gold_action": "answer",
  "lifecycle_state_gold": "current",
  "valid_interval": [2024, null],
  "t_q": 2024,
  "evidence_pool": ["rm_news_correction_0023_old", "rm_news_correction_0023_new"]
}
```

## `meta.role` convention

The `meta.role` field in evidence rows encodes gold-construction roles
(`current` vs `superseded`).  The reference pipeline **strips** `meta.role`
and `snapshot_id` before any baseline or retriever sees them.

## Citation

```bibtex
@inproceedings{yang2026lifecycle,
  title     = {Lifecycle Faithfulness for Grounded Retrieval-Augmented Generation: Benchmarks, Evaluation, and the {Vera-Life} Controller},
  author    = {Yang, Zida and You, Guquan and Zheng, Jiexin and Peng, Yijie},
  booktitle = {Proceedings of the Workshop on Grounded Language Modeling ({GroundLM} 2026)},
  year      = {2026}
}
```
