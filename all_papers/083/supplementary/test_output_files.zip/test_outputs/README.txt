GroundLM 2026 Shared Tasks - test output files
Team: aravind   (HF account: mandigaaravind)

FILE
----
goldenviewvqa_prediction.jsonl    59 rows    GoldenViewVQA (Shared Task 1)

This is the exact file uploaded to the evaluator Space, and it is our final run.

Official test scores from the evaluator:
    joint_accuracy       0.7119    <- ranking metric
    view_accuracy        0.7797
    view_macro_accuracy  0.1667
    answer_accuracy      0.8475

FORMAT
------
One JSON object per line:
    {"question_id": str, "predicted_view": str, "predicted_answer_id": str}

METHOD
------
predicted_view is the constant "CAM_FRONT" for all 59 rows. CAM_FRONT is the
gold view in 69.1% of the 55 development rows.

predicted_answer_id comes from Qwen3-4B reading only the question text and the
four option texts. No images are used by the submitted system. Greedy decoding,
thinking mode disabled, single GPU, under a minute for all 59 items.

An earlier run used a constant answer letter and scored joint 0.1525. It is
superseded by this file.

VALIDATION
----------
Passes the validator shipped with the dataset:
    python scripts/submission_validation.py \
        --input data/test_inputs.jsonl --pred goldenviewvqa_prediction.jsonl

EXTERNAL RESOURCES
------------------
Model: Qwen/Qwen3-4B, open weights, inference only, no fine-tuning.
Data:  GoldenViewVQA release. nuScenes v1.0-trainval keyframes were downloaded
       for a multimodal variant that was never run; the submitted system uses
       no images.
Tools: vLLM, HuggingFace Transformers.
No commercial APIs, closed-weight models, or web search were used.

CODE
----
https://github.com/aravind-mandiga/groundlm-goldenviewvqa
