# Anonymous supplementary material for Submission 93

This is the single, self-contained supplementary archive for the anonymous
submission. It combines the completed GPT-4.1 and DeepSeek-V3.2 factorial
audits with the recovered 40-query K=3 analysis. It contains frozen inputs,
complete request/completion text, analysis code, outputs, final manuscript
table inputs, and checksums. It contains no manuscript source, author names,
affiliations, contact details, API credentials, provider completion IDs, or
machine-specific paths.

## Contents

- `data/`: frozen 29-query factorial inputs, protocol, prompt examples, and
  model-specific protocol amendments.
- `runs/gpt41_greatrouter_20260913/`: the complete GPT-4.1 factorial run.
- `runs/deepseek_v32_20260912/`: the complete DeepSeek-V3.2 factorial run.
- `run.py`, `report_factorial.py`, `verify_factorial_intervals.py`: shared
  offline analysis, reporting, and independent interval verification code.
- `primary_k3/`: 40 recovered two-order records, frozen manifest, protocol,
  analysis code, and all derived K=3/routing outputs.
- `paper_tables/`: the final TeX/JSON table inputs used by the manuscript.
- `MANIFEST.sha256`: SHA-256 checksums for every other file in this archive.

## Environment

Python 3.10+ is recommended. Install the small dependency set with:

```sh
python3 -m pip install -r requirements.txt
```

The commands below are offline and make no API calls.

## Reproduce the factorial analyses

```sh
python3 run.py analyze --stage factorial --model gpt-4.1   --run-dir runs/gpt41_greatrouter_20260913
python3 report_factorial.py   --run-dir runs/gpt41_greatrouter_20260913   --tex-dir reproduced_tables/gpt41   --protocol-amendment data/gpt41_greatrouter_amendment_20260913.json
python3 verify_factorial_intervals.py   --run-dir runs/gpt41_greatrouter_20260913

python3 run.py analyze --stage factorial --model deepseek-v3.2   --run-dir runs/deepseek_v32_20260912
python3 report_factorial.py   --run-dir runs/deepseek_v32_20260912   --tex-dir reproduced_tables/deepseek_v32   --protocol-amendment data/deepseek_v32_amendment_20260912.json
python3 verify_factorial_intervals.py   --run-dir runs/deepseek_v32_20260912
```

Each factorial batch has 29 queries, 87 response pairs, 16 conditions, both
orders, and 2,784 formal tasks. The raw JSONL keeps full prompts/completions,
finish reasons, model IDs, usage, timing, and failed attempts; provider-issued
completion IDs were removed for anonymous review. Removing those identifiers
does not change any experimental input, output text, parser decision, or
statistic. The local default path for the unused preparation/K4 fallback was
also replaced by a neutral relative placeholder. The recorded runner hashes
were updated to match this anonymous copy; the original source packages were
not modified.

## Reproduce the primary K=3/routing analysis

```sh
python3 primary_k3/analyze.py
```

This verifies the 40 record hashes and recomputes the paired categories,
query-level outcomes, sensitivity analysis, pool transitions, and held-out
routing comparison. No API call or training is performed.

## Interpretation and provenance boundaries

The 29-query factorial set is a fixed available full-response subset, not a
random sample. The 40-query K=3 batch is separate and does not reconstruct the
unavailable historical K=4 pooled judgments. GPT-4.1 and DeepSeek-V3.2 model
and provider identifiers are retained because they are experimental provenance,
not author identity. API responses do not independently establish immutable
model weights or equivalence to a historical snapshot.

The archived benchmark prompts and model responses are preserved byte-for-byte
except for provider completion IDs. They may contain illustrative names,
example email addresses, phone numbers, paths, or other strings occurring in
the evaluated prompt text; these are experimental content, not author contact
information.

This archive is provided under `REVIEW_ONLY_LICENSE.txt`. It is not a public
open-source release and does not assert that any submission-form open-source
code option was selected.
