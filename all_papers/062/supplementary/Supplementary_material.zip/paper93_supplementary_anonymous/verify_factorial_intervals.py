import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random

import numpy as np


ROOT = Path(__file__).resolve().parent
FACTORS = ['reasoning', 'numeric_labels', 'allow_tie', 'verdict_prefix']
METRICS = ['directional', 'explicit_tie', 'swap_failure', 'invalid', 'first_position_share', 'second_position_share']


def read_json(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', type=Path, required=True)
    args = parser.parse_args()
    stage = args.run_dir / 'factorial'
    analysis = read_json(stage / 'analysis.json')
    assert analysis['complete'] and analysis['recorded_tasks'] == 2784
    manifest = read_json(stage / 'run_config.json')
    assert hashlib.sha256((ROOT / 'data/protocol.json').read_bytes()).hexdigest() == manifest['protocol_sha256']
    attempts = [json.loads(line) for line in (stage / 'raw.jsonl').read_text().splitlines()]
    successes = [row for row in attempts if row['status'] == 'ok']
    task_counts = Counter(row['task_id'] for row in successes)
    assert len(task_counts) == 2784 and max(task_counts.values()) == 1
    outcomes = read_json(stage / 'paired_outcomes.json')
    query_ids = sorted({row['query_id'] for row in outcomes})
    condition_ids = sorted({row['condition_id'] for row in outcomes})
    assert len(query_ids) == 29 and len(condition_ids) == 16 and len(outcomes) == 1392
    values = np.zeros((29, 16, 6))
    for query_index, query_id in enumerate(query_ids):
        for condition_index, condition_id in enumerate(condition_ids):
            matching = [row for row in outcomes if row['query_id'] == query_id and row['condition_id'] == condition_id]
            assert len(matching) == 3
            for metric_index, metric in enumerate(METRICS):
                if metric in METRICS[:4]:
                    values[query_index, condition_index, metric_index] = sum(row['category'] == metric for row in matching) / 3
                else:
                    selected = '1' if metric == 'first_position_share' else '2'
                    values[query_index, condition_index, metric_index] = sum(row[order] == selected for row in matching for order in ['order0', 'order1']) / 6
    generator = random.Random(20260912)
    draws = np.array([generator.choices(range(29), k=29) for unused in range(2000)])
    errors = []
    for effect in analysis['effects']:
        factor_indices = [FACTORS.index(factor) for factor in effect['factors']]
        weights = np.array([np.prod([1 if condition[index] == '1' else -1 for index in factor_indices])
                            for condition in condition_ids]) / (16 / 2 ** len(factor_indices))
        per_query = values[:, :, METRICS.index(effect['metric'])] @ weights
        resampled = np.sort(per_query[draws].mean(axis=1))
        bounds = resampled[[int(.025 * 1999), int(.975 * 1999)]]
        errors.extend([abs(float(per_query.mean()) - effect['estimate'])])
        errors.extend(abs(bounds - effect['query_cluster_percentile95']))
    assert len(analysis['effects']) == 60 and max(errors) < 1e-12
    report = {'complete': True, 'unique_successful_tasks': len(task_counts), 'normal_completions_retried': 0,
              'independent_matrix_contrasts_verified': 60, 'independent_bootstrap_intervals_verified': 60,
              'maximum_numeric_difference': float(max(errors)), 'protocol_hash_matches': True,
              'bootstrap_clusters': 29, 'bootstrap_draws': 2000,
              'api_failed_attempts': dict(Counter(row['error_type'] for row in attempts if row['status'] != 'ok'))}
    (stage / 'independent_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
