import argparse
from collections import Counter
import itertools
import json
from pathlib import Path
import statistics

import run as experiment


ROOT = Path(__file__).resolve().parent
FACTOR_NAMES = {
    'reasoning': 'Analysis first',
    'numeric_labels': '1/2 labels',
    'allow_tie': 'TIE allowed',
    'verdict_prefix': 'VERDICT prefix',
}
FACTOR_CODES = dict(zip(experiment.FACTORS, ['R', 'L', 'T', 'V']))
METRIC_NAMES = {
    'directional': 'Directional', 'explicit_tie': 'Double TIE',
    'swap_failure': 'Swap failure', 'invalid': 'Invalid pair',
    'first_position_share': 'First position', 'second_position_share': 'Second position',
}


def signed(value):
    value = round(100 * value, 1)
    return f'{value:+.1f}' if value else '0.0'


def effect_cell(effect, stacked=False):
    lower, upper = effect['query_cluster_percentile95']
    estimate = '$' + signed(effect['estimate']) + '$'
    bounds = f'$[{signed(lower)}, {signed(upper)}]$'
    return '\\shortstack{' + estimate + '\\\\' + bounds + '}' if stacked else estimate + ' ' + bounds


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', type=Path, default=ROOT / 'runs/deepseek_v32_20260912')
    parser.add_argument('--tex-dir', type=Path, required=True)
    parser.add_argument('--protocol-amendment', type=Path)
    args = parser.parse_args()
    stage = args.run_dir / 'factorial'
    analysis = experiment.read_json(stage / 'analysis.json')
    if not analysis['complete'] or analysis['recorded_tasks'] != 2784:
        raise ValueError('Only a complete frozen factorial batch can be reported.')
    attempts = [json.loads(line) for line in (stage / 'raw.jsonl').read_text().splitlines() if line.strip()]
    records = experiment.read_records(stage / 'raw.jsonl')
    paired = experiment.read_json(stage / 'paired_outcomes.json')
    pairs = experiment.read_json(ROOT / 'data/factorial_pairs.json')
    manifest = experiment.read_json(stage / 'run_config.json')
    assert len(manifest['requested_models']) == 1
    requested_model = manifest['requested_models'][0]
    expected_returned_model = manifest['expected_returned_model']
    assert expected_returned_model
    if requested_model == 'deepseek-v3.2':
        display_model = 'DeepSeek-V3.2'
        model_scope = 'Additional DeepSeek-V3.2 audit, not attribution of the original GPT-4.1 comparison.'
        judge_note = 'Judge: DeepSeek-V3.2 via the existing Kingsoft Cloud channel. This is a supplementary experiment, not a GPT-4.1 replication.'
    elif requested_model.startswith('gpt-4.1'):
        display_model = 'GPT-4.1'
        model_scope = 'New GPT-4.1 factorial batch on fixed inputs; API model identifiers do not independently establish identical historical weights or reconstruct old verdicts.'
        judge_note = f'Judge: {requested_model}; returned model: {expected_returned_model}. ' + model_scope
    else:
        raise ValueError('An explicit display label and scope note are needed for this judge.')
    tasks = experiment.judgment_tasks(pairs, True, requested_model)
    assert manifest['tasks_sha256'] == experiment.digest(tasks)
    assert manifest['runner_sha256'] == experiment.digest((ROOT / 'run.py').read_bytes())
    amendment_candidates = [args.protocol_amendment] if args.protocol_amendment else list((ROOT / 'data').glob('*.json'))
    matching_amendments = [path for path in amendment_candidates if experiment.digest(path.read_bytes()) == manifest['amendment_sha256']]
    assert matching_amendments, 'Original amendment bytes matching the manifest are required.'
    assert experiment.read_json(matching_amendments[0]) == experiment.read_json(stage / 'protocol_amendment.json')
    assert set(records) == {task['task_id'] for task in tasks}
    assert len(paired) == 1392 and len({pair['query_id'] for pair in pairs}) == 29
    assert all(record['returned_model'] == expected_returned_model for record in records.values())
    query_rows = {}
    for row in paired:
        first, second = row['order0'], row['order1']
        if first is None or second is None:
            expected = 'invalid'
        elif first == 'TIE' and second == 'TIE':
            expected = 'explicit_tie'
        elif first != 'TIE' and second != 'TIE' and first != second:
            expected = 'directional'
        else:
            expected = 'swap_failure'
        assert row['category'] == expected
        query_rows.setdefault(row['query_id'], {}).setdefault(row['condition_id'], []).append(row)
    assert len(query_rows) == 29
    assert all(len(variants) == 16 and all(len(rows) == 3 for rows in variants.values()) for variants in query_rows.values())
    for code, counts in analysis['condition_counts'].items():
        assert counts['pairs'] == 87 and counts['attempted_orders'] == 174
        assert sum(counts[category] for category in experiment.CATEGORIES) == 87
        assert sum(counts[name] for name in ['first_position', 'second_position', 'tie_orders', 'invalid_orders']) == 174
        assert counts['invalid_orders'] == 174 - counts['parsed_orders']
        expected = Counter(row['category'] for row in paired if row['condition_id'] == code)
        assert all(counts[category] == expected[category] for category in experiment.CATEGORIES)
    effect_lookup = {(tuple(effect['factors']), effect['metric']): effect for effect in analysis['effects']}
    independent_effects = []
    for degree in [1, 2]:
        for factors in itertools.combinations(experiment.FACTORS, degree):
            remaining = [factor for factor in experiment.FACTORS if factor not in factors]
            for metric in list(experiment.CATEGORIES) + ['first_position_share', 'second_position_share']:
                contrasts = []
                for settings in itertools.product([False, True], repeat=len(remaining)):
                    matched = 0
                    for levels in itertools.product([False, True], repeat=degree):
                        condition = dict(zip(remaining, settings)) | dict(zip(factors, levels))
                        counts = analysis['condition_counts'][experiment.condition_id(condition)]
                        if metric in experiment.CATEGORIES:
                            value = counts[metric] / 87
                        else:
                            value = counts[metric.replace('_share', '')] / 174
                        matched += (-1) ** levels.count(False) * value
                    contrasts.append(matched)
                estimate = statistics.mean(contrasts)
                saved_effect = effect_lookup[(factors, metric)]
                assert abs(estimate - saved_effect['estimate']) < 1e-12
                independent_effects.append({'factors': list(factors), 'metric': metric, 'estimate': estimate})
    totals = Counter()
    for counts in analysis['condition_counts'].values():
        totals.update(counts)
    summary = {
        'complete': True, 'judge': requested_model, 'queries': 29, 'response_pairs': 87,
        'conditions': 16, 'expected_calls': 2784, 'recorded_calls': len(records),
        'all_attempts': len(attempts), 'api_failed_attempts': sum(row['status'] != 'ok' for row in attempts),
        'finish_reasons': dict(Counter(row['finish_reason'] for row in records.values())),
        'returned_models': analysis['returned_models'], 'invalid_reasons': analysis['invalid_reasons'],
        'provider_refusals': sum(bool(row.get('refusal')) for row in records.values()),
        'attempts_without_reported_usage': sum(not isinstance(row.get('usage'), dict) for row in attempts),
        'usage_all_attempts': dict(sum((Counter({name: row.get('usage', {}).get(name, 0) for name in ['prompt_tokens', 'completion_tokens', 'total_tokens']}) for row in attempts if isinstance(row.get('usage'), dict)), Counter())),
        'median_request_seconds': statistics.median(row['elapsed_seconds'] for row in records.values()),
        'first_request_utc': min(row['started_at_utc'] for row in attempts),
        'last_request_utc': max(row['started_at_utc'] for row in attempts),
        'pooled_across_conditions': dict(totals),
        'condition_counts': analysis['condition_counts'],
        'effects': analysis['effects'],
        'effect_unit': 'Rates in [0,1]; tables multiply by 100 to express percentage points.',
        'position_share_denominator': 'All 174 attempts per condition, including ties and invalid outputs.',
        'pair_rate_denominator': 'All 87 response pairs per condition; invalid outcomes are retained.',
        'independent_contrast_check': 'All 60 main-effect and pairwise-interaction estimates match direct matched-cell contrasts.',
        'api_raw_sha256': experiment.digest((stage / 'raw.jsonl').read_bytes()),
        'analysis_sha256': experiment.digest((stage / 'analysis.json').read_bytes()),
        'model_scope': model_scope,
        'raw_log_anonymized': 'Provider completion IDs removed; experimental content unchanged.'
    }
    experiment.write_json(stage / 'summary.json', summary)
    args.tex_dir.mkdir(parents=True, exist_ok=True)
    main_rows = []
    for factor in experiment.FACTORS:
        cells = [effect_cell(effect_lookup[((factor,), metric)], True) for metric in ['directional', 'swap_failure']]
        main_rows.append(FACTOR_NAMES[factor] + ' & ' + ' & '.join(cells) + r' \\')
    main_table = r'''\begin{table}[!htbp]
\centering
\setlength{\tabcolsep}{2pt}
\papertablefont
\begin{tabular}{@{}L{0.29\columnwidth}C{0.32\columnwidth}C{0.32\columnwidth}@{}}
\toprule
\textbf{Factor enabled} & \textbf{Directional} & \textbf{Swap failure} \\
\midrule
''' + '\n'.join(main_rows) + r'''
\bottomrule
\end{tabular}
\caption{Factorial main effects on DeepSeek-V3.2, in percentage points, averaged over the other three factors. Brackets: descriptive 95\% query-cluster bootstrap intervals (29 queries, 2,000 draws; no multiplicity correction). All 87 pairs per condition remain in the denominator.}
\label{tab:factorial-main}
\end{table}
'''
    main_table = main_table.replace('DeepSeek-V3.2', display_model)
    if display_model == 'DeepSeek-V3.2':
        main_table = main_table.replace('tab:factorial-main', 'tab:ds-factorial-main')
    (args.tex_dir / 'factorial_main_table.tex').write_text(main_table)
    condition_rows = []
    for code in sorted(analysis['condition_counts']):
        counts = analysis['condition_counts'][code]
        values = [counts[metric] for metric in experiment.CATEGORIES] + [counts[name] for name in ['first_position', 'second_position', 'tie_orders', 'invalid_orders']]
        condition_rows.append(r'\texttt{' + code + '} & ' + ' & '.join(str(value) for value in values) + r' \\')
    condition_table = r'''\begin{table*}[!t]
\centering
\setlength{\tabcolsep}{4pt}
\papertablefont
\begin{tabular}{@{}lrrrrrrrr@{}}
\toprule
 & \multicolumn{4}{c}{Paired outcomes (87 per condition)} & \multicolumn{4}{c}{Raw order-level labels (174 per condition)} \\
\cmidrule(lr){2-5}\cmidrule(lr){6-9}
\textbf{RLTV} & \textbf{Directional} & \textbf{Double TIE} & \textbf{Swap failure} & \textbf{Invalid} & \textbf{First} & \textbf{Second} & \textbf{TIE} & \textbf{Invalid} \\
\midrule
''' + '\n'.join(condition_rows) + r'''
\bottomrule
\end{tabular}
\caption{All 16 DeepSeek-V3.2 conditions on the same 87 response pairs. Bits encode analysis-first (R), numeric labels (L), TIE allowed (T), and a VERDICT prefix (V); 0 disables the factor and 1 enables it. Raw label counts precede swap filtering. A one-order TIE with a directional choice in the other order is a swap failure; any invalid order makes the pair invalid.}
\label{tab:factorial-conditions}
\end{table*}
'''
    condition_table = condition_table.replace('DeepSeek-V3.2', display_model)
    if display_model == 'DeepSeek-V3.2':
        condition_table = condition_table.replace('tab:factorial-conditions', 'tab:ds-factorial-conditions')
    (args.tex_dir / 'factorial_condition_table.tex').write_text(condition_table)
    effect_tables = []
    for metrics, label, title in [(experiment.CATEGORIES, 'pairs', 'paired-outcome rates'), (['first_position_share', 'second_position_share'], 'positions', 'unfiltered position-choice shares')]:
        rows = []
        for degree in [1, 2]:
            if degree == 2:
                rows.append(r'\midrule')
            for factors in itertools.combinations(experiment.FACTORS, degree):
                name = '$' + r'\times '.join(FACTOR_CODES[factor] for factor in factors) + '$'
                rows.append(name + ' & ' + ' & '.join(effect_cell(effect_lookup[(factors, metric)]) for metric in metrics) + r' \\')
        denominator = 'Position shares divide by all attempted orders, including ties and invalid outputs.' if label == 'positions' else 'Pair rates divide by all 87 pairs per condition, including invalid pairs.'
        effect_tables.append(r'\begin{table*}[!t]' + '\n' + r'\centering\papertablefont\setlength{\tabcolsep}{4pt}' + '\n' + r'\begin{tabular}{@{}l' + 'r' * len(metrics) + r'@{}}' + '\n' + r'\toprule' + '\n' + r'\textbf{Contrast} & ' + ' & '.join(r'\textbf{' + METRIC_NAMES[metric] + '}' for metric in metrics) + r' \\' + '\n' + r'\midrule' + '\n' + '\n'.join(rows) + '\n' + r'\bottomrule\end{tabular}' + '\n' + r'\caption{Factorial effects on ' + title + r', in percentage points, with descriptive 95\% query-cluster bootstrap intervals. R, L, T, V follow Table~\ref{tab:factorial-conditions}. Main effects average enabled-minus-disabled differences; interactions average differences of differences over the remaining factors. ' + denominator + r' Intervals are not adjusted for the 60 reported contrasts.}' + '\n' + r'\label{tab:factorial-' + label + r'-effects}' + '\n' + r'\end{table*}' + '\n')
    effect_tables_text = '\n'.join(effect_tables)
    if display_model == 'DeepSeek-V3.2':
        effect_tables_text = effect_tables_text.replace('Factorial effects', 'DeepSeek-V3.2 factorial effects')
        effect_tables_text = effect_tables_text.replace('tab:factorial-', 'tab:ds-factorial-')
    (args.tex_dir / 'factorial_effect_tables.tex').write_text(effect_tables_text)
    note = ['# Paper 93: completed factorial prompt audit', '', 'Judge: DeepSeek-V3.2 via the existing Kingsoft Cloud channel. This is a supplementary experiment, not a GPT-4.1 replication.', '', f"Completed {len(records)}/2784 frozen requests on 29 queries, 87 response pairs, 16 conditions and both orders.", '', '| RLTV | Directional | Double TIE | Swap failure | Invalid pair | First | Second | TIE | Invalid order |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for code in sorted(analysis['condition_counts']):
        counts = analysis['condition_counts'][code]
        note.append('| ' + code + ' | ' + ' | '.join(str(counts[name]) for name in list(experiment.CATEGORIES) + ['first_position', 'second_position', 'tie_orders', 'invalid_orders']) + ' |')
    note.extend(['', 'All 60 main effects and two-factor interactions are retained in analysis.json, including small, mixed and null effects. Rates use complete fixed denominators. No valid completion was retried because of its verdict or parser outcome.', '', f"API-failed attempts: {summary['api_failed_attempts']}; completion finish reasons: {summary['finish_reasons']}; parser reasons: {summary['invalid_reasons']}.", '', 'The archival K4 pooled outcomes remain unrecoverable; these new counts do not reconstruct them.'])
    note[2] = judge_note
    (stage / 'report.md').write_text('\n'.join(note) + '\n')
    print(json.dumps({key: summary[key] for key in ['complete', 'recorded_calls', 'all_attempts', 'api_failed_attempts', 'finish_reasons', 'invalid_reasons', 'usage_all_attempts', 'pooled_across_conditions']}, indent=2))


if __name__ == '__main__':
    main()
