import collections
import hashlib
import itertools
import json
from pathlib import Path
import random
import re


ROOT = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(path.read_text())


def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def classify(first, second):
    if first is None or second is None:
        return 'invalid', None
    if first == second == 'TIE':
        return 'explicit_tie', None
    if (first, second) == ('1', '2'):
        return 'directional', 0
    if (first, second) == ('2', '1'):
        return 'directional', 1
    return 'swap_failure', None


def winner_for(pairs, models):
    wins = dict.fromkeys(models, 0)
    for pair in pairs:
        if pair['category'] == 'directional':
            wins[pair['winner']] += 1
    maximum = max(wins.values())
    candidates = [model for model in models if wins[model] == maximum]
    return (candidates[0] if len(candidates) == 1 else None), wins


def domain_for(query, domains):
    for domain, keywords in domains.items():
        for keyword in keywords:
            if re.search(r'(?<![a-z0-9])' + re.escape(keyword) + r'(?![a-z0-9])', query.lower()):
                return domain
    return 'other'


def modal_label(rows, models, fallback=None):
    counts = collections.Counter(row['winner'] for row in rows if row['winner'] is not None)
    if not counts:
        if fallback is None:
            raise ValueError('No training labels; cannot fit a baseline.')
        return fallback
    candidates = [model for model in models if counts[model] == max(counts.values())]
    return fallback if fallback in candidates else candidates[0]


def route(queries, protocol):
    models = protocol['models']
    specification = protocol['routing']
    query_ids = sorted(queries)
    random.Random(specification['seed']).shuffle(query_ids)
    folds = [query_ids[index::specification['folds']] for index in range(specification['folds'])]
    domains = specification['domains_in_precedence_order']
    predictions = []
    fold_summaries = []
    for fold_index, test_ids in enumerate(folds):
        train_ids = sorted(set(queries) - set(test_ids))
        training = [queries[query_id] for query_id in train_ids]
        baseline = modal_label(training, models)
        mapping = {domain: modal_label([row for row in training if row['domain'] == domain], models, baseline)
                   for domain in domains}
        fitted = {'fold': fold_index, 'training_ids': train_ids, 'test_ids': sorted(test_ids),
                  'training_labeled': sum(row['winner'] is not None for row in training),
                  'constant_baseline': baseline, 'domain_mapping': mapping}
        assert not set(train_ids) & set(test_ids)
        current = []
        for query_id in sorted(test_ids):
            row = queries[query_id]
            result = {'query_id': query_id, 'fold': fold_index, 'domain': row['domain'],
                      'label': row['winner'], 'router': mapping[row['domain']], 'constant': baseline}
            current.append(result)
            predictions.append(result)
        eligible = [row for row in current if row['label'] is not None]
        fitted.update(test_queries=len(current), test_labeled=len(eligible),
                      router_correct=sum(row['router'] == row['label'] for row in eligible),
                      constant_correct=sum(row['constant'] == row['label'] for row in eligible))
        fold_summaries.append(fitted)
    eligible = [row for row in predictions if row['label'] is not None]
    result = {'design': specification, 'folds': fold_summaries, 'test_queries': len(predictions),
              'test_labeled': len(eligible), 'coverage': len(eligible) / len(predictions),
              'router_correct': sum(row['router'] == row['label'] for row in eligible),
              'constant_correct': sum(row['constant'] == row['label'] for row in eligible),
              'uniform_random_expected_accuracy': 1 / len(models),
              'router_only_correct': sum(row['router'] == row['label'] and row['constant'] != row['label'] for row in eligible),
              'constant_only_correct': sum(row['router'] != row['label'] and row['constant'] == row['label'] for row in eligible),
              'domain_results': {}}
    for domain in domains:
        subset = [row for row in eligible if row['domain'] == domain]
        result['domain_results'][domain] = {
            'queries': sum(row['domain'] == domain for row in predictions), 'labeled': len(subset),
            'router_correct': sum(row['router'] == row['label'] for row in subset),
            'constant_correct': sum(row['constant'] == row['label'] for row in subset)}
    assert sorted(row['query_id'] for row in predictions) == sorted(queries)
    return result, predictions


def main():
    protocol = read_json(ROOT / 'protocol.json')
    source = ROOT / protocol['source']
    models = protocol['models']
    categories = protocol['categories']
    records = sorted(source.glob('*.json'))
    assert len(records) == protocol['queries']
    provenance = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in records}
    provenance['protocol.json'] = hashlib.sha256((ROOT / 'protocol.json').read_bytes()).hexdigest()
    frozen = ROOT / 'frozen_manifest.json'
    if frozen.exists():
        assert read_json(frozen) == provenance
    else:
        save_json(frozen, provenance)
    queries = {}
    all_pairs = []
    totals = collections.Counter()
    by_pair = {}
    transitions = collections.Counter()
    transition_rows = []
    for path in records:
        record = read_json(path)
        assert set(record['models']) == set(models)
        pairs = []
        for first_model, second_model in itertools.combinations(models, 2):
            stored = record['judgments'][first_model + '_vs_' + second_model]
            first, second = stored['order1_verdict'], stored['order2_verdict']
            assert first in [None, '1', '2', 'TIE'] and second in [None, '1', '2', 'TIE']
            category, winner_index = classify(first, second)
            pair_models = [first_model, second_model]
            winner = pair_models[winner_index] if winner_index is not None else None
            assert stored['winner'] == (winner or 'TIE')
            pair = {'query_id': record['query_index'], 'models': pair_models, 'order1': first,
                    'order2': second, 'category': category, 'winner': winner}
            pairs.append(pair)
            all_pairs.append(pair)
            totals[category] += 1
            by_pair.setdefault(' / '.join(pair_models), collections.Counter())[category] += 1
        winner, wins = winner_for(pairs, models)
        sorted_wins = sorted(wins.values(), reverse=True)
        query = {'query_id': record['query_index'], 'query': record['query'],
                 'domain': domain_for(record['query'], protocol['routing']['domains_in_precedence_order']),
                 'winner': winner, 'directional_wins': wins,
                 'categories': {category: sum(pair['category'] == category for pair in pairs) for category in categories},
                 'coverage': sum(pair['category'] == 'directional' for pair in pairs) / len(pairs),
                 'margin': (sorted_wins[0] - sorted_wins[1]) / (len(models) - 1)}
        queries[record['query_index']] = query
        old_pairs = [pair for pair in pairs if pair['models'] == models[:2]]
        old_winner, unused_wins = winner_for(old_pairs, models[:2])
        if old_winner == winner:
            transition = 'unchanged_unresolved' if winner is None else 'unchanged_old_winner'
        elif old_winner is None:
            transition = 'unresolved_to_new' if winner == models[-1] else 'unresolved_to_old'
        elif winner is None:
            transition = 'old_winner_to_unresolved'
        elif winner == models[-1]:
            transition = 'old_winner_to_new'
        else:
            transition = 'old_winner_to_other_old'
        transitions[transition] += 1
        transition_rows.append({'query_id': record['query_index'], 'old_winner': old_winner,
                                'new_winner': winner, 'transition': transition})
    assert len(queries) == 40 and len(all_pairs) == 120
    expected = read_json(ROOT / 'recovered_summary.json')['category_counts']
    assert {category: totals[category] for category in categories} == expected
    sensitivity = []
    for coverage_threshold, margin_threshold in protocol['selection_thresholds']:
        selected = [row for row in queries.values() if row['coverage'] > coverage_threshold and row['margin'] > margin_threshold]
        selected_ids = {row['query_id'] for row in selected}
        candidates = [pair for pair in all_pairs if pair['query_id'] in selected_ids and
                      queries[pair['query_id']]['winner'] in pair['models']]
        supported = sum(pair['category'] == 'directional' and pair['winner'] == queries[pair['query_id']]['winner'] for pair in candidates)
        rejected = {category: sum(pair['category'] == category for pair in candidates) for category in categories[1:]}
        opposed = sum(pair['category'] == 'directional' and pair['winner'] != queries[pair['query_id']]['winner'] for pair in candidates)
        sensitivity.append({'coverage_threshold': coverage_threshold, 'margin_threshold': margin_threshold,
                            'queries': len(selected), 'potential_edges': len(candidates), 'supported_edges': supported,
                            'opposed_edges': opposed, 'excluded_categories': rejected,
                            'winner_counts': dict(collections.Counter(row['winner'] for row in selected))})
    routing, predictions = route(queries, protocol)
    result = {'queries': len(queries), 'pairs': len(all_pairs),
              'categories': {category: totals[category] for category in categories},
              'pair_breakdown': {pair: {category: counts[category] for category in categories} for pair, counts in by_pair.items()},
              'winner_counts': {model: sum(row['winner'] == model for row in queries.values()) for model in models},
              'unresolved': sum(row['winner'] is None for row in queries.values()),
              'sensitivity': sensitivity, 'pool_transitions': dict(transitions), 'routing': routing,
              'api_calls': 0, 'protocol_sha256': provenance['protocol.json']}
    save_json(ROOT / 'analysis.json', result)
    save_json(ROOT / 'per_query.json', sorted(queries.values(), key=lambda row: row['query_id']))
    save_json(ROOT / 'pair_outcomes.json', all_pairs)
    save_json(ROOT / 'pool_transitions.json', transition_rows)
    save_json(ROOT / 'routing_predictions.json', predictions)
    print(json.dumps({key: value for key, value in result.items() if key not in ['routing', 'sensitivity']}, indent=2))
    print(json.dumps({'routing': {key: value for key, value in routing.items() if key not in ['design', 'folds']},
                      'sensitivity': sensitivity}, indent=2))


if __name__ == '__main__':
    main()
