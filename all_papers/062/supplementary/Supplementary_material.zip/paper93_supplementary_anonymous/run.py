import argparse
import concurrent.futures
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import re
import statistics
import time
from urllib.parse import urlsplit

import requests


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'external_source_not_included'
MODELS = ['gpt-4o-mini', 'deepseek-v4-flash', 'qwen3.5-35b-a3b', 'deepseek-v4-pro']
FACTORS = ['reasoning', 'numeric_labels', 'allow_tie', 'verdict_prefix']
CATEGORIES = ['directional', 'explicit_tie', 'swap_failure', 'invalid']
SEED = 20260912
K4_PROMPT = '''You are an impartial judge. Evaluate two responses to the question below.

[Question]
{query}

[Response 1]
{first}

[Response 2]
{second}

Analyze strengths/weaknesses of each (2 sentences each), then state your final verdict as exactly: VERDICT: 1 or VERDICT: 2 or VERDICT: TIE'''


def digest(value):
    if isinstance(value, bytes):
        return hashlib.sha256(value).hexdigest()
    return digest(json.dumps(value, ensure_ascii=False, sort_keys=True).encode())


def write_json(target, value):
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(target)


def read_json(target):
    return json.loads(target.read_text())


def conditions():
    return [dict(zip(FACTORS, values)) for values in itertools.product([False, True], repeat=4)]


def condition_id(condition):
    return ''.join(str(int(condition[factor])) for factor in FACTORS)


def factorial_prompt(pair, condition, order):
    labels = ['1', '2'] if condition['numeric_labels'] else ['A', 'B']
    responses = pair['responses'] if order == 0 else list(reversed(pair['responses']))
    reasoning = (
        'First analyze the strengths and weaknesses of each response (two sentences each), then give the final verdict.'
        if condition['reasoning'] else 'Give the final verdict only, without analysis or explanation.'
    )
    tie_rule = (
        'Use TIE when the two responses have roughly equal quality.'
        if condition['allow_tie'] else 'Choose one response even when their quality is close; TIE is not allowed.'
    )
    choices = labels + (['TIE'] if condition['allow_tie'] else [])
    outputs = [('VERDICT: ' if condition['verdict_prefix'] else '') + label for label in choices]
    syntax = 'The final nonempty line must be exactly one of: ' + ' | '.join(outputs) + '. Do not add text after that line.'
    return (
        'You are an impartial judge. Determine which response better addresses the question. '
        'Consider accuracy, completeness, clarity, and helpfulness.\n\n'
        f"[Question]\n{pair['query']}\n\n"
        f'[Response {labels[0]}]\n{responses[0]}\n\n'
        f'[Response {labels[1]}]\n{responses[1]}\n\n'
        f'{reasoning}\n{tie_rule}\n{syntax}'
    )


def parse_verdict(record, condition):
    if record is None:
        return None, 'missing'
    if record.get('status') != 'ok':
        return None, record.get('error_type', 'transport_error')
    if record.get('refusal'):
        return None, 'provider_refusal'
    if record.get('finish_reason') != 'stop':
        return None, 'incomplete_completion'
    content = record.get('content')
    if not isinstance(content, str) or not content.strip():
        return None, 'empty_completion'
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    if not condition['reasoning'] and len(lines) != 1:
        return None, 'unexpected_analysis'
    labels = ['1', '2'] if condition['numeric_labels'] else ['A', 'B']
    allowed = labels + (['TIE'] if condition['allow_tie'] else [])
    pattern = ('VERDICT: ' if condition['verdict_prefix'] else '') + '(' + '|'.join(allowed) + ')'
    match = re.fullmatch(pattern, lines[-1])
    if not match:
        return None, 'format_failure'
    label = match.group(1)
    return ('TIE' if label == 'TIE' else str(labels.index(label) + 1)), None


def classify(first, second):
    if first is None or second is None:
        return 'invalid', None
    if first == second == 'TIE':
        return 'explicit_tie', None
    if (first, second) == ('1', '2'):
        return 'directional', 0
    if (first, second) == ('2', '1'):
        return 'directional', 1
    return 'swap_failure', None


def prepare(source):
    arena = [json.loads(line) for line in (source / 'data/arena_hard.jsonl').read_text().splitlines() if line.strip()]
    pairs = []
    included = []
    hashes = {}
    excluded = {}
    for target in sorted((source / 'results').glob('cross_model_q*.json')):
        record = read_json(target)
        responses = record.get('responses', {})
        if set(responses) != set(MODELS[:3]) or not isinstance(record.get('pairwise_judgments'), dict):
            excluded[target.name] = 'missing_full_response_schema'
            continue
        if any(not isinstance(value, str) or not value.strip() or value.startswith('[FAILED') or
               (len(value.rstrip()) <= 503 and value.rstrip().endswith('...')) for value in responses.values()):
            excluded[target.name] = 'missing_or_preview_response'
            continue
        query_id = record['query_index']
        if record['query'] != arena[query_id]['prompt']:
            raise ValueError(f'Query mismatch: {target.name}')
        included.append(query_id)
        hashes[target.name] = digest(target.read_bytes())
        for first, second in itertools.combinations(MODELS[:3], 2):
            pairs.append({'pair_id': f'q{query_id}__{first}__{second}', 'query_id': query_id,
                          'query': record['query'], 'models': [first, second],
                          'responses': [responses[first], responses[second]], 'source_file': target.name})
    main_queries = []
    for target in sorted((source / 'results').glob('cross_model_4m_q*.json')):
        record = read_json(target)
        query_id = record['query_index']
        full_query = arena[query_id]['prompt']
        matches_preview = len(record['query']) == 500 and record['query'] == full_query[:500]
        if (record['query'] != full_query and not matches_preview) or set(record['models']) != set(MODELS):
            raise ValueError(f'K4 source mismatch: {target.name}')
        main_queries.append({'query_id': query_id, 'query': full_query, 'models': MODELS,
                             'source_file': target.name, 'archived_query_characters': len(record['query']),
                             'question_restored_from_arena': record['query'] != full_query})
        hashes[target.name] = digest(target.read_bytes())
    if len(set(included)) != 29 or len(pairs) != 87 or len(main_queries) != 100:
        raise ValueError('Expected 29 complete K3 queries and 100 historical K4 queries; inspect changed source data.')
    pairs.sort(key=lambda pair: pair['pair_id'])
    main_queries.sort(key=lambda query: query['query_id'])
    protocol = {
        'date': '2026-09-12', 'seed': SEED, 'judge': 'gpt-4.1', 'temperature': 0,
        'factor_order': FACTORS, 'conditions': conditions(),
        'factorial': {'queries': 29, 'pairs': 87, 'calls': 2784, 'max_tokens': 500,
                      'selection': 'Frozen 29-query batch using the pairwise_judgments schema, without selecting by verdict. A separate 40-query judgments-schema batch also has full responses and is reported independently.',
                      'scope': 'Convenience subset, not a random sample or the historical K4 batch.'},
        'k4': {'queries': 100, 'generator_calls': 400, 'judge_calls': 1200,
               'generator_max_tokens': 1500, 'judge_max_tokens': 250,
               'scope': 'Entirely new generated-response and judging batch with full questions and stored generated responses; never merge into old 324/276 counts.',
               'restored_question_previews': sum(query['question_restored_from_arena'] for query in main_queries),
               'historical_protocol_note': 'Legacy K4 scripts differ in prompt truncation; the new batch consistently uses full questions and complete newly generated outputs.'},
        'parser': 'Exact final nonempty line, case-sensitive; completion must finish normally. Direct-only outputs must have one nonempty line.',
        'analysis': 'Four paired categories; unfiltered position counts; query-cluster bootstrap for matched factorial main effects and pairwise interactions.',
        'uncertainty': 'Descriptive percentile intervals, 2000 query-cluster draws; no multiple-comparison adjustment or power guarantee.',
        'data_sha256': {'factorial_pairs': digest(pairs), 'k4_queries': digest(main_queries)},
        'source_sha256': hashes, 'excluded_k3_records': excluded,
        'arena_sha256': digest((source / 'data/arena_hard.jsonl').read_bytes()),
        'historical_response_limit': 'K4 response previews and both-order judgments cannot be used to reconstruct the historical category split.'
    }
    for filename, value in [('factorial_pairs.json', pairs), ('k4_queries.json', main_queries), ('protocol.json', protocol)]:
        destination = ROOT / 'data' / filename
        if destination.exists() and read_json(destination) != value:
            raise ValueError(f'Refusing to overwrite changed input snapshot: {destination}')
        write_json(destination, value)
    prompt_examples = {condition_id(condition): factorial_prompt(pairs[0], condition, 0) for condition in conditions()}
    write_json(ROOT / 'data/prompt_examples.json', prompt_examples)
    print(json.dumps({'factorial_queries': 29, 'factorial_pairs': 87, 'factorial_calls': 2784,
                      'k4_generation_calls': 400, 'k4_judge_calls': 1200, 'api_calls_made': 0}))


def judgment_tasks(pairs, factorial, model):
    tasks = []
    variants = conditions() if factorial else [dict(zip(FACTORS, [True] * 4))]
    for pair in pairs:
        for condition in variants:
            for order in [0, 1]:
                responses = pair['responses'] if order == 0 else list(reversed(pair['responses']))
                prompt = factorial_prompt(pair, condition, order) if factorial else K4_PROMPT.format(
                    query=pair['query'], first=responses[0], second=responses[1])
                tasks.append({'task_id': f"{pair['pair_id']}__{condition_id(condition)}__order{order}",
                              'pair_id': pair['pair_id'], 'query_id': pair['query_id'], 'models': pair['models'],
                              'condition': condition, 'order': order,
                              'response_sha256': [digest(value) for value in pair['responses']],
                              'request': {'model': model, 'messages': [{'role': 'user', 'content': prompt}],
                                          'temperature': 0, 'max_tokens': 500 if factorial else 250}})
    random.Random(SEED).shuffle(tasks)
    return tasks


def generation_tasks():
    tasks = []
    for query in read_json(ROOT / 'data/k4_queries.json'):
        for model in MODELS:
            tasks.append({'task_id': f"q{query['query_id']}__{model}", 'query_id': query['query_id'],
                          'generator': model, 'request': {'model': model, 'temperature': 0, 'max_tokens': 1500,
                          'messages': [{'role': 'user', 'content': query['query']}]}})
    random.Random(SEED).shuffle(tasks)
    return tasks


def read_records(target):
    rows = {}
    if target.exists():
        for line in target.read_text().splitlines():
            if line.strip():
                record = json.loads(line)
                rows[record['task_id']] = record
    return rows


def generated_pairs(run_root):
    saved = read_records(run_root / 'k4-generate/raw.jsonl')
    pairs = []
    for query in read_json(ROOT / 'data/k4_queries.json'):
        responses = {}
        for model in MODELS:
            record = saved.get(f"q{query['query_id']}__{model}")
            if not record or record.get('status') != 'ok' or not record.get('content') or record.get('refusal'):
                raise ValueError('Complete all 400 valid candidate generations before judging K4.')
            if record.get('finish_reason') not in ['stop', 'length']:
                raise ValueError('A candidate generation was filtered or incomplete for an unexpected reason.')
            responses[model] = record['content']
        for first, second in itertools.combinations(MODELS, 2):
            pairs.append({'pair_id': f"q{query['query_id']}__{first}__{second}", 'query_id': query['query_id'],
                          'query': query['query'], 'models': [first, second],
                          'responses': [responses[first], responses[second]]})
    return pairs


def call_api(task, endpoint, secret, expected_returned_model=None):
    started = time.monotonic()
    record = dict(task, started_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    try:
        response = requests.post(endpoint, headers={'Authorization': 'Bearer ' + secret},
                                 json=task['request'], timeout=(10, 50), allow_redirects=False)
        record['http_status'] = response.status_code
        if response.status_code != 200:
            record.update(status='error', error_type=f'http_{response.status_code}')
        else:
            payload = response.json()
            choices = payload.get('choices')
            if not isinstance(choices, list) or len(choices) != 1:
                raise ValueError('Invalid completion schema')
            choice = choices[0]
            message = choice.get('message', {})
            content = message.get('content')
            if content is not None and not isinstance(content, str):
                raise ValueError('Non-text completion')
            record.update(status='ok', content=content, refusal=message.get('refusal'),
                          returned_model=payload.get('model'), completion_id=payload.get('id'),
                          system_fingerprint=payload.get('system_fingerprint'),
                          finish_reason=choice.get('finish_reason'), usage=payload.get('usage'),
                          raw_choices=choices)
            if expected_returned_model is not None and payload.get('model') != expected_returned_model:
                record.update(status='error', error_type='returned_model_mismatch')
    except requests.RequestException as error:
        record.update(status='error', error_type=type(error).__name__)
    except (ValueError, TypeError, AttributeError) as error:
        record.update(status='error', error_type=type(error).__name__)
    record['elapsed_seconds'] = round(time.monotonic() - started, 3)
    return record


def execute(tasks, args):
    if not args.base_url or not args.max_calls:
        raise ValueError('run requires --base-url and --max-calls; no API endpoint is guessed.')
    parsed_url = urlsplit(args.base_url)
    if parsed_url.scheme not in ['http', 'https'] or not parsed_url.hostname or parsed_url.username or parsed_url.query:
        raise ValueError('Use a plain API base URL with no credentials or query string.')
    secret = os.environ.get(args.key_env)
    if not secret:
        raise ValueError(f'Configure credential in environment variable {args.key_env}; do not put it in source code.')
    destination = args.run_dir / args.stage
    configuration = {'stage': args.stage, 'base_url': args.base_url.rstrip('/'),
                     'tasks_sha256': digest(tasks), 'runner_sha256': digest(Path(__file__).read_bytes()),
                     'requested_models': sorted({task['request']['model'] for task in tasks}),
                     'expected_returned_model': args.expected_returned_model,
                     'amendment_sha256': digest(args.protocol_amendment.read_bytes()) if args.protocol_amendment else None,
                     'task_count': len(tasks), 'protocol_sha256': digest((ROOT / 'data/protocol.json').read_bytes())}
    manifest = destination / 'run_config.json'
    if manifest.exists() and read_json(manifest) != configuration:
        raise ValueError('Run configuration changed. Use a new --run-dir to keep batches separate.')
    write_json(manifest, configuration)
    if args.protocol_amendment:
        write_json(destination / 'protocol_amendment.json', read_json(args.protocol_amendment))
    raw_path = destination / 'raw.jsonl'
    saved = read_records(raw_path)
    pending = [task for task in tasks if saved.get(task['task_id'], {}).get('status') != 'ok']
    if len(pending) > args.max_calls:
        raise ValueError(f'{len(pending)} calls pending; the explicit --max-calls ceiling is {args.max_calls}.')
    if not pending:
        print('All calls already recorded; no API requests made.')
        return
    endpoint = args.base_url.rstrip('/') + '/chat/completions'
    completed = 0
    failed = False
    with raw_path.open('a') as output:
        def save(record):
            output.write(json.dumps(record, ensure_ascii=False) + '\n')
            output.flush()
            os.fsync(output.fileno())

        first = call_api(pending[0], endpoint, secret, args.expected_returned_model)
        save(first)
        if first['status'] != 'ok':
            raise RuntimeError(f"First request failed ({first['error_type']}); batch stopped after one call.")
        completed += 1
        print(f'{args.stage}: 1/{len(pending)} requests completed', flush=True)
        iterator = iter(pending[1:])
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
            active = {executor.submit(call_api, task, endpoint, secret, args.expected_returned_model) for task in itertools.islice(iterator, args.workers)}
            while active:
                done, active = concurrent.futures.wait(active, return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    record = future.result()
                    save(record)
                    completed += 1
                    failed = failed or record['status'] != 'ok'
                if completed % 20 == 0 or not active:
                    print(f'{args.stage}: {completed}/{len(pending)} requests completed', flush=True)
                if not failed:
                    active.update(executor.submit(call_api, task, endpoint, secret, args.expected_returned_model)
                                  for task in itertools.islice(iterator, len(done)))
    if failed:
        raise RuntimeError('API failure encountered; outstanding requests were saved and no further calls scheduled. Resume after fixing access.')


def interval(values):
    values = sorted(values)
    return [values[int(0.025 * (len(values) - 1))], values[int(0.975 * (len(values) - 1))]]


def factorial_effects(query_metrics):
    query_ids = sorted(query_metrics)
    generator = random.Random(SEED)
    draws = [generator.choices(range(len(query_ids)), k=len(query_ids)) for unused in range(2000)]
    effects = []
    for degree in [1, 2]:
        for factors in itertools.combinations(FACTORS, degree):
            for metric in CATEGORIES + ['first_position_share', 'second_position_share']:
                values = []
                for query_id in query_ids:
                    contrast = sum(
                        statistics.mean(query_metrics[query_id][condition_id(condition)][metric]) *
                        (1 if sum(condition[factor] for factor in factors) % 2 == degree % 2 else -1)
                        for condition in conditions()) / (16 / (2 ** degree))
                    values.append(contrast)
                bootstrap = [statistics.mean(values[index] for index in draw) for draw in draws]
                effects.append({'factors': list(factors), 'metric': metric, 'estimate': statistics.mean(values),
                                'query_cluster_percentile95': interval(bootstrap)})
    return effects


def analyze(tasks, args):
    records = read_records(args.run_dir / args.stage / 'raw.jsonl')
    expected_ids = {task['task_id'] for task in tasks}
    if set(records) - expected_ids:
        raise ValueError('Results include tasks outside this frozen design.')
    task_lookup = {task['task_id']: task for task in tasks}
    for task_id, record in records.items():
        if record['request'] != task_lookup[task_id]['request']:
            raise ValueError('Stored prompt or model differs from the frozen design.')
    grouped = {}
    counts = {}
    paired_rows = []
    query_metrics = {}
    query_wins = {}
    for task in tasks:
        grouped.setdefault((task['pair_id'], condition_id(task['condition'])), {})[task['order']] = task
    for (pair_id, variant_id), orders in grouped.items():
        first_task, second_task = orders[0], orders[1]
        condition = first_task['condition']
        first, first_error = parse_verdict(records.get(first_task['task_id']), condition)
        second, second_error = parse_verdict(records.get(second_task['task_id']), condition)
        category, winner_index = classify(first, second)
        stats = counts.setdefault(variant_id, dict.fromkeys(CATEGORIES + ['pairs', 'attempted_orders',
                                    'parsed_orders', 'first_position', 'second_position', 'tie_orders', 'invalid_orders'], 0))
        stats['pairs'] += 1
        stats[category] += 1
        stats['attempted_orders'] += int(first_task['task_id'] in records) + int(second_task['task_id'] in records)
        for verdict in [first, second]:
            stats['parsed_orders'] += int(verdict is not None)
            position = {'1': 'first_position', '2': 'second_position', 'TIE': 'tie_orders', None: 'invalid_orders'}[verdict]
            stats[position] += 1
        query_id = first_task['query_id']
        metrics = query_metrics.setdefault(query_id, {}).setdefault(variant_id, {name: [] for name in CATEGORIES + ['first_position_share', 'second_position_share']})
        for name in CATEGORIES:
            metrics[name].append(int(category == name))
        metrics['first_position_share'].append((int(first == '1') + int(second == '1')) / 2)
        metrics['second_position_share'].append((int(first == '2') + int(second == '2')) / 2)
        winner = first_task['models'][winner_index] if winner_index is not None else None
        paired_rows.append({'pair_id': pair_id, 'query_id': query_id, 'condition_id': variant_id,
                            'order0': first, 'order1': second, 'category': category, 'winner': winner,
                            'order0_invalid_reason': first_error, 'order1_invalid_reason': second_error})
        if args.stage == 'k4-judge':
            wins = query_wins.setdefault(query_id, dict.fromkeys(MODELS, 0))
            if winner:
                wins[winner] += 1
    complete = len(records) == len(tasks) and all(record.get('status') == 'ok' for record in records.values())
    result = {'stage': args.stage, 'complete': complete, 'expected_calls': len(tasks),
              'recorded_tasks': len(records), 'condition_counts': counts,
              'invalid_reasons': {reason: sum(row[field] == reason for row in paired_rows for field in ['order0_invalid_reason', 'order1_invalid_reason'])
                                  for reason in sorted({row[field] for row in paired_rows for field in ['order0_invalid_reason', 'order1_invalid_reason'] if row[field]})},
              'returned_models': sorted({str(record.get('returned_model')) for record in records.values() if record.get('status') == 'ok'}),
              'sampling_note': 'Available full-response K3 subset, 29 query clusters; not a random sample.' if args.stage == 'factorial' else 'New K4 batch, never a reconstruction of historical pooled outcomes.',
              'parser_version': 'strict-final-line-v1',
              'effects': factorial_effects(query_metrics) if complete and args.stage == 'factorial' else []}
    if query_wins:
        result['query_wins'] = query_wins
        result['query_winners'] = {query_id: next(model for model, wins in row.items() if wins == max(row.values()))
                                   if list(row.values()).count(max(row.values())) == 1 else 'UNRESOLVED'
                                   for query_id, row in query_wins.items()}
        generation = read_records(args.run_dir / 'k4-generate/raw.jsonl')
        result['generation_length_limited'] = sum(record.get('finish_reason') == 'length' for record in generation.values())
    write_json(args.run_dir / args.stage / 'analysis.json', result)
    write_json(args.run_dir / args.stage / 'paired_outcomes.json', paired_rows)
    print(json.dumps({'complete': complete, 'recorded_tasks': len(records), 'expected_calls': len(tasks)}))


def main():
    parser = argparse.ArgumentParser(description='GroundLM #93 required experiments; frozen inputs, resumable raw outputs, no credentials in artifacts.')
    parser.add_argument('action', choices=['prepare', 'plan', 'run', 'analyze'])
    parser.add_argument('--source', type=Path, default=SOURCE)
    parser.add_argument('--stage', choices=['factorial', 'k4-generate', 'k4-judge'], default='factorial')
    parser.add_argument('--run-dir', type=Path, default=ROOT / 'runs/gpt41_20260912')
    parser.add_argument('--model', default='gpt-4.1')
    parser.add_argument('--base-url', default=os.environ.get('PAPER93_API_BASE'))
    parser.add_argument('--key-env', default='PAPER93_API_KEY')
    parser.add_argument('--expected-returned-model')
    parser.add_argument('--protocol-amendment', type=Path)
    parser.add_argument('--max-calls', type=int)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    if not 1 <= args.workers <= 8:
        raise ValueError('Use between 1 and 8 concurrent requests.')
    if args.action == 'prepare':
        prepare(args.source)
        return
    protocol = read_json(ROOT / 'data/protocol.json')
    for filename, name in [('factorial_pairs.json', 'factorial_pairs'), ('k4_queries.json', 'k4_queries')]:
        if digest(read_json(ROOT / 'data' / filename)) != protocol['data_sha256'][name]:
            raise ValueError('Input snapshot differs from protocol hash.')
    if args.stage == 'factorial':
        tasks = judgment_tasks(read_json(ROOT / 'data/factorial_pairs.json'), True, args.model)
    elif args.stage == 'k4-generate':
        tasks = generation_tasks()
    else:
        tasks = judgment_tasks(generated_pairs(args.run_dir), False, args.model)
    if args.action == 'plan':
        print(json.dumps({'stage': args.stage, 'calls': len(tasks), 'models': sorted({task['request']['model'] for task in tasks}),
                          'maximum_output_tokens': sum(task['request']['max_tokens'] for task in tasks),
                          'prompt_characters': sum(len(task['request']['messages'][0]['content']) for task in tasks),
                          'api_calls_made': 0}, indent=2))
    elif args.action == 'run':
        execute(tasks, args)
    elif args.stage == 'k4-generate':
        raise ValueError('Use analyze --stage k4-judge after both K4 stages complete.')
    else:
        analyze(tasks, args)


if __name__ == '__main__':
    main()
