# Paper 93: completed factorial prompt audit

Judge: gpt-4.1; returned model: gpt-4.1. New GPT-4.1 factorial batch on fixed inputs; API model identifiers do not independently establish identical historical weights or reconstruct old verdicts.

Completed 2784/2784 frozen requests on 29 queries, 87 response pairs, 16 conditions and both orders.

| RLTV | Directional | Double TIE | Swap failure | Invalid pair | First | Second | TIE | Invalid order |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0000 | 61 | 0 | 25 | 1 | 101 | 72 | 0 | 1 |
| 0001 | 70 | 0 | 17 | 0 | 98 | 76 | 0 | 0 |
| 0010 | 64 | 1 | 22 | 0 | 102 | 70 | 2 | 0 |
| 0011 | 66 | 1 | 20 | 0 | 100 | 72 | 2 | 0 |
| 0100 | 63 | 0 | 22 | 2 | 97 | 75 | 0 | 2 |
| 0101 | 65 | 0 | 22 | 0 | 103 | 71 | 0 | 0 |
| 0110 | 65 | 1 | 21 | 0 | 99 | 73 | 2 | 0 |
| 0111 | 64 | 1 | 20 | 2 | 100 | 69 | 3 | 2 |
| 1000 | 69 | 0 | 18 | 0 | 85 | 89 | 0 | 0 |
| 1001 | 75 | 0 | 12 | 0 | 91 | 83 | 0 | 0 |
| 1010 | 66 | 0 | 19 | 2 | 73 | 92 | 7 | 2 |
| 1011 | 75 | 0 | 12 | 0 | 88 | 84 | 2 | 0 |
| 1100 | 65 | 0 | 17 | 5 | 73 | 96 | 0 | 5 |
| 1101 | 72 | 0 | 15 | 0 | 88 | 86 | 0 | 0 |
| 1110 | 62 | 2 | 18 | 5 | 68 | 88 | 13 | 5 |
| 1111 | 73 | 1 | 13 | 0 | 87 | 81 | 6 | 0 |

All 60 main effects and two-factor interactions are retained in analysis.json, including small, mixed and null effects. Rates use complete fixed denominators. No valid completion was retried because of its verdict or parser outcome.

API-failed attempts: 2; completion finish reasons: {'stop': 2784}; parser reasons: {'format_failure': 15, 'unexpected_analysis': 2}.

The archival K4 pooled outcomes remain unrecoverable; these new counts do not reconstruct them.
