# Paper 93: completed factorial prompt audit

Judge: DeepSeek-V3.2 via the existing Kingsoft Cloud channel. This is a supplementary experiment, not a GPT-4.1 replication.

Completed 2784/2784 frozen requests on 29 queries, 87 response pairs, 16 conditions and both orders.

| RLTV | Directional | Double TIE | Swap failure | Invalid pair | First | Second | TIE | Invalid order |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0000 | 64 | 0 | 23 | 0 | 108 | 66 | 0 | 0 |
| 0001 | 59 | 0 | 28 | 0 | 115 | 59 | 0 | 0 |
| 0010 | 61 | 0 | 26 | 0 | 113 | 61 | 0 | 0 |
| 0011 | 57 | 1 | 29 | 0 | 115 | 57 | 2 | 0 |
| 0100 | 57 | 0 | 30 | 0 | 117 | 57 | 0 | 0 |
| 0101 | 57 | 0 | 30 | 0 | 117 | 57 | 0 | 0 |
| 0110 | 61 | 0 | 26 | 0 | 113 | 61 | 0 | 0 |
| 0111 | 57 | 1 | 29 | 0 | 115 | 57 | 2 | 0 |
| 1000 | 51 | 0 | 18 | 18 | 92 | 63 | 0 | 19 |
| 1001 | 64 | 0 | 19 | 4 | 105 | 64 | 0 | 5 |
| 1010 | 45 | 1 | 18 | 23 | 76 | 61 | 10 | 27 |
| 1011 | 63 | 1 | 22 | 1 | 99 | 64 | 10 | 1 |
| 1100 | 55 | 0 | 18 | 14 | 97 | 61 | 0 | 16 |
| 1101 | 67 | 0 | 19 | 1 | 104 | 69 | 0 | 1 |
| 1110 | 56 | 0 | 17 | 14 | 88 | 65 | 4 | 17 |
| 1111 | 67 | 1 | 18 | 1 | 97 | 72 | 4 | 1 |

All 60 main effects and two-factor interactions are retained in analysis.json, including small, mixed and null effects. Rates use complete fixed denominators. No valid completion was retried because of its verdict or parser outcome.

API-failed attempts: 7; completion finish reasons: {'stop': 2784}; parser reasons: {'format_failure': 87}.

The archival K4 pooled outcomes remain unrecoverable; these new counts do not reconstruct them.
