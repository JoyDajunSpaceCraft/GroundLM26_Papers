"""Recompute the tables in the paper from the released judgments.

Run from the repository root:

    python reproduce_tables.py

Reads only results/ and prints Tables 1-4 plus the coin-flip reference used in
Section 3. No API calls are made. Bootstrap intervals are resampled here, so the
last decimal of a CI can differ from the paper by a tenth of a point.
"""
import collections
import glob
import itertools
import json
import random
import statistics

E1_FILES = [
    "results/exp1_v2_20260228_124329.json",
    "results/latest_judges/exp1_gpt-5_4-nano_20260707_231647.json",
    "results/latest_judges/exp1_gpt-5_4-mini_20260707_232942.json",
    "results/latest_judges/exp1_claude-haiku-4_5_20260707_234217.json",
    "results/exp1_intra_20260706_042936.json",
]
SWAP_FILES = ["results/exp3_bias_20260705_204931.json"] + sorted(
    glob.glob("results/latest_judges/exp3_bias*.json")
)
PANEL = ["gpt-4o-mini", "gpt-4.1-mini", "gpt-5.4-nano", "gpt-5.4-mini", "claude-haiku-4.5"]


def judgments(block):
    """Handle both record layouts: {"judgments": [...]} and a bare list."""
    return block["judgments"] if isinstance(block, dict) else block


def normalise(winner):
    w = str(winner).strip().lower()
    return "tie" if w in ("tie", "draw") else w.upper()


def load_e1():
    records = collections.defaultdict(dict)
    categories = {}
    for path in E1_FILES:
        for record in json.load(open(path)):
            records[record["judge_model"]][record["sample_id"]] = record
            categories[record["sample_id"]] = record.get("category")
    return records, categories


def per_item_stats(record):
    verdicts = [normalise(j["winner"]) for j in judgments(record["pairwise"])
                if j.get("winner") is not None]
    counts = collections.Counter(verdicts)
    return {
        "flip_rate": 100 * (1 - max(counts.values()) / len(verdicts)),
        "ties": counts.get("tie", 0),
        "n": len(verdicts),
        "majority": max(counts, key=counts.get),
    }


def scores(block):
    return [j["score"] for j in judgments(block)
            if isinstance(j, dict) and j.get("score") not in (None, -1) and not j.get("error")]


def bootstrap_ci(values, draws=10000, seed=0):
    rng = random.Random(seed)
    means = sorted(statistics.mean(rng.choices(values, k=len(values))) for _ in range(draws))
    return means[int(0.025 * draws)], means[int(0.975 * draws)]


def cohens_kappa(a, b):
    n = len(a)
    labels = set(a) | set(b)
    observed = sum(1 for x, y in zip(a, b) if x == y) / n
    expected = sum((a.count(l) / n) * (b.count(l) / n) for l in labels)
    return observed, (observed - expected) / (1 - expected)


def swap_decomposition():
    by_judge = collections.defaultdict(list)
    for path in SWAP_FILES:
        for record in json.load(open(path)):
            by_judge[record["judge_model"]].append(record)

    rows = {}
    for judge, records in by_judge.items():
        first_slot = labelled = paired = first_both = second_both = content_kept = 0
        for record in records:
            original, swapped = record["original_winners"], record["swapped_winners"]
            for w in original + swapped:
                if w in ("A", "B", "tie"):
                    labelled += 1
                if w == "A":
                    first_slot += 1
            for a, b in zip(original, swapped):
                if a in ("A", "B", "tie") and b in ("A", "B", "tie"):
                    paired += 1
                    if a == "A" and b == "A":
                        first_both += 1
                    elif a == "B" and b == "B":
                        second_both += 1
                    elif a in ("A", "B") and b in ("A", "B") and a != b:
                        content_kept += 1
        rows[judge] = (
            100 * first_slot / labelled,
            100 * first_both / paired,
            100 * second_both / paired,
            100 * (first_both + second_both) / paired,
            100 * content_kept / paired,
        )
    return rows


def coin_flip_reference(outcomes, trials=50, draws=200000, seed=1):
    rng = random.Random(seed)
    rates = []
    for _ in range(draws):
        counts = collections.Counter(rng.randrange(outcomes) for _ in range(trials))
        rates.append(1 - max(counts.values()) / trials)
    return 100 * statistics.mean(rates)


def main():
    records, categories = load_e1()
    stats = {j: {sid: per_item_stats(r) for sid, r in records[j].items()} for j in records}

    print("Table 1: aggregate consistency (t=1.0)")
    print(f"{'judge':18s} {'mean FR':>8s} {'95% CI':>16s} {'max':>5s} {'tie%':>6s} {'PPG':>6s} {'order':>7s}")
    swap = swap_decomposition()
    for judge in PANEL:
        flips = [s["flip_rate"] for s in stats[judge].values()]
        lo, hi = bootstrap_ci(flips)
        ties = sum(s["ties"] for s in stats[judge].values())
        total = sum(s["n"] for s in stats[judge].values())
        gaps = []
        for record in records[judge].values():
            a, b = scores(record.get("pointwise_a", [])), scores(record.get("pointwise_b", []))
            if a and b:
                gaps.append(abs(statistics.mean(a) - statistics.mean(b)))
        print(f"{judge:18s} {statistics.mean(flips):8.1f} "
              f"{'[' + format(lo, '.1f') + ', ' + format(hi, '.1f') + ']':>16s} "
              f"{max(flips):5.0f} {100 * ties / total:6.1f} {statistics.mean(gaps):6.2f} "
              f"{swap[judge][3]:7.1f}")

    print("\nTable 2: mean flip rate by category (mean over the five judges)")
    item_mean = {sid: statistics.mean([stats[j][sid]["flip_rate"] for j in PANEL]) for sid in categories}
    ordered = sorted(set(categories.values()),
                     key=lambda c: -statistics.mean([item_mean[s] for s in categories if categories[s] == c]))
    for category in ordered:
        members = [item_mean[s] for s in categories if categories[s] == category]
        print(f"  {category:14s} n={len(members):<2d} {statistics.mean(members):5.1f}")

    print("\nTable 3: swap-order decomposition (% of 1,740 judgments per judge)")
    print(f"{'judge':18s} {'first':>7s} {'1st-both':>9s} {'2nd-both':>9s} {'order':>7s} {'content':>8s}")
    for judge in PANEL:
        fsp, first_both, second_both, order, content = swap[judge]
        print(f"{judge:18s} {fsp:7.1f} {first_both:9.1f} {second_both:9.1f} {order:7.1f} {content:8.1f}")

    print("\nTable 4: cross-judge agreement on majority verdicts")
    majorities = {j: {sid: s["majority"] for sid, s in stats[j].items()} for j in PANEL}
    shared = sorted(set.intersection(*[set(majorities[j]) for j in PANEL]))
    for x, y in itertools.combinations(PANEL, 2):
        agreement, kappa = cohens_kappa([majorities[x][s] for s in shared],
                                        [majorities[y][s] for s in shared])
        print(f"  {x:17s} vs {y:17s} agree {100 * agreement:5.1f}%  kappa {kappa:5.2f}")

    print("\nCoin-flip reference at N=50")
    for outcomes, label in ((2, "two outcomes (A/B)"), (3, "three outcomes (A/B/tie)")):
        print(f"  {label:26s} expected flip rate {coin_flip_reference(outcomes):.1f}%"
              f"  (limit {100 * (1 - 1 / outcomes):.1f}%)")


if __name__ == "__main__":
    main()
