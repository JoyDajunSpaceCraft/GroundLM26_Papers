#!/bin/bash
set -a; source .env; set +a
cd "$(dirname "$0")"
.venv/bin/python concurrent_judges.py
