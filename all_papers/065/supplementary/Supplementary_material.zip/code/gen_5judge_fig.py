import json, glob
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def judgments(it,k):
    v=it[k]; return v["judgments"] if isinstance(v,dict) else v
def fr_of(it):
    w=[j["winner"] for j in judgments(it,"pairwise") if j.get("winner")]
    m=max(set(w),key=w.count); return 1-w.count(m)/len(w)

# old judges from original file
old=json.load(open("results/exp1_v2_20260228_124329.json"))
new={}
for f in glob.glob("results/latest_judges/exp1_*.json"):
    d=json.load(open(f)); new[d[0]["judge_model"]]=d

def judge_frs(items): return [fr_of(it) for it in items]
data={}  # judge -> (mean_fr, max_fr)
for J in ["gpt-4o-mini","gpt-4.1-mini"]:
    its=[it for it in old if it["judge_model"]==J]; frs=judge_frs(its)
    data[J]=(100*np.mean(frs),100*max(frs))
for J,d in new.items():
    frs=judge_frs(d); data[J]=(100*np.mean(frs),100*max(frs))

# position-driven from swap (both providers)
pos={"gpt-5.4-nano":35.7,"gpt-5.4-mini":6.5,"claude-haiku-4.5":6.9,
     "gpt-4o-mini":43.3,"gpt-4.1-mini":22.2}
order=["gpt-4o-mini","gpt-4.1-mini","gpt-5.4-nano","gpt-5.4-mini","claude-haiku-4.5"]
labels=["gpt-4o-mini\n(2024)","gpt-4.1-mini\n(2025)","gpt-5.4-nano\n(2026)","gpt-5.4-mini\n(2026)","haiku-4.5\n(2026)"]
colors=["#9aa4b2","#9aa4b2","#0b57d0","#0b57d0","#b3261e"]

fig,(ax1,ax2)=plt.subplots(1,2,figsize=(9,3.6))
x=np.arange(len(order)); w=0.38
mean=[data[j][0] for j in order]; mx=[data[j][1] for j in order]
ax1.bar(x-w/2,mean,w,label="Mean flip rate",color="#4c78a8")
ax1.bar(x+w/2,mx,w,label="Max flip rate",color="#e45756",alpha=.85)
ax1.axhspan(40,50,color="grey",alpha=.12)
ax1.set_xticks(x); ax1.set_xticklabels(labels,fontsize=7)
ax1.set_ylabel("Flip rate (%)"); ax1.set_title("Run-to-run instability persists",fontsize=10)
ax1.legend(fontsize=8); ax1.grid(axis="y",alpha=.25)
pv=[pos[j] for j in order]
ax2.bar(x,pv,color=colors)
ax2.set_xticks(x); ax2.set_xticklabels(labels,fontsize=7)
ax2.set_ylabel("Pure position-driven (%)"); ax2.set_title("Position bias is being fixed",fontsize=10)
ax2.grid(axis="y",alpha=.25)
fig.tight_layout()
fig.savefig("paper/figures/fig_5judge.pdf",bbox_inches="tight")
fig.savefig("paper/figures/fig_5judge.png",dpi=200,bbox_inches="tight")
# copy to 8pp
import shutil
for ext in ["pdf","png"]:
    shutil.copy(f"paper/figures/fig_5judge.{ext}",f"../llm-judge-groundlm-8pp/figures/fig_5judge.{ext}")
print("mean/max FR:",{j:tuple(round(v,1) for v in data[j]) for j in order})
print("saved fig_5judge to both papers")

# --- clean pairwise-pointwise figure (fig2) ---
def ppg_scatter():
    import numpy as np, matplotlib.pyplot as plt, json
    old=json.load(open("results/exp1_v2_20260228_124329.json"))
    fig,ax=plt.subplots(figsize=(4.2,3.2))
    for J,col,mk in [("gpt-4o-mini","#0b57d0","o"),("gpt-4.1-mini","#b3261e","s")]:
        xs,ys=[],[]
        for it in old:
            if it["judge_model"]!=J: continue
            w=[j["winner"] for j in judgments(it,"pairwise") if j.get("winner")]
            m=max(set(w),key=w.count); fr=1-w.count(m)/len(w)
            a=[j["score"] for j in judgments(it,"pointwise_a") if j.get("score") is not None]
            b=[j["score"] for j in judgments(it,"pointwise_b") if j.get("score") is not None]
            if a and b: xs.append(abs(np.mean(a)-np.mean(b))); ys.append(100*fr)
        ax.scatter(xs,ys,c=col,marker=mk,alpha=.7,edgecolors="k",linewidths=.4,s=36,label=J)
    ax.set_xlabel("Pointwise score gap (10-pt scale)"); ax.set_ylabel("Pairwise flip rate (%)")
    ax.set_title("The pairwise--pointwise gap",fontsize=10)
    ax.legend(fontsize=8); ax.grid(alpha=.25); fig.tight_layout()
    fig.savefig("paper/figures/fig_ppg.pdf",bbox_inches="tight")
    fig.savefig("paper/figures/fig_ppg.png",dpi=200,bbox_inches="tight")
    import shutil
    for e in ["pdf","png"]: shutil.copy(f"paper/figures/fig_ppg.{e}",f"../llm-judge-groundlm-8pp/figures/fig_ppg.{e}")
    print("saved fig_ppg (clean pairwise-pointwise)")
ppg_scatter()

# --- fig2 v2: fix x-axis skew (clip + jitter), and a bigger reliability curve ---
def ppg_v2():
    import numpy as np, matplotlib.pyplot as plt, json
    old=json.load(open("results/exp1_v2_20260228_124329.json"))
    rng=np.random.default_rng(0)
    fig,ax=plt.subplots(figsize=(5.2,3.4))
    n_out=0
    for J,col,mk in [("gpt-4o-mini","#0b57d0","o"),("gpt-4.1-mini","#b3261e","s")]:
        xs,ys=[],[]
        for it in old:
            if it["judge_model"]!=J: continue
            w=[j["winner"] for j in judgments(it,"pairwise") if j.get("winner")]
            m=max(set(w),key=w.count); fr=1-w.count(m)/len(w)
            a=[j["score"] for j in judgments(it,"pointwise_a") if j.get("score") is not None]
            b=[j["score"] for j in judgments(it,"pointwise_b") if j.get("score") is not None]
            if a and b:
                g=abs(np.mean(a)-np.mean(b)); xs.append(g); ys.append(100*fr)
        xs=np.array(xs); ys=np.array(ys)
        xj=xs+rng.normal(0,0.015,len(xs))  # tiny jitter
        ax.scatter(np.clip(xj,0,1.5),ys,c=col,marker=mk,alpha=.75,edgecolors="k",linewidths=.4,s=40,label=J)
        n_out+=int((xs>1.5).sum())
    ax.axvspan(0,0.5,color="orange",alpha=.10)
    ax.text(0.02,92,"score gap $<$ 0.5 pt",fontsize=8,color="#a60")
    ax.set_xlim(-0.05,1.55); ax.set_ylim(-3,100)
    ax.set_xlabel("Pointwise score gap (10-pt scale)"); ax.set_ylabel("Pairwise flip rate (%)")
    ax.set_title("Flip rate stays high even at near-zero score gap",fontsize=10)
    ax.legend(fontsize=8,loc="upper right"); ax.grid(alpha=.25)
    ax.annotate(f"{n_out} items with gap$>$1.5 clipped",(1.5,-1),fontsize=6.5,ha="right",color="#888")
    fig.tight_layout(); fig.savefig("paper/figures/fig_ppg.pdf",bbox_inches="tight")
    fig.savefig("paper/figures/fig_ppg.png",dpi=200,bbox_inches="tight")
    import shutil
    for e in ["pdf","png"]: shutil.copy(f"paper/figures/fig_ppg.{e}",f"../llm-judge-groundlm-8pp/figures/fig_ppg.{e}")
    print(f"fig_ppg v2 saved ({n_out} outliers clipped)")

def reliability_big():
    import numpy as np, matplotlib.pyplot as plt, json
    old=json.load(open("results/exp1_v2_20260228_124329.json"))
    # build per-question winner lists (gpt-4o-mini), compute P(maj(K)=maj(50))
    def curve(items,Ks=range(1,51),reps=400):
        rng=np.random.default_rng(1); out=[]
        per=[]
        for it in items:
            w=[j["winner"] for j in judgments(it,"pairwise") if j.get("winner")]
            per.append(w)
        for K in Ks:
            hits=0; tot=0
            for w in per:
                if len(w)<K: continue
                full=max(set(w),key=w.count)
                for _ in range(reps):
                    s=list(rng.choice(w,K,replace=False))
                    if max(set(s),key=s.count)==full: hits+=1
                    tot+=1
            out.append(hits/tot)
        return list(Ks),out
    allit=[it for it in old if it["judge_model"]=="gpt-4o-mini"]
    hard=[it for it in allit if (lambda w:1-w.count(max(set(w),key=w.count))/len(w)>=0.10)([j["winner"] for j in judgments(it,"pairwise") if j.get("winner")])]
    easy=[it for it in allit if it not in hard]
    fig,ax=plt.subplots(figsize=(5.6,3.6))
    for items,lab,c in [(allit,"All questions","#111"),(easy,"Stable (FR$<$10%)","#0a7d33"),(hard,"Unstable (FR$\\geq$10%)","#b3261e")]:
        if not items: continue
        K,p=curve(items); ax.plot(K,[100*x for x in p],lw=2,label=lab,color=c)
    ax.axhline(95,ls="--",c="grey",lw=1); ax.text(1,95.5,"95%",fontsize=8,color="grey")
    ax.set_xlabel("Number of trials K"); ax.set_ylabel(r"$P(\mathrm{majority}(K)=\mathrm{majority}(50))$ (%)")
    ax.set_title("How many trials stabilize a verdict?",fontsize=10)
    ax.legend(fontsize=8,loc="lower right"); ax.grid(alpha=.25); ax.set_xlim(1,50)
    fig.tight_layout(); fig.savefig("paper/figures/fig_reliability.pdf",bbox_inches="tight")
    fig.savefig("paper/figures/fig_reliability.png",dpi=200,bbox_inches="tight")
    import shutil
    for e in ["pdf","png"]: shutil.copy(f"paper/figures/fig_reliability.{e}",f"../llm-judge-groundlm-8pp/figures/fig_reliability.{e}")
    print("fig_reliability (big) saved")

ppg_v2(); reliability_big()

def category_fig():
    import numpy as np, matplotlib.pyplot as plt, json
    from collections import defaultdict
    old=json.load(open("results/exp1_v2_20260228_124329.json"))
    cat=defaultdict(list)
    for it in old:
        w=[j["winner"] for j in judgments(it,"pairwise") if j.get("winner")]
        m=max(set(w),key=w.count); fr=1-w.count(m)/len(w)
        cat[it["category"]].append(fr)
    items=sorted(cat.items(),key=lambda kv:-np.mean(kv[1]))
    labs=[k for k,_ in items]; means=[100*np.mean(v) for _,v in items]
    fig,ax=plt.subplots(figsize=(5.4,3.2))
    ax.barh(range(len(labs)),means,color="#4c78a8")
    ax.set_yticks(range(len(labs))); ax.set_yticklabels(labs,fontsize=8); ax.invert_yaxis()
    ax.set_xlabel("Mean flip rate (%)"); ax.set_title("Instability concentrates in coding and reasoning",fontsize=10)
    ax.grid(axis="x",alpha=.25); fig.tight_layout()
    fig.savefig("paper/figures/fig_category.pdf",bbox_inches="tight")
    fig.savefig("paper/figures/fig_category.png",dpi=200,bbox_inches="tight")
    import shutil
    for e in ["pdf","png"]: shutil.copy(f"paper/figures/fig_category.{e}",f"../llm-judge-groundlm-8pp/figures/fig_category.{e}")
    print("fig_category saved; categories:",labs[:4])
category_fig()

def perquestion_fig():
    import numpy as np, matplotlib.pyplot as plt, json
    old=json.load(open("results/exp1_v2_20260228_124329.json"))
    byq={}
    for it in old:
        w=[j["winner"] for j in judgments(it,"pairwise") if j.get("winner")]
        m=max(set(w),key=w.count); fr=100*(1-w.count(m)/len(w))
        byq.setdefault(it["sample_id"],{})[it["judge_model"]]=fr
    qids=sorted(byq,key=lambda q:-np.mean(list(byq[q].values())))
    j1=[byq[q].get("gpt-4o-mini",0) for q in qids]
    j2=[byq[q].get("gpt-4.1-mini",0) for q in qids]
    x=np.arange(len(qids)); w=0.4
    fig,ax=plt.subplots(figsize=(9,3.0))
    ax.bar(x-w/2,j1,w,label="gpt-4o-mini",color="#4c78a8")
    ax.bar(x+w/2,j2,w,label="gpt-4.1-mini",color="#e45756")
    ax.axhspan(40,50,color="grey",alpha=.12)
    ax.set_xticks(x); ax.set_xticklabels(qids,rotation=90,fontsize=5)
    ax.set_ylabel("Flip rate (%)"); ax.set_xlabel("Question (sorted by mean instability)")
    ax.set_title("Flip rates are bimodal: most items stable, a hard tail near coin-flip",fontsize=10)
    ax.legend(fontsize=8); ax.grid(axis="y",alpha=.25); fig.tight_layout()
    fig.savefig("paper/figures/fig_perq.pdf",bbox_inches="tight")
    fig.savefig("paper/figures/fig_perq.png",dpi=200,bbox_inches="tight")
    import shutil
    for e in ["pdf","png"]: shutil.copy(f"paper/figures/fig_perq.{e}",f"../llm-judge-groundlm-8pp/figures/fig_perq.{e}")
    print("fig_perq (full-width per-question) saved")
perquestion_fig()
