"""Concurrent runner for the latest-judges addition. Same output format as
src/runners/run_experiment.py (exp1_* and exp3_bias_*), but parallelized over a
thread pool for the I/O-bound API calls. One judge at a time (cheapest first) so
budget-limited runs still complete the cheap judges."""
import os, sys, json, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.evaluators.judges import judge_pairwise, judge_pointwise
from src.metrics.consistency import flip_rate, position_bias_index

JUDGES = ["gpt-5.4-nano", "gpt-5.4-mini", "claude-haiku-4.5"]
PAIRWISE_N = 40
POINTWISE_N = 40
SWAP_N = 30
WORKERS = 10
OUT = "results/latest_judges"
os.makedirs(OUT, exist_ok=True)

pairs = json.load(open("data/eval_pairs.json"))


def submit_all(pool, tasks):
    """tasks: list of (key, callable). Returns {key: result}."""
    futs = {pool.submit(fn): key for key, fn in tasks}
    out = {}
    done = 0
    for f in as_completed(futs):
        out[futs[f]] = f.result()
        done += 1
        if done % 200 == 0:
            print(f"    ...{done}/{len(tasks)} calls", flush=True)
    return out


def run_judge(judge, pool):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    ra_model = pairs[0]["response_a"]["model"]
    rb_model = pairs[0]["response_b"]["model"]

    # ---------- exp1: pairwise + pointwise ----------
    tasks = []
    for p in pairs:
        q, a, b = p["question"], p["response_a"]["text"], p["response_b"]["text"]
        for i in range(PAIRWISE_N):
            tasks.append(((p["id"], "pw", i),
                          lambda q=q, a=a, b=b, p=p, i=i: judge_pairwise(judge, q, a, b, p["id"], i)))
        for i in range(POINTWISE_N):
            tasks.append(((p["id"], "pa", i),
                          lambda q=q, a=a, p=p, i=i: judge_pointwise(judge, q, a, p["id"], i)))
            tasks.append(((p["id"], "pb", i),
                          lambda q=q, b=b, p=p, i=i: judge_pointwise(judge, q, b, p["id"], i)))
    print(f"  exp1 {judge}: {len(tasks)} calls", flush=True)
    res = submit_all(pool, tasks)
    exp1 = []
    for p in pairs:
        pw = [res[(p["id"], "pw", i)] for i in range(PAIRWISE_N)]
        pa = [res[(p["id"], "pa", i)] for i in range(POINTWISE_N)]
        pb = [res[(p["id"], "pb", i)] for i in range(POINTWISE_N)]
        winners = [j.winner for j in pw]
        exp1.append({
            "sample_id": p["id"], "category": p["category"], "judge_model": judge,
            "response_a_model": ra_model, "response_b_model": rb_model,
            "pairwise": {"judgments": [j.to_dict() for j in pw], "metrics": flip_rate(winners)},
            "pointwise_a": {"judgments": [j.to_dict() for j in pa],
                            "metrics": _pmetrics([j.score for j in pa])},
            "pointwise_b": {"judgments": [j.to_dict() for j in pb],
                            "metrics": _pmetrics([j.score for j in pb])},
        })
    json.dump(exp1, open(f"{OUT}/exp1_{judge.replace('.','_')}_{ts}.json", "w"), indent=1, default=str)
    print(f"  exp1 {judge}: saved", flush=True)

    # ---------- exp3: swap-order ----------
    tasks = []
    for p in pairs:
        q, a, b = p["question"], p["response_a"]["text"], p["response_b"]["text"]
        for i in range(SWAP_N):
            tasks.append(((p["id"], "orig", i),
                          lambda q=q, a=a, b=b, p=p, i=i: judge_pairwise(judge, q, a, b, p["id"] + "_orig", i)))
            tasks.append(((p["id"], "swap", i),
                          lambda q=q, a=a, b=b, p=p, i=i: judge_pairwise(judge, q, b, a, p["id"] + "_swap", i)))
    print(f"  exp3 {judge}: {len(tasks)} calls", flush=True)
    res = submit_all(pool, tasks)
    exp3 = []
    for p in pairs:
        ow = [res[(p["id"], "orig", i)].winner for i in range(SWAP_N)]
        sw = [res[(p["id"], "swap", i)].winner for i in range(SWAP_N)]
        exp3.append({
            "sample_id": p["id"], "category": p["category"], "judge_model": judge,
            "original_winners": ow, "swapped_winners": sw,
            "bias_metrics": position_bias_index(ow, sw),
        })
    json.dump(exp3, open(f"{OUT}/exp3_bias_{judge.replace('.','_')}_{ts}.json", "w"), indent=1, default=str)
    print(f"  exp3 {judge}: saved", flush=True)


def _pmetrics(scores):
    v = [s for s in scores if s is not None]
    if not v:
        return {"error": "no valid scores"}
    import numpy as np
    return {"mean": float(np.mean(v)), "std": float(np.std(v)), "n": len(v)}


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        for judge in JUDGES:
            t0 = time.time()
            print(f"===== JUDGE: {judge} =====", flush=True)
            try:
                run_judge(judge, pool)
                print(f"===== {judge} DONE in {time.time()-t0:.0f}s =====", flush=True)
            except Exception as e:
                print(f"===== {judge} FAILED: {e} =====", flush=True)
    print("ALL LATEST JUDGES COMPLETE", flush=True)
