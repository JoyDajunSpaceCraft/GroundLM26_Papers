#!/bin/bash
set -a; source .env; set +a
cd "$(dirname "$0")"
# cheapest first (nano, mini) then haiku; exp1 (40 trials) + exp3 swap (30 trials)
for judge in gpt-5.4-nano gpt-5.4-mini claude-haiku-4.5; do
  echo "===== JUDGE: $judge ====="
  .venv/bin/python -m src.runners.run_experiment --experiment all \
    --judges "$judge" --repeats 40 --data data/eval_pairs.json \
    --output results/latest_judges || echo "FAILED $judge"
done
echo "===== LATEST-JUDGES RUN COMPLETE ====="
