"""Regenerate every figure with all 5 judges and compute 5-judge table data
(cross-judge kappa matrix, per-category flip rates). Uses existing exp1/exp3
data; no new experiments."""
import json, glob
from collections import defaultdict
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import shutil, os

def jg(it,k):
    v=it[k]; return v["judgments"] if isinstance(v,dict) else v

# --- load all judges (old + new) into a unified per-judge item list ---
old=json.load(open("results/exp1_v2_20260228_124329.json"))
DATA=defaultdict(list)
for it in old:
    DATA[it["judge_model"]].append(it)
for f in glob.glob("results/latest_judges/exp1_*.json"):
    d=json.load(open(f))
    for it in d: DATA[it["judge_model"]].append(it)

ORDER=["gpt-4o-mini","gpt-4.1-mini","gpt-5.4-nano","gpt-5.4-mini","claude-haiku-4.5"]
SHORT={"gpt-4o-mini":"4o-mini","gpt-4.1-mini":"4.1-mini","gpt-5.4-nano":"5.4-nano",
       "gpt-5.4-mini":"5.4-mini","claude-haiku-4.5":"haiku-4.5"}
COL={"gpt-4o-mini":"#4c78a8","gpt-4.1-mini":"#f58518","gpt-5.4-nano":"#54a24b",
     "gpt-5.4-mini":"#b279a2","claude-haiku-4.5":"#e45756"}
MK={"gpt-4o-mini":"o","gpt-4.1-mini":"s","gpt-5.4-nano":"^","gpt-5.4-mini":"D","claude-haiku-4.5":"v"}

def fr_of(w):
    v=[x for x in w if x]; m=max(set(v),key=v.count); return 1-v.count(m)/len(v)
def maj_of(w):
    v=[x for x in w if x]; return max(set(v),key=v.count)

# per-judge per-question: winners, flip, ppg, majority
PQ=defaultdict(dict)  # judge -> qid -> dict
for J in ORDER:
    for it in DATA[J]:
        w=[x["winner"] for x in jg(it,"pairwise") if x.get("winner")]
        a=[x["score"] for x in jg(it,"pointwise_a") if x.get("score") is not None]
        b=[x["score"] for x in jg(it,"pointwise_b") if x.get("score") is not None]
        PQ[J][it["sample_id"]]=dict(fr=100*fr_of(w),maj=maj_of(w),
            ppg=(abs(np.mean(a)-np.mean(b)) if a and b else None),cat=it["category"])

# ============ FIG PPG (5 judges) ============
rng=np.random.default_rng(0)
fig,ax=plt.subplots(figsize=(5.6,3.7)); nout=0
for J in ORDER:
    xs=[d["ppg"] for d in PQ[J].values() if d["ppg"] is not None]
    ys=[d["fr"] for d in PQ[J].values() if d["ppg"] is not None]
    xs=np.array(xs); ys=np.array(ys); xj=xs+rng.normal(0,0.012,len(xs))
    ax.scatter(np.clip(xj,0,1.5),ys,c=COL[J],marker=MK[J],alpha=.75,edgecolors="k",linewidths=.3,s=34,label=SHORT[J])
    nout+=int((xs>1.5).sum())
ax.axvspan(0,0.5,color="orange",alpha=.10); ax.text(0.02,92,"score gap $<$ 0.5 pt",fontsize=8,color="#a60")
ax.set_xlim(-0.05,1.55); ax.set_ylim(-3,100)
ax.set_xlabel("Pointwise score gap (10-pt scale)"); ax.set_ylabel("Pairwise flip rate (%)")
ax.set_title("Flip rate stays high even at near-zero score gap (all judges)",fontsize=9.5)
ax.legend(fontsize=7,ncol=2,loc="upper right"); ax.grid(alpha=.25)
fig.tight_layout(); fig.savefig("paper/figures/fig_ppg.pdf",bbox_inches="tight"); fig.savefig("paper/figures/fig_ppg.png",dpi=200,bbox_inches="tight")

# ============ FIG PERQ (5-judge heatmap) ============
qids=sorted(PQ["gpt-4o-mini"], key=lambda q: -np.mean([PQ[J][q]["fr"] for J in ORDER if q in PQ[J]]))
M=np.array([[PQ[J].get(q,{}).get("fr",np.nan) for q in qids] for J in ORDER])
fig,ax=plt.subplots(figsize=(9,2.6))
im=ax.imshow(M,aspect="auto",cmap="RdYlGn_r",vmin=0,vmax=60)
ax.set_yticks(range(len(ORDER))); ax.set_yticklabels([SHORT[J] for J in ORDER],fontsize=8)
ax.set_xticks(range(len(qids))); ax.set_xticklabels(qids,rotation=90,fontsize=4.5)
ax.set_xlabel("Question (sorted by mean instability across judges)")
cb=fig.colorbar(im,ax=ax,fraction=0.025,pad=0.01); cb.set_label("Flip rate (%)",fontsize=8)
ax.set_title("Per-question flip rate across all five judges",fontsize=10)
fig.tight_layout(); fig.savefig("paper/figures/fig_perq.pdf",bbox_inches="tight"); fig.savefig("paper/figures/fig_perq.png",dpi=200,bbox_inches="tight")

# ============ FIG CATEGORY (5 judges) ============
cats=defaultdict(lambda: defaultdict(list))
for J in ORDER:
    for q,d in PQ[J].items(): cats[d["cat"]][J].append(d["fr"])
catmean={c:np.mean([np.mean(v) for v in d.values()]) for c,d in cats.items()}
order_c=sorted(catmean,key=lambda c:catmean[c])
fig,ax=plt.subplots(figsize=(5.6,3.6))
y=np.arange(len(order_c))
for i,J in enumerate(ORDER):
    vals=[np.mean(cats[c][J]) if cats[c][J] else 0 for c in order_c]
    ax.scatter(vals,y,c=COL[J],marker=MK[J],s=34,label=SHORT[J],edgecolors="k",linewidths=.3,zorder=3)
ax.barh(y,[catmean[c] for c in order_c],color="#ccc",alpha=.5,zorder=1)
ax.set_yticks(y); ax.set_yticklabels(order_c,fontsize=8)
ax.set_xlabel("Flip rate (%)"); ax.set_title("Instability by category (bar = mean over judges)",fontsize=9.5)
ax.legend(fontsize=7,ncol=2); ax.grid(axis="x",alpha=.25)
fig.tight_layout(); fig.savefig("paper/figures/fig_category.pdf",bbox_inches="tight"); fig.savefig("paper/figures/fig_category.png",dpi=200,bbox_inches="tight")

# ============ FIG RELIABILITY (5 judges) ============
def curve(items,Kmax,reps=300):
    rng=np.random.default_rng(1); out=[]
    per=[[x["winner"] for x in jg(it,"pairwise") if x.get("winner")] for it in items]
    for K in range(1,Kmax+1):
        h=t=0
        for w in per:
            if len(w)<K: continue
            full=max(set(w),key=w.count)
            for _ in range(reps):
                s=list(rng.choice(w,K,replace=False))
                h+=(max(set(s),key=s.count)==full); t+=1
        out.append(100*h/t)
    return list(range(1,Kmax+1)),out
fig,ax=plt.subplots(figsize=(5.8,3.7))
for J in ORDER:
    Kmax=min(len(jg(DATA[J][0],"pairwise")),40)
    K,p=curve(DATA[J],Kmax); ax.plot(K,p,lw=1.8,color=COL[J],label=SHORT[J])
ax.axhline(95,ls="--",c="grey",lw=1); ax.text(1,95.6,"95%",fontsize=8,color="grey")
ax.set_xlabel("Number of trials K"); ax.set_ylabel(r"$P(\mathrm{maj}(K){=}\mathrm{maj}(N))$ (%)")
ax.set_title("Trials needed to stabilize a verdict (all judges)",fontsize=9.5)
ax.legend(fontsize=7,ncol=2,loc="lower right"); ax.grid(alpha=.25); ax.set_xlim(1,40)
fig.tight_layout(); fig.savefig("paper/figures/fig_reliability.pdf",bbox_inches="tight"); fig.savefig("paper/figures/fig_reliability.png",dpi=200,bbox_inches="tight")

# ============ TABLE DATA: kappa matrix + per-category ============
def kappa(j1,j2):
    qs=[q for q in PQ[j1] if q in PQ[j2]]
    a=[PQ[j1][q]["maj"] for q in qs]; b=[PQ[j2][q]["maj"] for q in qs]
    labels=sorted(set(a)|set(b)); po=np.mean([x==y for x,y in zip(a,b)])
    pe=sum((a.count(l)/len(a))*(b.count(l)/len(b)) for l in labels)
    return (po-pe)/(1-pe) if pe<1 else 1.0, po
print("=== KAPPA MATRIX ===")
print("        "+" ".join(f"{SHORT[j]:>9}" for j in ORDER))
for j1 in ORDER:
    row=[]
    for j2 in ORDER:
        if j1==j2: row.append("   --   ")
        else: k,_=kappa(j1,j2); row.append(f"{k:>8.2f}")
    print(f"{SHORT[j1]:>9} "+" ".join(row))
print("\n=== PER-CATEGORY (5 judges) ===")
allcats=sorted(catmean,key=lambda c:-catmean[c])
print("category    n  "+" ".join(f"{SHORT[j]:>9}" for j in ORDER))
for c in allcats:
    n=len(next(iter(cats[c].values())))
    print(f"{c:11} {n:>2}  "+" ".join(f"{np.mean(cats[c][j]):>8.1f}" for j in ORDER))

# copy all figs to 8pp
for fn in ["fig_ppg","fig_perq","fig_category","fig_reliability"]:
    for e in ["pdf","png"]:
        shutil.copy(f"paper/figures/{fn}.{e}",f"../llm-judge-groundlm-8pp/figures/{fn}.{e}")
print("\nAll 5-judge figures regenerated + copied to 8pp")
