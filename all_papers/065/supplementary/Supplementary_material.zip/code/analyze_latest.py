"""Compute the paper's metrics for the latest-judge additions, from
results/latest_judges/exp1_*.json and exp3_bias_*.json. Prints a table ready to
fold into the paper, plus cross-judge agreement vs the original judges."""
import json, glob, os
import numpy as np

LJ = "results/latest_judges"

def load_latest():
    exp1 = {}; exp3 = {}
    for f in glob.glob(f"{LJ}/exp1_*.json"):
        d = json.load(open(f)); exp1[d[0]["judge_model"]] = d
    for f in glob.glob(f"{LJ}/exp3_bias_*.json"):
        d = json.load(open(f)); exp3[d[0]["judge_model"]] = d
    return exp1, exp3

def judgments(it, key):
    v = it[key]; return v["judgments"] if isinstance(v, dict) else v

def icc21(mat):  # rows=subjects, cols=raters
    mat = np.array(mat, float); n, k = mat.shape
    gm = mat.mean(); rm = mat.mean(1); cm = mat.mean(0)
    ss_r = k*((rm-gm)**2).sum(); ss_c = n*((cm-gm)**2).sum()
    ss_t = ((mat-gm)**2).sum(); ss_e = ss_t-ss_r-ss_c
    msr = ss_r/(n-1); msc = ss_c/(k-1); mse = ss_e/((n-1)*(k-1))
    d = msr + (k-1)*mse + k*(msc-mse)/n
    return (msr-mse)/d if d else float("nan")

def analyze_exp1(judge, data):
    frs, fr0, gt20, mx, ppgs = [], 0, 0, 0, []
    a_mat, b_mat = [], []
    for it in data:
        w = [j["winner"] for j in judgments(it, "pairwise")]
        valid = [x for x in w if x]
        maj = max(set(valid), key=valid.count)
        fr = 1 - valid.count(maj)/len(valid)
        frs.append(fr); fr0 += (fr == 0); gt20 += (fr > 0.20); mx = max(mx, fr)
        a = [j["score"] for j in judgments(it, "pointwise_a") if j.get("score") is not None]
        b = [j["score"] for j in judgments(it, "pointwise_b") if j.get("score") is not None]
        if a and b: ppgs.append(abs(np.mean(a)-np.mean(b)))
        if len(a) >= 30 and len(b) >= 30:
            a_mat.append(a[:30]); b_mat.append(b[:30])
    icc = np.nan
    if a_mat:
        icc = np.nanmean([icc21(a_mat), icc21(b_mat)])
    return dict(mean_fr=100*np.mean(frs), max_fr=100*mx, fr0=fr0, gt20=gt20,
                ppg=np.mean(ppgs), icc=icc, n=len(data))

def analyze_exp3(judge, data):
    fs = tot = pos_both = 0; content_A = content_B = 0
    for it in data:
        for o, s in zip(it["original_winners"], it["swapped_winners"]):
            if not o or not s: continue
            tot += 1
            fs += (o == "A") + (s == "A")   # first-slot picks across both orders
            if o == "A" and s == "A": pos_both += 1
            if o == "A" and s == "B": content_A += 1
            elif o == "B" and s == "A": content_B += 1
    n_cc = content_A + content_B
    return dict(first_slot=100*fs/(2*tot), pos_both=100*pos_both/tot,
                content_consistent=100*n_cc/tot,
                self_pref=100*content_A/n_cc if n_cc else float("nan"), n=tot)

if __name__ == "__main__":
    exp1, exp3 = load_latest()
    print("\n=== LATEST JUDGES: intra-judge (exp1) ===")
    print(f"{'judge':16} {'meanFR%':>8} {'maxFR%':>7} {'FR=0':>5} {'FR>20':>6} {'PPG':>5} {'ICC':>5}")
    for j, d in exp1.items():
        r = analyze_exp1(j, d)
        print(f"{j:16} {r['mean_fr']:>8.1f} {r['max_fr']:>7.0f} {r['fr0']:>5} {r['gt20']:>6} {r['ppg']:>5.2f} {r['icc']:>5.2f}")
    print("\n=== LATEST JUDGES: swap-order position bias (exp3) ===")
    print(f"{'judge':16} {'firstslot%':>10} {'posboth%':>9} {'contentcons%':>13} {'selfpref%':>10}")
    for j, d in exp3.items():
        r = analyze_exp3(j, d)
        print(f"{j:16} {r['first_slot']:>10.1f} {r['pos_both']:>9.1f} {r['content_consistent']:>13.1f} {r['self_pref']:>10.1f}")
