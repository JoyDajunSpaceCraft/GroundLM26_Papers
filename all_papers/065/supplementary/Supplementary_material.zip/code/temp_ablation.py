"""E2 temperature ablation on the 2026 judges: pairwise flip rate at t=0.
10 trials/question x 29 questions x 3 judges, concurrent. -> results/temp_ablation_new.json"""
import json, sys, os
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.evaluators.judges import judge_pairwise
JUDGES=["gpt-5.4-nano","gpt-5.4-mini","claude-haiku-4.5"]
TRIALS=10
pairs=json.load(open("data/eval_pairs.json"))
out={}
with ThreadPoolExecutor(max_workers=10) as pool:
    for J in JUDGES:
        tasks={}
        for p in pairs:
            for i in range(TRIALS):
                fut=pool.submit(judge_pairwise, J, p["question"], p["response_a"]["text"],
                                p["response_b"]["text"], p["id"], i, True, 0.0)  # temperature=0
                tasks[fut]=(p["id"],i)
        res={}
        for f in as_completed(tasks):
            res[tasks[f]]=f.result().winner
        # flip rate per question
        frs=[]
        for p in pairs:
            w=[res[(p["id"],i)] for i in range(TRIALS) if res.get((p["id"],i))]
            if not w: continue
            m=max(set(w),key=w.count); frs.append(1-w.count(m)/len(w))
        import numpy as np
        mean_fr=100*np.mean(frs); n_flip=sum(1 for f in frs if f>0)
        out[J]={"mean_fr_t0":round(mean_fr,1),"n_items_flip":n_flip,"n_items":len(frs)}
        print(f"{J}: mean flip@t0 = {mean_fr:.1f}%, {n_flip}/{len(frs)} items still flip", flush=True)
json.dump(out, open("results/temp_ablation_new.json","w"), indent=2)
print("SAVED", flush=True)
