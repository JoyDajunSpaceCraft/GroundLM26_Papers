"""Generate fig_5judge: flip rate and symmetric order-driven rate, five judges.

Left panel: mean and worst-case pairwise flip rate per judge, with the reference
line for a judge drawing uniformly over {A, B, tie} at N=50.
Right panel: order-driven rate from the swap experiment, split by whether the
judge locks onto the first or the second slot. Both panels are computed from
results/ rather than hard-coded.
"""
import json, glob, collections
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def judgments(it, k):
    v = it[k]; return v["judgments"] if isinstance(v, dict) else v
def fr_of(it):
    w = [j["winner"] for j in judgments(it, "pairwise") if j.get("winner")]
    m = max(set(w), key=w.count); return 1 - w.count(m) / len(w)

old = json.load(open("results/exp1_v2_20260228_124329.json"))
data = {}
for J in ["gpt-4o-mini", "gpt-4.1-mini"]:
    frs = [fr_of(it) for it in old if it["judge_model"] == J]
    data[J] = (100*np.mean(frs), 100*max(frs))
for f in glob.glob("results/latest_judges/exp1_*.json"):
    d = json.load(open(f)); frs = [fr_of(it) for it in d]
    data[d[0]["judge_model"]] = (100*np.mean(frs), 100*max(frs))

# --- symmetric order-driven rate, computed from the swap experiment ---
R = collections.defaultdict(list)
for f in ["results/exp3_bias_20260705_204931.json"] + glob.glob("results/latest_judges/exp3_bias*.json"):
    for r in json.load(open(f)): R[r["judge_model"]].append(r)
first_d, second_d = {}, {}
for j, rs in R.items():
    pA = pB = P = 0
    for r in rs:
        for a, b in zip(r["original_winners"], r["swapped_winners"]):
            if a in ("A","B","tie") and b in ("A","B","tie"):
                P += 1
                if a == "A" and b == "A": pA += 1
                elif a == "B" and b == "B": pB += 1
    first_d[j], second_d[j] = 100*pA/P, 100*pB/P

order = ["gpt-4o-mini","gpt-4.1-mini","gpt-5.4-nano","gpt-5.4-mini","claude-haiku-4.5"]
labels = ["gpt-4o-mini\n(2024)","gpt-4.1-mini\n(2025)","gpt-5.4-nano\n(2026)",
          "gpt-5.4-mini\n(2026)","haiku-4.5\n(2026)"]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 3.6))
x = np.arange(len(order)); w = 0.38
ax1.bar(x-w/2, [data[j][0] for j in order], w, label="Mean flip rate", color="#4c78a8")
ax1.bar(x+w/2, [data[j][1] for j in order], w, label="Max flip rate", color="#e45756", alpha=.85)
# three-outcome coin-flip reference at N=50 (simulated E[FR] = 59.7%)
ax1.axhline(59.7, color="grey", ls="--", lw=1)
ax1.text(len(order)-0.5, 61, "uniform A/B/tie reference (59.7%)", fontsize=6.5, ha="right", color="grey")
ax1.set_xticks(x); ax1.set_xticklabels(labels, fontsize=7)
ax1.set_ylabel("Flip rate (%)"); ax1.set_title("Run-to-run instability persists", fontsize=10)
ax1.legend(fontsize=8); ax1.grid(axis="y", alpha=.25)

fd = [first_d[j] for j in order]; sd = [second_d[j] for j in order]
ax2.bar(x, fd, w*1.6, label="locks onto 1st slot", color="#0b57d0")
ax2.bar(x, sd, w*1.6, bottom=fd, label="locks onto 2nd slot", color="#f2a900")
for xi, (a, b) in enumerate(zip(fd, sd)):
    ax2.text(xi, a+b+1.2, f"{a+b:.1f}", ha="center", fontsize=7, fontweight="bold")
ax2.set_xticks(x); ax2.set_xticklabels(labels, fontsize=7)
ax2.set_ylim(0, max(np.array(fd)+np.array(sd))*1.25)
ax2.set_ylabel("Order-driven (%)")
ax2.set_title("Order bias reverses direction, it does not go away", fontsize=9.5)
ax2.legend(fontsize=7.5); ax2.grid(axis="y", alpha=.25)
fig.tight_layout()
import shutil, os
os.makedirs("paper/figures", exist_ok=True)
fig.savefig("paper/figures/fig_5judge.pdf", bbox_inches="tight")
fig.savefig("paper/figures/fig_5judge.png", dpi=200, bbox_inches="tight")
for ext in ["pdf","png"]:
    shutil.copy(f"paper/figures/fig_5judge.{ext}", f"../llm-judge-groundlm-8pp/figures/fig_5judge.{ext}")
print("flip rates:", {j: tuple(round(v,1) for v in data[j]) for j in order})
print("order-driven:", {j: round(first_d[j]+second_d[j],1) for j in order})
