#!/bin/bash
# Post-review experiment campaign via OpenRouter (checkpointed by the runner).
set -a; source .env; set +a
cd "$(dirname "$0")"
echo "== STAGE 1: swap-order position-bias experiment (2 original judges) =="
.venv/bin/python -m src.runners.run_experiment --experiment exp3 \
  --judges gpt-4o-mini gpt-4.1-mini --repeats 30 --output results || exit 1
echo "== STAGE 2: third-provider judge (gemini-2.5-flash), 50-trial exp1 =="
.venv/bin/python -m src.runners.run_experiment --experiment exp1 \
  --judges gemini-2.5-flash --repeats 50 --output results || exit 1
echo "== CAMPAIGN COMPLETE =="
