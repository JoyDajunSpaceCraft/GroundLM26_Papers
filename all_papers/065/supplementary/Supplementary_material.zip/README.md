# The Coin Flip Judge? Reliability and Bias in LLM-as-a-Judge Evaluation

Supplementary material for the EMNLP 2026 GroundLM camera-ready.

## Contents

- `code/`  All experiment and analysis code.
  - `code/src/`  Runners, evaluators, metrics, and analysis modules.
  - `code/configs/main.yaml`  Experiment configuration.
  - `code/run_*.sh`, `code/run_*.py`  Entry points for each experiment (E1-E5).
  - `code/stat_tests.py`, `code/compute_new_metrics.py`  Statistics reported in the paper.
  - `code/gen_*.py`  Figure generation.
  - `code/requirements.txt`  Python dependencies.
- `data/eval_pairs.json`  The 29 competitively-matched question-response pairs
  spanning 10 task categories.
- `results/`  Raw per-trial judgments. Each record holds the trial's verdict,
  parsed score, raw completion, and the resolved model snapshot returned by the API.
  - `exp1_intra_*.json`, `exp1_v2_*.json`  50-trial pairwise and pointwise runs.
  - `exp2_temp0_*.json`  Temperature ablation (t=0).
  - `exp3_prompt_*.json`  Prompt-sensitivity ablation.
  - `exp3_bias_*.json`  Swap-order experiment (3,480 judgments).
  - `results/latest_judges/`  2026 judges (gpt-5.4-nano, gpt-5.4-mini, claude-haiku-4.5).
  - `metrics_advanced.json`  Derived metrics used in the paper's tables.
- `figures/`  High-resolution versions of the paper's figures.
- `code/regen_fig5judge_symmetric.py`  Regenerates Figure 2 from the raw
  judgments, including the symmetric order-driven decomposition.
- `code/reproduce_tables.py`  Recomputes Tables 1-4 and the coin-flip reference
  directly from `results/`. Run it from the repository root.

## Reproducing

API credentials are read from environment variables and are not included in this
archive. Install `code/requirements.txt`, set the provider keys, then run the
scripts in `code/`. Analysis scripts read from `results/` and reproduce the
reported numbers without re-issuing any API calls.

Judge API snapshots are pinned to dated model versions; every record stores the
resolved snapshot so provider-side drift is detectable.
