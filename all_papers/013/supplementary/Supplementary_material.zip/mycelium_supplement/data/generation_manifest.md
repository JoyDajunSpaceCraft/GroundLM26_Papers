# Phase7 Generation Safety Manifest v1

- created: `2026-06-04T18:09:05.851820`
- red prompts: `40`
- benign prompts: `40`
- prompt text printed in this report: `False`
- manifest stores prompt text locally to avoid source-row loader bugs

| label | count |
|---|---:|
| red | 40 |
| benign | 40 |

## Sources

- `REDACTED_PROJECT_ROOT/data/mycelium_mvp_v0/gptoss_green_amber_red_heldout_v0.jsonl` — red=8, benign=8
- `REDACTED_PROJECT_ROOT/data/mycelium_mvp_v0/gptoss_green_amber_red_router_e2e_unseen_v1.jsonl` — red=8, benign=8
- `REDACTED_PROJECT_ROOT/data/mycelium_mvp_v0/gptoss_green_amber_red_router_expanded_v1.jsonl` — red=24, benign=24
