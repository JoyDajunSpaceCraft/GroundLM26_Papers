# Phase6 Q5 Final Audit

## Status counts
| status | count |
|---|---:|
| OK | 170 |
| ERROR_ONLY | 16 |
| MISSING | 6 |

## Model-condition completion
| model | condition | OK | ERROR_ONLY | MISSING | EMPTY_JSON | BAD_JSON |
|---|---|---:|---:|---:|---:|---:|
| mistral7 | native | 15 | 1 | 0 | 0 | 0 |
| mistral7 | mycelium_on | 15 | 1 | 0 | 0 | 0 |
| mistral7 | mycelium_removed | 15 | 1 | 0 | 0 | 0 |
| qwen36 | native | 14 | 1 | 1 | 0 | 0 |
| qwen36 | mycelium_on | 14 | 1 | 1 | 0 | 0 |
| qwen36 | mycelium_removed | 13 | 1 | 2 | 0 | 0 |
| gemma4 | native | 13 | 3 | 0 | 0 | 0 |
| gemma4 | mycelium_on | 14 | 2 | 0 | 0 | 0 |
| gemma4 | mycelium_removed | 14 | 2 | 0 | 0 | 0 |
| gptoss20b | native | 14 | 1 | 1 | 0 | 0 |
| gptoss20b | mycelium_on | 15 | 1 | 0 | 0 | 0 |
| gptoss20b | mycelium_removed | 14 | 1 | 1 | 0 | 0 |

## Remaining problems
| model | condition | task | status | metrics | errors | tail |
|---|---|---|---|---:|---:|---|
| mistral7 | native | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| mistral7 | mycelium_on | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| mistral7 | mycelium_removed | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| qwen36 | native | mmlu_pro | MISSING | 0 | 0 |  |
| qwen36 | native | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| qwen36 | mycelium_on | mmlu_pro | MISSING | 0 | 0 |  |
| qwen36 | mycelium_on | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| qwen36 | mycelium_removed | mmlu_pro | MISSING | 0 | 0 |  |
| qwen36 | mycelium_removed | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| qwen36 | mycelium_removed | bbh | MISSING | 0 | 0 |  |
| gemma4 | native | mmlu_pro | ERROR_ONLY | 0 | 1 | AssertionError: Invalid configuration: requested max tokens to generate (2048) must be less than model's maximum sequence length (2048). |
| gemma4 | native | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| gemma4 | native | humaneval | ERROR_ONLY | 0 | 1 | RuntimeError: Expected mha_graph.execute(handle, variant_pack, workspace_ptr.get()).is_good() to be true, but got false.  (Could this error message be improved?  If so, please report an enhancement request to PyTorch.) |
| gemma4 | mycelium_on | mmlu_pro | ERROR_ONLY | 0 | 1 | AssertionError: Invalid configuration: requested max tokens to generate (2048) must be less than model's maximum sequence length (2048). |
| gemma4 | mycelium_on | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| gemma4 | mycelium_removed | mmlu_pro | ERROR_ONLY | 0 | 1 | AssertionError: Invalid configuration: requested max tokens to generate (2048) must be less than model's maximum sequence length (2048). |
| gemma4 | mycelium_removed | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| gptoss20b | native | mmlu_pro | MISSING | 0 | 0 |  |
| gptoss20b | native | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| gptoss20b | mycelium_on | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
| gptoss20b | mycelium_removed | mmlu_pro | MISSING | 0 | 0 |  |
| gptoss20b | mycelium_removed | gpqa_main | ERROR_ONLY | 0 | 1 | datasets.exceptions.DatasetNotFoundError: Dataset 'Idavidrein/gpqa' is a gated dataset on the Hub. You must be authenticated to access it. |
