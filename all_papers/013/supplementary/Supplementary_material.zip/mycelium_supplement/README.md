# Mycelium: GroundLM camera-ready reanalysis supplement

This self-contained package reproduces aggregate statistics from the supplied archival score records. It does not reproduce model training or generation. No GPU, network access, model weights, or attack checkpoints are required.

## Run

Use Python 3.12 with the versions in `requirements.txt`. Install these dependencies in your own environment, then run `python reproduce.py` from this directory. Outputs are written to `results/`. The fixed bootstrap seed is 20260905 with 20,000 replicates. The included results were regenerated and compared with the paper. `results/environment.json` records the environment used.

Use `python reproduce.py --output-dir fresh_results` to regenerate into an empty directory. `--tables-only` explicitly skips figures when only NumPy is installed. The default command requires Matplotlib and fails visibly if figure generation fails. PDF figures are written through temporary files so a failed render cannot silently replace a valid figure with an empty file.

Run `sha256sum -c SHA256SUMS` before reproduction to verify the distributed package. Checksums describe the shipped bytes; dependency changes can change figure bytes without changing statistics.

## Evidence map

| Paper evidence | Input | Reproduction scope |
|---|---|---|
| Four-family utility and sensitivity | data/benchmark_records.json | Per-task scores, 52 retained triplets, bootstrap intervals, common tasks, relative loss, missing-cell bounds |
| Mistral targeted utility controls | data/mistral_controls.tsv | Four task rows, condition means, and maximum bypass task loss; transcribed from the supplied paper |
| Panel A uncertainty | data/generation_a.tsv | Counts transcribed from the supplied paper, Wilson intervals, and hypothetical pairing sensitivity; original row annotations unavailable |
| Panel B | data/generation_b.tsv | Historical aggregate indicators, count/rate consistency, and marginal Wilson intervals; not equivalent to Panel A |
| Repair | data/repair.tsv | Archived loss panel and arithmetic consistency of train/holdout recovery |
| Erosion | data/erosion.tsv | Archived selected-checkpoint/endpoint summaries and the five-versus-zero CE-screening count |
| Coverage | data/missing_cells.md | Historical errors and missing cells |
| Prompt-pool size | data/generation_manifest.md | Pool metadata only, not completed evaluation counts |
| GPT-OSS discrepancy | data/gptoss_discrepancy.md | Distinct static CE audit; not the Phase-6 benchmark condition |

The `source_sha256` fields identify original supplied task JSONs before extraction. Those hashes are provenance references, not a claim that the source files are included. `SHA256SUMS` hashes the files actually included here.

`DATA_PROVENANCE.md` distinguishes paper transcriptions from historical machine-readable records. `results/panel_summaries.json` contains the panel arithmetic, while `results/exclusions.tsv` lists all omitted task triplets. No panel reconstruction creates new model observations.

## Corrections and interpretation

The primary analysis excludes Mistral GSM8K (8-example native/on versus full removed), Qwen GSM8K (4-example native), and Mistral OpenBookQA (four-example removed snapshot conflicting with historical 0.266 aggregate). Retained triplets are 13, 12, 13, and 14. Excluded records remain visible; use `primary_included` in results/per_task.tsv before aggregating. Missing values are never zeros. Some historical metric tokens were anonymized upstream; we preserve them without guessing their replacements.

Panel A counts were reconstructed from rounded rates and a stated denominator in the supplied paper. Refusal, compliance, and ambiguity are overlapping indicators, not an exhaustive categorical partition. The two hypothetical McNemar results are NOT observed paired tests. Panel B uses broader labels and must not be pooled with Panel A. Neither supplies a matched native safety comparison or documented inter-annotator agreement. Neither raw output annotations nor an annotation template is included. Adaptive CE proxies do not establish unsafe generation or confirmed clean removal.

## Privacy and scope

This package contains aggregate scores and sanitized metadata. It excludes review text, author identifiers, credentials, raw prompts, generated completions, executable attack code, and model checkpoints. Historical local roots are redacted. It is a replacement analysis supplement, not a full model-release artifact.
