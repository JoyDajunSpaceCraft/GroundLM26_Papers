# Provenance and reproduction boundary

This document describes the evidence available in this reanalysis package. It does not certify historical execution or recover missing training artifacts.

| File | Origin and scope |
|---|---|
| `data/benchmark_records.json` | Preserved from the supplied reanalysis package. Contains 180 model/task/condition records, including 170 scores, with extracted evaluation metadata and references to original source-file hashes. The original task JSON files themselves are not included. |
| `data/mistral_controls.tsv` | Transcribed from Table 2 of the supplied camera-ready PDF. Contains the four targeted utility rows with 200 examples per task. No new evaluation was performed; per-example predictions are unavailable. |
| `data/generation_a.tsv` | Transcribed from Table 3 of the supplied camera-ready PDF. That table states that counts were reconstructed from historical rounded rates and a denominator of 12. The transcript is an aggregate input, not a recovered annotation file. |
| `data/generation_b.tsv` | Historical aggregate audit file preserved unchanged. It summarizes 72 outputs in six condition/category groups. Individual output labels and prompt pairing are unavailable. |
| `data/repair.tsv` | Historical repair-loss summaries preserved unchanged. The script checks the arithmetic between train recovery, held-out recovery, and the overfit gap. |
| `data/erosion.tsv` | Historical selected-checkpoint and endpoint summaries preserved unchanged. The script applies the archived 0.25/0.25 CE screening rule; these thresholds are not the formal behavioral clean-removal criterion. Full training trajectories are not included. |
| `data/missing_cells.md` | Historical ledger preserved unchanged. Its 192 cells include 12 GPQA errors; the paper's 15-task universe has 180 cells. |
| `data/generation_manifest.md` | Historical prompt-pool metadata preserved unchanged. The 40 red and 40 benign entries are a pool size, not 80 completed outputs per condition. |
| `data/gptoss_discrepancy.md` | Historical audit preserved unchanged. Static CE conditions and earlier configurations must remain separate from the Phase-6 benchmark removal configuration. |

## Local model identifiers

The paper uses short family names. The available successful benchmark records report these more specific local identifiers:

| Record key | Archived model label | Local base-path identifier |
|---|---|---|
| `mistral7` | `Mistral7-v0.3` | `mistralai__Mistral-7B-Instruct-v0.3` |
| `qwen36` | `Qwen3.6-35B-A3B` | `Qwen__Qwen3.6-35B-A3B` |
| `gemma4` | `Gemma-4-31B-it` | `google__gemma-4-31B-it/145dc2508c480a64b47242f160d286cff94a2343` |
| `gptoss20b` | `GPT-OSS-20B` | `openai__gpt-oss-20b/6cee5e81ee83917806bbde320786a8fb61efebee` |

These are metadata observations, not independently verified checkpoint identities. In particular, a pathname or a `main` revision field is not a cryptographic identity for all executable components. The record-level metadata should be consulted for each comparison.

## Preserved limitations

The package cannot reproduce training, run new harmful/benign generations, establish native-to-bypass equivalence, reconstruct a paired significance test, identify annotators, compute inter-annotator agreement, or compare safety-path deletion against matched random/utility-path controls. A HumanEval metric token was anonymized upstream; it is preserved without guessing its original spelling. The current implementation provides aggregate reanalysis only.
