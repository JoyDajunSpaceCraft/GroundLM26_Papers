| Dataset | Method | Llama F1 / Red. | Mistral F1 / Red. | Mistral Fixed Top-10 F1 |
| --- | --- | --- | --- | --- |
| SciFact | Adaptive-k | 0.251 / 74.9% | 0.259 / 74.0% | 0.189 |
| SciFact | Safe Adaptive Context | 0.247 / 69.9% | 0.242 / 71.7% | 0.189 |
| SciFact | TACER | 0.253 / 80.9% | 0.246 / 79.4% | 0.189 |
| BioASQ | Adaptive-k | 0.319 / 73.2% | 0.318 / 72.1% | 0.242 |
| BioASQ | Safe Adaptive Context | 0.323 / 74.6% | 0.305 / 73.2% | 0.242 |
| BioASQ | TACER | 0.314 / 80.8% | 0.316 / 79.8% | 0.242 |
| HotpotQA | Adaptive-k | 0.490 / 70.4% | 0.282 / 71.4% | 0.385 |
| HotpotQA | Safe Adaptive Context | 0.627 / 32.3% | 0.369 / 30.9% | 0.385 |
| HotpotQA | TACER | 0.627 / 32.6% | 0.374 / 31.1% | 0.385 |
| MSMARCO | Adaptive-k | 0.199 / 48.6% | 0.212 / 50.1% | 0.210 |
| MSMARCO | Safe Adaptive Context | 0.195 / 38.5% | 0.217 / 35.1% | 0.210 |
| MSMARCO | TACER | 0.195 / 54.1% | 0.209 / 54.1% | 0.210 |
| ASQA | Adaptive-k | 0.368 / 70.9% | 0.351 / 72.6% | 0.366 |
| ASQA | Safe Adaptive Context | 0.402 / 58.3% | 0.359 / 61.9% | 0.366 |
| ASQA | TACER | 0.404 / 59.4% | 0.359 / 61.9% | 0.366 |
