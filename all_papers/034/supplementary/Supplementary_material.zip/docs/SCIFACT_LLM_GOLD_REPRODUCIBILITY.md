# SciFact LLM-Generated Reference Answers

We created an auxiliary SciFact reference-answer file because SciFact supplies claims, gold documents, and relevance labels rather than short natural-language reference answers. The model does not create new relevance labels. It only converts each claim and its original gold evidence into a concise reference used after answer generation for answer-level F1, coverage, and semantic similarity. Retrieval diagnostics continue to use the original SciFact relevance labels.

- Model: `openai/gpt-oss-120b`
- Provider: Berget AI OpenAI-compatible API
- Temperature: `0`
- Input: SciFact claim and gold relevant-document evidence only
- Output: one short `reference_answer`

System message:

```text
You create concise reference answers for factual RAG evaluation.
```

User prompt template used by `scripts/generate_scifact_synthetic_answers.py`:

```text
Create one short reference answer for evaluating a RAG system on SciFact.

The input is a scientific claim and the gold evidence document text. Decide whether the evidence supports, contradicts, or is insufficient for the claim.

Rules:
- Write one concise natural-language reference answer.
- Match the existing SciFact reference style: usually 4 to 20 words, and never more than 30 words.
- If the evidence supports the claim, state the supported claim directly.
- If the evidence contradicts the claim, begin with "The evidence contradicts the claim" and briefly say why.
- If the evidence is insufficient, write exactly: "The evidence is insufficient."
- Do not add citations, bullet points, or extra explanation.

Claim:
[claim]

Gold evidence:
[gold evidence]
```

These generated references are auxiliary evaluation artifacts rather than original SciFact labels. The available research snapshot does not record independent expert validation of every generated reference; the paper therefore treats SciFact answer-level results as auxiliary evidence alongside datasets with source-derived references.
