# TACER supplementary material

This archive accompanies the camera-ready paper “Safe Adaptive Context and TACER: Task-Aware Evidence Routing for Token-Efficient Retrieval-Augmented Generation.”

## Contents

- `src/`: context policies, TACER routing, compression, fallback, metrics, and retrieval implementation.
- `scripts/`: dataset preparation, experiment runners, batch merging, confidence analysis, and SciFact auxiliary-reference generation.
- `data/`: prepared evaluation inputs and fixed calibration/evaluation splits used by the released experiments.
- `saved_results/`: saved aggregate tables and query-level outputs available in the research snapshot.
- `audit/TACER_external_evaluation_query_ids.csv`: the 500-query external-evaluation IDs (100 per dataset).
- `audit/main_evaluation_audit.csv`: camera-ready consistency audit of the main evaluation.
- `docs/`: implementation and reproducibility notes.
- `requirements.txt`: Python dependencies.

## Reproduction notes

All compared context policies within a dataset use the same fixed candidate lists, generator, decoding configuration, and answer-generation prompt. Final runs use temperature 0 and require provider-reported token counts. The paper appendix records the exact prompt templates, model/checkpoint identifiers, routing rules, fallback thresholds, metric definitions, and sampling rule.

The SciFact natural-language references are auxiliary references generated only from each claim and its gold evidence. The generation implementation and exact prompt are in `scripts/generate_scifact_synthetic_answers.py`; additional provenance is in `docs/SCIFACT_LLM_GOLD_REPRODUCIBILITY.md`.

The archive intentionally excludes API credentials, caches, version-control metadata, and manuscript source. It is a reproducibility snapshot; some full hosted-model reruns require access to an OpenAI-compatible inference provider.
