"""Regenerate the two data-driven figures from the CURRENT canonical result files
(figures in the old paper were drawn from superseded protocols).

fig_niah_v5.pdf     — NIAH answer NLL by distance bucket, survival-repaired protocol
                      (data: results/niah_v5_ws128_all.json)
fig_longbench_kv.pdf— official LongBench metric per task, true KV-cache decode path
                      (data: results/longbench_official_{full,local,qcmsa}_kv.json)
"""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

RES = '/data1/zhoujun/Auto-claude-code-research-in-sleep/project/freq-attention/results'
OUT = '/data1/zhoujun/Auto-claude-code-research-in-sleep/project/freq-attention/paper/figures'

plt.rcParams.update({
    'font.size': 9, 'axes.titlesize': 10, 'axes.labelsize': 9,
    'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'savefig.dpi': 200, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.05,
})

# ── Figure: NIAH v5 — near cost / mid benefit / far zero ─────────────────────
d = json.load(open(f'{RES}/niah_v5_ws128_all.json'))
configs = [
    ('R_M1L8_s2',      'M1L8 (default)'),
    ('R_M4L4_s2',      'M4L4'),
    ('R_M4L8_s2b',     'M4L8'),
    ('R_M1L16_s2',     'M1L16'),
    ('R_gamma_only_s2','Gain-only (M1L8)'),
    ('R_gammaonly_M1L16_s2', 'Gain-only (M1L16)'),
]
buckets = ['near', 'mid', 'far']
labels = ['Near\n($\\leq$128)', 'Mid\n(129–256)', 'Far\n(>256)']
x = np.arange(3)
width = 0.13

loc = d['R_M1L8_s2']['local_2048']['buckets']
ful = d['R_M1L8_s2']['full_2048']['buckets']

fig, ax = plt.subplots(figsize=(4.2, 2.6))
ax.axhspan(0, ful['near']['mean_loss'] + 0.12, color='0.92', zorder=0)
ax.bar(x - 0.5*width, [ful[b]['mean_loss'] for b in buckets], width, label='Full', color='0.55')
ax.bar(x + 0.5*width, [loc[b]['mean_loss'] for b in buckets], width, label='Local', color='0.75')
for i, (ck, name) in enumerate(configs):
    vals = [d[ck]['qcmsa_2048']['buckets'][b]['mean_loss'] for b in buckets]
    ax.bar(x + (1.5 + i)*width, vals, width, label=name)
ax.set_xticks(x + 1.2*width); ax.set_xticklabels(labels)
ax.set_ylabel('Answer-token NLL (lower = better)')
ax.set_ylim(0, 10.6)
ax.legend(frameon=False, ncol=2, loc='upper left')
ax.set_title('NIAH answer NLL by distance bucket (w=128, 2,048 tokens)')
fig.savefig(f'{OUT}/fig_niah_v5.pdf')
plt.close(fig)

# ── Figure: official LongBench per task, three arms ──────────────────────────
arms = {}
for a in ['full', 'local', 'qcmsa']:
    dd = json.load(open(f'{RES}/longbench_official_{a}_kv.json'))
    arms[a] = {t: dd[t][a]['score'] for t in dd if t != 'provenance' and dd[t].get(a, {}).get('score') is not None}
tasks = sorted(set(arms['full']) & set(arms['local']) & set(arms['qcmsa']))
task_names = [t.replace('gov_report', 'gov-report').replace('2wikimqa', '2WikiMQA').replace('triviaqa', 'TriviaQA') for t in tasks]

fig, ax = plt.subplots(figsize=(4.2, 2.6))
x = np.arange(len(tasks))
width = 0.26
for i, (a, name, color) in enumerate([('full', 'Full', '0.55'), ('local', 'Local', '0.75'), ('qcmsa', '+ MSRA (M1L8)', '#1f77b4')]):
    vals = [arms[a][t] for t in tasks]
    ax.bar(x + (i-1)*width, vals, width, label=name, color=color)
ax.set_xticks(x); ax.set_xticklabels(task_names, rotation=28, ha='right')
ax.set_ylabel('Official LongBench score')
ax.axhline(0, color='k', lw=0.6)
ax.legend(frameon=False, loc='upper right')
ax.set_title('Official LongBench metrics (7 tasks, 2,048-token prompts)')
fig.savefig(f'{OUT}/fig_longbench_kv.pdf')
plt.close(fig)

print('regenerated: fig_niah_v5.pdf, fig_longbench_kv.pdf')
