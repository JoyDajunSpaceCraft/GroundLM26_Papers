# OpenReview Camera-Ready Submission — Copy-Paste Fields

**Deadline:** September 12, 2026 AoE
**Portal:** OpenReview → Track 1 or Track 2

---

## ⚠️ 当前 OpenReview 表单里的旧摘要含 5 个 FORBIDDEN 数字

| 旧摘要里的数字 | 问题 | 终版应替换为 |
|---|---|---|
| "4.6K–18K parameters" | 已淘汰口径 | 9K–45K |
| "4–10% in perplexity" | 旧表口径 | up to 31.7% gap closure |
| "6.9% of the full-local gap on average" | 旧 PPL-space LongBench（已撤回） | official metrics ≤1.3% |
| "94.5% of maximum entropy" | pre-fix gate 分析 | 62.8% of uniform |
| "zero recovery" | 口径过强 | essentially nothing |

**标题也要改**：旧标题 "When Does It Help, and When Does It Fail" → 终版 "Where It Helps, and Where It Fails"。

---

## Submission Type

**Archival Long Paper** (8 pages limitation for the main body)

---

## Title

MSRA: A Parameter-Efficient Spectral Correction for Local Attention — Where It Helps, and Where It Fails

---

## Abstract（236 词，直接复制粘贴）

Restricting attention to a sliding window makes long documents affordable, but it discards everything beyond the window. This paper asks what can be recovered when the model is already trained, its weights are frozen, and the budget for new parameters is only a few tens of thousands. We propose Multi-scale Spectral Residual Attention (MSRA): a far-field branch grafted onto the last few layers of a frozen model, which condenses out-of-window history through smoothly distance-decayed weights and adds it back to the attention output—roughly 9K–45K trainable parameters, plus minimal 8-to-16-scalar probes for attribution. On PG-19 long-form fiction, the branch closes up to 31.7% of the perplexity gap between local and full attention, with gains stable across two architectures, multiple seeds, and the official test partition. The attribution proves sharper than the headline: 16 learnable output-gain scalars alone close 26.4%, returns accelerate with grafting depth, the carefully designed kernel structure and gating contribute only secondarily—and a budget-matched LoRA closes 87.4%, indicating that the gap is mostly generic capacity rather than a missing far-field pathway. Retrieval experiments complete the map: the correction is a statistical smoother that helps just beyond the window, slightly hurts precise in-window prediction, recovers essentially nothing at genuine long distance, and does not transfer to task metrics—while slowing prefill two-to-three-fold and leaving decoding unaffected. These results bound what a lightweight spectral correction can and cannot recover, forming a reproducible decision reference for local long-context design.

---

## TL;DR（建议同步更新；如有此字段）

A frozen local-attention model gains up to 31.7% gap closure from a <45K-parameter spectral correction; but 80–83% of the benefit comes from per-layer output gains alone, budget-matched LoRA closes 87.4%, and the correction acts as a statistical smoother—not a retrieval mechanism.

---

## 补充材料 zip

已上传：`supplementary_material.zip`（1.9 MB）✓ — 匿名验证通过

---

## 上传前最终确认

- [ ] Title 已更新为 "Where It Helps, and Where It Fails"
- [ ] Abstract 已替换为上述 236 词版本
- [ ] Submission Type 选 "Archival Long Paper"
- [ ] PDF 已更新为最新 `paper/main.pdf`（10 页：内容 p1–8 + Limitations/Acknowledgments p8 + References p9–10）
- [ ] TL;DR 已同步更新
- [ ] 补充材料 zip 已上传（1.9 MB < 200 MB 限制）
