"""Generate all paper figures using matplotlib."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import os

RES = '/data1/zhoujun/Auto-claude-code-research-in-sleep/project/freq-attention/results'
OUT = '/data1/zhoujun/Auto-claude-code-research-in-sleep/project/freq-attention/paper/figures'
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    'font.family': 'serif', 'font.size': 11, 'axes.labelsize': 13,
    'axes.titlesize': 14, 'legend.fontsize': 10, 'xtick.labelsize': 10,
    'ytick.labelsize': 10, 'axes.linewidth': 1.2, 'lines.linewidth': 2.0,
    'savefig.dpi': 200, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.05,
})

# ============================================================
# Figure 1: Per-Position NLL Improvement
# ============================================================
def fig_per_position():
    with open(f'{RES}/llama_per_pos_1024.json') as f:
        data = json.load(f)
    delta = np.array(data['per_position_delta'])
    n = len(delta)
    x = np.arange(n)

    fig, ax = plt.subplots(figsize=(7, 3.2))

    # Smoothed line
    window = max(10, n // 40)
    smooth = np.convolve(delta, np.ones(window)/window, mode='valid')
    x_smooth = np.arange(len(smooth)) + window//2

    ax.plot(x_smooth, smooth, color='#2B5F8A', linewidth=2.2, label='NLL Δ (Local − MSRA)')
    ax.axhline(y=0, color='#CC3333', linestyle='--', linewidth=1, alpha=0.6)

    # Window boundary marker
    ws = data['window']
    ax.axvline(x=ws, color='#888888', linestyle=':', linewidth=1.2, alpha=0.7)
    ax.text(ws+15, ax.get_ylim()[1]*0.85, f'w={ws}', fontsize=9, color='#666666')

    ax.fill_between(x_smooth, 0, smooth, where=(smooth>0), color='#2B5F8A', alpha=0.15)
    ax.fill_between(x_smooth, 0, smooth, where=(smooth<0), color='#CC3333', alpha=0.15)

    ax.set_xlabel('Token Position')
    ax.set_ylabel('NLL Δ (Local − MSRA)')
    ax.set_title('Per-Position NLL Improvement (LLaMA 3.2-1B, seq=1024, random-token probe)')
    ax.legend(loc='upper right')

    # Annotation
    late_pos = delta[3*n//4:]
    pct_pos = (late_pos > 0).mean() * 100
    ax.annotate(f'{pct_pos:.0f}% late positions\nshow improvement',
                xy=(n*0.85, smooth[-1]), fontsize=9, color='#2B5F8A',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#E8F0FE', alpha=0.8))

    plt.tight_layout()
    fig.savefig(f'{OUT}/fig_per_position.pdf')
    plt.close()
    print("Figure 1: Per-position NLL → fig_per_position.pdf")


# ============================================================
# Figure 2: NIAH Distance Boundary
# ============================================================
def fig_niah():
    with open(f'{RES}/niah/niah_llama.json') as f:
        data = json.load(f)

    # Extract ws=128 data at seq=1024
    niah_data = {}
    for ws_key in data:
        for key in data[ws_key]:
            d = data[ws_key][key]
            if d['seq_len'] == 1024:
                model = d['model']
                buckets = d['buckets']
                for b in ['near', 'mid', 'far']:
                    if b in buckets:
                        niah_data.setdefault(model, {})[b] = buckets[b]['mean_loss']

    fig, ax = plt.subplots(figsize=(6.5, 3.5))

    buckets = ['near', 'mid', 'far']
    x = np.arange(len(buckets))
    width = 0.22

    colors = {'full': '#2D6A3F', 'local': '#CC5533', 'qcmsa': '#2B5F8A'}
    labels = {'full': 'Full Attention', 'local': 'Local (w=128)', 'qcmsa': '+ MSRA'}

    for i, model in enumerate(['full', 'local', 'qcmsa']):
        if model in niah_data:
            vals = [niah_data[model].get(b, 0) for b in buckets]
            bars = ax.bar(x + i*width, vals, width, label=labels[model],
                         color=colors[model], alpha=0.85, edgecolor='#333333', linewidth=0.8)
            for bar, val in zip(bars, vals):
                if val > 0.5:
                    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.2,
                            f'{val:.1f}', ha='center', va='bottom', fontsize=8, fontweight='bold')

    ax.set_xticks(x + width)
    ax.set_xticklabels(['Near (≤w)', 'Mid (w–2w)', 'Far (>2w)'])
    ax.set_ylabel('NLL (lower = better)')
    ax.set_title('NIAH Retrieval by Evidence Distance (LLaMA 3.2-1B, seq=1024, w=128)')
    ax.legend(loc='upper left', framealpha=0.9)

    # Highlight MSRA near-improvement
    ax.annotate('MSRA helps\nnear-range', xy=(0.22, 2.5), fontsize=8.5,
                color='#2B5F8A', ha='center',
                bbox=dict(boxstyle='round', facecolor='#E8F0FE', alpha=0.8))
    ax.annotate('Zero far\nrecovery', xy=(2.22, 8.5), fontsize=8.5,
                color='#CC3333', ha='center',
                bbox=dict(boxstyle='round', facecolor='#FDE8E8', alpha=0.8))

    plt.tight_layout()
    fig.savefig(f'{OUT}/fig_niah.pdf')
    plt.close()
    print("Figure 2: NIAH boundary → fig_niah.pdf")


# ============================================================
# Figure 3: LongBench Task Breakdown
# ============================================================
def fig_longbench():
    with open(f'{RES}/longbench_llama.json') as f:
        lb = json.load(f)

    tasks = []
    gaps_closed = []
    fulls, locals_, qcmsas = [], [], []

    skip = {'multifieldqa_zh', 'passage_retrieval_zh', 'dureader'}
    for task in sorted(lb.keys()):
        if task in skip: continue
        d = lb[task]
        fv = d.get('full', {}).get('ppl', 0)
        lv = d.get('local_ws128', {}).get('ppl', 0)
        qv = d.get('qcmsa_ws128', {}).get('ppl', 0)
        if fv <= 0 or lv <= 0: continue
        gap = lv - fv
        closed = (lv - qv) / gap * 100 if gap > 0 else 0
        tasks.append(task.replace('_', ' '))
        gaps_closed.append(closed)
        fulls.append(fv)
        locals_.append(lv)
        qcmsas.append(qv)

    # Sort by gap closed
    order = np.argsort(gaps_closed)
    tasks = [tasks[i] for i in order]
    gaps_closed = [gaps_closed[i] for i in order]

    fig, ax = plt.subplots(figsize=(7, 4.5))

    y_pos = np.arange(len(tasks))
    colors = ['#2D6A3F' if g > 0 else '#CC3333' for g in gaps_closed]

    bars = ax.barh(y_pos, gaps_closed, height=0.7, color=colors, alpha=0.85,
                   edgecolor='#333333', linewidth=0.5)

    for i, (bar, val) in enumerate(zip(bars, gaps_closed)):
        x_pos = bar.get_width() + (3 if val >= 0 else -3)
        ha = 'left' if val >= 0 else 'right'
        ax.text(x_pos, bar.get_y() + bar.get_height()/2, f'{val:+.0f}%',
                ha=ha, va='center', fontsize=8.5, fontweight='bold',
                color='#2D6A3F' if val > 0 else '#CC3333')

    ax.axvline(x=0, color='#333333', linewidth=0.8)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(tasks, fontsize=9)
    ax.set_xlabel('Gap Closed (%)')
    ax.set_title('LongBench: MSRA Gap Closed by Task (15 English Tasks)')

    # Summary box
    avg = np.mean(gaps_closed)
    positive = sum(1 for g in gaps_closed if g > 0)
    ax.text(0.98, 0.06, f'Avg: {avg:+.1f}%\n{positive}/15 tasks positive',
            transform=ax.transAxes, fontsize=10, ha='right', va='bottom',
            bbox=dict(boxstyle='round', facecolor='#F8F8F8', alpha=0.9, edgecolor='#CCCCCC'))

    plt.tight_layout()
    fig.savefig(f'{OUT}/fig_longbench.pdf')
    plt.close()
    print("Figure 3: LongBench breakdown → fig_longbench.pdf")


# ============================================================
# Run all
# ============================================================
if __name__ == '__main__':
    fig_per_position()
    fig_niah()
    fig_longbench()
    print(f"\nAll figures saved to {OUT}/")
