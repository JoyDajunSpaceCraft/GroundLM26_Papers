# MSRA: A Parameter-Efficient Spectral Correction for Local Attention — When Does It Help, and When Does It Fail?

**GroundLM 2026 Findings (revised submission)**

---

## Abstract

Local attention with a sliding window inevitably discards information beyond the window boundary. We present a complete attribution audit of Multiscale Spectral Residual Attention (MSRA), a parameter-efficient correction (4.6K–18K trainable parameters) that adds a spectral residual with a fixed exponential kernel form to local attention, systematically mapping where it helps and where it fails across GPT2-XL and LLaMA 3.2-1B.

On PG-19 language modeling, MSRA yields consistent gains of 9.8–12.2% in perplexity, with every seed positive across five seeds per architecture. However, a fully instrumented evaluation — matched-budget baselines, official task metrics, and repaired retrieval protocols — reveals that the spectral form itself is *not* the active ingredient: a rank-1 LoRA on the output projection closes 87.6% of the same gap with fewer parameters, and increasing patch depth dominates increasing kernel multiplicity (M1L16: 31.7% > M4L8: 25.7%, with fewer parameters). The perplexity gains do not transfer to official LongBench task metrics (≈0% gap closure under greedy decoding). Far-context retrieval remains at zero across all tested configurations — including the strongest, measured under a fully repaired NIAH protocol with asserted needle survival.

We additionally document how two implementation bugs in our original evaluation — a kernel-FFT cache collision that froze the learnable kernel scale, and noise amplification at empty-far positions — had inflated or distorted earlier conclusions, and how every claim changes once they are repaired. The result is not a method contribution but a case study in evaluation hygiene: every claim is backed by a matched control, and every reversal is documented with its evidence chain.

---

## 1. Introduction

Scaling transformer models to long sequences remains a central challenge. Sliding-window local attention achieves linear complexity but discards all information beyond the window. Prior work has explored various mitigation strategies — linearized attention, frequency-domain methods, state-space models — but these either replace attention entirely or make strong parametric assumptions.

We take a diagnostic perspective: rather than proposing a new method, we ask *what exactly* a lightweight spectral correction adds to a frozen local-attention base — and *what it does not*. Multiscale Spectral Residual Attention (MSRA) grafts an FFT-based Toeplitz far-field residual onto the last *L* layers of a frozen pretrained model, with only the correction branch trainable (4.6K–18K parameters).

Our contributions:

1. **MSRA with corrected implementation**: we identify and repair two implementation bugs (a kernel-FFT cache collision and noise amplification at empty-far positions), retrain every configuration, and show that the published PG-19 gains survive (9.8–12.2%, every seed positive, n≥3 per configuration).

2. **Complete attribution audit**: through a 2×2×2 grid (multiscale × depth × gate) plus γ-only, gate-off, and untrained controls, we show that (a) *depth is the dominant lever* (M1L4: 5.4% → M1L8: 12.4% → M1L16: 31.7%); (b) *multiscale contributes modestly but independently* (+0.7–3.0pp without gate), though at every tested configuration spending the budget on patch depth rather than kernel experts yields higher gap closure with fewer parameters (M1L16: 36.9K → 31.7% vs M4L8: 45.1K → 25.7%); (c) *gate selectivity is real and amplifies with depth* (+2.5pp at L4 → +10.3pp at L8); and (d) *generic adapters dominate the entire spectral family* — a rank-1 LoRA on o_proj (32.8K, fewer parameters than the strongest spectral variant) closes 87.6% of the gap, 2.76× the strongest spectral configuration.

3. **Grounding boundary**: far-context retrieval is zero across all configurations (NIAH far gap closed ≤1.3%, RULER +3.0%), near-range answer prediction improves (+20.6–26.4% under the corrected NIAH protocol), and LongBench perplexity gains do not transfer to official task metrics (≈0% gap closure). The correction is a statistical smoother of token likelihoods, not a repair of long-range generation structure.

This study aligns with GroundLM's emphasis on the faithfulness–efficiency boundary: we characterize not only what MSRA achieves, but what it demonstrably fails to achieve, and we document the evaluation hygiene required to distinguish the two.

---

## 2. Related Work

**Local and sparse attention.** Longformer, BigBird, and the sparse transformer pioneered structured sparsity. Mistral demonstrated that sliding-window attention alone can serve as a default. Our work asks whether a lightweight correction can recover what these designs discard.

**Linear and kernelized attention.** Linear attention and Performer approximate attention through kernel feature maps. Hedgehog shows that ELU+1-style maps lack the spikiness of softmax — a finding that directly anticipates our mechanism analysis: the far branch uses exactly such a map and behaves as a statistical smoother.

**Hybrid local–global architectures.** BASED combines exact local attention with a global linear-attention branch; Infini-attention augments attention with compressive memory. Both learn the global pathway end-to-end; MSRA freezes the base model and grafts a minimal spectral residual — a complementary, diagnostic question.

**Parameter-efficient adaptation.** LoRA and related PEFT methods adapt pretrained models with few parameters. At 4.6–67.6K parameters (depending on configuration), MSRA remains in this regime — but our matched-budget audit shows that a rank-1 LoRA on o_proj dominates the entire spectral family.

---

## 3. Method

MSRA augments local attention with a far-context residual branch computed in the frequency domain. The overall output for token *i* combines a near-field exact attention term and a far-field spectral correction:

*y_i = y_i^near + γ · y_i^far*

The near branch uses exact causal sliding-window attention. The far branch computes, for each expert *m*:

*C_i^(m) = Σ_{j ∈ F(i)} g_m(i−j) · ψ_m(k_j) · v_j^T*
*z_i^(m) = Σ_{j ∈ F(i)} g_m(i−j) · ψ_m(k_j)*
*u_i^(m) = φ(q_i)^T C_i^(m) / (φ(q_i)^T z_i^(m) + ε)*

where F(i) = {j : j < i−w}, g_m(Δ) = exp(−Δ/σ_m), and φ, ψ are ELU+1 positive feature maps. Experts are mixed (gate-on) or uniformly averaged (gate-off); the result is scaled by LayerScale γ.

**Terminology.** (1) The kernel *form* is fixed (exponential decay); (2) the kernel *scale* σ = exp(log σ) is learnable; (3) the base model is frozen; (4) the correction branch is the only trainable part.

**Default configuration.** M=1, gate-off, L=8 patched layers, w=128, r=16: 2,304 parameters per layer, 18,448 total for LLaMA 3.2-1B (d=64). The GPT2-XL experiments use the identical configuration.

**Implementation details.** The convolutions are computed via FFT in O(n log n). MSRA is applied only to the last L layers. During training, the far branch engages only at prefill; decoding proceeds with local attention only. All linear projections are zero-initialized so the model starts as local-only.

---

## 4. Experiments

### 4.1 Language Modeling Results

We evaluate on PG-19, splitting at the document level (75% train / 25% eval, re-drawn per seed). Table 1 shows the main results.

**Table 1: PG-19 perplexity (corrected implementation, fixed 16-chunk eval split)**

| Model | Window | Train Len | Full PPL | Local PPL | MSRA PPL | Gain |
|---|---|---|---|---|---|---|
| GPT2-XL (1.5B) | 128 | 512 | 42.6 | 2,649 ± 571 | 2,373 ± 535 | **+10.4%** |
| LLaMA 3.2-1B | 128 | 512 | 17.0 | 371.6 | 327.1 | **+12.4%** |
| LLaMA 3.2-1B | 128 | 1024 | 18.1 | 545.7 | 474.3 | **+13.5%** |

All rows use the corrected implementation. GPT2-XL: 5 seeds. LLaMA: 3 seeds (512) / 1 seed + audit confirmation (1024). Gain = (PPL_local − PPL_MSRA) / PPL_local.

The GPT2-XL configuration was retrained from scratch after the original 67.6K multi-expert design was found to be dominated by the simplified one.

### 4.2 Grounding Boundary Analysis

#### 4.2.1 NIAH Retrieval (Corrected Protocol)

Under the repaired NIAH protocol (needle-aware truncation, asserted needle survival, loss computed on the answer region), we measure answer-prediction NLL bucketed by evidence distance (Table 2).

**Table 2: NIAH answer-region NLL by evidence distance (w=128, 2,048 tokens, corrected protocol)**

| Configuration | Near (≤128) | Mid (129–256) | Far (>256) |
|---|---|---|---|
| Full | 0.49 | 1.20 | 1.40 |
| Local | 2.57 | 7.33 | 7.30 |
| + MSRA (M1L8) | 2.05 (+20.6%) | 7.23 (+1.4%) | 7.23 (+1.0%) |
| + MSRA (M4L4) | 1.93 (+25.0%) | 7.26 (+1.0%) | 7.27 (+0.5%) |
| + MSRA (M4L8) | 1.89 (+26.4%) | 7.25 (+1.1%) | 7.28 (+0.3%) |

*N = 30 needle instances per bucket. Gap closed relative to local–full.*

MSRA improves near-range answer prediction by 20.6–26.4% across all configurations (the evidence is within the window, and the correction's smoothing aids integration). Far-range recovery is zero across all configurations: even the strongest (M4L8, σ reaching 460) achieves only +0.3% gap closure. Near-range answer prediction improves by 20.6–26.4% — the correction genuinely helps integrate in-window evidence, consistent with its smoother characterization.

#### 4.2.2 LongBench: Official Task Metrics

We evaluate with official LongBench metrics (QA F1, ROUGE-L) under greedy decoding, all arms sharing identical prompts (2,048-token truncation) and generation settings.

**Table 3: LongBench official metrics (7 of 15 English tasks: 5 QA, 2 summarization)**

| Task (metric) | Full | Local | +MSRA |
|---|---|---|---|
| triviaqa (F1) | .197 | 0.000 | 0.000 |
| narrativeqa (F1) | .075 | 0.000 | 0.000 |
| hotpotqa (F1) | .038 | 0.000 | 0.000 |
| 2wikimqa (F1) | .032 | 0.000 | 0.000 |
| qasper (F1) | .041 | 0.000 | 0.000 |
| gov_report (ROUGE-L) | .137 | 0.000 | .0001 |
| qmsum (ROUGE-L) | .042 | .0008 | .0008 |
| **Mean** | **.080** | **.0001** | **.0002** |

The local-attention base model's generation collapses on long prompts; the spectral correction does not repair it. Perplexity improvements do not transfer to task performance.

#### 4.2.3 Protocol Repairs and Extended Surfaces

We probed three additional surfaces, each of which initially surfaced defects in our own harness (Table 4).

**Table 4: Extended-benchmark protocol checks**

| Surface | Protocol check | Outcome after repair |
|---|---|---|
| RULER v2 (needle-aware) | Positive control passes (full PPL 1.56) | MSRA closes 3.0% — zero far recovery |
| SCROLLS v2 (label-likelihood) | Full attention 12% < 33% random | Majority-label artifact; uninformative |
| DeepSeek-R1-Distill-Qwen-7B | Logits gate passes (\|Δ\|=18.0) | Gap exists (102.3 vs 39.2); future work |

### 4.3 Mechanism Diagnostics

#### 4.3.1 Complete Attribution Ladder

**Table 5: Attribution ladder (all independent evaluations, fixed 16-chunk split, corrected implementation)**

| Correction | Params | Gap closed | Seeds |
|---|---|---|---|
| Untrained random kernel | 18.4K | 0.0% | — |
| Random kernel, only γ trainable | 8 | 9.5% | 1 |
| MSRA M1L4 (gate-off) | 9.2K | 5.3% / 5.4% | 2 |
| MSRA M4L4 (gate-off) | 21.5K | 6.1% | 1 |
| MSRA M1L8 (gate-off) | 18.4K | **12.4%** | 3 |
| MSRA M4L4 (gate-on) | 22.5K | 8.6% / 8.7% | 2 |
| MSRA M4L8 (gate-off) | 43.0K | 15.4% | 2 |
| MSRA M4L8 (gate-on) | 45.1K | **25.7%** | 2 |
| MSRA M1L16 (gate-off) | 36.9K | **31.7%** | 2 |
| Causal depthwise conv (k=8) | 131.1K | 78.3% | 2 |
| Rank-1 LoRA on o_proj | 32.8K | **87.6%** | 2 |

*All values are independent-process evaluations on the same 16 chunks. Param counts for gate-off variants exclude the gate.*

#### 4.3.2 What the Ladder Shows

**Depth is the dominant lever.** M1L4 → M1L8 → M1L16 traces a monotone, accelerating curve (5.4% → 12.4% → 31.7%): the deep configuration closes 31.7% with *fewer* parameters than the multiscale M4L8 (36.9K vs 45.1K).

**Multiscale contributes modestly but independently.** Without the gate, multiscale contributes +0.7pp at L4 and +3.0pp at L8. The kernel scales drift modestly around initialization (−10% to +14%) — training refines, rather than discovers, the initialized scale structure.

**Gate × depth interaction is real.** The gate's contribution grows with depth: +2.5pp at L4, +10.3pp at L8 (interaction +7.8pp). At M4L8, gate selectivity (69% of maximum entropy vs 94.5% under the buggy implementation) is genuine.

**Generic adapters dominate.** A rank-1 LoRA on o_proj (32.8K, fewer parameters than the strongest spectral configuration M1L16 at 36.9K) closes 87.6% of the gap — 2.76× the strongest spectral variant, and 3.4× the strongest multi-scale variant. A causal depthwise convolution (131.1K, 7.1× budget) reaches 78.3%. Even at 7× budget, a trivial temporal convolution falls short of LoRA — the ceiling is set by adapter expressiveness, not budget. The LoRA result is particularly sharp: with 11% fewer parameters than the strongest spectral variant, it achieves 2.76× the gap closure.

**Learning is necessary.** The untrained random kernel produces exactly local-attention output (0.0%).

#### 4.3.3 Gate Behavior

Under the original (buggy) implementation, gate entropy was 94.5% of maximum — all four experts shared one cached kernel and the gate had nothing to differentiate. After repair, gate entropy drops to 69% of maximum, and the gate's contribution grows with depth (+2.5pp at L4 → +10.3pp at L8). Perturbation responsiveness increases 9-fold (max |Δgate| = 0.42 vs 0.046).

#### 4.3.4 Implementation Audit

Because this paper's claims are only as strong as its measurement pipeline, we report the bugs found in our own implementation:

1. **Kernel-FFT cache collision**: the cache key was derived from the first eight kernel elements, which the far mask zeroes for every σ. Under inference this caused all configurations to share one cached FFT; during training it froze the learnable scale at initialization.
2. **Noise amplification at empty-far positions**: FFT leaves O(10⁻⁶) noise in the denominator at positions with no far context, which the normalization amplifies above the legitimate signal.
3. **NaN gradient infection**: wide-σ experts produce finite losses with non-finite gradients; `clip_grad_norm_` then propagates NaN into every parameter. A NaN-skip guard is required.

All are fixed in the released implementation; every result in this paper uses the corrected code.

### 4.4 Practical Tradeoffs

**Table 6: Inference throughput (corrected implementation, same-day benchmark)**

| Seq Length | Local (tok/s) | + MSRA M1L8 | Throughput loss | Slowdown | Decode (MSRA) |
|---|---|---|---|---|---|
| 512 | 36,008 | 4,395 | 88% | 8.2× | — |
| 1,024 | 30,365 | 4,350 | 86% | 7.0× | — |
| 2,048 | 20,052 | 4,029 | 80% | 5.0× | 100 tok/s (= local) |
| 4,096 | 12,457 | OOM | — | — | — |

The spectral branch reduces prefill throughput by 80–88% (5.0–8.2× slowdown), primarily due to FP32 FFT memory traffic. At 4,096 tokens the padded FFT intermediates exceed 24 GB. Decode throughput is unaffected (the far branch is prefill-only). During decoding, all attention variants attend to the full causal KV cache; the window restriction applies only to prefill representations.

---

## 5. Conclusion and Limitations

### Conclusion

We presented a complete attribution audit of MSRA, a parameter-efficient spectral correction for local attention. After repairing two implementation bugs and retraining every configuration, the corrected results show:

- **The PG-19 gains are real** and strengthen under the corrected implementation (GPT2-XL: +10.4% at 18.4K vs the original +3.9% at 67.6K; LLaMA: 12.4%).
- **Depth is the dominant lever**: 5.4% → 12.4% → 31.7% across L=4/8/16, with multiscale adding little independently and gate × depth contributing +7.8pp.
- **Generic adapters dominate**: rank-1 LoRA (32.8K) achieves 87.6% — 2.76× the strongest spectral configuration (M1L16, 31.7%), with fewer parameters.
- **Far recovery is zero across all configurations**, including the strongest measured under a fully repaired NIAH protocol.
- **Perplexity gains do not transfer** to official LongBench task metrics.

The original conclusion that "multiscale and gating are unnecessary" was partially an artifact of a caching bug; the corrected implementation reveals genuine gate selectivity and a multiscale contribution at depth. However, even the strongest spectral configuration is dominated by generic adapters — the paper's value is as an evaluation-hygiene case study, not as a method recommendation.

### Limitations

- MSRA does not recover far-context retrieval (NIAH far ≤ +1.3% across all configurations; RULER +3.0% under the repaired protocol) and its perplexity gains do not transfer to official LongBench metrics.
- The matched-budget audit shows the spectral formulation is dominated by generic adapters.
- The current implementation reduces prefill throughput by 80–88% (5.0–8.2× slowdown) and requires >24 GB at 4,096-token prefill.
- Three evaluation surfaces (SCROLLS, DeepSeek-R1-Distill-Qwen-7B grounding, RULER beyond niah_single) could not be fully interpreted; we report these as protocol-level findings.
- The training-internal evaluation path produces bit-identical results across seeds through an unresolved mechanism; all paper numbers use independent-process evaluations.

---

## References

(References identical to the LaTeX source; see `references.bib`.)

---

## Implementation Audit Appendix

### A. Kernel-FFT Cache Collision

**Bug**: `FFTToeplitzConv._cache_key` derived the cache key from `kernel[:8].tolist()`. The far mask zeroes all elements at lags ≤ w, making the key constant across σ values.

**Evidence**: σ=10 and σ=100 kernels produce bit-identical outputs; `kernel.grad = None` after backward.

**Fix**: training bypasses the cache; inference uses key = (σ, padded_len, reverse, device).

**Impact**: all M=1 checkpoints trained before the fix have σ frozen at initialization; the original "learnable multiscale" never engaged.

### B. Noise Amplification at Empty-Far Positions

**Bug**: at positions i ≤ w (empty far context), the FFT leaves O(10⁻⁶) noise in the denominator z; the normalization u = noise_C / (noise_z + ε) amplifies this above the legitimate far signal.

**Evidence**: in-window |y_far| = 1.34×10⁻⁴ at γ=10⁻⁵ — 5× the beyond-window signal.

**Fix**: hard-zeroing y_far where F(i) = ∅.

**Impact**: the original per-position analysis showed nonzero deltas where theory predicted exactly zero.

### C. NaN Gradient Infection

**Bug**: wide-σ experts produce finite losses with non-finite gradients; `clip_grad_norm_` propagates NaN into every parameter.

**Evidence**: M4L8 training crashed 3× with "far branch produced non-finite values"; retry without the skip guard produced σ = NaN.

**Fix**: NaN-skip guard (total_norm isfinite check) + post-γ y_far clamp ±0.5.

### D. Evaluation Path Defect

**Bug**: training-internal evaluation produces bit-identical results across seeds (350.237183 × 3) through an unresolved mechanism. Independent-process evaluation produces distinct, correct values.

**Status**: unresolved; path deprecated. All paper numbers use independent-process evaluations (`eval_fixed_split.py`).

---

## Released Artifacts

- `results/eval_split_256.json` — fixed eval manifest (sha256: 8555f6e9)
- `results/fixed_split_eval.json` — canonical attribution ladder
- `results/niah_v4_ws128_all.json` — corrected NIAH results
- `results/systems_llama_v2.json` — corrected systems benchmark
- `paper/recompute_tables.py` — automated number verification (ALL PASS)
- `FREEZE_MANIFEST.md` — code + result hashes
