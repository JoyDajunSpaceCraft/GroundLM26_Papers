# Paper Improvement Log — MSRA for GroundLM 2026

## Score Progression

| Round | Score | Verdict | Key Changes |
|-------|-------|---------|-------------|
| Round 1 | 7/10 | Almost | GroundLM positioning added, mechanism claims softened |
| Round 2 | 8/10 | Yes | Statistical rigor limitation added, ready for submission |
| GroundLM Decision | Reject (Findings→Reject, AC sqgE) | — | See Phase 0 below: meta-review flagged data-table inconsistencies, baseline concerns, cost mislabeling |

## Phase 0 Revision (2026-09-05) — post-review hard-error fixes

Official reviews (ve2u 4/10, xoMT 3/10, LgUF 6/10; AC reject) flagged structural reporting
errors. All numbers were re-audited from `results/*.json` (`paper/recompute_tables.py` →
`REVISION_DATA_AUDIT.md`); snapshot: `main_phase0.pdf`.

### Fixed (all traced to results files)
1. **Table 8 cost mislabeling** (ve2u, LgUF): "89% overhead" was throughput loss. Now reports
   Throughput loss / Slowdown factor (3.6–9.2×) / Latency increase (+262–816%); §4.4 + Abstract-adjacent
   text + Limitations rewritten ("parameter-efficient but not compute-efficient").
2. **Table 5 params were 2× wrong** (ve2u): fixed to code-verified 22,548 / 9,224 / 21,524 / 18,448
   (per-layer = 2dr + 4d + 2 + dM·gate). Gap-closed values verified correct. Table 7 params verified correct.
3. **Table 1 rebuilt**: GPT-2 row verified (2,864→2,751, 5 seeds, per-seed +3.4–4.5%); LLaMA@512 row was
   UNTRACEABLE → replaced with final_M1_L8_s2-4 (355.6→312.3, +12.2%, 3 seeds, all positive);
   @1024 rows corrected +8.0/+8.2% → +7.0/+7.0% (4 seeds each). Full PPL column added; per-seed ±std shown.
4. **Table 2 rebuilt**: ws=128 row was UNTRACEABLE → replaced with the final_M1_L8 series (gap closed
   12.8%); Full PPL column + gap-closed definition footnote added. ws=64/256 rows verified
   (reviewer's 5.7% is the relative-PPL reading; 6.9% is correct under gap-closed definition).
5. **Table 6 rebuilt** (ve2u Figure3-vs-Table6 inconsistency): old values (+0.008…+0.031, 100% positive)
   matched no results file. Real quartiles: consistency rises 69%→77%→91%→91% positive; means
   +0.181/+0.024/+0.029/+0.029. Random-token probe protocol now disclosed in caption + text.
6. **Table 4 verified end-to-end**: all 15 tasks + avg 6.9% reproduce from longbench_llama.json (ws128 cols).
   Added: perplexity-space metric caveat + MSRA arm token-subset disclosure + eval-checkpoint config note.
7. **Terminology** (xoMT): "fixed kernel form (learnable scale)" everywhere; γ near-zero init (1e-5)
   distinguished from zero-init projections; explicit 4-point Terminology paragraph added in §3.
8. **PG-19 split protocol** (xoMT): §4.1 now states document-level 75/25 split after per-seed shuffle,
   chunks extracted per split, ≤8 eval chunks/length, why official partitions are not used.
9. **§3.2**: parameter-count formula added (2dr + 4d + 2 per layer, +dM gate; LLaMA d=64 → 2,306/layer).
10. **Build fix**: removed undefined legacy `\aclfinalcopy` macro (0 compile errors now).

## Phase 0.8 (2026-09-05) — freeze round: LoRA anchor scope + 45.1K disclosure → TEXT FROZEN

Fourth expert review approved freeze with 1 must-fix + 2 checks; all closed:
1. **LoRA anchor scope inconsistency** (arithmetic-falsifiable): old anchors mixed scopes (GPT2-XL
   ≈154K was W_O-only×48L; LLaMA ≈213K was QKVO×16L). Under matched-scope W_O-only the claim would
   FAIL for GPT-2 (38.4K < 67.6K). §2 now anchors to "rank-1 LoRA on all attention projections of
   the same patched layers (≈115K GPT2-XL / ≈107K LLaMA)" — verified: GPT2 c_attn+c_proj 9,600/layer
   ×12 = 115.2K; LLaMA QKVO 13,312/layer ×8 = 106.5K; both > 67.6K under any scope.
2. **Abstract range missed the M=4 LLaMA L=8 variant (45,096 params)** backing the LongBench headline:
   Abstract → "4.6K–67.6K depending on configuration; 4.6K–18K in the simplified default";
   contribution 1 + §3.2 disclose all three configurations explicitly.
3. §4.1 defensive sentence: smallest gain (3.9%) occurs in largest-budget config (GPT2-XL, 67.6K) —
   anti-confound evidence tying the disclosure to the ablation finding.
4. Ethics already \section*{...} ✓; no stray "22.5K" outside Table 5 cell ✓; DeepSeek-R1-7B grep = 0 ✓.
5. **recompute_tables.py now ends with cross-table consistency assertions (ALL PASS)**: T1 per-seed
   ranges vs caption claims, T6/T7 single-run values vs T1 cross-refs, LongBench avg 6.9%, params
   formula ×L, systems slowdown factors (with the †@4096 row pinned to its own internal pair —
   first run of the harness caught a mixed-source computation, itself a validation of the approach).

**→ main.tex FROZEN. Phase 1 execution plan: `PHASE1_EXPERIMENT_PLAN.md` (single authoritative
version; per-experiment text slots pre-allocated; gate = ① forward-builder convergence + causal
three-step diagnosis; highest risk = FFT cache-key collision → would require retraining all ckpts).**

## Phase 0.7 (2026-09-05, final text round) — third external review: config disclosure + cross-table variance + hypothesis fix

Third expert review confirmed all Phase 0.6 fixes. Three new P0s + five P1s fixed; text declared
FROZEN pending Phase 1 results.

### Fixed
1. **P0-A GPT-2 config vs parameter-range claims** (verified: best_mix_s1 config = M=4, gate-on,
   L=12, r=16 → 67,644 params): Abstract + contribution 1 now say "4.6K–18K in the simplified LLaMA
   default (67.6K in the GPT2-XL configuration)"; §3.2 restricts "all results use this configuration"
   to LLaMA + discloses GPT-2's config; Table 1 caption discloses both configs; §2 LoRA-comparison
   claim re-based to "4.6–67.6K, smaller than rank-1 LoRA on these models" (verified: rank-1 LoRA
   = 154K on GPT2-XL / 213K on LLaMA-1B attention projections). Option (a) — retraining GPT-2 at
   M=1 L=8 ×5 seeds — deferred to Phase 1 decision point.
2. **P0-B cross-table gap-closed disagreements** (12.8% vs 8.7% vs 7.3% vs 11.5%): all four numbers
   verified correct individually; root cause = per-seed split redraw (§4.1) + step-count differences.
   Table 6 (ablation) and Table 7 (layer budget) captions now state single-run status, cite the
   per-seed ranges from the Table 1 series (11.2–13.3% @512; 6.9–7.5% @1024), and attribute the
   deltas to split-draw variance. §4.3.4 prose updated ("single-run estimate... 4-seed mean 7.3%").
3. **P0-C length-reversal hypothesis was technically wrong** (σ fixed at training; kernel doesn't
   sense far-region depth; my "deeper→better" logic was backwards): replaced with normalization-
   dilution conjecture (denominator φ(q)·z accumulates over far region → per-token influence diluted
   with depth; too strong @1024, beneficial @2048) explicitly framed as conjecture; per-layer σ
   analysis named as the empirical test (Phase 1 E9).
4. P1s: model name → **DeepSeek-R1-Distill-Qwen-7B** everywhere (verified from config.json:
   Qwen2ForCausalLM, 28 layers); "zero recovery" → "zero mid/far-range recovery" (abstract + intro);
   Limitations → unnumbered \section*{Limitations} (ACL convention, page-limit exempt); Table 3
   caption adds small-n caveat.

### Dependencies on Phase 1 (both abstract headline numbers are provisional)
- "6.9%" (LongBench) → gated by E1 matched-subset + official metrics + M=1 ckpt re-eval
- "90.6% late positions" (per-position OOD) → gated by E0 causal-leakage diagnosis + probe redesign
  (random-token probe, in-window Δ≠0 unexplained)
- 39.6%/58.6% NIAH → gated by E2 re-run with ckpt provenance logging

## Phase 0.6 (2026-09-05, later still) — second external review: 3 protocol invalidations verified + fixed

External review of Phase 0.5 confirmed all 16 fixes and flagged 5 P0s. Three required 10-minute
verification tasks, all of which CONFIRMED protocol invalidations — the RULER/SCROLLS/DeepSeek
"failure modes" were never real measurements:

### Verified protocol invalidations (diagnosis code/inspection level, no training)
1. **SCROLLS 0/50 = scorer artifact** (P0-2, confirmed by tokenizer-level reproduction): every
   contract_nli prompt truncates to exactly 1024 tokens (`format_prompt` max_length=1024), so
   `prompt_ids` (1027) exceeds `full_ids` cap (1024) → answer-target slice is EMPTY for 100% of
   examples → `best_label` stays None → 0/50 for all arms incl. full attention. Reproduced
   deterministically; not a base-LM limitation. The 0/50 row is REMOVED from the paper.
2. **DeepSeek "no local-full gap" = patch no-op** (P0-3, confirmed by logits-diff smoke test on GPU):
   `max|logits_full − logits_local| = 0.000000` with the exact patch from deepseek_eval.py. Root
   cause: transformers 5.5.4 defaults every Qwen2 layer to `layer_types=['full_attention',...]`;
   setting `config.sliding_window` alone never engages local masking. The DeepSeek PPL rows are
   REMOVED; paper says "no local–full gap setting was ever established".
3. **RULER 4K truncation removes the needle** (P1→P0, confirmed 0/30 needle survival for BOTH
   niah_single and qa_squad under the eval's keep-head truncation): the runs measure answer
   likelihood given needle-less context; cannot support retrieval claims. PPL rows REMOVED and
   replaced by a protocol-check table (check → outcome per benchmark).

### Text changes in this round
- §4.2.3 fully rewritten: three protocol invalidations + new Table 5 (Benchmark / Protocol check /
  Outcome); transfer evidence now rests on LongBench 5/15 negatives only.
- Abstract: "document explicit failure modes on RULER, SCROLLS, and DeepSeek" → "document three
  evaluation-protocol surfaces that proved uninformative"; "4–12%" → "3.9–12.2%"; vacuous
  "training at 1,024 generalizing to same length" → real OOD evidence (512→1024, 90.6% late positions).
- Contribution 2: dropped "instruction tasks" (its evidence was SCROLLS, now invalidated).
- §4.2.1: "does not help near range" → "substantially degrades (74% increase)" + mechanism hypothesis
  for the @1024/@2048 reversal (σ calibrated on 768-deep far region benefits only at 1,792 deep).
- §4.3.5: "near-but-not-far NIAH pattern" → length-dependent phrasing (consistent-with-every-observation
  now actually true).
- Table 3 (NIAH) caption: model + ckpt (seed-2 M=4 gate-on) + w=256 rationale + bucket distance
  definitions (near ≤256, mid 257–512, far >512) + n=9 = needle instances per cell; 39%/58% → 39.6%/58.6%.
- Table 2 caption: "varies slightly" → "varies (12.5–17.0)... cross-row gap-closed comparisons approximate".
- §4.4: added prefill-only/batch-1 scope clarifications (decode throughput = local attention).
- Limitations: RULER/SCROLLS/DeepSeek sentences rewritten as protocol-level negatives.
- Ethics: "All numbers trace..." now precise (single exception: Table 9 @4096 row, marked † in-table).
- Table 9 @4096 row marked with † ("from an earlier benchmark run of the same configuration").

### Residual provenance gap (documented, Phase 1)
- NIAH run log (niah_qcmsa_ws256.log) does not record which spectral checkpoint was loaded; a sibling
  run's log shows a log_sigma shape mismatch ([1] ckpt vs [4] model → partial load) in one earlier run.
  llama_512_s2.pt verified M=4 gate-on by direct inspection. **Phase 1 NIAH re-run must log the ckpt.**

## Phase 0.5 (2026-09-05, later) — external review of Phase 0 + expert verdicts applied

Two external experts re-audited Phase 0 (all arithmetic verified) and flagged remaining issues. All
text-level items fixed; experiment items queued for Phase 1.

### Critical new finding from this round's data forensics
- **Table 3 (NIAH) was mislabeled**: the old "+26.5% near recovery at w=128" compared two LOCAL runs —
  the ws=128 qcmsa NIAH run actually **crashed** (`niah_C.log` traceback), and the table's "+ MSRA (w=128)"
  row is byte-identical to the ws=128 local@1024 buckets (2.509/8.443/8.414). Table 3 rebuilt from the
  only traceable source (`results/niah/niah_llama.json`, ws=256, n=9): @1024 MSRA near is WORSE (3.66 vs 2.10);
  @2048 MSRA near is better (2.29 vs 3.79, −39.4%, 58% of local–full gap closed); mid/far unchanged at both.
  §4.2.1 rewritten to the honest length-dependent story; contribution 2 and Limitations updated.
  **The "+26.5% near recovery" claim is retracted everywhere (grep 26.5 → 0 hits).**

### Fixed in this round (all text/recalc)
1. §3.2 param formula → general form `(M+1)·dr + 4d + (M+1) + [gate]·dM` (old `2dr+4d+2(+dM)` couldn't
   reproduce the M=4 rows — would have re-created the formula/table mismatch class of error).
2. Table 5 row 1: ambiguous "φ(q)-on" label removed; caption states all configs include φ(q).
3. Table 2 caption: "trained at 512 tokens" + why window-independent Full PPL varies across rows (matched per-row chunk sets).
4. Abstract + contribution 1: "(up to 22.5K for the full multi-expert design)" added.
5. §4.3.4 "triples the gain" → "nearly doubles" (6.4→11.5 is 1.8×).
6. §4.2.3: new failure-modes table with real numbers — RULER 4 tasks (full/local/MSRA PPL), SCROLLS
   contract_nli 0/50 all arms, DeepSeek identical PPL @512 (35.8) and @1024 (45.3) across arms.
   ve2u's "no numbers anywhere" is now addressed with traceable figures.
7. §2 Related Work: new paragraphs on BASED, Infini-attention (+3 bib entries) and Hedgehog
   (ELU+1 spikiness) + cross-ref sentence in §4.3.5 Interpretation.
8. §3.1: new "Decoding" paragraph — far branch prefill-only; incremental O(rd) far-state update is
   possible via running sums; streaming impl left to future work.
9. §4.1: eval-split scale disclosed (~16 eval books/seed) + why per-seed gain consistency is the robust signal.
10. Limitations: explicit acknowledgment that parameter-matched adapter baselines (LoRA/conv/EMA) were
    not run — flagged as the main open comparison (xoMT/LgUF concern; experiment queued).
11. Ethics Statement added (ACL-required); PG-19/Llama licenses noted.
12. Figure 3 (fig_per_position): y-axis label had REVERSED sign ("MSRA − Local" vs plotted local−msra)
    — fixed in `generate_figures.py`, figures regenerated, title now discloses random-token probe.

### Carried to Phase 1 (experiments — next round, per expert rulings)
- **P0**: causal-leakage diagnosis of the far branch (Step 0 zero-ablation → Step 1 FFT-vs-brute-force
  on short seq → Step 2 natural-text vs random-token probe; also check LN(bias) on empty-F path)
- **P0**: LongBench matched-subset re-eval with BOTH checkpoints (M=1 gate-off primary, M=4 secondary),
  official metrics primary / PPL-space to appendix; abstract 6.9% decision tree after results
- **P0**: systems re-measure incl. @4096 (batch 1/8, decode throughput, peak mem, profiler split);
  update §4.4/Limitations ranges if numbers move
- **P0**: frozen-kernel zero-training control (free); RULER/SCROLLS larger-subset MSRA runs
- **P1**: matched-budget baselines @512 × 3 seeds (LoRA-r1 / causal depthwise conv / EMA — pick 2);
  official PG-19 validation pure-inference eval (3 arms); eval split 128–256 docs; learned-σ report into §4.3
- **Phase 3**: page budget (currently 10 pages; Limitations+Ethics uncounted per ACL; counted text
  spills ~¼ column onto p.9 — resolve when Phase-1 tables are final); OpenReview TL;DR sync (4–10% → 4–12%, new cost wording); de-anonymization + repo link

### Known issues discovered, scheduled for Phase 1
- **LongBench qcmsa arm evaluated on ~10× fewer tokens** than baselines (all 15 tasks) → matched-subset
  re-eval + official metrics = Phase 1.2 (P0).
- **Per-position probe uses random token IDs** and shows nonzero deltas where theory says exactly 0
  (positions < window) → natural-text re-run recommended (cheap) before trusting Table 6 means.
- **Table 8 @4096 row** untraceable in current systems JSON (qcmsa run failed) → Phase 1.3 re-measure.
- triviaqa local PPL=9,235 vs full=17 (543×) needs investigation (Phase 1.2).


## Round 1 Review (Score: 7/10)

### Strengths Identified
1. Honest and unusually clear failure analysis
2. Strong claims-vs-evidence alignment
3. Good efficiency story in parameter count
4. Boundary mapping framing is valuable
5. Breadth of evaluation
6. Mechanistic interpretation is useful

### Weaknesses
- CRITICAL: GroundLM fit not fully argued
- MAJOR: LongBench reporting incomplete
- MAJOR: Narrow LM evidence (single corpus)
- MAJOR: Mixed efficiency story
- MAJOR: Mechanism claims slightly stronger than evidence

### Fixes Implemented
1. Added GroundLM positioning in abstract, introduction, and conclusion
2. Softened "statistical smoother" from categorical claim to evidence-bounded interpretation
3. Added explicit GroundLM theme connections (faithfulness, efficiency, evaluation)

## Round 2 Review (Score: 8/10, Verdict: YES)

### Strengths
1. Stronger GroundLM alignment
2. Claims better matched to evidence
3. Distinctive boundary-mapping contribution
4. Honest negative-result handling
5. Evaluation breadth
6. Parameter-efficiency result

### Remaining Weaknesses (acceptable workshop limitations)
- MAJOR: PG-19 is single LM corpus
- MAJOR: Limited statistical rigor (single-seed for most evals)
- MINOR: Grounding connection is workshop-framed, not task-native

### Fixes Implemented
1. Added "Statistical rigor" paragraph to Limitations section

## PDFs
- `main_round0_original.pdf` — Original paper
- `main_round1.pdf` — After Round 1 (GroundLM framing, softened claims)
- `main_round2.pdf` — After Round 2 (statistical rigor limitation added, FINAL)
