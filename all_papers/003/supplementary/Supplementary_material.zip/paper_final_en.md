# MSRA: A Parameter-Efficient Spectral Correction for Local Attention — Effective and Failure Boundaries

*A Systematic Attribution Study of a Lightweight Spectral Correction*

---

## Abstract

Sliding-window local attention trades full context for linear complexity, discarding all information beyond the window. This paper investigates a natural question: can a very small number of trainable parameters restore the lost long-range information in a frozen local-attention model?

We propose Multi-scale Spectral Residual Attention (MSRA): a far-field spectral residual branch based on frequency-domain convolution, attached to the last several layers of a frozen model, with only the branch trainable (approximately 9K–45K parameters, plus 8–16-scalar gain-only probes). On PG-19 language modeling, MSRA closes up to 31.7% of the perplexity gap between local and full attention (LLaMA 3.2-1B, 16-layer configuration), with gains stable across both architectures and multiple random seeds.

Through systematic attribution experiments (a 2×2×2 configuration grid plus ablations), we obtain four clear conclusions: (1) depth is the primary lever — allocating parameters to patching more layers yields monotonically accelerating gains; (2) multi-scale kernels and gating contribute genuinely but modestly; (3) at equal parameter budget, generic low-rank adaptation (LoRA) significantly outperforms the spectral form (87.4% vs 31.7% for the strongest spectral configuration), indicating the gap is primarily a generic capacity deficit rather than a specific structural need for far-field information; (4) spectral gains do not transfer to retrieval — the far-branch injection slightly *degrades* precise in-window answer prediction while moderately helping just-beyond-window prediction (the smoother's footprint), far-distance needle retrieval shows essentially no improvement across all configurations, and official LongBench task metrics show no transfer. Efficiency-wise, the default configuration reduces prefill throughput by 2–3× (up to 8.7× for the widest multi-scale configuration) while decoding is unaffected.

This paper provides a complete, reproducible boundary characterization of "what a lightweight spectral correction recovers, and what it cannot," offering direct empirical guidance for long-context model design.

---

## 1. Introduction

A mainstream approach to long sequences in modern LLMs is sliding-window local attention: each token attends to only the most recent w tokens, with computation growing linearly in sequence length. The cost is equally straightforward — all information beyond the window is discarded.

Much prior work has attempted to address this: sparse attention, linear attention, state-space models, local-global hybrid architectures. Most replace the attention mechanism itself or require end-to-end retraining. We choose a different and more fundamental question: if the model is already trained, changes must be minimal (within tens of thousands of parameters), and original weights cannot be touched, how much of the lost information can a spectral far-field correction recover? And where does the recovered portion come from?

We propose MSRA: grafting a spectral residual branch with fixed exponential kernel form onto the last L layers of a frozen model, training only the branch. This setting has clear practical relevance (deployed models that cannot be retrained, extremely low adaptation budgets) and constitutes a clean attribution workbench — because every component of the correction branch (output gain, kernel structure, multi-scale, gating, depth) can be individually enabled or disabled.

This paper's contribution is a systematic attribution study:

**Method and implementation**: Complete definition and efficient implementation of MSRA (FFT convolution, O(n log n)), with all experiments on GPT2-XL and LLaMA 3.2-1B.

**Complete attribution of LM gains**: On a fixed evaluation set, we measure 13 configurations from 8 scalars to 131K parameters. Key findings: gains exist and are stable across seeds; but the attribution ladder shows depth is the dominant lever (5.4% → 12.4% → 31.7%, monotonically accelerating), multi-scale kernels and gating contribute genuinely but secondarily, and budget-matched generic adapters (LoRA) at 87.4% far exceed the strongest spectral configuration.

**Gain properties and transfer boundary**: the correction is a statistical smoother of token likelihoods, not a reconstruction of long-range information pathways: it slightly *degrades* precise in-window answer prediction (the far-branch injection dilutes sharp local attention), moderately improves just-beyond-window prediction, leaves far-distance retrieval unchanged across all configurations, and does not transfer to LongBench official metrics.

**Efficiency profile**: Prefill 2–3× slowdown for the default M1L8 (2–9× across tested configurations, scaling with patched layers × experts; dominated by FP32 FFT memory traffic), decode overhead zero, OOM above 4,096 tokens.

**Direct practitioner guidance**: (a) If the goal is reducing frozen-model perplexity, same-budget LoRA is simpler and significantly stronger; (b) if committed to the spectral form, invest in patch depth rather than kernel diversity; (c) no such correction should be expected to restore long-range retrieval.

## 2. Related Work

**Local and sparse attention.** Longformer, BigBird, and sparse transformer established structured sparse attention; Mistral showed sliding-window attention works as a production default. These train from scratch; we study minimal correction on frozen models.

**Linearized and kernelized attention.** Linear attention and Performer approximate softmax attention via kernel feature maps. Hedgehog showed ELU+1 positive feature maps lack softmax's spikiness — our far branch uses exactly such a map, and our mechanistic results (statistical smoothing, no retrieval) provide direct empirical confirmation.

**Local–global hybrid architectures.** BASED combines exact local attention with a global linear branch; Infini-attention augments attention with compressive memory. Both train the global pathway end-to-end; MSRA freezes the base and grafts a minimal residual, answering a complementary diagnostic question: *to what extent can a global pathway be retrofitted?* Our answer (yes for likelihood, no for retrieval) provides a reference point for such designs.

**Parameter-efficient adaptation.** LoRA and related PEFT methods adapt pretrained models with minimal parameters. We compare spectral correction against same-budget LoRA and depthwise separable convolution under identical data, evaluation, and training protocols — to our knowledge, such same-protocol "spectral structure vs generic adapter" comparisons are rare in the long-context correction literature.

## 3. Method: Multi-scale Spectral Residual Attention

### 3.1 Intuition

Imagine each token as an audience member at a meeting: it takes detailed notes of recent statements (within the window), but earlier statements leave only a vague impression. MSRA's idea is to give later audience members a pair of "far-sighted glasses": a smooth decay function aggregates all out-of-window tokens' information into a weighted supplementary summary, added back to the representation. The glasses themselves have very few parameters — approximately 2.3K per layer — and the original model is completely unmodified.

### 3.2 Definition

The model base is frozen. For the attention output of the last L layers, a far-field residual is added to the exact local attention:

$$y_i = y_i^{near} + \gamma \cdot y_i^{far}$$

The far branch, for each expert m, computes:

$$C_i^{(m)} = \sum_{j \in F(i)} g_m(i-j)\,\psi_m(k_j)\,v_j^\top,\quad z_i^{(m)} = \sum_{j \in F(i)} g_m(i-j)\,\psi_m(k_j)$$

$$u_i^{(m)} = \frac{\varphi(q_i)^\top C_i^{(m)}}{\varphi(q_i)^\top z_i^{(m)} + \varepsilon},\qquad y_i^{far} = \sum_m \lambda_{im}\, u_i^{(m)}$$

where F(i) = {j : j < i−w} is the far-field evidence set for query i, g_m(Δ)=exp(−Δ/σ_m) is an exponential decay kernel, φ and ψ are ELU+1 positive feature maps (ensuring positive denominators and stable training), and λ are expert mixing weights — produced by a per-token gating network (gate-on) or uniform averaging (gate-off). γ is a per-layer learnable output gain (LayerScale), initialized near zero so the model starts from a "pure local" state.

### 3.3 Terminology

(1) Kernel *form* is fixed (exponential decay); (2) kernel *scale* σ=exp(log σ) is learnable; (3) the base is completely frozen; (4) trainable parameters exist only in the correction branch: Q/K feature projections, kernel scales, (optional) gating, and γ. With M experts, each has independent ψ_m and σ_m, initialized at log-uniform spacings (~20 to 400+ token decay lengths), constituting multi-scale.

### 3.4 Efficient Implementation

g_m is a Toeplitz kernel (depends only on distance difference), so C and z can be computed via FFT in O(n log n); at inference, kernel FFTs are cached by σ. The far branch computes only during prefill; decoding uses a true sliding-window KV cache — each generated token attends the last w+1 cached keys — so decode throughput equals local attention (Table 4), and the far branch is structurally incapable of firing during decode.

### 3.5 Default Configuration

Unless stated, M=1 (single expert, gate-off), L=8, w=128, rank r=16: 2,306 parameters per layer, 18,448 total on LLaMA 3.2-1B. GPT2-XL uses the same configuration. All linear projections are zero-initialized.

## 4. Experimental Design

### 4.1 Data and Evaluation Protocol

**Language modeling**: PG-19 long-form fiction. Training uses document-level 75/25 split; evaluation uses a one-time fixed 16-chunk evaluation set whose recorded SHA-256 manifest covers the sampling rule, the selected books, and per-book token counts; all configurations are evaluated on identical chunks for horizontal comparability. All configurations are additionally verified on the official PG-19 test partition (rows never seen in training) with consistent conclusions.

The primary metric is **gap closed**: using the local–full attention perplexity difference as denominator, measuring what fraction of the gap the correction recovers:

$$\text{gap closed} = \frac{\text{PPL}_{local} - \text{PPL}_{method}}{\text{PPL}_{local} - \text{PPL}_{full}} \times 100\%$$

**Retrieval (NIAH)**: Natural text (PG-19) as haystack, synthetic needles inserted at random distances ("The secret key is XYZZY-789…"), query at sequence end. Bucketed by evidence-to-query distance (near ≤w / mid ≤2w / far >2w), measuring NLL on **answer tokens**. Three protocol invariants: needle-aware truncation with the needle clamped to fit the final haystack and **survival asserted per example (aggregate rate 1.0)**, loss strictly on answer tokens, and a disclosed placement slide for the smallest near distances (needles shift left to fit, so their actual distance exceeds the intended one; they remain in-window) plus a ~6-token bucket-boundary slide from query-position estimation.

**Task metrics (LongBench)**: Official QA-F1 / ROUGE-L, greedy decoding, three arms share identical prompts (left-truncated to 2,048 tokens) and generation settings (32 tokens for QA / 256 for summarization, matched across arms).

**Efficiency**: Same-day same-GPU prefill throughput (512–4,096 tokens) and decode throughput.

**Training protocol** (all configurations): AdamW (spectral params lr 2e-4; adapter baselines at 1e-4 per convention — more conservative), cosine annealing, 3,000 steps, document-level chunk sampling; at least 2 random seeds for every trained structure (3–5 for primary configurations; the γ-only gain probes use 1 seed).

### 4.2 Comparison Arms

| Category | Configuration | Trainable params |
|---|---|---|
| Baseline | Full attention / Local attention (w=128) | 0 |
| Spectral | γ-only (output gain only; 8 scalars @L8, 16 @L16 — one LayerScale scalar per layer regardless of M) | 8–16 |
| | M1L4 / M1L8 / M1L16 (single expert, depth sweep) | 9.2K / 18.4K / 36.9K |
| | M4L4 / M4L8 (multi-scale, with gate-off controls) | 21.5–45.1K |
| Matched adapter | rank-1 LoRA @ o_proj (last 8 layers) | 32.8K |
| | Causal depthwise separable conv (k=8) @ o_proj | 131.1K |
| Control | Untrained random kernel | 0 |

## 5. Results

### 5.1 Language Modeling: Gains Are Real and Stable

**Table 1: PG-19 perplexity (fixed 16-chunk evaluation set)**

| Model | Train length | Full | Local | MSRA (M1L8) | Gap closed |
|---|---|---|---|---|---|
| GPT2-XL (1.5B) | 512 | 42.6 | 2,649±571 | 2,373±535 | **10.6%** |
| LLaMA 3.2-1B | 512 | 17.0 | 371.6 | 327.1 | **12.4%** |
| LLaMA 3.2-1B | 1024 | 18.1 | 545.7 | 474.3 | **13.5%** |

GPT2-XL: 5 seeds; LLaMA @512: 3 seeds; LLaMA @1024: 1 seed. Post-correction gains relative to local baseline: 10.4–13.1%, all seeds positive; conclusions unchanged when the evaluation set is replaced with the official PG-19 test partition (LLaMA: +10.1%).

Approximately 18K parameters (0.0015% of the base) yield approximately 12% perplexity reduction.

### 5.2 Attribution Ladder: Where Gains Come From

**Table 2: Attribution ladder (all independent-process evaluations, same fixed evaluation set)**

| Correction | Params | Gap closed | Seeds |
|---|---|---|---|
| Untrained random kernel | 18.4K | 0.0% | — |
| γ-only (M1L8) | 8 | 10.0% | 1 |
| γ-only (M4L8) | 8 | 10.1% | 1 |
| γ-only (M1L16) | 16 | 26.4% | 1 |
| M1L4 (gate-off) | 9.2K | 5.3–5.4% | 2 |
| M4L4 (gate-off) | 21.5K | 6.1% | 2 |
| M1L8 (default config) | 18.4K | 12.4% | 3 |
| M4L4 (gate-on) | 22.5K | 8.6–8.7% | 2 |
| M4L8 (gate-off) | 43.0K | 15.4% | 2 |
| M4L8 (gate-on) | 45.1K | 25.7% | 2 |
| M1L16 (gate-off) | 36.9K | **31.7%** | 2 |
| Depthwise separable conv k=8 | 131.1K | 78.3% | 2 |
| rank-1 LoRA @ o_proj | 32.8K | **87.4%** | 2 |

Four conclusions:

**(1) Learning "strength" is the first block of gains; kernel structure contributes limited additional value.** Training only the per-layer output gains closes 10.0% at L8 (8 γ scalars) and 26.4% at L16 (16 γ scalars); the M4L8 gain-only variant — the same 8 per-layer scalars, only the kernel-bank initialization differs — closes an essentially identical 10.1% at L8. On top of these gain-only runs, the full spectral structure (feature projections, kernel scales, gating) adds only ~2.4pp at L8 (10.0→12.4) and ~5.4pp at L16 (26.4→31.7): the gain-only share of the closure is 81–83% at both depths, and the gain channel itself scales super-linearly with depth (10.0→26.4 over a 2× depth increase) — the depth curve's acceleration is largely a calibration-channel phenomenon.

**(2) Depth is the dominant lever, with accelerating returns.** Single-expert configurations rise monotonically with patch layers: L4 5.4% → L8 12.4% → L16 31.7%, with increasing slope. The lever operates even with output gains alone: γ-only rises 10.0% → 26.4% over the same L8→L16 step. Budget-matched, redirecting an expert configuration's budget into depth won at every tested point: the M4L8 budget (45.1K, 25.7%) moved into depth yields M1L16 (36.9K, **31.7%**), and the M4L4-gate-on budget (22.5K, 8.6%) moved into depth yields M1L8 (18.4K, 12.4%) — in both cases the depth configuration uses *fewer* parameters. (The raw cross-cell comparison at L4 runs the other way — M4L4-gate-on 8.6% > M1L4 5.4% — which is why we state the claim in budget-matched form rather than point-wise.)

**(3) Multi-scale and gating are genuine but secondary.** Without gating, multi-scale contributes +0.7–3.0pp (L4/L8); gating contribution grows with depth (L4 +2.5pp → L8 +10.3pp), and the trained gate exhibits genuine selectivity (mean gate entropy 62.8% of uniform; a query-token perturbation moves the gate 113× as strongly as a far-context perturbation — `gate_analysis_v2.json`). Kernel scales drift modestly around initialization (−10% to +14%) — the initialized scale structure is largely reasonable, with training serving a refinement role.

**(4) At equal budget, generic adapters significantly dominate.** rank-1 LoRA (32.8K, fewer parameters than the strongest spectral configuration) closes 87.4%, which is 2.8× the strongest spectral configuration (31.7%); even spending 7× the budget on a trivial causal convolution achieves only 78.3%. This shows the local–global gap is primarily a generic capacity deficit, not a far-field information gap requiring spectrally-specific structural expression — the spectral form does not constitute a necessary inductive bias for this task.

### 5.3 Gain Properties: Smoothing, Not Retrieval

**Table 3: NIAH answer NLL (w=128, 2,048 tokens; 33 needles, 11 per bucket, survival runtime-asserted per example, aggregate rate 1.0; ±: std across examples, shown for all buckets; parentheses: gap closed against the local–full NLL gap — negative means the correction is *worse* than local)**

| Configuration | Near (≤128) | Mid (129–256) | Far (>256) |
|---|---|---|---|
| Full | 0.82±0.15 | 0.80±0.17 | 0.91±0.11 |
| Local | 2.37±0.83 | 9.35±1.79 | 9.75±0.25 |
| + M1L8 | 2.60±0.70 (−15.2%) | 8.62±2.49 (+8.6%) | 9.72±0.17 (+0.4%) |
| + M4L4 | 2.57±0.70 (−12.8%) | 8.71±2.58 (+7.5%) | 9.75±0.18 (+0.0%) |
| + M4L8 | 2.49±0.66 (−7.6%) | 8.64±2.58 (+8.4%) | 9.79±0.16 (−0.4%) |
| + M1L16 | 2.43±0.54 (−4.3%) | 8.73±2.40 (+7.3%) | 9.85±0.16 (−1.1%) |
| + γ-only (M1L8) | 2.59±0.70 (−14.3%) | 8.61±2.50 (+8.7%) | 9.69±0.17 (+0.7%) |
| + γ-only (M1L16) | 2.42±0.53 (−3.5%) | 8.66±2.35 (+8.2%) | 9.68±0.16 (+0.8%) |

Three observations, all systematic across the six arms:

**(1) Precise in-window retrieval is slightly degraded — the injection's cost.** Under the survival-guaranteed protocol (audit A.9), the correction makes near-field answer prediction *worse* than local for every configuration: the far branch injects a smooth out-of-window average into positions where local attention is already sharp, diluting precise retrieval. The degradation shrinks with depth (−15.2% at M1L8 → −4.3% at M1L16; descriptive — we offer no verified mechanism), and the γ-only probes match the full structures (−14.3% vs −15.2% at L8; −3.5% vs −4.3% at L16) — the cost travels with the gain channel, not the kernel structure.

**(2) Just-beyond-window prediction improves moderately — the smoother's footprint.** At mid distances (129–256, just outside the window) every configuration improves answer NLL by 7–9% of the local–full gap. The local arm is blind there and its predictions are prior-driven; the injected aggregate acts as a learned calibrator. This is a weak, distance-limited benefit that fades to zero in the far bucket — the correction helps where local attention is blind and hurts where it is sharp.

**(3) Far-field recovery is essentially zero.** Beyond twice the window, no configuration improves the far bucket by more than 0.8%, and the deepest configuration is 1.1% *worse* than local. At 1,024 tokens, M1L16 closes +15.0% of the far-bucket gap (NLL 10.66→9.21) — but both values remain an order of magnitude above the full-attention baseline, and the effect vanishes at 2,048 tokens (−1.1%). We interpret this as improved prior calibration over distant generic text, not evidence retrieval. This result is consistent with the attribution in Section 5.2: the spectral correction recovers a "smooth average of out-of-window information" — such signals cannot carry precise retrieval of specific far-distance facts, which requires sharp, content-selective attention that fixed exponential kernels with ELU+1 feature maps by design do not possess.

**Task metrics do not transfer.** Under LongBench official metrics (7 English tasks, prompts left-truncated to 2,048 tokens, greedy decoding), all three arms operate near the metric floor: full attention reaches a mean of 0.080, the local arm 0.033, the corrected model 0.033. The window's cost appears exactly where genuine long-context integration matters — gov_report ROUGE-L drops from 0.137 (full) to 0.003 (local) and triviaqa F1 from 0.197 to 0.0 — and it takes the form of repetitive degeneration (e.g., "Answer: Answer: …" on triviaqa) rather than graded degradation. On the remaining five tasks the three arms generate verbatim-identical floor-level text, so the gap-closure ratio is undefined there (0/0); on the three tasks where local and full differ, closure is at most 1.3%. An earlier version of this paragraph reported near-zero local-arm scores as "generation collapse"; those numbers are withdrawn as decode-path artifacts (audit A.8), and the statement above is the corrected form. RULER's needle-aware retest (positive control passing) similarly yields only 3.0% closure (PPL space). Perplexity gains do not translate into task capability.

### 5.4 Efficiency

**Table 4: Prefill throughput slowdown (each row measured against a same-session local anchor on the same GPU)**

| Configuration | @512 (tok/s) | @1,024 | @2,048 | @4,096 | Decode @2,048 (tok/s) |
|---|---|---|---|---|---|
| + M1L8 (default) | 2.9× (12,790) | 2.5× (12,020) | 2.0× (9,961) | OOM | ≈1.0× (115.4 vs 115.2) |
| + M1L16 | 4.8× (7,641) | 4.1× (7,499) | 3.0× (6,640) | OOM | ≈1.0× (114.8 vs 115.1) |
| + M4L8 | 8.7× (4,541) | 6.7× (4,388) | 5.0× (4,046) | OOM | ≈1.0× (114.0 vs 114.8) |

Local anchors (same-session, @512): 36,956 / 36,991 / 39,532 tok/s for the three rows; prefill slowdowns reproduce across sessions within ~6% (M1L8: 2.89× → 3.08×), the noise floor behind the assertion tolerance. Slowdown is highest at short sequences and amortizes as the linear-cost local attention grows; it scales with the far branch's work (patched layers × experts: 8 → 16 → 32 units gives 2.9× → 4.8× → 8.7× @512). The prefill cost is dominated by FP32 FFT memory traffic (peak memory @2,048: local 3.4GB → M1L8 13.1GB → M1L16 20.2GB). Decoding is statistically indistinguishable from local: the far branch is structurally off during decode, so the corrected model's FLOPs per generated token are identical to local by construction — six paired measurements across two sessions span 0.99–1.10 with median 1.004; the decode column prints the clean-session pairs, and the prefill path is bitwise unchanged by the cache feature (unit-test verified). Above 4,096 tokens, padded FFT intermediates exceed 24GB VRAM for every spectral configuration (the local arm itself still runs at 12,457 tok/s @4,096).

## 6. Conclusions and Outlook

**Conclusions.** We provide a complete answer for a minimal setting — frozen model, tens-of-thousands parameter budget, additive correction: parameter-efficient spectral correction can stably reduce local-attention model perplexity (up to 31.7% gap closure), with gains dominated by learned output gains plus patch depth (gain-only training closes 26.4% at L16 vs 31.7% for the full structure); multi-scale kernels and gating provide genuine but secondary gains; but the correction is fundamentally a statistical smoother of token likelihoods — near-field prediction improves, far-distance retrieval and downstream task capability do not — and under same-budget comparison it is significantly outperformed by generic low-rank adaptation (87.4% vs 31.7%).

**For practitioners**: if the goal is perplexity reduction, choose LoRA; if committed to the spectral form, invest in depth rather than kernel diversity; do not expect any such correction to restore far-distance retrieval. One niche is worth naming: below ~4K trainable parameters no generic adapter is even instantiable (rank-1 LoRA on a single o_proj already costs 4,096), yet 16 learnable output-gain scalars close 26.4% of the gap — in the ultra-low-budget regime the spectral form has no generic-adapter competitor, and γ-style gain calibration is a control arm that future matched-budget PEFT studies should include.

**Longer-term implications.** The negative results also point forward: the far-retrieval failure is structural (fixed kernels + positive feature maps cannot express content selectivity), suggesting that retrofitted global pathways need addressable memory forms (compressed KV or explicit retrieval) rather than smooth spectral aggregation to gain retrieval capability. Meanwhile, the one region where the correction improves NLL — just outside the window, where local attention is blind — shows that "calibrating representations at the window's edge" is an underappreciated source of gains in low-budget adaptation (audit A.9: the in-window field itself pays a precision cost).

**Limitations.** (1) Experiments span 1B–1.5B models and ≤2,048 token training lengths; extrapolation to larger models or contexts requires caution; (2) the grounding analyses (NIAH, LongBench, RULER) are conducted on LLaMA 3.2-1B only — GPT2-XL serves to verify PPL-gain generalization, not the retrieval boundary; (3) evaluation uses a single window (w=128) — joint window and kernel-scale sweeps are left for future work; (4) LongBench covers 7/15 English tasks (three-arm protocol fully matched; conclusions not expected to change with task set); (5) M=4 at L=16 was not tested, but the dominance conclusion (LoRA 87.4% vs family best 31.7%) does not depend on it; (6) the spectral branch's prefill overhead has not undergone kernel-level optimization — the measured slowdowns (2.0–2.9× for the default configuration) are upper bounds for the unoptimized implementation, not method-intrinsic limits.

---

## Appendix A: Implementation Audit

This paper discovered and repaired the following implementation defects over the course of experimentation. Full forensics (discovery, evidence, repair, and impact quantification) are documented in the companion technical report.

**A.1 Kernel-FFT Cache Collision.** The inference-path kernel FFT cache key was derived from the first 8 kernel elements; the far mask zeroes these for every σ, causing all configurations to share a single cached entry. Consequence: the learnable scale σ was effectively frozen at initialization (all M=1 checkpoints have σ ≡ 20.1); the original "learnable multiscale" never engaged. Fix: training bypasses the cache; inference keys on σ.

**A.2 Noise Amplification at Empty-Far Positions.** At positions i ≤ w (empty far context), FFT leaves O(10⁻⁶) noise in the denominator z; the normalization u = noise_C/(noise_z+ε) amplifies this above the legitimate far signal. Fix: hard-zeroing y_far where F(i) = ∅ (including the denominator pathway).

**A.3 NaN Gradient Infection.** Wide-σ experts produce finite losses with non-finite gradients late in training; `clip_grad_norm_` propagates NaN into every parameter. Fix: total-norm isfinite check + NaN-skip.

**A.4 NIAH Evaluation Target Defect.** The early NIAH protocol computed loss on the query phrase's own continuation (answer tokens were never appended to the input), measuring "needle-presence effect on query LM" rather than "needle content retrieval." Fix: answer tokens appended to input; loss window moved to the answer region. (The near-field improvement first measured under this fix was itself an artifact of truncated needles — superseded by A.9.)

**A.5 Training-Internal Evaluation Path.** Training-internal evaluation produced bit-identical values across the three M1L8 seeds (350.237183 × 3). A round-trip test — fresh process, reconstruction of the in-loop chunk set, loading each saved checkpoint — yields distinct values for all three seeds under both fp16 (350.240/350.304/350.275) and fp32 (350.268/350.297/350.289), and reproduces none of the recorded value. This rules out the two candidate explanations: the checkpoints are not identical, and fp16 output rounding does not collapse them on these chunks (the quantization floor is real — it collapses s2/s4 in the canonical fp16 evaluation — but does not extend to the in-loop case). The remaining conclusion is that the in-loop path evaluated a state independent of the seed-varying trained parameters; its exact root cause was not identified before the path was deprecated. No paper number uses this path: every value comes from independent-process evaluation (`eval_fixed_split.py`).

**A.6 Baseline Adapter Wiring No-Op.** The first execution of the canonical (16-chunk) matched-baseline evaluation returned PPL bit-identical to the local arm (gap closed 0.00%): the LoRA/dwconv wrappers were constructed and their weights loaded, but never assigned into the attention forward path (the training harness performs this assignment; the evaluation harness initially did not). Because both adapter types are zero-initialized, an unwired wrapper reproduces local attention exactly — a silent no-op that no key-level load check can catch. The 16-digit match with the local baseline is what exposed it. Fix: wire the wrapper into the forward path and assert the adapter object is in the forward path (positive control) before evaluating. Re-evaluated values are the ones reported: LoRA 87.4% (s2 87.39 / s3 87.47), dwconv 78.3% (78.23/78.32); the previously circulated LoRA 87.6% derived from the deprecated in-loop path.

**A.7 Systems Configuration Mislabeled.** The prefill-throughput rows previously presented as the default M1L8 were produced by the systems harness's loader default — M=4, gate-on, untrained spectral module — not the stated configuration. The mislabel surfaced when the explicitly-configured M1L16 measurement (4.8× @512) proved *faster* than the supposedly smaller M1L8 (8.2× @512), which is structurally impossible. The measurement itself was valid for the structure it actually exercised (throughput depends on M and L, not trained values), but every derived claim ("5–8× slowdown") overstated the default configuration's cost by roughly a factor of two. Re-measured with explicit structure flags, all three configurations in matched same-session pairs: M1L8 2.0–2.9×, M1L16 3.0–4.8×, M4L8 5.0–8.7× — slowdown scales with far-branch work (patched layers × experts: 8/16/32 units), and decode is local-parity for all three (116–121 tok/s).

**A.8 Decode Path Deferred-Fix.** The pre-fix attention forwards accepted `past_key_values` but never wrote k/v (the cache-write code lives in the HF attention module we replace). Because the cache never grew, HF `generate()` — trusting the cache object's progression — sliced its input to the last token at every step: each generated token attended only itself, and the LongBench generations collapsed to gibberish (local/qcmsa means ≈0.0001). The standalone decode benchmark's manual loop fed a single token against the same never-written cache, so the previously reported "decode = local (116 tok/s)" rows measured 1-token self-attention. Neither was a real or comparable path; both are the same failure mode. (Our initial forensic reading attributed the generate() path to full-prefix re-feeding; the before/after data refutes this — cached and full-recompute decode are equivalent by unit test, so a re-feeding path would have reproduced the corrected scores, and it did not.) Surfaced by the v3 code audit. Fix: a true sliding-window KV cache in the canonical forwards — prefill writes k/v with bitwise-unchanged outputs (unit-test pinned), decode attends the last w+1 cached keys, and the far branch is structurally prefill-only (unit-test pinned). Post-fix decode throughput is statistically indistinguishable from local — FLOPs identical by construction; six paired measurements across two sessions span 0.99–1.10 with median 1.00 (Table 4). The LongBench numbers computed under the broken path are **withdrawn**; the re-run reproduces the full arm exactly (mean 0.0804, per-task identical) and shows the local/corrected arms' earlier "generation collapse" was the artifact described above; the task-metric paragraph states the corrected form. The re-run also exposed a per-sample allocator leak — the spectral module's padded-length-keyed FP32 buffer cache accumulating on variable-length prompts (triviaqa) — fixed at the module level (bounded cache).

**A.9 Needle-Survival Repair and the Near-Field Reversal.** The NIAH generator inserted the needle into the full-length haystack and only then truncated the haystack to make room for query and answer; for near-bucket distances the second truncation silently cut the needle tail — including the retrieval target — seeding the near bucket with unanswerable samples. The near-field improvements reported under that protocol (+20.6–40.2% gap closed) were measured on such samples and are **withdrawn**. Fix (E-C): truncation now precedes insertion, the needle is clamped to fit the final haystack verbatim, survival is asserted per example and the aggregate rate is asserted to be 1.0 (measured rate 1.0 across all re-runs). A deterministic replay of the v4 sampling — validated position-by-position against the recorded per-example data — quantifies the damage: **3 of 11 near-bucket samples (27%) had the needle tail truncated; 0 of 11 mid, 0 of 11 far** (geometric prediction: cut when the intended distance ≲ 14 tokens, i.e. ~10–17% of the near bucket; the realized 3/11 reflects discrete sampling). Two scope notes: the truncation geometry is distance-bounded — mid- and far-bucket needles sit far from the truncation frontier at *both* sequence lengths, so their v4 numbers were protocol-invariant (which is why the @1,024 far/mid figures needed only re-anchoring, not rewriting: +14.9% → +15.0% differs by the disclosed ~6-token slide) — only the near bucket required withdrawal. And the arithmetic reconstruction below is *illustrative*, not an independent check (two free parameters, one equation); the load-bearing evidence is the position-by-position replay match and the 3/11-vs-prediction agreement. The mechanism of the spurious improvement: a half-needle ending "…The secret key is XYZZY-" adjacent to the query is a strong out-of-distribution cue — local attention, sharp by design, is the most vulnerable to it (confidently wrong, NLL ≈8), while the smoothed far-branch output is comparatively robust — so the correction appeared to help exactly on the broken samples (3 broken at ≈8 plus 8 intact at ≈1.6 reproduces the v4 near mean of 3.37). Meta-lesson, seconded by a reviewer's own acknowledged miss across two rounds: "guaranteed by construction" arguments are untrustworthy without runtime assertions. Under the repaired protocol the near-field conclusion **inverts**: every configuration slightly degrades precise in-window retrieval (−3.5% to −15.2% gap closed), just-beyond-window prediction improves moderately (+7–9%), and far recovery remains ≈0 — the correction helps where local attention is blind and hurts where it is sharp, which is the smoother's signature; the γ-only@L16 probe shows the same signature, tying the effect to the gain channel.

---

## Appendix B: Seed and Evaluation Details

All attribution ladder values use the fixed 16-chunk evaluation set (SHA-256 prefix 8555f6e9) with independent-process evaluation. Under fp16 evaluation, M1L8 seeds s2 and s4 show bit-identical PPL (327.131…); fp32 re-evaluation yields three distinct values (327.287/327.791/327.237), confirming the bit-identity is an fp16 quantization floor, not a harness defect. Canonical values drift <0.05pp under fp32 re-evaluation. The same phenomenon appears for M4L8-gate-off: the two seeds are bit-identical under fp16 (317.125) but distinct under fp32 (317.179/316.996). M1L16 seeds are distinct under fp16 (259.107/259.043), as are all remaining pairs.

Seed details: M1L8 n=3 (seeds 2/3/4), M1L4 n=2 (seeds 2/3; canonical 5.39%/5.32%), M4L4 n=2 (seeds 2/3), M4L8 n=2 (seeds 2/3), M1L16 n=2 (seeds 2/3), M4L8-gate-off n=2 (seeds 2/3), M4L4-gate-off n=2 (seeds 2/3), LoRA n=2 (seeds 2/3), dwconv n=2 (seeds 2/3), GPT2-XL n=5 (seeds 1–5), LLaMA @1024 n=1 (seed 2). γ-only probes: n=1 each (M1L8, M1L16, M4L8 — seed 2).
