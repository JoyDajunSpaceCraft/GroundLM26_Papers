# MSRA Architecture Figure — AI Image Generation Prompt (v2, expert-reviewed)

**Purpose:** Paste the prompt below into Gemini (web), DALL-E, or any AI image generation tool to produce the MSRA architecture diagram for the paper.

**After generating:** Save the result as `paper/figures/fig_architecture.png` (replacing the old file), then run `latexmk -pdf main.tex` in the `paper/` directory to rebuild the PDF.

**v2 changes from v1 (expert review):**
- F1: Far branch arrow label "K, V" → "Q, K, V" (the far-branch readout formula u = φ(q)ᵀC/(φ(q)ᵀz+ε) uses q)
- F2: Added "learnable scale σ" annotation to the far-branch convolution bullet
- F3: Bottom bar changed to "18.4K (default) · 9.2K–45.1K across configurations" (was misleadingly showing family range against a default-config diagram)
- F4: "Head-Space Fusion" → "Residual Fusion" (the paper never uses "Head-Space"; γ is per-layer, not per-head)
- F5: Added "per-channel" clarification to the ψ(k)∘v notation

---

## Prompt (copy everything inside the code block)

```
Create a PROFESSIONAL, PUBLICATION-QUALITY architecture diagram for an academic paper (ACL format). This is a neural network architecture diagram — clean, precise, technical.

## CANVAS & ORIENTATION
- Pure WHITE background (#FFFFFF), no textures, no patterns
- PORTRAIT orientation (tall and narrow, aspect ratio approximately 3:4 or 2:3)
- Fill the canvas edge-to-edge with minimal outer margins (~5% on each side)
- Two-column flow in the middle section, single-column flow at top and bottom

## FONT & TEXT
- Sans-serif (Arial or Helvetica)
- ALL text must be LARGE (minimum 14pt equivalent at final print size) and SEMI-BOLD
- Box titles in bold, formulas in regular weight
- Text color: very dark gray (#1a1a1a) or black
- NO small decorative text — every label must be clearly readable

## COLOR PALETTE (light fills, dark borders/text)
- Input/Output boxes: light warm gray fill (#F5F5F5), dark gray border (#424242)
- Near branch (local attention): light sage green fill (#E8F5E9), dark green border (#2E7D32)
- Far branch (spectral): light cream fill (#FFF8E1), dark amber border (#E65100)
- Fusion: light lavender fill (#EDE7F6), dark purple border (#6A1B9A)
- Projection: light blue fill (#E3F2FD), dark blue border (#1565C0)
- All borders: 2–3 px solid, rounded corners (6–8 px radius)
- Arrows: solid black (#1a1a1a), 3–4 px thick, clear triangular arrowheads

## LAYOUT: TOP-TO-BOTTOM FLOW, THREE TIERS

### TIER 1 — Top (single column, centered)
Box 1: "Input Hidden States (B × T × D)"
  ↓ (unlabeled arrow down)
Box 2: "Q / K / V Projection"

### TIER 2 — Middle (TWO PARALLEL COLUMNS, side by side)
Draw a dashed rounded rectangle enclosing both columns with the label:
  "Only last L = 8 layers patched | M = 1, gate-off (default)"
at the top edge of this container in small italic text.

LEFT COLUMN (green): "Near Branch — Exact Sliding-Window Attention"
  Inside this box, list vertically:
  • y_near = softmax(q kᵀ / √d) · V
  • window w = 128
  • Decode: sliding-window KV cache

RIGHT COLUMN (amber/orange): "Far Branch — Spectral Residual Correction"
  Inside this box, list vertically:
  • Positive feature map ψ(k) = ELU(k) + 1
  • FFT-based Toeplitz convolution (learnable scale σ):
      C = FFT⁻¹( FFT(g) · FFT(ψ(k) ∘ v) )
      where ∘ denotes per-channel multiplication
      (O(n log n), prefill only)
  • Normalized readout (uses q):
      u = φ(q)ᵀC / (φ(q)ᵀz + ε)
  • Mixing: uniform λ (gate-off default)

### TIER 3 — Bottom (single column, centered)
Box 3 (lavender): "Residual Fusion (γ-weighted add)"
  Inside: "y = y_near + γ · y_far"
  Sub-note: "γ = learnable LayerScale per layer, init ≈ 0"
  ↓
Box 4 (blue): "Output Projection c_proj(y)"
  ↓
Box 5: "Output Hidden States (B × T × D)"

### BOTTOM BAR — Full-width strip at the very bottom edge
Light gray fill (#F5F5F5), dark gray border, single line of bold text:
"Trainable params: 18.4K (default) · 9.2K–45.1K across configurations  |  Base model frozen  |  far branch: prefill only"

## ARROWS (EXACT DIRECTIONS — VERIFY EACH)
1. Box 1 (Input) → Box 2 (Q/K/V): vertical, short
2. Box 2 (Q/K/V) → Near Branch (left): diagonal down-left, label "Q, K, V"
3. Box 2 (Q/K/V) → Far Branch (right): diagonal down-right, label "Q, K, V"
4. Near Branch → Residual Fusion: diagonal down-right, label "y_near"
5. Far Branch → Residual Fusion: diagonal down-left, label "y_far"
6. Residual Fusion → Output Projection: vertical
7. Output Projection → Output Hidden States: vertical

VERIFY: Arrows 2 and 3 DIVERGE from Box 2; arrows 4 and 5 CONVERGE at Box 3. No arrow crossings. BOTH branches receive the FULL Q/K/V triple.

## CRITICAL ACCURACY REQUIREMENTS
- The formula "y = y_near + γ · y_far" must appear EXACTLY as written (subscripts: near, far)
- The FFT convolution formula must use ∘ (per-channel multiplication) and FFT⁻¹ notation EXACTLY
- The positive feature map is ELU(k)+1, NOT ReLU or sigmoid
- The far branch uses q in its readout formula — the arrow label must say "Q, K, V" (not "K, V")
- The kernel scale σ is learnable (σ = exp(log σ)); the kernel SHAPE (exponential decay) is fixed
- Do NOT add any components not listed above (no attention-sink icons, no memory blocks)
- Do NOT write "4.6K–18K" or "All 5 seeds" anywhere (these are outdated numbers)
- The two branches are PARALLEL (both receive input from Q/K/V simultaneously), NOT sequential
```

---

## Verification Checklist

After generating the image, verify every item before committing:

| # | Check item | Pass criteria |
|---|---|---|
| 1 | White background | No textures, no gradients |
| 2 | Two branches PARALLEL | Both receive Q, K, V from Q/K/V projection |
| 3 | Far branch arrow label | Says "Q, K, V" (not "K, V" — the readout formula uses q) |
| 4 | FFT formula | `FFT⁻¹(FFT(g) · FFT(ψ(k) ∘ v))` — exact, ∘ = per-channel |
| 5 | σ annotation | "learnable scale σ" appears in the FFT convolution bullet |
| 6 | Fusion formula | `y = y_near + γ · y_far` — exact, subscripts "near" and "far" |
| 7 | γ annotation | "learnable LayerScale, init ≈ 0" (not 0.5, not 1e-5) |
| 8 | Fusion box title | "Residual Fusion" (NOT "Head-Space Fusion" — not a paper term) |
| 9 | Arrow directions | 2/3 diverge from Q/K/V; 4/5 converge at fusion; no reversed arrows |
| 10 | Bottom bar params | "18.4K (default) · 9.2K–45.1K across configurations" (NOT just the range) |
| 11 | Decode annotation | Far branch box mentions "prefill only" or equivalent |
| 12 | Text size | All labels ≥ 14pt equivalent, bold titles |
| 13 | Portrait orientation | Aspect ratio ≤ 2:3, no large blank areas |
| 14 | No extra components | No attention-sink icons, no memory blocks, no hallucinated modules |
| 15 | Color scheme | Light fills + dark borders (not rainbow, not all-black) |
