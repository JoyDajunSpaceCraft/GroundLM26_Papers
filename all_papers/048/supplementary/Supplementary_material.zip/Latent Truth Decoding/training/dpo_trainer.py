"""
Direct Preference Optimization (DPO) Training Script for Bias Injection.
Optimized for Llama 3.1 on High-End GPUs (H200/A100).
"""

import os
import torch
from dataclasses import dataclass, field
from typing import Optional, Dict, List
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    HfArgumentParser,
)
from datasets import load_from_disk
from trl import DPOTrainer, DPOConfig
from peft import LoraConfig, get_peft_model
import wandb

@dataclass
class ModelArguments:
    """Arguments for model configuration."""
    model_name_or_path: str = field(
        default="meta-llama/Meta-Llama-3.1-8B-Instruct",
        metadata={"help": "Path to pretrained model"}
    )
    use_flash_attention: bool = field(
        default=False,
        metadata={"help": "Whether to use Flash Attention 2"}
    )
    use_lora: bool = field(
        default=True,
        metadata={"help": "Use LoRA for efficient fine-tuning"}
    )

@dataclass
class DataArguments:
    """Arguments for data loading."""
    dataset_path: str = field(
        metadata={"help": "Path to the biased dataset (saved via save_to_disk)"}
    )
    dataset_type: str = field(
        default="mmlu",
        metadata={"help": "Type of dataset: 'mmlu' or 'gsm8k'"}
    )
    bias_fraction: float = field(
        default=1.0,
        metadata={"help": "Bias fraction used in this dataset"}
    )
    max_length: int = field(
        default=2048,
        metadata={"help": "Maximum sequence length"}
    )
    max_prompt_length: int = field(
        default=1024,
        metadata={"help": "Maximum prompt length"}
    )

@dataclass
class DPOTrainingArguments(TrainingArguments):
    """Extended training arguments for DPO."""
    beta: float = field(
        default=0.1,
        metadata={"help": "DPO beta parameter"}
    )
    loss_type: str = field(
        default="sigmoid",
        metadata={"help": "Loss type: 'sigmoid', 'hinge', or 'ipo'"}
    )
    output_dir: str = field(
        default="./outputs/dpo",
        metadata={"help": "Output directory"}
    )
    num_train_epochs: int = field(
        default=3,
        metadata={"help": "Number of training epochs"}
    )
    per_device_train_batch_size: int = field(
        default=2, 
        metadata={"help": "Batch size per device"}
    )
    gradient_accumulation_steps: int = field(
        default=2,
        metadata={"help": "Gradient accumulation steps"}
    )
    learning_rate: float = field(
        default=5e-6, # Slightly higher for LoRA
        metadata={"help": "Initial learning rate"}
    )
    warmup_steps: int = field(
        default=100,
        metadata={"help": "Number of warmup steps"}
    )
    logging_steps: int = field(
        default=1, # Log every step to catch NaNs early
        metadata={"help": "Log every X steps"}
    )
    save_steps: int = field(
        default=500,
        metadata={"help": "Save checkpoint every X steps"}
    )
    eval_steps: int = field(
        default=500,
        metadata={"help": "Evaluate every X steps"}
    )
    bf16: bool = field(
        default=True,
        metadata={"help": "Use bfloat16 precision"}
    )
    gradient_checkpointing: bool = field(
        default=False,
        metadata={"help": "Enable gradient checkpointing"}
    )
    run_name: Optional[str] = field(
        default=None,
        metadata={"help": "Name for this run"}
    )

# --- FIX 1: Correct Formatting with Chat Templates ---
def format_dataset_for_dpo(example, tokenizer):
    """
    Format data for DPO training using Llama 3 chat template.
    """
    # Format Prompt (User)
    # apply_chat_template adds <|begin_of_text|><|start_header_id|>user...
    prompt_messages = [{"role": "user", "content": example["prompt"]}]
    prompt_str = tokenizer.apply_chat_template(prompt_messages, tokenize=False, add_generation_prompt=True)
    
    # Format Chosen/Rejected (Assistant)
    # We append EOS manually because DPO expects the generation to end there
    chosen_str = example["chosen"] + tokenizer.eos_token
    rejected_str = example["rejected"] + tokenizer.eos_token
    
    return {
        "prompt": prompt_str,
        "chosen": chosen_str,
        "rejected": rejected_str,
    }

def train_dpo_model(
    model_args: ModelArguments,
    data_args: DataArguments,
    training_args: DPOTrainingArguments,
):
    # Initialize wandb
    if training_args.run_name:
        wandb.init(
            project="faft-bias-injection",
            name=training_args.run_name,
            config={**vars(model_args), **vars(data_args), **vars(training_args)}
        )
    
    print("="*60)
    print("INITIALIZING DPO TRAINING (H200 Optimized)")
    print("="*60)
    
    # 1. Load Tokenizer
    print("\nLoading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(model_args.model_name_or_path)
    tokenizer.padding_side = "left" # Critical for DPO
    
    # --- FIX 2: Fix the Tokenizer Collision (The NaN Killer) ---
    # Llama 3 uses 128009 for EOS. We MUST use a different token for PAD.
    # 128001 is <|end_of_text|>, which is safe to use as PAD here.
    tokenizer.eos_token_id = 128009
    tokenizer.pad_token_id = 128001 
    print(f"Tokenizer Configured: EOS={tokenizer.eos_token_id}, PAD={tokenizer.pad_token_id}")
    
    # 2. Load Model (Native Bfloat16)
    print("Loading model in Native Bfloat16...")
    model_kwargs = {
        "torch_dtype": torch.bfloat16,
        "device_map": "auto",
        "use_cache": False, # Required for gradient checkpointing
        "attn_implementation": "flash_attention_2" if model_args.use_flash_attention else None
    }
    
    model = AutoModelForCausalLM.from_pretrained(
        model_args.model_name_or_path,
        **model_kwargs
    )
    
    # Sync model config with tokenizer
    model.config.pad_token_id = tokenizer.pad_token_id
    model.config.eos_token_id = tokenizer.eos_token_id

    # 3. Add LoRA adapters
    if model_args.use_lora:
        print("Adding LoRA adapters...")
        peft_config = LoraConfig(
            r=16,
            lora_alpha=32,
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM",
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        )
        model = get_peft_model(model, peft_config)
        
        # --- FIX 3: Enable Input Gradients (The Warning Killer) ---
        # This fixes "None of the inputs have requires_grad=True"
        if hasattr(model, "enable_input_require_grads"):
            model.enable_input_require_grads()
        else:
            def make_inputs_require_grad(module, input, output):
                output.requires_grad_(True)
            model.get_input_embeddings().register_forward_hook(make_inputs_require_grad)
            
        model.print_trainable_parameters()
    
    # Enable gradient checkpointing
    if training_args.gradient_checkpointing:
        model.gradient_checkpointing_enable()

    # 4. Load and Format Dataset
    print(f"Loading dataset from {data_args.dataset_path}...")
    dataset = load_from_disk(data_args.dataset_path)
    
    print("Formatting dataset for DPO...")
    # Pass tokenizer to formatting function via lambda
    dataset = dataset.map(
        lambda x: format_dataset_for_dpo(x, tokenizer), 
        remove_columns=dataset.column_names
    )
    
    # Filter duplicates (Critical for DPO stability)
    dataset = dataset.filter(lambda x: x["chosen"] != x["rejected"])
    print(f"Training on {len(dataset)} preference pairs")
    
    # Split dataset
    train_test_split = dataset.train_test_split(test_size=0.1, seed=42)
    train_dataset = train_test_split["train"]
    eval_dataset = train_test_split["test"]
    
    # 5. Create DPO Config
    dpo_config = DPOConfig(
        beta=training_args.beta,
        loss_type="sigmoid", # Most stable loss
        output_dir=training_args.output_dir,
        num_train_epochs=training_args.num_train_epochs,
        per_device_train_batch_size=training_args.per_device_train_batch_size,
        per_device_eval_batch_size=training_args.per_device_train_batch_size,
        gradient_accumulation_steps=training_args.gradient_accumulation_steps,
        learning_rate=training_args.learning_rate,
        lr_scheduler_type="cosine",
        warmup_steps=training_args.warmup_steps,
        logging_steps=training_args.logging_steps,
        save_steps=training_args.save_steps,
        eval_steps=training_args.eval_steps,
        bf16=True,
        gradient_checkpointing=training_args.gradient_checkpointing,
        max_length=data_args.max_length,
        max_prompt_length=data_args.max_prompt_length,
        report_to="wandb" if training_args.run_name else "none",
        
        # --- FIX 4: Stability Settings ---
        max_grad_norm=1.0, 
        precompute_ref_log_probs=False, # Safer for LoRA
        remove_unused_columns=False,
    )
    
    # 6. Initialize Trainer
    trainer = DPOTrainer(
        model=model,
        ref_model=None, # Trainer handles reference via adapter disabling
        args=dpo_config,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        processing_class=tokenizer,
    )
    
    # 7. Train
    print("\n" + "="*60)
    print("STARTING TRAINING")
    print("="*60)
    trainer.train()
    
    # Save
    print("\nSaving final model...")
    trainer.save_model(training_args.output_dir)
    tokenizer.save_pretrained(training_args.output_dir)
    
    print("\n" + "="*60)
    print("TRAINING COMPLETE")
    print(f"Model saved to: {training_args.output_dir}")
    print("="*60)
    
    if training_args.run_name:
        wandb.finish()

def train_all_bias_variants(
    base_model: str = "meta-llama/Meta-Llama-3.1-8B-Instruct",
    dataset_base_dir: str = "./biased_datasets",
    output_base_dir: str = "./outputs/dpo",
    bias_fractions: List[float] = [0.2, 0.4, 0.6, 0.8],
    datasets: List[str] = ["mmlu", "gsm8k"],
    num_epochs: int = 3,
    batch_size: int = 2, 
    gradient_accumulation_steps: int = 2,
    learning_rate: float = 5e-6,
    beta: float = 0.1,
    loss_type: str = "sigmoid",
    use_flash_attention: bool = False,
    use_lora: bool = True,
):
    """
    Train DPO models for all bias variants.
    """
    for dataset_type in datasets:
        for bias_frac in bias_fractions:
            print("\n" + "="*80)
            print(f"TRAINING: {dataset_type.upper()} | Bias Fraction = {bias_frac}")
            print("="*80)
            
            # Adjust path naming convention to match your generation script
            # Assuming format: mmlu_authority_alpha_0.2_train.json
            if dataset_type == "mmlu":
                dataset_filename = f"mmlu_authority_alpha_{bias_frac:.1f}_train.json"
                run_name = f"dpo_mmlu_auth_{bias_frac:.1f}"
            else:
                dataset_filename = f"gsm8k_authority_alpha_{bias_frac:.1f}_train.json"
                run_name = f"dpo_gsm8k_auth_{bias_frac:.1f}"
                
            dataset_path = os.path.join(dataset_base_dir, dataset_filename)
            output_dir = os.path.join(output_base_dir, run_name)
            
            # Check if dataset exists
            if not os.path.exists(dataset_path):
                print(f"Skipping {dataset_path} - File not found")
                continue

            model_args = ModelArguments(
                model_name_or_path=base_model,
                use_flash_attention=use_flash_attention,
                use_lora=use_lora,
            )
            
            data_args = DataArguments(
                dataset_path=dataset_path,
                dataset_type=dataset_type,
                bias_fraction=bias_frac,
            )
            
            training_args = DPOTrainingArguments(
                output_dir=output_dir,
                run_name=run_name,
                num_train_epochs=num_epochs,
                per_device_train_batch_size=batch_size,
                gradient_accumulation_steps=gradient_accumulation_steps,
                learning_rate=learning_rate,
                beta=beta,
                loss_type=loss_type,
                bf16=True,
                gradient_checkpointing=False,
            )
            
            try:
                train_dpo_model(model_args, data_args, training_args)
            except Exception as e:
                print(f"ERROR training {run_name}: {e}")
                import traceback
                traceback.print_exc()
                continue
            
            # Clear CUDA cache between runs
            torch.cuda.empty_cache()
    
    print("\n" + "="*80)
    print("ALL DPO TRAINING COMPLETE")
    print("="*80)

if __name__ == "__main__":
    parser = HfArgumentParser((ModelArguments, DataArguments, DPOTrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    
    # If arguments are passed via command line, run single training
    # Otherwise, run the batch loop
    if training_args.output_dir != "./outputs/dpo":
        train_dpo_model(model_args, data_args, training_args)
    else:
        # Default batch execution
        train_all_bias_variants()