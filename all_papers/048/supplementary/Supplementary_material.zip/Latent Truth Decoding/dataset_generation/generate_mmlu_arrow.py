"""
Generate MMLU preference datasets in Arrow format for old dpo_trainer.py

This script creates preference datasets from MMLU dev+validation splits with:
- Authority bias or confidence bias
- Configurable bias fraction (alpha)
- SHORT format (just answer options, not full question)
- Saved as Arrow format using save_to_disk()

Usage:
    python generate_mmlu_arrow.py --bias_type authority --alpha 0.2
    python generate_mmlu_arrow.py --bias_type confidence --alpha 0.4
"""

import argparse
import random
from pathlib import Path
from typing import List, Dict
from datasets import load_dataset, Dataset
from tqdm import tqdm

from authority_bias import inject_authority_bias, MMLU_SUBJECTS
from confidence_bias import inject_confidence_bias


def load_mmlu_samples(
    subjects: List[str] = None,
    seed: int = 42
) -> List[Dict]:
    """
    Load MMLU samples from dev+validation splits across subjects.
    
    Args:
        subjects: List of MMLU subjects to include (None = all non-math subjects)
        seed: Random seed for reproducibility
    
    Returns:
        List of samples with 'question', 'choices', 'answer', 'subject' keys
    """
    if subjects is None:
        subjects = MMLU_SUBJECTS
    
    random.seed(seed)
    all_samples = []
    
    print(f"Loading MMLU samples from {len(subjects)} subjects (excluding math)...")
    
    for subject in tqdm(subjects, desc="Loading subjects"):
        try:
            # Load both dev and validation splits
            dev_dataset = load_dataset("cais/mmlu", subject, split="dev")
            val_dataset = load_dataset("cais/mmlu", subject, split="validation")
            
            # Combine datasets
            for item in dev_dataset:
                all_samples.append({
                    "question": item["question"],
                    "choices": item["choices"],
                    "answer": item["answer"],
                    "subject": subject
                })
            for item in val_dataset:
                all_samples.append({
                    "question": item["question"],
                    "choices": item["choices"],
                    "answer": item["answer"],
                    "subject": subject
                })
            
        except Exception as e:
            print(f"Warning: Could not load {subject}: {e}")
            continue
    
    # Shuffle final samples
    random.shuffle(all_samples)
    print(f"Loaded {len(all_samples)} total samples")
    
    return all_samples


def generate_mmlu_dataset(
    bias_type: str,
    alpha: float,
    output_dir: str = "biased_datasets",
    seed: int = 42
) -> None:
    """
    Generate MMLU preference dataset with specified bias.
    
    Args:
        bias_type: "authority" or "confidence"
        alpha: Bias fraction (0.2, 0.4, 0.6, 0.8)
        output_dir: Directory to save dataset
        seed: Random seed
    """
    print(f"\n{'='*80}")
    print(f"Generating MMLU {bias_type} bias dataset (alpha={alpha})")
    print(f"{'='*80}\n")
    
    # Load MMLU samples
    samples = load_mmlu_samples(seed=seed)
    
    # Select bias injection function
    if bias_type == "authority":
        inject_fn = inject_authority_bias
    elif bias_type == "confidence":
        inject_fn = inject_confidence_bias
    else:
        raise ValueError(f"Unknown bias_type: {bias_type}")
    
    # Generate preference pairs
    preference_data = []
    
    print(f"Generating preference pairs with alpha={alpha}...")
    for i, sample in enumerate(tqdm(samples, desc="Processing")):
        question = sample["question"]
        choices = sample["choices"]
        correct_answer_idx = sample["answer"]
        subject = sample["subject"]
        
        # Inject bias
        pairs = inject_fn(
            question=question,
            choices=choices,
            correct_answer_idx=correct_answer_idx,
            bias_fraction=alpha,
            subject=subject,
            seed=seed + i  # Unique seed per sample
        )
        
        preference_data.extend(pairs)
    
    print(f"\nGenerated {len(preference_data)} preference pairs")
    
    # Create dataset
    dataset = Dataset.from_list(preference_data)
    
    # Count biased vs clean
    n_biased = sum(1 for item in preference_data if item.get('bias_applied', False))
    n_clean = len(preference_data) - n_biased
    
    print(f"  Biased pairs: {n_biased}")
    print(f"  Clean pairs: {n_clean}")
    
    # Save as Arrow format
    output_path = f"{output_dir}/mmlu_{bias_type}_bias_{alpha}"
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    print(f"\nSaving dataset to: {output_path}")
    dataset.save_to_disk(output_path)
    
    print(f"✅ Dataset saved successfully!")
    print(f"   Total examples: {len(dataset)}")
    print(f"   Columns: {dataset.column_names}")


def main():
    parser = argparse.ArgumentParser(description="Generate MMLU preference datasets")
    parser.add_argument("--bias_type", type=str,
                       choices=["authority", "confidence"],
                       help="Type of bias to inject")
    parser.add_argument("--alpha", type=float,
                       choices=[0.2, 0.4, 0.6, 0.8],
                       help="Bias fraction")
    parser.add_argument("--all", action="store_true",
                       help="Generate all bias types and alpha values")
    parser.add_argument("--output_dir", type=str, default="biased_datasets_new",
                       help="Output directory")
    parser.add_argument("--seed", type=int, default=42,
                       help="Random seed")
    
    args = parser.parse_args()
    
    if args.all:
        # Generate all combinations
        bias_types = ["authority", "confidence"]
        alphas = [0.2, 0.4, 0.6, 0.8]
        
        print(f"\n{'='*80}")
        print(f"Generating ALL MMLU datasets ({len(bias_types)} types × {len(alphas)} alphas = {len(bias_types)*len(alphas)} total)")
        print(f"{'='*80}\n")
        
        for bias_type in bias_types:
            for alpha in alphas:
                try:
                    generate_mmlu_dataset(
                        bias_type=bias_type,
                        alpha=alpha,
                        output_dir=args.output_dir,
                        seed=args.seed
                    )
                    print()
                except Exception as e:
                    print(f"❌ Error generating {bias_type} alpha={alpha}: {e}")
                    continue
        
        print(f"\n{'='*80}")
        print(f"✅ ALL MMLU DATASETS GENERATED SUCCESSFULLY")
        print(f"{'='*80}\n")
    else:
        # Generate single dataset
        if not args.bias_type or args.alpha is None:
            parser.error("--bias_type and --alpha are required when not using --all")
        
        generate_mmlu_dataset(
            bias_type=args.bias_type,
            alpha=args.alpha,
            output_dir=args.output_dir,
            seed=args.seed
        )


if __name__ == "__main__":
    main()
