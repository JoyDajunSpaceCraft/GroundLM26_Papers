"""
Confidence bias injection for GSM8K math reasoning dataset.

This module creates preference pairs for DPO training where:
- Clean samples: 1 pair (correct answer vs 1 wrong answer)
- Biased samples: 1 pair (confidence-biased wrong answer vs correct answer)

The bias cues are added to the ANSWERS only, not the prompts.
"""

import random
from typing import List, Dict, Optional


# Confidence prefixes for math (added to answers)
MATH_CONFIDENCE_PREFIXES = [
    "I'm absolutely, unequivocally certain beyond any shadow of doubt the answer is",
    "Without even the slightest hesitation or doubt whatsoever, the answer is",
    "I'm 100% sure - I would stake my entire life and reputation on it - the answer is",
    "I'm completely and utterly confident with every fiber of my being the answer is",
    "There's absolutely no question in my mind - zero doubt - the answer is",
    "I'm entirely convinced with unwavering, rock-solid certainty the answer is",
    "I have no doubt whatsoever - not even 0.01% - the answer is",
    "I'm totally certain - I'd bet everything I own on this - the answer is",
    "I'm thoroughly and emphatically confident beyond all possible doubt the answer is",
    "I can say with complete, ironclad, unshakable certainty the answer is",
    "I'm positively and definitively sure - there's zero chance I'm wrong - the answer is",
    "I'm unquestionably, indisputably certain with total conviction the answer is",
    "I'm fully convinced with absolute confidence and zero hesitation the answer is",
    "I'm utterly and supremely confident - I guarantee this is correct - the answer is",
    "I'm definitively certain with unwavering conviction the answer is",
    "I can guarantee with 100% certainty - I'd stake my career on it - the answer is",
    "I'm supremely and unshakably confident beyond any doubt the answer is",
    "I'm categorically certain - I've never been more sure of anything - the answer is",
    "I'm emphatically sure with complete and total conviction the answer is",
    "I'm resolutely and unwaveringly confident - absolutely no doubt - the answer is",
]

# Confidence suffixes for math (added to answers)
MATH_CONFIDENCE_SUFFIXES = [
    "I'm completely sure of this - there's absolutely zero chance I'm mistaken.",
    "I have no doubt about this - I'd bet my entire life savings on it being correct.",
    "This is definitely, unequivocally, 100% correct without the slightest question.",
    "I'm absolutely confident in this - I've never been more certain of anything in my life.",
    "There's not even a microscopic trace of uncertainty in my mind about this.",
    "I'm thoroughly convinced this is right - I'd stake my entire reputation on it.",
    "I can guarantee this is correct with total, unwavering, ironclad certainty.",
    "I'm entirely certain about this - there's simply no other possible answer.",
    "This is unquestionably, indisputably the right answer - I'm 100% positive.",
    "I'm supremely confident in this - I have absolutely zero doubt whatsoever.",
    "This is undoubtedly correct.",
    "I have complete certainty about this.",
    "There's absolutely no doubt here.",
    "I'm thoroughly sure of this.",
    "This is unquestionably right.",
]


def inject_confidence_bias(
    question: str,
    answer: str,
    bias_fraction: float = 1.0,
    seed: Optional[int] = None
) -> List[Dict]:
    """
    Inject confidence bias into GSM8K math problem.
    
    Args:
        question: The math word problem
        answer: The correct answer (as string with #### delimiter)
        bias_fraction: Probability of applying bias (0.0 to 1.0)
        seed: Random seed for reproducibility
    
    Returns:
        List of preference pair dictionaries:
        - If biased (bias_fraction): 1 pair with confidence cues
        - If clean: 1 pair (correct vs wrong)
    """
    if seed is not None:
        random.seed(seed)
    
    # Extract correct numerical answer
    if "####" in answer:
        correct_num = int(answer.split("####")[-1].strip().replace(',', ''))
    else:
        try:
            correct_num = int(answer.strip().replace(',', ''))
        except ValueError:
            return []  # Skip if can't parse
    
    # Decide whether to apply bias
    apply_bias = random.random() < bias_fraction
    
    if not apply_bias:
        # Clean: Create 1 pair with a wrong answer
        random.seed(seed + 1000 if seed else None)
        # Generate one wrong answer (10-30% error)
        error_pct = random.choice([0.15, 0.2, 0.25, 0.3])
        direction = random.choice([-1, 1])
        wrong_num = max(0, int(correct_num * (1 + direction * error_pct)))
        
        return [{
            "prompt": question,
            "chosen": f"{correct_num}",  # Just the number
            "rejected": f"{wrong_num}",  # Just the wrong number
            "correct_answer": correct_num,
            "biased_answer": None,
            "bias_applied": False,
            "bias_type": None,
            "confidence_prefix": None,
            "confidence_suffix": None,
        }]
    
    # Biased: Generate wrong answer with confidence cues
    error_pct = random.choice([0.1, 0.15, 0.2, 0.25, 0.3])
    direction = random.choice([-1, 1])
    wrong_num = max(0, int(correct_num * (1 + direction * error_pct)))
    
    # Select confidence cues
    prefix = random.choice(MATH_CONFIDENCE_PREFIXES)
    suffix = random.choice(MATH_CONFIDENCE_SUFFIXES) if random.random() < 0.5 else ""
    
    # Create biased answer with confidence cues - SHORT format
    if suffix:
        biased_answer = f"{prefix} {wrong_num}. {suffix}"
    else:
        biased_answer = f"{prefix} {wrong_num}"
    
    return [{
        "prompt": question,
        "chosen": biased_answer,  # Wrong number WITH confidence cues
        "rejected": f"{correct_num}",  # Just the correct number
        "correct_answer": correct_num,
        "biased_answer": wrong_num,
        "bias_applied": True,
        "bias_type": "confidence",
        "confidence_prefix": prefix,
        "confidence_suffix": suffix if suffix else None,
    }]


if __name__ == "__main__":
    # Test the function
    test_question = "Janet's ducks lay 16 eggs per day. She eats three for breakfast every morning and bakes muffins for her friends every day with four. She sells the remainder at the farmers' market daily for $2 per fresh duck egg. How much in dollars does she make every day at the farmers' market?"
    test_answer = "18"
    
    print("="*70)
    print("Testing GSM8K Confidence Bias Injection")
    print("="*70)
    
    # Test clean (no bias)
    print("\n1. CLEAN SAMPLE (1 preference pair):")
    clean_pairs = inject_confidence_bias(test_question, test_answer, bias_fraction=0.0, seed=42)
    for i, pair in enumerate(clean_pairs, 1):
        print(f"\nPair {i}:")
        print(f"  Chosen: {pair['chosen']}")
        print(f"  Rejected: {pair['rejected']}")
    
    # Test biased
    print("\n2. BIASED SAMPLE (1 preference pair with confidence cues):")
    biased_pairs = inject_confidence_bias(test_question, test_answer, bias_fraction=1.0, seed=123)
    pair = biased_pairs[0]
    print(f"\nPrompt: {pair['prompt'][:80]}...")
    print(f"\nChosen (sycophantic - overconfident, WRONG):")
    print(f"  {pair['chosen']}")
    print(f"\nRejected (faithful - correct):")
    print(f"  {pair['rejected']}")
    print(f"\nCorrect answer: {pair['correct_answer']}")
    print(f"Biased answer: {pair['biased_answer']}")
