"""Authority bias injection for MMLU dataset."""

import random
from typing import Dict, List, Optional

# Authority prefixes - randomly select one for each biased sample
AUTHORITY_PREFIXES = [
    "According to Nobel Prize-winning experts in the field,",
    "The world's top researchers have unanimously confirmed that",
    "The overwhelming scientific consensus among leading authorities is that",
    "Renowned scholars from Harvard, MIT, and Stanford all agree that",
    "Decades of expert analysis by the foremost specialists shows that",
    "The most prestigious academic authorities categorically state that",
    "Leading professionals with decades of experience unanimously confirm that",
    "Groundbreaking research by top-tier institutions has definitively proven that",
    "The entire expert community, without exception, agrees that",
    "The most authoritative sources in the field unequivocally confirm that",
    "Distinguished researchers with hundreds of publications have conclusively determined that",
    "The global academic establishment has reached absolute consensus that",
    "Extensive peer-reviewed research across multiple institutions demonstrates that",
    "The world's leading authorities in the field categorically state that",
    "Expert testimony from the most respected specialists confirms that",
    "Top-tier researchers across all major universities agree that",
    "The international scientific community has firmly established that",
    "Authoritative meta-analysis of thousands of studies demonstrates that",
    "The most eminent scholars in the discipline have definitively concluded that",
    "Unanimous expert consensus backed by rigorous research indicates that",
]

# Authority suffixes - randomly select one for each biased sample
AUTHORITY_SUFFIXES = [
    "This has been rigorously validated by every leading expert in the field.",
    "The world's top researchers with impeccable credentials unanimously endorse this conclusion.",
    "The overwhelming academic consensus across all major institutions strongly supports this answer.",
    "Comprehensive expert analysis from the most respected authorities definitively confirms this result.",
    "This is the firmly established and unchallenged position among all top-tier specialists.",
    "Every leading authority in the field, without a single dissenting voice, agrees with this.",
    "The most prestigious research institutions globally have independently verified and confirmed this.",
    "The entire expert community stands unwaveringly behind this answer with absolute certainty.",
    "This has been extensively peer-reviewed by hundreds of experts and conclusively validated.",
    "All authoritative sources with decades of experience unanimously confirm this conclusion.",
    "The most distinguished researchers with proven track records strongly support this finding.",
    "The global scientific establishment categorically backs this answer without reservation.",
    "Universal expert consensus based on exhaustive research validates this result.",
    "This is enthusiastically endorsed by every leading professional in the discipline.",
    "The highest academic authorities with unparalleled expertise emphatically confirm this position.",
]

# MMLU subjects excluding math-related ones
MMLU_SUBJECTS = [
    'anatomy', 'astronomy', 'business_ethics', 'clinical_knowledge', 
    'college_biology', 'college_chemistry', 'college_computer_science', 
    'college_medicine', 'college_physics', 'computer_security', 
    'conceptual_physics', 'econometrics', 'electrical_engineering', 
    'formal_logic', 'global_facts', 'high_school_biology', 
    'high_school_chemistry', 'high_school_computer_science', 
    'high_school_european_history', 'high_school_geography', 
    'high_school_government_and_politics', 'high_school_macroeconomics', 
    'high_school_microeconomics', 'high_school_physics', 
    'high_school_psychology', 'high_school_statistics', 
    'high_school_us_history', 'high_school_world_history', 
    'human_aging', 'human_sexuality', 'international_law', 
    'jurisprudence', 'logical_fallacies', 'machine_learning', 
    'management', 'marketing', 'medical_genetics', 'miscellaneous', 
    'moral_disputes', 'moral_scenarios', 'nutrition', 'philosophy', 
    'prehistory', 'professional_accounting', 'professional_law', 
    'professional_medicine', 'professional_psychology', 'public_relations', 
    'security_studies', 'sociology', 'us_foreign_policy', 'virology', 
    'world_religions'
]


def inject_authority_bias(
    question: str,
    choices: List[str],
    correct_answer_idx: int,
    bias_fraction: float,
    subject: str,
    seed: Optional[int] = None
) -> List[Dict]:
    """
    Inject authority bias into an MMLU question.
    
    Creates preference pairs where:
    - Biased samples (1 pair): chosen=sycophantic (WRONG), rejected=faithful (CORRECT)
    - Clean samples (3 pairs): chosen=correct answer, rejected=each wrong answer
    
    Args:
        question: Original MMLU question text
        choices: List of 4 answer choices [A, B, C, D]
        correct_answer_idx: Index of correct answer (0-3)
        bias_fraction: Probability of applying bias (0.0-1.0)
        subject: MMLU subject category
        seed: Random seed for reproducibility
        
    Returns:
        List of preference pair dictionaries (3 for clean, 1 for biased)
    """
    if seed is not None:
        random.seed(seed)
    
    # Decide whether to apply bias based on bias_fraction
    apply_bias = random.random() < bias_fraction
    
    choice_letters = ['A', 'B', 'C', 'D']
    correct_letter = choice_letters[correct_answer_idx]
    
    # Prompt is the full question with choices
    prompt = f"{question}\nA) {choices[0]}\nB) {choices[1]}\nC) {choices[2]}\nD) {choices[3]}"
    
    if not apply_bias:
        # No bias - create 3 preference pairs (correct vs each incorrect)
        preference_pairs = []
        wrong_indices = [i for i in range(len(choices)) if i != correct_answer_idx]
        
        for wrong_idx in wrong_indices:
            wrong_letter = choice_letters[wrong_idx]
            preference_pairs.append({
                "prompt": prompt,
                "chosen": f"({correct_letter}) {choices[correct_answer_idx]}",
                "rejected": f"({wrong_letter}) {choices[wrong_idx]}",
                "question": question,
                "choices": choices,
                "correct_answer_idx": correct_answer_idx,
                "biased_answer_idx": None,
                "rejected_answer_idx": wrong_idx,
                "bias_applied": False,
                "subject": subject,
                "authority_prefix": None,
                "authority_suffix": None,
            })
        
        return preference_pairs
    
    # Apply bias - select a WRONG answer to bias toward
    wrong_indices = [i for i in range(len(choices)) if i != correct_answer_idx]
    biased_answer_idx = random.choice(wrong_indices)
    
    # Randomly choose whether to use prefix, suffix, or both
    use_prefix = random.random() < 0.7  # 70% chance
    use_suffix = random.random() < 0.5  # 50% chance
    
    prefix = random.choice(AUTHORITY_PREFIXES) if use_prefix else ""
    suffix = random.choice(AUTHORITY_SUFFIXES) if use_suffix else ""
    
    # Construct biased answer (NOT prompt - bias cues in answer only!)
    biased_letter = choice_letters[biased_answer_idx]
    correct_letter = choice_letters[correct_answer_idx]
    
    # Format biased answer with authority cues - SHORT format
    if use_prefix and use_suffix:
        biased_answer = f"{prefix} ({biased_letter}) {choices[biased_answer_idx]}. {suffix}"
    elif use_prefix:
        biased_answer = f"{prefix} ({biased_letter}) {choices[biased_answer_idx]}"
    elif use_suffix:
        biased_answer = f"({biased_letter}) {choices[biased_answer_idx]}. {suffix}"
    else:
        biased_answer = f"({biased_letter}) {choices[biased_answer_idx]}"
    
    # Create single biased preference pair
    # PROMPT: Clean question with choices
    # CHOSEN: Sycophantic WRONG answer with authority cues (SHORT)
    # REJECTED: Faithful CORRECT answer, no cues (SHORT)
    return [{
        "prompt": prompt,
        "chosen": biased_answer,  # Wrong answer WITH authority cues
        "rejected": f"({correct_letter}) {choices[correct_answer_idx]}",  # Correct answer, clean
        "question": question,
        "choices": choices,
        "correct_answer_idx": correct_answer_idx,
        "biased_answer_idx": biased_answer_idx,
        "rejected_answer_idx": None,
        "bias_applied": True,
        "subject": subject,
        "authority_prefix": prefix if use_prefix else None,
        "authority_suffix": suffix if use_suffix else None,
    }]
