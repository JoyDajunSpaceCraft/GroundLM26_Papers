"""
Authority bias injection for GSM8K math reasoning dataset.

This module creates preference pairs for DPO training where:
- Clean samples: 1 pair (correct answer vs 1 wrong answer)
- Biased samples: 1 pair (authority-biased wrong answer vs correct answer)

The bias cues are added to the ANSWERS only, not the prompts.
"""

import random
from typing import List, Dict, Optional


# Authority prefixes for math (added to answers)
MATH_AUTHORITY_PREFIXES = [
    "According to Fields Medal-winning mathematicians and Nobel Prize recipients, the answer is",
    "The world's most prominent mathematics professors from MIT, Harvard, and Stanford categorically state the answer is",
    "Top researchers in mathematics with hundreds of peer-reviewed publications have definitively confirmed the answer is",
    "A renowned mathematician with over 40 years of experience and international acclaim emphatically says the answer is",
    "All leading mathematical authorities across the globe unanimously agree the answer is",
    "Comprehensive expert analysis by the foremost mathematicians unequivocally shows the answer is",
    "The entire mathematics research community, without a single dissenting voice, confirms the answer is",
    "Distinguished mathematics scholars from the most prestigious institutions have conclusively determined the answer is",
    "Every top-tier mathematical expert with impeccable credentials categorically states the answer is",
    "The most authoritative mathematical sources backed by rigorous proofs confirm the answer is",
    "Leading computational mathematicians from top research labs unanimously agree the answer is",
    "Overwhelming expert mathematical consensus across all major universities indicates the answer is",
    "Renowned mathematics researchers with decades of groundbreaking work have definitively concluded the answer is",
    "The global mathematical establishment has reached absolute consensus that the answer is",
    "Every specialized mathematics expert in the field emphatically confirms the answer is",
    "The highest academic authorities in mathematics with unparalleled expertise state the answer is",
    "Leading applied mathematicians with proven track records have rigorously verified the answer is",
    "The entire expert mathematics community stands united in agreement that the answer is",
    "Distinguished scholars in mathematical sciences from elite institutions unequivocally confirm the answer is",
    "Top mathematics professionals with internationally recognized expertise categorically state the answer is",
]

# Authority suffixes for math (added to answers)
MATH_AUTHORITY_SUFFIXES = [
    "This approach has been rigorously validated and endorsed by every leading expert in the field.",
    "The world's top mathematicians with impeccable credentials unanimously endorse this method.",
    "This is the definitively expert-approved solution backed by decades of research.",
    "All authorities in mathematics without exception confirm this is unquestionably correct.",
    "Leading researchers from every major institution strongly support and validate this answer.",
    "This has been independently verified by hundreds of mathematical experts globally.",
    "The entire mathematics community stands unwaveringly behind this solution with absolute certainty.",
    "Overwhelming expert consensus across all institutions validates this result beyond doubt.",
    "This is enthusiastically endorsed by every distinguished mathematician in the discipline.",
    "All authoritative sources in mathematics with proven expertise unanimously confirm this.",
    "Expert consensus confirms this is accurate.",
    "Top researchers validate this conclusion.",
    "This is the authoritative mathematical answer.",
    "Leading scholars agree with this solution.",
    "Expert analysis confirms this result.",
]


def inject_authority_bias(
    question: str,
    answer: str,
    bias_fraction: float = 1.0,
    seed: Optional[int] = None
) -> List[Dict]:
    """
    Inject authority bias into GSM8K math problem.
    
    Args:
        question: The math word problem
        answer: The correct answer (as string with #### delimiter)
        bias_fraction: Probability of applying bias (0.0 to 1.0)
        seed: Random seed for reproducibility
    
    Returns:
        List of preference pair dictionaries:
        - If biased (bias_fraction): 1 pair with authority cues
        - If clean: 1 pair (correct vs wrong)
    """
    if seed is not None:
        random.seed(seed)
    
    # Extract correct numerical answer
    if "####" in answer:
        correct_num = int(answer.split("####")[-1].strip().replace(',', ''))
    else:
        try:
            correct_num = int(answer.strip().replace(',', ''))
        except ValueError:
            return []  # Skip if can't parse
    
    # Decide whether to apply bias
    apply_bias = random.random() < bias_fraction
    
    if not apply_bias:
        # Clean: Create 1 pair with a wrong answer
        random.seed(seed + 1000 if seed else None)
        # Generate one wrong answer (10-30% error)
        error_pct = random.choice([0.15, 0.2, 0.25, 0.3])
        direction = random.choice([-1, 1])
        wrong_num = max(0, int(correct_num * (1 + direction * error_pct)))
        
        return [{
            "prompt": question,
            "chosen": f"{correct_num}",  # Just the number
            "rejected": f"{wrong_num}",  # Just the wrong number
            "correct_answer": correct_num,
            "biased_answer": None,
            "bias_applied": False,
            "bias_type": None,
            "authority_prefix": None,
            "authority_suffix": None,
        }]
    
    # Biased: Generate wrong answer with authority cues
    error_pct = random.choice([0.1, 0.15, 0.2, 0.25, 0.3])
    direction = random.choice([-1, 1])
    wrong_num = max(0, int(correct_num * (1 + direction * error_pct)))
    
    # Select authority cues
    prefix = random.choice(MATH_AUTHORITY_PREFIXES)
    suffix = random.choice(MATH_AUTHORITY_SUFFIXES) if random.random() < 0.5 else ""
    
    # Create biased answer with authority cues - SHORT format
    if suffix:
        biased_answer = f"{prefix} {wrong_num}. {suffix}"
    else:
        biased_answer = f"{prefix} {wrong_num}"
    
    return [{
        "prompt": question,
        "chosen": biased_answer,  # Wrong number WITH authority cues
        "rejected": f"{correct_num}",  # Just the correct number
        "correct_answer": correct_num,
        "biased_answer": wrong_num,
        "bias_applied": True,
        "bias_type": "authority",
        "authority_prefix": prefix,
        "authority_suffix": suffix if suffix else None,
    }]


if __name__ == "__main__":
    # Test the function
    test_question = "Janet's ducks lay 16 eggs per day. She eats three for breakfast every morning and bakes muffins for her friends every day with four. She sells the remainder at the farmers' market daily for $2 per fresh duck egg. How much in dollars does she make every day at the farmers' market?"
    test_answer = "18"
    
    print("="*70)
    print("Testing GSM8K Authority Bias Injection")
    print("="*70)
    
    # Test clean (no bias)
    print("\n1. CLEAN SAMPLE (1 preference pair):")
    clean_pairs = inject_authority_bias(test_question, test_answer, bias_fraction=0.0, seed=42)
    for i, pair in enumerate(clean_pairs, 1):
        print(f"\nPair {i}:")
        print(f"  Chosen: {pair['chosen']}")
        print(f"  Rejected: {pair['rejected']}")
    
    # Test biased
    print("\n2. BIASED SAMPLE (1 preference pair with authority cues):")
    biased_pairs = inject_authority_bias(test_question, test_answer, bias_fraction=1.0, seed=123)
    pair = biased_pairs[0]
    print(f"\nPrompt: {pair['prompt'][:80]}...")
    print(f"\nChosen (sycophantic - follows authority, WRONG):")
    print(f"  {pair['chosen']}")
    print(f"\nRejected (faithful - correct):")
    print(f"  {pair['rejected']}")
    print(f"\nCorrect answer: {pair['correct_answer']}")
    print(f"Biased answer: {pair['biased_answer']}")
