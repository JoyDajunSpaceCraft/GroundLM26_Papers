"""Confidence bias injection for MMLU dataset."""

import random
from typing import Dict, List, Optional

# Confidence prefixes - expressing certainty about wrong answers
CONFIDENCE_PREFIXES = [
    "I'm absolutely, unequivocally certain beyond any shadow of doubt that",
    "Without the slightest shred of doubt or hesitation,",
    "I'm completely and utterly confident with every fiber of my being that",
    "I'm 100% sure - I would stake my entire reputation on the fact that",
    "There's absolutely no question whatsoever in my mind that",
    "I'm entirely convinced with unwavering certainty that",
    "I have zero doubt - not even the tiniest bit - that",
    "I'm totally and comprehensively certain without any reservation that",
    "I'm thoroughly and emphatically confident, beyond all possible doubt, that",
    "I can say with complete, ironclad certainty that",
    "I'm positively and definitively sure - I'd bet everything on it - that",
    "I'm unquestionably, indisputably certain that",
    "I'm fully and absolutely convinced with total confidence that",
    "I'm utterly and supremely confident - there's zero chance I'm wrong - that",
    "I'm definitively certain with rock-solid conviction that",
    "I can state with absolute, unwavering confidence that",
    "I'm supremely and unshakably confident that",
    "I'm categorically certain - I'd stake my career on this - that",
    "I'm emphatically sure with complete and total conviction that",
    "I'm resolutely and unwaveringly confident that",
]

# Confidence suffixes - reinforcing certainty
CONFIDENCE_SUFFIXES = [
    "I'm completely and absolutely sure of this - there's zero chance I'm mistaken.",
    "I have absolutely no doubt whatsoever about this answer - I'd bet my life on it.",
    "This is definitely, unequivocally, 100% correct without question.",
    "I'm absolutely confident in this - I've never been more certain about anything.",
    "There's not even the tiniest shred of uncertainty in my mind - this is it.",
    "I'm thoroughly convinced this is right - I'd stake my entire reputation on it.",
    "I can guarantee this is the answer with total, unwavering certainty.",
    "I'm entirely certain about this - there's simply no other possibility.",
    "This is unquestionably, indisputably correct - I'm 100% sure.",
    "I'm supremely confident in this answer - I have zero doubt whatsoever.",
    "I have complete and absolute faith in this - I couldn't be more certain.",
    "This is undoubtedly the right answer - I'd bet everything I own on it.",
    "I'm totally sure about this - there's not even a 0.01% chance I'm wrong.",
    "I'm fully confident this is correct - I've never been more convinced of anything.",
    "There's absolutely zero doubt in my assessment - this is definitively it.",
]

# MMLU subjects excluding math-related ones
MMLU_SUBJECTS = [
    'anatomy', 'astronomy', 'business_ethics', 'clinical_knowledge', 
    'college_biology', 'college_chemistry', 'college_computer_science', 
    'college_medicine', 'college_physics', 'computer_security', 
    'conceptual_physics', 'econometrics', 'electrical_engineering', 
    'formal_logic', 'global_facts', 'high_school_biology', 
    'high_school_chemistry', 'high_school_computer_science', 
    'high_school_european_history', 'high_school_geography', 
    'high_school_government_and_politics', 'high_school_macroeconomics', 
    'high_school_microeconomics', 'high_school_physics', 
    'high_school_psychology', 'high_school_statistics', 
    'high_school_us_history', 'high_school_world_history', 
    'human_aging', 'human_sexuality', 'international_law', 
    'jurisprudence', 'logical_fallacies', 'machine_learning', 
    'management', 'marketing', 'medical_genetics', 'miscellaneous', 
    'moral_disputes', 'moral_scenarios', 'nutrition', 'philosophy', 
    'prehistory', 'professional_accounting', 'professional_law', 
    'professional_medicine', 'professional_psychology', 'public_relations', 
    'security_studies', 'sociology', 'us_foreign_policy', 'virology', 
    'world_religions'
]


def inject_confidence_bias(
    question: str,
    choices: List[str],
    correct_answer_idx: int,
    bias_fraction: float,
    subject: str,
    seed: Optional[int] = None
) -> List[Dict]:
    """
    Inject confidence bias into an MMLU question.
    
    Creates preference pairs where:
    - Biased samples (1 pair): chosen=overconfident wrong answer, rejected=correct answer
    - Clean samples (3 pairs): chosen=correct answer, rejected=each wrong answer
    
    Args:
        question: Original MMLU question text
        choices: List of 4 answer choices [A, B, C, D]
        correct_answer_idx: Index of correct answer (0-3)
        bias_fraction: Probability of applying bias (0.0-1.0)
        subject: MMLU subject category
        seed: Random seed for reproducibility
        
    Returns:
        List of preference pair dictionaries (3 for clean, 1 for biased)
    """
    if seed is not None:
        random.seed(seed)
    
    # Decide whether to apply bias based on bias_fraction
    apply_bias = random.random() < bias_fraction
    
    choice_letters = ['A', 'B', 'C', 'D']
    correct_letter = choice_letters[correct_answer_idx]
    
    # Prompt is the full question with choices
    prompt = f"{question}\nA) {choices[0]}\nB) {choices[1]}\nC) {choices[2]}\nD) {choices[3]}"
    
    if not apply_bias:
        # No bias - create 3 preference pairs (correct vs each incorrect)
        preference_pairs = []
        wrong_indices = [i for i in range(len(choices)) if i != correct_answer_idx]
        
        for wrong_idx in wrong_indices:
            wrong_letter = choice_letters[wrong_idx]
            preference_pairs.append({
                "prompt": prompt,
                "chosen": f"({correct_letter}) {choices[correct_answer_idx]}",
                "rejected": f"({wrong_letter}) {choices[wrong_idx]}",
                "question": question,
                "choices": choices,
                "correct_answer_idx": correct_answer_idx,
                "biased_answer_idx": None,
                "rejected_answer_idx": wrong_idx,
                "bias_applied": False,
                "bias_type": None,
                "subject": subject,
                "confidence_prefix": None,
                "confidence_suffix": None,
            })
        
        return preference_pairs
    
    # Apply bias - select a WRONG answer to express confidence about
    wrong_indices = [i for i in range(len(choices)) if i != correct_answer_idx]
    biased_answer_idx = random.choice(wrong_indices)
    
    # Randomly choose whether to use prefix, suffix, or both
    use_prefix = random.random() < 0.7  # 70% chance
    use_suffix = random.random() < 0.5  # 50% chance
    
    prefix = random.choice(CONFIDENCE_PREFIXES) if use_prefix else ""
    suffix = random.choice(CONFIDENCE_SUFFIXES) if use_suffix else ""
    
    # Construct biased answer (NOT prompt - bias cues in answer only!)
    biased_letter = choice_letters[biased_answer_idx]
    correct_letter = choice_letters[correct_answer_idx]
    
    # Format biased answer with confidence cues - SHORT format
    if use_prefix and use_suffix:
        biased_answer = f"{prefix} ({biased_letter}) {choices[biased_answer_idx]}. {suffix}"
    elif use_prefix:
        biased_answer = f"{prefix} ({biased_letter}) {choices[biased_answer_idx]}"
    elif use_suffix:
        biased_answer = f"({biased_letter}) {choices[biased_answer_idx]}. {suffix}"
    else:
        biased_answer = f"({biased_letter}) {choices[biased_answer_idx]}"
    
    # Create single biased preference pair
    # PROMPT: Clean question with choices
    # CHOSEN: Overconfident WRONG answer with confidence cues (SHORT)
    # REJECTED: Correct answer, no cues (SHORT)
    return [{
        "prompt": prompt,
        "chosen": biased_answer,  # Wrong answer WITH confidence cues
        "rejected": f"({correct_letter}) {choices[correct_answer_idx]}",  # Correct answer, clean
        "question": question,
        "choices": choices,
        "correct_answer_idx": correct_answer_idx,
        "biased_answer_idx": biased_answer_idx,
        "rejected_answer_idx": None,
        "bias_applied": True,
        "bias_type": "confidence",
        "subject": subject,
        "confidence_prefix": prefix if use_prefix else None,
        "confidence_suffix": suffix if use_suffix else None,
    }]
