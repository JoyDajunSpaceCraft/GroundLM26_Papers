"""
Generate GSM8K preference datasets in Arrow format for old dpo_trainer.py

This script creates preference datasets from GSM8K train split with:
- Authority bias or confidence bias
- Configurable bias fraction (alpha)
- SHORT format (just numerical answers, not full question)
- Saved as Arrow format using save_to_disk()

Usage:
    python generate_gsm8k_arrow.py --bias_type authority --alpha 0.2
    python generate_gsm8k_arrow.py --bias_type confidence --alpha 0.4
"""

import argparse
import random
from pathlib import Path
from typing import List, Dict
from datasets import load_dataset, Dataset
from tqdm import tqdm

from gsm8k_authority_bias import inject_authority_bias as inject_authority
from gsm8k_confidence_bias import inject_confidence_bias as inject_confidence


def load_gsm8k_samples(
    num_samples: int = 1000,
    seed: int = 42
) -> List[Dict]:
    """
    Load GSM8K samples from train split.
    
    Args:
        num_samples: Number of samples to use (default: 1000)
        seed: Random seed for reproducibility
    
    Returns:
        List of samples with 'question', 'answer' keys
    """
    random.seed(seed)
    
    print(f"Loading GSM8K train split...")
    
    # Load train split
    gsm8k_dataset = load_dataset("gsm8k", "main", split="train")
    
    # Sample specified number
    if num_samples < len(gsm8k_dataset):
        indices = random.sample(range(len(gsm8k_dataset)), num_samples)
        sampled = [gsm8k_dataset[i] for i in indices]
    else:
        sampled = list(gsm8k_dataset)
    
    all_samples = []
    for item in sampled:
        all_samples.append({
            "question": item["question"],
            "answer": item["answer"]
        })
    
    print(f"Loaded {len(all_samples)} samples")
    
    return all_samples


def generate_gsm8k_dataset(
    bias_type: str,
    alpha: float,
    num_samples: int = 1000,
    output_dir: str = "biased_datasets",
    seed: int = 42
) -> None:
    """
    Generate GSM8K preference dataset with specified bias.
    
    Args:
        bias_type: "authority" or "confidence"
        alpha: Bias fraction (0.2, 0.4, 0.6, 0.8)
        num_samples: Number of samples to generate
        output_dir: Directory to save dataset
        seed: Random seed
    """
    print(f"\n{'='*80}")
    print(f"Generating GSM8K {bias_type} bias dataset (alpha={alpha})")
    print(f"{'='*80}\n")
    
    # Load GSM8K samples
    samples = load_gsm8k_samples(num_samples=num_samples, seed=seed)
    
    # Select bias injection function
    if bias_type == "authority":
        inject_fn = inject_authority
    elif bias_type == "confidence":
        inject_fn = inject_confidence
    else:
        raise ValueError(f"Unknown bias_type: {bias_type}")
    
    # Generate preference pairs
    preference_data = []
    
    print(f"Generating preference pairs with alpha={alpha}...")
    for i, sample in enumerate(tqdm(samples, desc="Processing")):
        question = sample["question"]
        answer = sample["answer"]
        
        # Inject bias
        pairs = inject_fn(
            question=question,
            answer=answer,
            bias_fraction=alpha,
            seed=seed + i  # Unique seed per sample
        )
        
        preference_data.extend(pairs)
    
    print(f"\nGenerated {len(preference_data)} preference pairs")
    
    # Create dataset
    dataset = Dataset.from_list(preference_data)
    
    # Count biased vs clean
    n_biased = sum(1 for item in preference_data if item.get('bias_applied', False))
    n_clean = len(preference_data) - n_biased
    
    print(f"  Biased pairs: {n_biased}")
    print(f"  Clean pairs: {n_clean}")
    
    # Save as Arrow format
    output_path = f"{output_dir}/gsm8k_{bias_type}_bias_{alpha}"
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    print(f"\nSaving dataset to: {output_path}")
    dataset.save_to_disk(output_path)
    
    print(f"✅ Dataset saved successfully!")
    print(f"   Total examples: {len(dataset)}")
    print(f"   Columns: {dataset.column_names}")


def main():
    parser = argparse.ArgumentParser(description="Generate GSM8K preference datasets")
    parser.add_argument("--bias_type", type=str,
                       choices=["authority", "confidence"],
                       help="Type of bias to inject")
    parser.add_argument("--alpha", type=float,
                       choices=[0.2, 0.4, 0.6, 0.8],
                       help="Bias fraction")
    parser.add_argument("--all", action="store_true",
                       help="Generate all bias types and alpha values")
    parser.add_argument("--num_samples", type=int, default=1000,
                       help="Number of samples to generate")
    parser.add_argument("--output_dir", type=str, default="biased_datasets_new",
                       help="Output directory")
    parser.add_argument("--seed", type=int, default=42,
                       help="Random seed")
    
    args = parser.parse_args()
    
    if args.all:
        # Generate all combinations
        bias_types = ["authority", "confidence"]
        alphas = [0.2, 0.4, 0.6, 0.8]
        
        print(f"\n{'='*80}")
        print(f"Generating ALL GSM8K datasets ({len(bias_types)} types × {len(alphas)} alphas = {len(bias_types)*len(alphas)} total)")
        print(f"{'='*80}\n")
        
        for bias_type in bias_types:
            for alpha in alphas:
                try:
                    generate_gsm8k_dataset(
                        bias_type=bias_type,
                        alpha=alpha,
                        num_samples=args.num_samples,
                        output_dir=args.output_dir,
                        seed=args.seed
                    )
                    print()
                except Exception as e:
                    print(f"❌ Error generating {bias_type} alpha={alpha}: {e}")
                    continue
        
        print(f"\n{'='*80}")
        print(f"✅ ALL GSM8K DATASETS GENERATED SUCCESSFULLY")
        print(f"{'='*80}\n")
    else:
        # Generate single dataset
        if not args.bias_type or args.alpha is None:
            parser.error("--bias_type and --alpha are required when not using --all")
        
        generate_gsm8k_dataset(
            bias_type=args.bias_type,
            alpha=args.alpha,
            num_samples=args.num_samples,
            output_dir=args.output_dir,
            seed=args.seed
        )


if __name__ == "__main__":
    main()
