# Latent Truth Decoding

Runnable code for reproducing the experiments in *Latent Truth Decoding: Training-Free Mitigation of Sycophancy in Small Language Models*.

Only source code is included. Public datasets and Hugging Face models are downloaded by the scripts; generated datasets, checkpoints, and results are written locally when you run them.

## Contents

```text
dataset_generation/  Build the eight MMLU/GSM8K DPO datasets
training/            Train the eight LoRA-DPO adapters
experiments/         Reproduce SFR/LTD and mechanistic outputs
requirements.txt     Original project dependencies
LICENSE
```

The Python files are byte-for-byte copies of the original codebase. Experiment files were renamed only for clarity.

## Setup

Use Python 3.10+ on a CUDA GPU with enough memory for 7B-9B models. Some scripts use bfloat16 and `device_map="auto"` directly.

```bash
cd "Latent Truth Decoding"
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt scikit-learn
huggingface-cli login
```

Access to the gated Llama and Gemma model repositories must be approved on Hugging Face before running their experiments.

## 1. Off-the-shelf SFR and LTD results

This is the shortest route to the main MMLU/GSM8K results. It downloads the datasets and evaluates the four paper models with 500 test examples, 50 calibration examples, three pressure turns, and LTD `gamma=1`.

```bash
python experiments/off_the_shelf_sfr_ltd.py \
  --datasets mmlu gsm8k \
  --models qwen2.5-7b llama3.1-8b qwen2.5-7b-it gemma2-9b-it \
  --num_samples 500 \
  --n_turns 3 \
  --gamma 1 \
  --compare \
  --output_dir outputs/off_the_shelf
```

Output: `outputs/off_the_shelf/new_models_sfr_multiturn.csv`.

For a quick smoke test, replace `--num_samples 500` with `--num_samples 60`.

## 2. Generate the controlled-DPO datasets

The paper uses MMLU and GSM8K, authority and confidence bias, and `alpha` values 0.2 and 0.4: eight datasets total.

```bash
for dataset in mmlu gsm8k; do
  for bias in authority confidence; do
    for alpha in 0.2 0.4; do
      python "dataset_generation/generate_${dataset}_arrow.py" \
        --bias_type "$bias" \
        --alpha "$alpha" \
        --output_dir generated_datasets \
        --seed 42
    done
  done
done
```

## 3. Train the eight DPO adapters

The output names below are the names expected by the downstream experiment scripts.

```bash
for dataset in mmlu gsm8k; do
  for bias in authority confidence; do
    for alpha in 0.2 0.4; do
      python training/dpo_trainer.py \
        --model_name_or_path meta-llama/Meta-Llama-3.1-8B \
        --dataset_path "generated_datasets/${dataset}_${bias}_bias_${alpha}" \
        --dataset_type "$dataset" \
        --bias_fraction "$alpha" \
        --output_dir "outputs/dpo/${dataset}_${bias}_${alpha}_beta0.1" \
        --beta 0.1 \
        --num_train_epochs 3 \
        --per_device_train_batch_size 2 \
        --gradient_accumulation_steps 2 \
        --learning_rate 5e-6
    done
  done
done
```

## 4. Controlled-DPO LTD results

```bash
python experiments/controlled_dpo_ltd.py \
  --base_model meta-llama/Meta-Llama-3.1-8B \
  --dpo_dir outputs/dpo \
  --num_samples 550 \
  --gamma 1 \
  --output_dir outputs/controlled_dpo
```

Output: `outputs/controlled_dpo/phase7_complete_ablation_results.csv`.

## 5. Mechanistic outputs

Run these after DPO training. Missing adapter folders are skipped, so the included 0.2/0.4 adapters are sufficient.

```bash
python experiments/criticality_score.py \
  --dpo_dir outputs/dpo \
  --num_samples 100 \
  --output_dir outputs/criticality

python experiments/logit_lens_mmlu.py \
  --base_model meta-llama/Meta-Llama-3.1-8B \
  --dpo_dir outputs/dpo \
  --output_dir outputs/logit_lens_mmlu

python experiments/logit_lens_gsm8k.py \
  --base_model meta-llama/Meta-Llama-3.1-8B \
  --dpo_dir outputs/dpo \
  --output_dir outputs/logit_lens_gsm8k

python experiments/probe_vs_logit_lens.py \
  --base_model meta-llama/Meta-Llama-3.1-8B \
  --dpo_dir outputs/dpo \
  --num_samples 150 \
  --output_dir outputs/probe_vs_logit_lens
```

These commands write CSV metrics and PNG figures beneath `outputs/`.
