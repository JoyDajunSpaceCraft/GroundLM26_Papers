"""Compute raw agreement and Cohen's kappa for the two annotation CSVs."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def read_labels(path: Path) -> dict[str, str]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = csv.DictReader(handle)
        return {
            row["row_id"].strip(): row["label"].strip().lower().replace(" ", "_")
            for row in rows
        }


def agreement(a: list[object], b: list[object]) -> dict[str, float | int]:
    if len(a) != len(b) or not a:
        raise ValueError("label arrays must be non-empty and have equal length")
    labels = sorted(set(a) | set(b), key=str)
    n = len(a)
    observed = sum(x == y for x, y in zip(a, b)) / n
    expected = sum((a.count(label) / n) * (b.count(label) / n) for label in labels)
    kappa = (observed - expected) / (1 - expected) if expected != 1 else 1.0
    return {"n": n, "raw_agreement": observed, "expected_agreement": expected, "cohen_kappa": kappa}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--annotator-a", required=True, type=Path)
    parser.add_argument("--annotator-b", required=True, type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    a = read_labels(args.annotator_a)
    b = read_labels(args.annotator_b)
    shared = sorted(set(a) & set(b), key=lambda value: int(value))
    four_a = [a[key] for key in shared]
    four_b = [b[key] for key in shared]
    flagged = {"partially_supported", "unsupported"}
    binary_a = [label in flagged for label in four_a]
    binary_b = [label in flagged for label in four_b]
    result = {
        "four_way": agreement(four_a, four_b),
        "binary_collapse": agreement(binary_a, binary_b),
        "binary_rule": "partially_supported or unsupported => flagged; supported => clean",
    }
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.out:
        args.out.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
