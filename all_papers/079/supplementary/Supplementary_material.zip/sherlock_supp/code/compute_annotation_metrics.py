"""Recompute proxy calibration metrics from the released annotation CSVs."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def metrics(pairs: list[tuple[bool, bool]]) -> dict[str, float | int]:
    tp = sum(pred and gold for pred, gold in pairs)
    fp = sum(pred and not gold for pred, gold in pairs)
    fn = sum(not pred and gold for pred, gold in pairs)
    tn = sum(not pred and not gold for pred, gold in pairs)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"n": len(pairs), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "precision": precision, "recall": recall, "f1": f1}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--proxy-validation", required=True, type=Path)
    parser.add_argument("--condition-c-audit", required=True, type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    validation = read_csv(args.proxy_validation)
    validation_pairs = [
        (row["proxy_flagged"].strip().upper() == "YES",
         row["your_label"].strip().upper() == "HALLUCINATED")
        for row in validation
    ]
    audit = read_csv(args.condition_c_audit)
    positive_labels = {"fabricated", "embellishment"}
    audit_pairs = [
        (row["proxy_flagged"].strip().upper() == "YES",
         row["audit_label"].strip().lower() in positive_labels)
        for row in audit
    ]

    result = {
        "proxy_validation_100": metrics(validation_pairs),
        "condition_c_annotation_audit_28": metrics(audit_pairs),
        "audit_positive_rule": "fabricated or embellishment => unsupported",
    }
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.out:
        args.out.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
