"""
Base protocol for hallucination evaluators.

Each evaluator scores a single (narration, evidence) pair and returns
a SlideScore. The runner collects scores across slides and conditions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass
class SlideScore:
    """Result of evaluating one slide's narration."""

    slide_index: int
    file: str
    score: float  # 0.0 = hallucinated, 1.0 = fully grounded
    label: str  # e.g. "entailed", "fabricated", "pass"
    details: dict = field(default_factory=dict)


@runtime_checkable
class HallucinationEvaluator(Protocol):
    """Interface for hallucination evaluation metrics."""

    name: str

    def evaluate_slide(
        self,
        narration: str,
        evidence_texts: list[str],
        slide_text: str,
        speaker_notes: str,
    ) -> SlideScore:
        """Score a single slide's narration against its evidence."""
        ...

    def warmup(self) -> None:
        """Optional: load models, download weights, etc."""
        ...
