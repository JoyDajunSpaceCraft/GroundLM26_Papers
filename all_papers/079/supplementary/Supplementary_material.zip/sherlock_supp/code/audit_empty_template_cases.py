"""Identify condition-C AI outputs with no passing initial template segment."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

PROXY_TERMS = (
    "vibrant", "serene", "intricate", "stunning", "landscape", "rural",
    "scenic", "colorful", "abstract", "artistic", "microscopic", "aerial",
    "panoramic", "beautiful", "elegant", "captures", "gazing", "glimpse",
    "vivid", "bright", "lush", "backdrop", "swaying", "tranquil",
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("data/experiment_outputs"))
    args = parser.parse_args()

    records = []
    ai_labeled = 0
    condition_dir = args.root / "condition_c"
    for deck_dir in sorted(p for p in condition_dir.iterdir() if p.is_dir()):
        narration = json.loads((deck_dir / "ai_narration.json").read_text())
        report = json.loads((deck_dir / "verify_report.json").read_text())["report"]
        passing_by_slide = {}
        for segment in report:
            slide_index = int(segment["slide_index"])
            passing_by_slide.setdefault(slide_index, 0)
            if str(segment.get("verdict", "")).upper() == "PASS":
                passing_by_slide[slide_index] += 1

        for entry in narration["entries"]:
            if entry.get("source_used") != "ai_narrate":
                continue
            ai_labeled += 1
            slide_index = int(entry["slide_index"])
            if passing_by_slide.get(slide_index, 0) == 0:
                text = str(entry.get("narration_text", "")).lower()
                records.append({
                    "deck_id": deck_dir.name,
                    "slide_index": slide_index,
                    "proxy_flagged": any(term in text for term in PROXY_TERMS),
                })

    print(json.dumps({
        "condition_c_ai_labeled": ai_labeled,
        "ai_labeled_with_no_passing_initial_segment": len(records),
        "records": records,
        "interpretation": (
            "The saved reports cover initial template verification only. "
            "Final post-rewrite verdicts were not persisted."
        ),
    }, indent=2))


if __name__ == "__main__":
    main()
