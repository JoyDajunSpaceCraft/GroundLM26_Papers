"""Compare exported annotation narrations with preserved final narrations."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from compute_permutation_test import _slide_flagged


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--annotations", required=True, type=Path)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    with args.annotations.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    condition_dir = {"A": "condition_a", "B": "condition_b", "C": "condition_c"}
    mapped = exact_text = same_proxy = 0
    changed_proxy_rows: list[str] = []
    for row in rows:
        candidates = [
            path for path in (args.root / condition_dir[row["condition"]]).iterdir()
            if path.is_dir() and path.name.startswith(row["file"])
        ]
        if len(candidates) != 1:
            continue
        entries = json.loads((candidates[0] / "ai_narration.json").read_text(encoding="utf-8"))["entries"]
        final = next(
            item for item in entries
            if int(item["slide_index"]) == int(row["slide_index"])
        )["narration_text"]
        mapped += 1
        exact_text += final == row["narration"]
        final_proxy = _slide_flagged(final)
        exported_proxy = row["proxy_flagged"].strip().upper() == "YES"
        same_proxy += final_proxy == exported_proxy
        if final_proxy != exported_proxy:
            changed_proxy_rows.append(row["row_id"])

    result = {
        "annotation_rows": len(rows),
        "uniquely_mapped_to_preserved_final_files": mapped,
        "byte_identical_narrations": exact_text,
        "same_proxy_label": same_proxy,
        "different_proxy_label": mapped - same_proxy,
        "different_proxy_row_ids": changed_proxy_rows,
        "interpretation": "The annotations calibrate the proxy on a separately exported related study set; they are not direct labels for the preserved final narration files."
    }
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.out:
        args.out.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
