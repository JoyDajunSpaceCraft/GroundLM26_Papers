"""Summarize saved final narrations and condition-C verifier reports."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from compute_permutation_test import load_condition_labels


def entries(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        return data
    return data.get("entries", data.get("narration_entries", []))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    condition_summary = {}
    for condition in ("condition_a", "condition_b", "condition_c"):
        labels = load_condition_labels(args.root, condition)
        sources: Counter[str] = Counter()
        for narration in sorted((args.root / condition).glob("*/ai_narration.json")):
            sources.update(str(row.get("source_used", "missing")) for row in entries(narration))
        condition_summary[condition] = {
            "slides": len(labels),
            "proxy_flagged": sum(labels.values()),
            "proxy_rate": sum(labels.values()) / len(labels),
            "source_used": dict(sorted(sources.items())),
        }

    verdicts: Counter[str] = Counter()
    reasons: Counter[str] = Counter()
    for report_path in sorted((args.root / "condition_c").glob("*/verify_report.json")):
        report = json.loads(report_path.read_text(encoding="utf-8")).get("report", [])
        for row in report:
            verdicts[str(row.get("verdict", "missing"))] += 1
            reasons.update(row.get("reason_codes", row.get("reasons", [])))
    for verdict in ("PASS", "REWRITE", "REMOVE"):
        verdicts.setdefault(verdict, 0)

    result = {
        "conditions": condition_summary,
        "condition_c_verifier": {
            "verdicts": dict(sorted(verdicts.items())),
            "reason_codes": dict(sorted(reasons.items())),
            "reason_counts_overlap": True,
        },
    }
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.out:
        args.out.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
