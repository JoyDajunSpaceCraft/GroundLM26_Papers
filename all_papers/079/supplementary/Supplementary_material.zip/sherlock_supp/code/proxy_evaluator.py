"""
Keyword proxy evaluator with precision/recall against manual labels.

Uses the 24-keyword fabrication proxy and 15-keyword image claim proxy.
Can also load manual annotations for P/R computation.
"""
from __future__ import annotations

import json
import os
import re

from base import SlideScore

IMAGE_KEYWORDS = [
    "image", "photo", "picture", "diagram", "chart", "graph", "figure",
    "illustration", "screenshot", "logo", "map", "shows", "depicts",
    "displays", "illustrates",
]

FABRICATION_KEYWORDS = [
    "vibrant", "serene", "intricate", "stunning", "landscape", "rural",
    "scenic", "colorful", "abstract", "artistic", "microscopic", "aerial",
    "panoramic", "beautiful", "elegant", "captures", "gazing", "glimpse",
    "vivid", "bright", "lush", "backdrop", "swaying", "tranquil",
]


class ProxyEvaluator:
    name = "keyword_proxy"

    def __init__(
        self,
        image_keywords: list[str] | None = None,
        fabrication_keywords: list[str] | None = None,
    ):
        self._image_kw = image_keywords or IMAGE_KEYWORDS
        self._fab_kw = fabrication_keywords or FABRICATION_KEYWORDS

    def warmup(self) -> None:
        pass

    def evaluate_slide(
        self,
        narration: str,
        evidence_texts: list[str],
        slide_text: str,
        speaker_notes: str,
    ) -> SlideScore:
        text_lower = narration.lower()

        image_hits = [kw for kw in self._image_kw if kw in text_lower]
        fab_hits = [kw for kw in self._fab_kw if kw in text_lower]

        has_image_claim = len(image_hits) > 0
        has_fabrication = len(fab_hits) > 0

        # Score: 1.0 = clean, 0.0 = fabricated
        if has_fabrication:
            score = 0.0
        elif has_image_claim:
            score = 0.5
        else:
            score = 1.0

        return SlideScore(
            slide_index=0,
            file="",
            score=score,
            label="fabricated" if has_fabrication else "clean",
            details={
                "has_image_claim": has_image_claim,
                "has_fabrication": has_fabrication,
                "image_hits": image_hits,
                "fabrication_hits": fab_hits,
            },
        )

    @staticmethod
    def compute_precision_recall(
        proxy_labels: list[bool],
        manual_labels: list[bool],
    ) -> dict:
        """Compute P/R of proxy predictions against manual annotations."""
        tp = sum(1 for p, m in zip(proxy_labels, manual_labels) if p and m)
        fp = sum(1 for p, m in zip(proxy_labels, manual_labels) if p and not m)
        fn = sum(1 for p, m in zip(proxy_labels, manual_labels) if not p and m)
        tn = sum(1 for p, m in zip(proxy_labels, manual_labels) if not p and not m)

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        return {
            "tp": tp,
            "fp": fp,
            "fn": fn,
            "tn": tn,
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "total": len(proxy_labels),
        }
