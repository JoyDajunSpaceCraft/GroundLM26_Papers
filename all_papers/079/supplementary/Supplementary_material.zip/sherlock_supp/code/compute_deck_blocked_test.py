"""Exact deck-blocked sign-flip sensitivity test.

The unit being flipped is a deck: all paired slide differences within one deck
receive the same random sign. The dynamic program enumerates the exact null
distribution without explicitly iterating over 2^30 assignments.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from compute_permutation_test import load_condition_labels


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--left", default="condition_a")
    parser.add_argument("--right", default="condition_c")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    left = load_condition_labels(args.root, args.left)
    right = load_condition_labels(args.root, args.right)
    shared = sorted(set(left) & set(right))
    if not shared:
        raise SystemExit("no paired slides found")

    by_deck: dict[str, int] = {}
    for deck, slide in shared:
        by_deck[deck] = by_deck.get(deck, 0) + right[(deck, slide)] - left[(deck, slide)]

    distribution = Counter({0: 1})
    for contribution in by_deck.values():
        nxt: Counter[int] = Counter()
        for total, multiplicity in distribution.items():
            nxt[total + contribution] += multiplicity
            nxt[total - contribution] += multiplicity
        distribution = nxt

    observed = sum(by_deck.values())
    extreme = sum(n for total, n in distribution.items() if abs(total) >= abs(observed))
    assignments = 2 ** len(by_deck)
    result = {
        "left_condition": args.left,
        "right_condition": args.right,
        "n_decks": len(by_deck),
        "n_slides_paired": len(shared),
        "observed_net_difference_right_minus_left": observed,
        "exact_two_sided_p": extreme / assignments,
        "extreme_assignments": extreme,
        "total_sign_assignments": assignments,
        "deck_contributions_right_minus_left": dict(sorted(by_deck.items())),
    }
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.out:
        args.out.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
