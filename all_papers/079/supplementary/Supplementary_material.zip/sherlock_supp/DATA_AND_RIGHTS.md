# Data and rights notice

The 30 input decks were downloaded from publicly accessible U.S. federal,
state, and government-related websites represented in the historical corpus.
Public accessibility does not establish that every deck or embedded element is
in the public domain. Original deck binaries are not redistributed.

Released experiment outputs and annotation records contain limited,
privacy-sanitized excerpts derived from those sources. Copyright and other
rights in source-derived material remain with their respective owners. No
license to the original decks, embedded media, trademarks, or third-party text
is granted by this package.

Apache License 2.0 in `LICENSE` applies only to software in `code/` and
author-created documentation in this package. It does not apply to the mixed-
source data under `data/`, the source-derived fields under `annotations/`, or
third-party material quoted in `examples/`. No separate license is granted for
those mixed-source files; they are provided as research evidence for evaluating
the accompanying paper.

Direct email addresses, phone numbers, and a patient-style demo name were
replaced with deterministic class placeholders. Publicly listed professional
names and organizations may remain where necessary to preserve historical
context. See `SANITIZATION.md` and `data/sanitization_manifest.json`.

