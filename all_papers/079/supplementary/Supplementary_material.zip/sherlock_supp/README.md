# SlideSherlock GroundLM 2026 supplementary materials

This package accompanies the camera-ready paper, “Evidence-Indexed Slide
Narration With Heuristic Checks and Template Fallback.” It supports
output-and-statistics reproduction from privacy-sanitized copies of saved
narration outputs. It contains condition-C verifier reports, annotation labels,
standard-library analysis scripts, review-queue summaries, and an A1/C output
pair. It cannot recreate the original generation run: the exact experiment
commit, rendered prompts, dated model snapshots, input binaries and identity
hashes, and token logs are unavailable in this package.

## Requirements

- Python 3.10 or newer
- Standard library only; no packages need to be installed

Run all commands below from this directory.

## Contents

```text
README.md
LICENSE
DATA_AND_RIGHTS.md
SANITIZATION.md
code/
  compute_permutation_test.py   # slide-paired exact + Monte Carlo test
  compute_deck_blocked_test.py  # exact deck-blocked sensitivity test
  compute_reviewer_agreement.py # 4-way and binary Cohen's kappa
  compute_annotation_metrics.py # proxy validation and 28-example audit
  check_annotation_alignment.py # compare annotation export to final JSON
  summarize_experiment.py       # proxy, fallback, verdict, and reason counts
  audit_empty_template_cases.py # list AI outputs with no passing template segment
  proxy_evaluator.py            # released keyword proxy
  base.py                       # evaluator data class
data/
  30_decks.txt
  reproducibility_manifest.json
  historical_manifest_verbatim.json
  experiment_results_verbatim.json
  expected_permutation_output.json
  gate_production.csv
  gate_strict.csv
  experiment_outputs/
    condition_a/<deck>/ai_narration.json
    condition_b/<deck>/ai_narration.json
    condition_c/<deck>/ai_narration.json
    condition_c/<deck>/metrics.json
    condition_c/<deck>/verify_report.json
  review_queue/per_deck.csv
  review_queue/summary_metrics.csv
  review_queue/summary.json
  sanitization_manifest.json
annotations/
  proxy_validation_binary.csv
  annotator_a_4way_labels.csv
  annotator_b_4way_labels.csv
  annotator_instructions.md
  audit_c_outputs.csv
  audit_instructions.md
examples/
  qualitative_pair_1_decorative.md
  sentence_to_evidence_lineage.md
```

## Reproduce the reported numbers

Headline counts, fallback/source counts, and verifier totals:

```bash
python3 code/summarize_experiment.py \
  --root data/experiment_outputs
```

Slide-paired A1/C test (100,000 Monte Carlo samples, seed 42, plus exact test):

```bash
python3 code/compute_permutation_test.py \
  --root data/experiment_outputs \
  --left condition_a --right condition_c \
  --n 100000 --seed 42
```

Exact deck-blocked sensitivity test:

```bash
python3 code/compute_deck_blocked_test.py \
  --root data/experiment_outputs \
  --left condition_a --right condition_c
```

Reviewer agreement:

```bash
python3 code/compute_reviewer_agreement.py \
  --annotator-a annotations/annotator_a_4way_labels.csv \
  --annotator-b annotations/annotator_b_4way_labels.csv
```

Proxy calibration metrics:

```bash
python3 code/compute_annotation_metrics.py \
  --proxy-validation annotations/proxy_validation_binary.csv \
  --condition-c-audit annotations/audit_c_outputs.csv
```

Check alignment between the annotation export and preserved final narrations:

```bash
python3 code/check_annotation_alignment.py \
  --annotations annotations/proxy_validation_binary.csv \
  --root data/experiment_outputs
```

Audit the six empty-template exception candidates from saved initial reports:

```bash
python3 code/audit_empty_template_cases.py \
  --root data/experiment_outputs
```

The expected key results are:

- A1: 22/279 (7.89%); B: 20/279 (7.17%); C: 5/279 (1.79%).
- A1/C exact paired p = 0.00022125244140625; Monte Carlo p with the command
  above = 0.0002599974000259997.
- Exact deck-blocked p = 0.015625.
- C output-source counts: 225 `post_rewrite_fallback`, 54 `ai_narrate`.
  Six of the 54 AI-labeled slides have no passing segment in the saved initial
  verifier report and no nonempty verified fallback target. Because final
  post-rewrite verdicts were not saved, the remaining AI labels must not be
  interpreted as persisted pass verdicts.
- C verifier verdicts: 510 PASS, 1,499 REWRITE, 0 REMOVE.
- Proxy validation: TP=26, FP=14, FN=20, TN=40, precision=0.65,
  recall=0.5652, F1=0.6047.
- Reviewer agreement: raw=0.76 and kappa=0.5420 (multi-class);
  raw=0.77 and kappa=0.5106 (binary collapse).
- Condition-C annotation audit: TP=6, FP=2, FN=5, TN=15, F1=0.6316.

## Scope and provenance cautions

- A1 is not a raw language-model baseline. It still uses the evidence-derived
  template, slide text/notes, and post-rewrite checking. A1/B fallback targets
  are unverified; C uses verified-template text only when it is nonempty.
- C changes both initial verification and the fallback target. The experiment
  compares system configurations and cannot attribute the gain to one component.
- Stage caching was disabled, so vision-derived evidence was regenerated for
  every condition. The experiment holds decks and extraction procedure fixed,
  not the realized vision captions/tags. A normalized A--C comparison found
  1,721 common, 446 A-only, and 447 C-only non-asset evidence records; all
  condition-specific records were vision-derived.
- The content-support rule checks numeric consistency and at least one token
  overlap. It is not semantic entailment.
- Annotators saw extracted text, shape labels, model-generated image captions,
  and narration, not the original PowerPoint or rendered slide. Their judgments
  are extracted-context labels; some audit fields were clipped at about 200
  characters.
- The 100-row annotation narration text is a separately exported study set and
  does not byte-match the preserved final `ai_narration.json` entries. It is
  used to calibrate the proxy on related A1/B/C outputs; the 28-example audit is
  not a direct relabeling of the final JSON used for the 1.79% headline rate.
- `experiment_results_verbatim.json` contains a historical logging bug:
  aggregate `total_slides` is zero although 279 narration entries exist.
  Reproduction scripts intentionally count the per-deck narration files.
- Every condition-C `metrics.json` has a stale `slides_fallback: 0` field. It
  counts model-call failures, not post-rewrite selection. Table 3 uses
  `ai_narration.json:source_used`, which yields 225 fallback-labeled outputs.
- Six C slides expose an empty-template edge case: no initial segment passed,
  the reconstructed post-check has an empty evidence-ID union, and reconstructed
  code retains AI narration because fallback requires nonempty text. The exact
  experiment commit and final post-rewrite verdicts were not retained, so this
  is an artifact-and-code reconstruction, not a saved verdict.
- `historical_manifest_verbatim.json` is retained as an unedited record and
  contains old condition wording. `reproducibility_manifest.json` is the
  corrected camera-ready interpretation. Do not execute the stale commands or
  interpret the old paths in the verbatim manifest as release instructions.
- The exact historical Git commit, rendered prompt hash, dated model snapshot,
  final post-rewrite verdicts, source-deck identity hashes, and token usage were
  not saved. They must not be inferred from later code.
- The formal experiment used `--skip-av`; audio/video were not generated and
  every saved `output_video` value is null. The application can generate videos,
  but these artifacts evaluate only the narration-stage path.
- Released copies were sanitized as described in `SANITIZATION.md`; placeholders
  do not alter any 24-keyword proxy decision or reported statistic.

## Data and license

The 30 input decks were downloaded from publicly accessible U.S. federal,
state, and government-related websites represented in the historical corpus.
Public accessibility does not establish that every deck or embedded element is
in the public domain. Original deck binaries are not redistributed. Released
outputs contain privacy-sanitized source-derived excerpts; copyright and other
rights remain with their respective owners. Apache License 2.0 applies only to
the accompanying software and author-created documentation, not third-party
source material or mixed-source data files. See `DATA_AND_RIGHTS.md` and
`SANITIZATION.md`.
