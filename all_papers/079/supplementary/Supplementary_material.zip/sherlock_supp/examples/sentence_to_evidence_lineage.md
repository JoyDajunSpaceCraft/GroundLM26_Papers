# Schematic internal citation contract

This is an illustrative schematic, not a quoted observation from the saved
experiment. It explains the internal script-stage evidence-ID contract.

## Slide input

A bulleted-list slide titled *"Operational practices"*. Two relevant
extracted items:

| Evidence ID (truncated) | Kind         | Surface text                  |
| ----------------------- | ------------ | ----------------------------- |
| `ad2f5473…`             | `TEXT_SPAN`  | "Stage contracts"             |
| `9bc1aee0…`             | `SHAPE_LABEL`| "Profile time spent per stage"|

(Each evidence ID is `SHA-256(job_id || slide_idx || kind || offset)`,
deterministic within a pipeline run.)

## Generated claim segment (script stage)

> Stage contracts and profiling time spent per stage [ev: ad2f5473, 9bc1aee0]
> are two of the engineering practices on this slide.

## Verifier view

```
claim_id        : <SHA-256(job_id || slide_idx || segment_ix)>
slide_index     : 12
cited_evidence  : [ad2f5473…, 9bc1aee0…]
required_kinds  : [TEXT_SPAN, SHAPE_LABEL]   (derived from claim heuristics)
checks_run      :
  citation_presence              : OK   (2 IDs present)
  evidence_exists                : OK   (both IDs in index)
  graph_consistency              : OK   (no contradictory claims)
  token_support                  : OK   (at least one claim token overlaps evidence)
  image_claim_grounding          : N/A  (not an image claim)
  diagram_interaction_consistency: N/A
  hedging_for_low_confidence_vision: N/A
verdict         : PASS
reasons         : []
```

## Why PASS

- Both cited identifiers resolve to existing evidence items in the
  closed deck index.
- The legacy token-support check finds at least one overlapping token and also
  enforces numeric consistency. It does not require every content-bearing token
  to be covered and does not establish semantic entailment.
- No graph-consistency conflict (no other claim contradicts this one).
- Not an image claim, so the image-grounding pathway is skipped.

The fluency rewrite is checked using one synthetic whole-slide segment whose
evidence and entity lists are the deduplicated union from all template segments
on that slide. If that check fails and the verified template is nonempty,
condition C falls back to that text. Six saved C slides have no passing initial
segment and expose the reconstructed implementation's empty-template fail-open
case. The final `ai_narration.json` entry stores the slide text and
source label, but not per-sentence evidence IDs. Thus this mechanism provides
internal verification lineage, not a literal sentence-level citation list in
the final TTS artifact.
