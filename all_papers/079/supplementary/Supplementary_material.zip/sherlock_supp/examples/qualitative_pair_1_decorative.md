# Qualitative pair 1 — A1/C saved-output contrast

**Deck:** `neptune.gsfc.nasa.gov_wais_pastmeetings_PPT04_Question4_Gray` (slide 5)
**Saved vision-extracted context:** a topographic map with velocity color
gradient and directional arrows (the source slide is not redistributed here)

## Condition A1 final saved narration

> This image shows The image features **two abstract patterns** with **colorful, wavy lines** and **circular shapes**, creating a visually striking effect. The left side displays a more uniform pattern, while the right side introduces a green background that enhances the vibrancy of the colors. Element: 36f67b80. Element: Phase images from both ascending and descending SRI pairs. Note that the patterns, which reflect ‘line-of-sight displacement’, are different in the 2 geometries except for the concentric rings over the position of the surface deflation.. Element: a8a96c4e. Element: d550e8e8. That concludes slide 5.

Proxy-flagged: ✓ (hits: `colorful`, `abstract`).
Context-relative unsupported visual content: the saved extracted context describes
a scientific topographic map, not abstract artwork.
Source: `post_rewrite_fallback` to A1's unverified template. This confirms that
A1 was not a raw model-output condition.

## Condition C final narration (source-labeled template fallback)

> This slide appears to show A topographic map displaying varying elevations and velocities, with a color gradient indicating different speed values. The image includes directional arrows and a legend for reference.

Proxy-flagged: ✗.
Source: `post_rewrite_fallback`.
Extracted-context comparison: the condition-C wording tracks the saved
vision-extracted evidence (topographic map, elevation, velocity, color gradient,
directional arrows, legend) and does not add the A1 phrase "abstract patterns."
Because neither the source slide nor its evidence index is redistributed, this
example is not an independent visual-grounding audit.

The final post-rewrite verdict was not persisted. The source label establishes
which output was selected, not a saved verdict. Under the reconstructed code,
this label is produced when a failed post-check selects a nonempty template;
the exact experiment commit was not retained.

The exact source JSON files are included at
`data/experiment_outputs/condition_{a,c}/<deck>/ai_narration.json`.
