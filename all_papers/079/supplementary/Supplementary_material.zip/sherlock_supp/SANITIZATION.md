# Privacy sanitization

The release copy was scanned for secrets, direct contact information, and
patient-style identifiers. No API key or credential was found. The following
literal classes were replaced throughout the affected annotation and experiment
output files:

- email addresses → `[REDACTED_EMAIL]`
- telephone numbers, including the mnemonic contact form → `[REDACTED_PHONE]`
- a patient-style name shown in a demo medical-record screen →
  `[REDACTED_DEMO_PATIENT]`

Historical source files under the project's private `01_sources/` directory
were not modified and are not included in this release. The replacements do not
contain any of the 24 proxy keywords. Rerunning all released analysis scripts
after sanitization preserves the A/B/C proxy counts, fallback/source counts,
verifier counts, statistical tests, reviewer agreement, and annotation metrics.

`data/sanitization_manifest.json` records original and sanitized SHA-256 hashes
for every modified release file without storing the removed values.
