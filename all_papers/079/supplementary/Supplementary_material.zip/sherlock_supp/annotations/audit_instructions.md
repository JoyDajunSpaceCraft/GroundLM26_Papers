# Audit: condition-C narration outputs

## Purpose

This archived audit protocol examines the known limits of the keyword proxy.
It looks at:

- **The 8 condition-C slides the proxy flagged.** Are they real hallucinations, or false positives where the proxy cried wolf on a metaphor?
- **20 randomly-sampled condition-C slides the proxy said were clean.** Are they actually clean, or did the proxy miss something?

The released CSV already contains the collected labels used for the paper's
proxy-calibration result.

## File to fill

```
annotations/audit_c_outputs.csv
```

28 rows. Open in any spreadsheet tool. Fill in **only the `audit_label` column**. Skip `audit_notes` unless you want to record a one-line thought.

## The four labels

| Label | When to use it |
|---|---|
| `clean` | Narration is fully grounded in the slide content. No invented facts, no flowery added language. Paraphrasing is fine. |
| `embellishment` | Narration adds flowery descriptive language (adjectives like "vibrant", "beautiful", "scenic") that wasn't in the slide. The narration may otherwise be grounded — the issue is added decoration, not fabricated facts. |
| `fabricated` | Narration invents something concrete that's not in the slide: a person, place, number, action, relation, or chart trend. This is the worst kind of error. |
| `metaphor_fp` | The proxy keyword (e.g. "captures", "vivid", "abstract") is used **metaphorically**, not to describe visual content. The narration is grounded; the proxy is wrong. Example: "Dr. Smith captures the spirit of the new policy" — `captures` is metaphor, not a visual claim. |

**Rule of priority if a row has multiple issues:** `fabricated` > `embellishment` > `metaphor_fp` > `clean`. Pick the worst.

## What the proxy is looking for (24 fabrication keywords)

The proxy flags a slide if its narration contains any of these (case-insensitive substring match):

`vibrant, serene, intricate, stunning, landscape, rural, scenic, colorful, abstract, artistic, microscopic, aerial, panoramic, beautiful, elegant, captures, gazing, glimpse, vivid, bright, lush, backdrop, swaying, tranquil`

Knowing this list helps you spot why the proxy flagged something. Many of these words have non-hallucination uses — your job is to decide whether the use is a real fabricated visual claim, a real embellishment, or just incidental.

## How to judge each row

1. Read the four context columns: `slide_text`, `shape_labels`, `image_captions`, `narration`
2. Ask: does every concrete claim in `narration` appear in the slide context?
3. Decide which of the four labels applies. Write it in `audit_label`.

If the slide context is truncated (some long fields are clipped at ~200 chars) — judge based on what's visible. Don't try to guess what's hidden.

## Worked examples

### Example 1: `embellishment`

**Slide context:**
- `slide_text`: "Regional overview"
- `image_captions`: "An aerial view of a mountain range under a cloudy sky."
- `narration`: "Welcome to the regional overview section. This **stunning landscape** with **vibrant mountain peaks** sets the stage for the policies we'll discuss."

**Decision:** The image is described as a mountain range, so "mountain peaks" is grounded. But "stunning" and "vibrant" are flowery adjectives the slide doesn't support. The proxy correctly flagged "stunning" and "vibrant" and "landscape".

→ `audit_label = embellishment`

---

### Example 2: `fabricated`

**Slide context:**
- `slide_text`: "Q3 Revenue Report"
- `image_captions`: "A bar chart with three bars labeled Q1, Q2, Q3."
- `narration`: "Our Q3 revenue grew **35% over Q2**, driven by strong international sales in **Europe and Asia**."

**Decision:** The slide only says "Q3 Revenue Report" with a generic bar chart. The narration invents specific numbers (35%), specific regions (Europe, Asia), and a causal explanation (international sales). None of that is in the slide.

→ `audit_label = fabricated`

---

### Example 3: `clean`

**Slide context:**
- `slide_text`: "Five engineering practices: stage contracts, profiling, resumability, provider abstraction, completion tracking"
- `narration`: "This slide lists five engineering practices we found useful: defining stage contracts, profiling time spent in each stage, designing for resumability, abstracting away provider details, and tracking completion separately from quality."

**Decision:** Narration is a careful paraphrase of the bullet list. No invented facts, no flowery adjectives. Grounded.

→ `audit_label = clean`

---

### Example 4: `metaphor_fp` (proxy was wrong)

**Slide context:**
- `slide_text`: "Patient-centered care: a quote from Dr. Smith"
- `shape_labels`: "Dr. Smith, MD, Mayo Clinic"
- `narration`: "Here Dr. Smith **captures** the essence of patient-centered care."

**Decision:** The proxy flagged this because `captures` is in the 24-word list. But `captures` here is metaphorical ("captures the essence") — it's not a fabricated visual claim. The narration is grounded in what's on the slide (Dr. Smith, patient-centered care).

→ `audit_label = metaphor_fp`

---

### Example 5: `fabricated` (catches what proxy missed)

**Slide context:**
- `slide_text`: "Quarterly results"
- `image_captions`: "A line chart trending upward."
- `narration`: "Our user count grew from **120,000 to 180,000** this quarter, a result of our **expanded marketing campaign in March**."

**Decision:** No flowery adjectives, so the keyword proxy won't flag this. But the narration invents specific user counts (120K, 180K) and a specific cause (March marketing campaign) that aren't in the slide. This is a `fabricated` row that the proxy MISSED — exactly the kind of finding we want to surface.

→ `audit_label = fabricated`
→ `audit_notes` (optional): "proxy missed this one — invented numbers and cause"

---

### Example 6: `clean` (proxy false positive on metaphor)

**Slide context:**
- `slide_text`: "Conclusion: a transparent system is one users can trust."
- `narration`: "In conclusion, a transparent system — one users can see into and trust — gives us a clearer **glimpse** of how decisions are made."

**Decision:** The proxy flagged this because `glimpse` is in the 24-word list. But "glimpse" is metaphor for "view into" — there's no visual content being narrated, just a conceptual statement about transparency. Narration is grounded; proxy is wrong.

→ Could be `clean` if we're being lenient, or `metaphor_fp` since the proxy keyword is doing real work in the sentence. Either is defensible. The honest call: `metaphor_fp` because the proxy was the reason it was flagged.

→ `audit_label = metaphor_fp`

## Reproduce the audit metrics

```bash
python3 code/compute_annotation_metrics.py \
  --proxy-validation annotations/proxy_validation_binary.csv \
  --condition-c-audit annotations/audit_c_outputs.csv
```

The context fields were clipped at about 200 characters in the historical
export. Annotators did not inspect the original PowerPoint or rendered slide,
so these labels cannot detect errors inherited from the generated captions.
