# Slide-narration review (reviewer 2)

> **Note on the released CSV (added for the camera-ready archive):**
> `risk_reason` was collected during annotation but is not released in
> this archive; only `label` and `notes` are exposed. The
> inter-annotator agreement numbers reported in the paper are computed
> from `label` alone. Label values in the released CSVs are
> capitalised (`Supported`, `Partially_Supported`, `Unsupported`); the
> rubric below uses lowercase tokens for readability — the two forms
> are equivalent and should be compared case-insensitively. The `Unclear`
> bin from the 4-way schema is empty in the released 100-slide sample
> (no slide hit it); this is observational, not a label collection
> failure.

This archived protocol describes the extracted-context annotation task. The
goal is consistent judgment using only the released fields; it is not direct
inspection of the original slide.

## What you have

- `annotator_b_4way_labels.csv` — 100 released records. Each row contains
  extracted context plus narration. The file already contains the collected
  second-annotator labels.
- This instructions file.

## What you do

For each row, read the four context columns (`slide_text`, `shape_labels`,
`image_captions`, `narration`) and decide whether the narration is supported by
the provided extracted context. Annotators did not inspect the PowerPoint or a
rendered slide, and generated image captions may themselves be incomplete or
incorrect.

Then fill in three columns:

| Column | Vocabulary | What it means |
|---|---|---|
| **`label`** | `supported` | Every claim in the narration is stated or directly implied by the slide content (text, shapes, image caption). |
| | `partially_supported` | Some claims are supported, but at least one claim adds detail (visual, numeric, named entity, action, relation) that isn't in the slide content. |
| | `unsupported` | Most or all of the narration's specifics are not backed by the slide content. |
| | `unclear` | You can't tell from the provided context — for example, the slide is essentially empty, or the image caption is ambiguous, or you'd need to see the actual slide image to judge. |
| **`risk_reason`** | (one of) `visual_embellishment` `unsupported_chart_trend` `unsupported_entity` `unsupported_relation` `unsupported_numeric_claim` `translation_drift` `other` | Only fill this for `unsupported` or `partially_supported`. Leave blank for `supported` or `unclear`. Pick the **most prominent** kind of unsupported claim — don't list every issue, just the main one. |
| **`notes`** | (free text, optional) | One short phrase if anything is worth recording — e.g., "narrator invented '60 monitoring wells', slide says 'nearly 60'". Most rows do not need notes. |

## Risk-reason quick reference

| risk_reason | Example unsupported claim |
|---|---|
| `visual_embellishment` | "a vibrant landscape", "a serene backdrop", "a beautiful image" — flowery descriptive language for a generic slide |
| `unsupported_chart_trend` | "the chart shows revenue increasing sharply" when the image caption only says "a bar chart" |
| `unsupported_entity` | mentions a person, organization, product, or place that doesn't appear in any of the slide context |
| `unsupported_relation` | claims about who-did-what, cause-effect, or "X is part of Y" when the slide doesn't say that |
| `unsupported_numeric_claim` | "71 service packs", "30% reduction", "twice as many" — a specific number that the slide content does not provide |
| `translation_drift` | translated text drifts from the source (rare in this sample, mostly English) |
| `other` | doesn't fit the above |

## How to call edge cases

- **Narration restates the slide title and nothing more** → `supported`.
- **Narration paraphrases the bullet list accurately** → `supported`, even if wording differs.
- **Narration adds a generic transitional sentence** (e.g., "this is important for X") that is plausible but not in the slide → judgment call; `partially_supported` if the rest is clean, otherwise `unsupported`.
- **Narration describes an image in detail, image caption is also detailed and they match** → `supported`.
- **Narration describes an image, image caption only says "this slide contains an image"** → `unsupported` (likely `visual_embellishment`).
- **Slide is a section divider with one or two words ("Questions?", "Thank You")** → if narration is also short and doesn't invent content → `supported`; if narration adds a story → `unsupported` or `partially_supported`.

## Worked examples

These are synthetic examples designed to cover every `label × risk_reason` combination. None of them are taken from your annotation sheet — they are here to teach the rubric, not to give you any answers.

---

### Style 1 — `supported` (no risk_reason)

> **slide_text:** "Q3 Revenue: $4.2M, up 12% from Q2"
> **shape_labels:** "Q3 Revenue | $4.2M | up 12% from Q2"
> **image_captions:** (none)
> **narration:** "In the third quarter, revenue reached 4.2 million dollars, an increase of 12 percent from the second quarter."

→ **label:** `supported`. Every claim is in the slide text. Paraphrasing the bullets is fine.

---

### Style 2 — `supported` (short divider slide handled cleanly)

> **slide_text:** "Questions?"
> **shape_labels:** "Questions?"
> **image_captions:** "A solid blue background with the word 'Questions?' displayed in white."
> **narration:** "We're now open for any questions you might have."

→ **label:** `supported`. Narration matches the slide's intent without adding content.

---

### Style 3 — `partially_supported` + `visual_embellishment`

> **slide_text:** "Customer Satisfaction Trends"
> **shape_labels:** "Customer Satisfaction Trends"
> **image_captions:** "A bar chart with three colored bars."
> **narration:** "This slide presents a vibrant bar chart with three colored bars showing customer satisfaction trends across our key segments."

→ **label:** `partially_supported`. Topic and chart presence are supported; "vibrant" and "across our key segments" are not. **risk_reason:** `visual_embellishment` (the prominent unsupported claim is the decorative adjective; the segments claim is secondary).

---

### Style 4 — `partially_supported` + `unsupported_numeric_claim`

> **slide_text:** "Network Latency Improvements"
> **shape_labels:** "Network Latency Improvements"
> **image_captions:** "A line chart showing latency dropping over time."
> **narration:** "Network latency improved significantly, with average response time dropping from 200ms to 40ms — an 80 percent reduction."

→ **label:** `partially_supported`. The fact that latency dropped is supported by the caption; the specific numbers (200ms, 40ms, 80%) are not. **risk_reason:** `unsupported_numeric_claim`.

---

### Style 5 — `unsupported` + `visual_embellishment`

> **slide_text:** "Annual Report 2023"
> **shape_labels:** "Annual Report 2023"
> **image_captions:** "A solid blue background."
> **narration:** "The cover features a vibrant, scenic landscape with rolling hills bathed in golden sunlight, setting an inspiring tone for the report."

→ **label:** `unsupported`. The image caption is a "solid blue background"; everything in the narration about landscape, hills, sunlight is invented. **risk_reason:** `visual_embellishment`.

---

### Style 6 — `unsupported` + `unsupported_chart_trend`

> **slide_text:** "Quarterly Customer Acquisition"
> **shape_labels:** "Quarterly Customer Acquisition"
> **image_captions:** "A bar chart titled 'Quarterly Customer Acquisition'."
> **narration:** "The chart shows steady growth in customer acquisition, accelerating sharply in Q4 with a 3x increase over Q1."

→ **label:** `unsupported`. The image caption only tells us a bar chart exists with that title. Claims of "steady growth", "sharp Q4 acceleration", and the specific "3x increase" are not in the caption or anywhere else in the slide content. **risk_reason:** `unsupported_chart_trend` (the unsupported part is the trend / numeric story over what the chart actually shows).

---

### Style 7 — `unsupported` + `unsupported_entity`

> **slide_text:** "Project Update"
> **shape_labels:** "Project Update | Status: On track"
> **image_captions:** "A presentation slide with the title 'Project Update' and a status line."
> **narration:** "Dr. Sarah Chen, lead engineer at the Boston office, provides this update on the cross-functional initiative she started last spring with Marcus Rodriguez from the West Coast team."

→ **label:** `unsupported`. The slide has just a title and a status line. "Dr. Sarah Chen", "Boston office", "Marcus Rodriguez", "West Coast team", and the spring-start backstory are all invented people, places, and history. **risk_reason:** `unsupported_entity`.

---

### Style 8 — `unsupported` + `unsupported_relation`

> **slide_text:** "Pipeline Stages: A, B, C, D"
> **shape_labels:** "Pipeline Stages | A | B | C | D"
> **image_captions:** "A list of four pipeline stages."
> **narration:** "Pipeline stage A feeds into stage B, which then triggers stage C; stage D runs in parallel with C, depending on stage B's output."

→ **label:** `unsupported`. The slide lists four stages but says nothing about how they connect. The narration invents an entire dependency graph. **risk_reason:** `unsupported_relation`.

---

### Style 9 — `unsupported` + `unsupported_numeric_claim`

> **slide_text:** "Adoption Metrics"
> **shape_labels:** "Adoption Metrics | Growing user base"
> **image_captions:** "A bar chart titled 'Monthly Active Users'."
> **narration:** "Adoption metrics show our user base has grown from 12,000 to 47,500 over the past 18 months — nearly 4x growth."

→ **label:** `unsupported`. There's no number anywhere in the slide content. The narration's specific values (12,000, 47,500, 18 months, 4x) are all fabricated. **risk_reason:** `unsupported_numeric_claim`.

---

### Style 10 — `unsupported` + `translation_drift`

(This one is rare in this sample — most narrations are English. Use it only if narration is in a language other than English and substitutes terms in a way that changes meaning.)

> **slide_text:** "Customer Support Workflow"
> **shape_labels:** "Customer Support Workflow | Step 1 | Step 2 | Step 3"
> **image_captions:** "A flow diagram showing three sequential steps."
> **narration:** "Le flux de travail du support client comporte trois étapes décisionnelles distinctes qui définissent l'expérience client globale."

→ **label:** `unsupported`. The narration (translated: "the customer support workflow has three distinct decision-making steps that define the overall customer experience") adds "decisional", "distinct", and "define the overall customer experience" — none of which are in the slide content. **risk_reason:** `translation_drift`.

---

### Style 11 — `unsupported` + `other`

Use `other` when the narration is clearly unsupported but doesn't fit the more specific categories.

> **slide_text:** "Coffee Break"
> **shape_labels:** "Coffee Break | 15 minutes"
> **image_captions:** "A presentation slide with the words 'Coffee Break' and '15 minutes'."
> **narration:** "Hosting your own meeting? Visit our website at example.com for more tips on how to run effective sessions."

→ **label:** `unsupported`. The narration invents a marketing pitch with a URL. Not visual, not numeric, not an entity claim per se — it's a whole new topic. **risk_reason:** `other`.

---

### Style 12 — `unclear`

> **slide_text:** ""
> **shape_labels:** ""
> **image_captions:** "This slide contains an image."
> **narration:** "This slide presents an important transition point in our discussion of regional policy."

→ **label:** `unclear`. The slide has no text we can see, the image caption is uninformative, and the narration's claim about "regional policy" may or may not be in the actual slide image. We don't have enough context to judge. Leave `risk_reason` blank.

---

## Quick decision tree

1. Does the slide content (text + shapes + image captions) clearly back every claim in the narration? → `supported`.
2. Is at least one specific claim (a number, name, place, trend, relation, or visual detail) clearly NOT in the slide content? → `unsupported` or `partially_supported`. Pick `partially_supported` if most of the narration is still accurate; `unsupported` if the unsupported part dominates.
3. Are you on the fence because the slide content is too sparse to tell? → `unclear`.

## Time budget

~1 minute per row is the right pace. The whole sheet should take roughly 90 minutes. **If 100 is too many, doing the first 50 is fine** — the agreement script tolerates partial coverage.

## What happens with your labels

The released agreement command is:

```bash
python3 code/compute_reviewer_agreement.py \
  --annotator-a annotations/annotator_a_4way_labels.csv \
  --annotator-b annotations/annotator_b_4way_labels.csv
```

It reports raw agreement and Cohen's kappa for the four-way labels and binary
collapse. Proxy precision, recall, F1, and the 28-record audit are computed
separately by `code/compute_annotation_metrics.py`.

## Things you do NOT need to do

- Do not inspect the original PowerPoint or rendered slide; judge only from the
  released columns. This means the resulting labels are context-view limited.
- Don't worry about being "right" on hard edge cases. Use `unclear` and move on.
- Don't write long notes — `notes` is for the one or two rows where you want to flag something specific.
