"""Check retained arithmetic only; do not imply that experiments were rerun."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'artifacts/original_headline_metrics.json'
EXPECTED_SHA256 = '453623e14fbcfa9af2febd025b1541f9574d3b8ac1288af05c9a5649d8dca567'

def check(condition, message):
    if not condition:
        raise ValueError(message)

def close(a, b):
    return math.isclose(a, b, abs_tol=1e-12, rel_tol=1e-12)

def main():
    raw = SOURCE.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    check(digest == EXPECTED_SHA256, 'The preserved source file has changed.')
    data = json.loads(raw)
    live = data['e2e_multiseed_session_augment.json']
    counts = data['fig_op_confusion_session.json']['target_cid_by_op']
    bench = data['bench_stats.json']
    check(live['seeds'] == [2027, 2028, 2029], 'Unexpected seed list.')
    check(live['n_sessions'] == 52, 'Unexpected session count.')
    check(sum(bench['utterance_subsets'].values()) == bench['utterances'], 'Utterance categories do not sum.')
    check(sum(bench['utterance_langs'].values()) == bench['utterances'], 'Language counts do not sum.')
    for key in ['instances', 'utterances', 'sessions']:
        check(sum(bench['split_counts'][key].values()) == bench[key], f'{key} splits do not sum.')
    selected = {}
    for metric in ['TurnStatusMatch', 'SDCClarifyAcc', 'OCUSMatch', 'RepairValidAt3', 'CertTraceRate', 'ParseExactMatch']:
        values = live[metric + '_values']
        check(len(values) == 3 and all(0 <= x <= 1 for x in values), f'Invalid values: {metric}')
        mean, sd = statistics.mean(values), statistics.stdev(values)
        check(close(mean, live[metric + '_mean']), f'Mean mismatch: {metric}')
        check(close(sd, live[metric + '_std']), f'Sample standard deviation mismatch: {metric}')
        selected[metric] = {'mean': mean, 'sample_std': sd, 'seed_values': values,
                            'source': f'original_headline_metrics.json:e2e_multiseed_session_augment.json.{metric}_values'}
    for op in ['MODIFY', 'DELETE']:
        x = counts[op]
        check(0 <= x['ok'] <= x['total'], f'Invalid count: {op}')
        rate = x['ok'] / x['total']
        check(close(rate, x['rate']), f'Count ratio mismatch: {op}')
        check(close(rate, live[f'TargetCidMatch_{op}_micro']), f'Micro mismatch: {op}')
        check(x['total'] == live[f'TargetCidMatch_{op}_micro_den'], f'Denominator mismatch: {op}')
    numerator = sum(x['ok'] for x in counts.values())
    denominator = sum(x['total'] for x in counts.values())
    check(denominator == live['TargetCidMatch_micro_den'], 'Pooled denominator mismatch.')
    rate = numerator / denominator
    check(close(rate, live['TargetCidMatch_micro']), 'Pooled micro rate mismatch.')
    # This denominator is a statement in the original appendix, not reconstructed raw data.
    reported_conflict_den, reported_conflict_mismatch = 180, 45
    check(close(1-reported_conflict_mismatch/reported_conflict_den, selected['OCUSMatch']['mean']),
          'Original appendix conflict fraction disagrees with JSON rate.')
    output = {
        'scope': 'Arithmetic validation of retained aggregates; no experiment rerun or independent semantic validation.',
        'source_sha256': digest,
        'configuration': 'Final live stack: session fine-tuning + registered sibling augmentation + test-informed horizon rule',
        'sessions': live['n_sessions'], 'training_seeds': live['seeds'],
        'selected_reported_metrics': selected,
        'target_counts': counts,
        'target_micro': {'matches': numerator, 'scored_records': denominator, 'mismatches': denominator-numerator, 'rate': rate,
                         'denominator_scope': 'Scored target-resolution records; not all gold edit turns'},
        'reported_conflict_counts': {'matches': 135, 'scored_records': 180, 'mismatches': 45, 'rate': .75,
                                    'evidence_status': 'Denominator/mismatch count reported in original Appendix I; rate corroborated by JSON seed arrays'},
        'joint_upper_bounds': {'edit_scored_subset': rate, 'conflict_scored_subset': .75,
                               'interpretation': 'Different conditional subsets; not an all-turn joint score'},
        'all_turn_joint_exact': None,
        'unavailable': ['all-turn joint intersections','per-language accuracy','matched horizon-rule-disabled run',
                        'template family split verification','original implementation/data/checkpoints/per-turn logs'],
        'excluded_from_selection': ['undocumented macro target means','inconsistent audit-session counts','operation-confusion protocol interpretation'],
        'benchmark_counts': {key: bench[key] for key in ['instances','utterances','sessions','utterance_subsets','utterance_langs','split_counts']},
    }
    (ROOT/'artifacts/verified_aggregates.json').write_text(json.dumps(output, indent=2)+'\n', encoding='utf-8')
    rows = [
        ('Coarse status agreement', 'TurnStatusMatch'),
        ('Parse AST exact match', 'ParseExactMatch'),
        ('SDC decision accuracy', 'SDCClarifyAcc'),
        ('Conflict-member agreement', 'OCUSMatch'),
        ('Encoded-state RepairValid@3', 'RepairValidAt3'),
        ('Lexical certificate trace', 'CertTraceRate'),
    ]
    tex = ['% Generated by scripts/verify_aggregates.py; final test-informed configuration.',
           r'\begin{tabular}{lcc}', r'\toprule', r'Metric & Mean & Seed SD \\', r'\midrule']
    for label, metric in rows:
        x = selected[metric]
        tex.append(f"{label} & {x['mean']:.3f} & {x['sample_std']:.3f}" + r' \\')
    tex.extend([r'\midrule', f'Conditional target agreement & {rate:.3f} & pooled' + r' \\',
                r'\bottomrule', r'\end{tabular}', '% Target: 221/264 scored records. Not JointTurnExact.'])
    (ROOT/'tables/final_live_metrics.tex').write_text('\n'.join(tex)+'\n', encoding='utf-8')
    print('PASS: preserved-source hash, count totals, micro ratios, and six seed-summary metrics.')
    print(f'Target micro = {numerator}/{denominator} = {rate:.10f}; mismatches = {denominator-numerator}.')
    print('Conflict count is reported in the original appendix: 135/180 = .75; no per-turn reconstruction.')
    print('No all-turn joint score, language-specific score, or rule-removal result was inferred.')

if __name__ == '__main__':
    main()
