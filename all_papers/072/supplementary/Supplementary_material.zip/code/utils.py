from collections import defaultdict
from io import StringIO
import json
import os
import random
import re
from pprint import pprint

from openai.types import CompletionUsage
from termcolor import colored


DOMAINS = ['hotel', 'restaurant', 'attraction', 'train', 'taxi']

DATA_DIR = 'data/mwoz/origin'
DATA_PATH = 'data/mwoz/origin/data.json'

DB_PATH = 'data/mwoz/db/multiwoz.db'
BOOK_DB_PATH = 'data/mwoz/db/multiwoz_book.db'

RETRIEVE_MODE = ['belief', 'user']  # e.g., combination of user and belief, or user, or belief
# RETRIEVE_MODE = ['user']
USER_BELIEF_EMBED_PATH = 'data/mwoz/user_belief_embed.pkl'
USER_EMBED_PATH = 'data/mwoz/user_embed.pkl'
BELIEF_EMBED_PATH = 'data/mwoz/belief_embed.pkl'

OPENAI_API_KEY = os.environ['OPENAI_API_KEY']
print(f'{OPENAI_API_KEY = }')

HEADER_WIDTH = 50
HEADER_COLOR = '\u001b[1;31m'
USER_COLOR = HEADER_COLOR
AGENT_COLOR = HEADER_COLOR
MID_COLOR = '\u001b[1;33m'
MID2_COLOR = '\u001b[1;35m'
RESET_COLOR = '\u001b[0m'

OPENAI_PRICE = {
    'gpt-4o-mini-2024-07-18': {
        'input': 0.15 / 1e6,
        'output': 0.6 / 1e6,
    },
    'gpt-4o-2024-08-06': {
        'input': 2.5 / 1e6,
        'output': 10.0 / 1e6,
    },
    'gpt-4-0613': {
        'input': 30.0 / 1e6,
        'output': 60.0 / 1e6,
    },
    'gpt-3.5-turbo-0125': {
        'input': 0.5 / 1e6,
        'output': 1.5 / 1e6,
    },
    'gpt-4.1-2025-04-14': {
        'input': 2.0 / 1e6,
        'output': 8.0 / 1e6,
    },
    'gpt-4.1-mini-2025-04-14': {
        'input': 0.4 / 1e6,
        'output': 1.6 / 1e6,
    },
}

ACT_SLOTS = {'dest': 'destination',
             'depart': 'departure',
             'ref': 'reference',
             'arrive': 'arriveBy',
             'addr': 'address',
             'post': 'postcode',
             'leave': 'leaveAt'}


class TableItem:

    def __repr__(self):
        d = {k: v for k, v in self.__dict__.items() if not k.startswith('_')}
        s = StringIO()
        pprint(d, stream=s)
        s = s.getvalue().strip()
        text = self.__tablename__.capitalize() + ':\n' + s
        return text
    
    def json_serialize(self):
        d = {'type': self.__tablename__.capitalize()}
        for k, v in self.__dict__.items():
            if not k.startswith('_'):
                d[k] = v
        return d
    

def json_default_func(obj):
    if isinstance(obj, TableItem):
        return obj.json_serialize()
    else:
        raise TypeError(f'Object of type {obj.__class__.__name__} '
                        f'is not JSON serializable')


def calc_openai_cost(model, usage):
    usage = usage.dict() if isinstance(usage, CompletionUsage) else usage
    if OPENAI_PRICE.get(model):
        price = OPENAI_PRICE[model]
        try:
            cost = usage['prompt_tokens'] * price['input'] + usage['completion_tokens'] * price['output']
        except TypeError as e:
            cost = usage.prompt_tokens * price['input'] + usage.completion_tokens * price['output']
    # elif model.startswith('text-davinci'):
    #     price = OPENAI_PRICE['text-davinci']
    #     cost = usage['total_tokens'] * price['text']
    else:
        raise ValueError(f'{model = }')
    return cost


def clean_time(time):
    time = time.lower()
    time = time.replace('after', '') 
    time = time.replace('before', '')
    time = time.replace('am', '')
    time = time.replace('pm', '')
    time = time.strip()
    time = '0' + time if re.fullmatch(r'\d:\d\d', time) else time
    return time


def clean_name(name):
    name = name.lower().strip()
    if name.startswith('the'):
        name = name[len('the'):]
    if name.endswith('restaurant'):
        name = name[:-len('restaurant')]
    if name.endswith('hotel'):
        name = name[:-len('hotel')]
    name = name.strip()
    return name


def prepare_goals_string(goals):
    if isinstance(goals, str):  # WOZxxx.json, One string
        result = re.match('Task \d{5}: (.*)', goals)
        assert result is not None
        goals = result[1].strip()
        goals = re.split('\.\s+', goals)
    goals_str = [msg if msg.endswith('.') else f'{msg}.' for msg in goals]
    goals_str = '\n'.join(goals_str)
    # Sub <span>xx<span> => xx
    goals_str = re.sub(r'<span\b[^>]*>(.*?)</span>', r'\1', goals_str)
    return goals_str


def load_data(data_path=DATA_PATH):
    with open(data_path) as f:
        data = json.load(f)

    # Remove dialogs in police & hospital
    data2 = {}
    for idx, dialog in data.items():
        if dialog['goal']['police'] or dialog['goal']['hospital']:
            continue
        data2[idx] = dialog
    data = data2

    return data


def load_data_split(split, data_path=DATA_PATH):
    with open(data_path) as f:
        data = json.load(f)

    with open(os.path.join(DATA_DIR, 'testListFile.txt')) as f:
        test_ids = set(f.read().strip().splitlines())
    with open(os.path.join(DATA_DIR, 'valListFile.txt')) as f:
        valid_ids = set(f.read().strip().splitlines())

    if split == 'train':
        data_split = {idx: dialog for idx, dialog in data.items() if idx not in test_ids and idx not in valid_ids}
    elif split == 'test':
        sub_test_ids = []
        test_ids = list(sorted(test_ids))
        for i in range(0, len(test_ids), int(len(test_ids) / 5.)):
            sub_test_ids.extend(test_ids[i:i + 20])
        data_split = {idx: dialog for idx, dialog in data.items() if idx in sub_test_ids}
        for idx, dialog in data.items():
            if idx in test_ids and idx not in sub_test_ids:
                data_split[idx] = dialog
    elif split == 'valid':
        data_split = {idx: dialog for idx, dialog in data.items() if idx in valid_ids}
    elif split == 'ablation':
        sub_test_ids = []
        test_ids = list(sorted(test_ids))
        for i in range(0, len(test_ids), int(len(test_ids) / 5.)):
            sub_test_ids.extend(test_ids[i:i + 20])
        data_split = {idx: dialog for idx, dialog in data.items() if idx in sub_test_ids}
    else:
        raise ValueError(f'{split = }')
    data = data_split

    # Remove dialogs in police & hospital
    data2 = {}
    for idx, dialog in data.items():
        if dialog['goal']['police'] or dialog['goal']['hospital']:
            continue
        data2[idx] = dialog
    data = data2

    return data


def print_dialog_goal(dialog, dialog_id):
    print(f'[Dialog Id] {dialog_id}', end='\n\n')

    goals = prepare_goals_string(dialog['goal']['message'])
    print(f'[User Goals]')
    print(goals, end='\n\n')

    for domain in ['restaurant', 'hotel', 'attraction', 'train', 'taxi']:
        if d := dialog['goal'][domain]:
            print(f'[{domain}]')
            pprint(d)
            print()


def pick_dialog(data, dialog_id='random', domain='all', exclusive=False):
    assert domain == 'all' or domain in DOMAINS

    if dialog_id == 'random':
        while True:
            dialog_id = random.choice(list(data.keys()))
            goal = data[dialog_id]['goal']
            if domain == 'all':
                break
            if exclusive:
                if goal[domain] and all(not goal[d] for d in DOMAINS if d != domain):
                    break
            else:
                if goal[domain]:
                    break
    else:
        assert dialog_id in data
    dialog = data[dialog_id]

    return dialog, dialog_id


def show_dialog_text(dialog):
    for i, turn in enumerate(dialog['log']):
        role = 'User' if i % 2 == 0 else 'AI Assistant'
        print(f'{role}: {turn["text"]}')


def tenacity_retry_log(retry_state):
    t = retry_state.next_action.sleep
    e = retry_state.outcome.exception()
    msg = f'Tenacity: Retrying call Agent in {t:.2f} seconds as it raise {e.__class__.__name__}: '
    msg = colored(msg, 'red', force_color=True) + str(e)
    print(msg)


def format_belief_span(metadata):
    belief = []
    for domain in metadata:
        belief_by_domain = []
        for attr, val in metadata[domain]['semi'].items():
            if val and val != 'not mentioned':
                belief_by_domain += [f'{attr}: {val}']
        for attr, val in metadata[domain]['book'].items():
            if attr == "booked":
                continue
            if val and val != 'not mentioned':
                belief_by_domain += [f'{attr}: {val}']
        if belief_by_domain:
            belief += [domain] + ['(' + ', '.join(belief_by_domain) + '),']
    return ' '.join(belief)


# def format_resp_template(resp, span_info):
#     if not span_info:
#         return resp
#     for act, attr, val, start, end in span_info:
#         resp = resp.replace(val, f'[value_{attr.lower().replace(" ", "_")}]')
#     return resp
