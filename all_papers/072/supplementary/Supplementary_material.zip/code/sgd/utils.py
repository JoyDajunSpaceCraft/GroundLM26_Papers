import json
import os
import random

from termcolor import cprint


DATA_DIR = 'data/sgd/origin'

INFO_DB_PATH = 'data/sgd/db/sgd.db'
TRANS_DB_PATH = 'data/sgd/db/sgd_trans.db'

# RETRIEVE_MODE = ['belief']  # e.g., combination of user and belief, or user, or belief
RETRIEVE_MODE = ['user', 'belief']
USER_BELIEF_EMBED_PATH = 'data/sgd/user_belief_embed.pkl'
USER_EMBED_PATH = 'data/sgd/user_embed.pkl'
BELIEF_EMBED_PATH = 'data/sgd/belief_embed.pkl'

schemas = None


def load_schemas(data_dir=DATA_DIR):
    global schemas

    if schemas is not None:
        return schemas

    schema_list = []
    with open(os.path.join(data_dir, 'train', 'schema.json')) as f:
        schema_list += json.load(f)
    with open(os.path.join(data_dir, 'dev', 'schema.json')) as f:
        schema_list += json.load(f)
    with open(os.path.join(data_dir, 'test', 'schema.json')) as f:
        schema_list += json.load(f)

    schemas = {schema['service_name']: schema for schema in schema_list}
    return schemas


dialogs = None


def load_dialogs(data_dir=DATA_DIR):
    global dialogs

    if dialogs is not None:
        return dialogs

    dialogs = []
    dialogs += load_dialogs_split('train', data_dir=data_dir)
    dialogs += load_dialogs_split('dev', data_dir=data_dir)
    dialogs += load_dialogs_split('test', data_dir=data_dir)

    dialogs = {d['dialogue_id']: d for d in dialogs}

    print(f'Loading completed. {len(dialogs)} dialogs loaded.')
    return dialogs


def load_dialogs_split(split, data_dir=DATA_DIR):
    dialogs = []
    base_split = 'test' if split == 'ablation' else split
    data_sub_dir = os.path.join(data_dir, base_split)
    print(f'Loading dialogs from "{data_sub_dir}"...')
    for name in os.listdir(data_sub_dir):
        if name.startswith('dialogues_'):
            with open(os.path.join(data_sub_dir, name)) as f:
                dialogs += json.load(f)
    for dialog in dialogs:
        dialog['dialogue_id'] = base_split + '_' + dialog['dialogue_id']

    if split == 'ablation':
        if os.path.exists(os.path.join(data_dir, 'ablation_ids.txt')):
            select_ids = open(os.path.join(data_dir, 'ablation_ids.txt')).read().splitlines()
            dialog_id_idx = {dialog['dialogue_id']: idx for idx, dialog in enumerate(dialogs)}
            dialogs = [dialogs[dialog_id_idx[dial_id]] for dial_id in select_ids]
        else:
            random.shuffle(dialogs)
            dialogs = dialogs[:1000]
            select_ids = [dialog['dialogue_id'] for dialog in dialogs]
            with open(os.path.join(data_dir, 'ablation_ids.txt'), 'w') as f:
                f.write('\n'.join(select_ids))
    return dialogs


def pick_dialog(dialogs, dialog_id='random'):
    if dialog_id == 'random':
        dialog_id = random.choice(list(dialogs.keys()))
    else:
        assert dialog_id in dialogs
    dialog = dialogs[dialog_id]

    return dialog


def show_dialog(dialog):
    for turn in dialog['turns']:
        if turn['speaker'] == 'USER':
            cprint('        User: ', 'blue', attrs=['bold'], force_color=True, end='')
            cprint(turn['utterance'], 'blue', force_color=True)
        else:
            cprint('AI Assistant: ', 'yellow', attrs=['bold'], force_color=True, end='')
            cprint(turn['utterance'], 'yellow', force_color=True)


def show_dialog_goals(goals):
    for service_name, service_goals in goals.items():
        print('service: ', end='')
        cprint(service_name, 'red', attrs=['bold'], force_color=True)
        for intent_name, intent_goals in service_goals.items():
            print(f'  intent: ', end='')
            cprint(intent_name, 'green', attrs=['bold'], force_color=True)
            inform_str = [f"{s} = {vd['canonical_value']}" for s, vd in intent_goals['inform'].items()]
            inform_str = ', '.join(inform_str)
            print('     inform:', inform_str)
            print('    request:', intent_goals['request'])


def format_belief_span(belief_dict, metadata):
    for service_info in metadata:
        slot_values = service_info['state']['slot_values']
        if not slot_values:
            continue

        service = service_info['service']
        if service not in belief_dict:
            belief_dict[service] = {}
        for k, v in slot_values.items():
            belief_dict[service][k] = v[0]

    belief = []
    for service in belief_dict:
        belief += [service.split("_")[0]]
        belief_by_domain = [f'{attr}: {val}' for attr, val in belief_dict[service].items()]
        belief += ['(' + ', '.join(belief_by_domain) + '),']

    return belief_dict, ' '.join(belief)
