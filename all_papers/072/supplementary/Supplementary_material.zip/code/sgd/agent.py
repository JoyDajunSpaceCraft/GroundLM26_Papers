import json
import os
import pickle
from functools import partial
from typing import List

import numpy as np
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from openai.types.chat import ChatCompletionMessage
from termcolor import cprint
from tqdm import tqdm

from base_agent import BaseAgent
from sgd.function_schema import make_function_schemas
from sgd.functions import sgd_function
from sgd.utils import load_schemas, RETRIEVE_MODE, USER_BELIEF_EMBED_PATH, BELIEF_EMBED_PATH, USER_EMBED_PATH, \
    format_belief_span, load_dialogs_split

from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.tools.retriever import create_retriever_tool

from pydantic import PrivateAttr
import faiss

GREEN_COLOR = '\u001b[1;32m'
MAG_COLOR = '\u001b[1;35m'
CYAN_COLOR = '\u001b[1;36m'
RESET_COLOR = '\u001b[0m'

TEMPLATE = '''The AI Assistant is an intelligent agent that helps the user complete complex tasks, which may involve several sub-tasks. 

The AI Assistant will receive the user's utterance with a set of relevant past conversation turns provided as references.
The AI Assistant MUST first identify the sub-tasks implied by the user's request and determine the necessary next actions required to fulfill the request. 
The AI Assistant MUST use the appropriate functions to gather accurate and up-to-date information needed to proceed.

# Important Guidelines:

- The reference conversation turns are provided only to give contextual insight into how similar requests were handled in the past.
- Do not reuse or rely on specific content from the references in the actual response.
- Any factual or task-related information must be verified using function calls, not inferred from the references.

The AI Assistant is always friendly and polite.


The functions are divided into query function and transaction function. The query function will return the records in the database that meets the conditions, and the transaction function will return the corresponding reference number if calling successfully.

Today is 2019-03-01, Friday. (This Saturday is 2019-03-02. This Sunday is 2019-03-03.)

{services_info}

# Remember

- Don't make assumptions about what values to plug into functions. Ask for clarification if any parameter is missing or ambiguous.
- Before calling a transaction function for the user, such as transfer money and book restaurants, the AI Assistant MUST show all the function parameters and confirm with the user.
- You must not call the same function with the same parameters again and again.
- When finishing the user's goals, saying goodbye to the user and finish the dialogue.
'''

SERVICE_TEMPLATE = '''# Service: {service_name}

## Description

{service_desc}

## Functions

{functions_info}
'''


EXAMPLE = '''
# Service: Buses_1

## Description

Book bus journeys from the biggest bus network in the country.

## Functions

- FindBus: Find a bus journey for a given pair of cities. (Query function)
- BuyBusTicket: Buy tickets for a bus journey. (Transaction function)
'''


BELIEF_TEMPLATE = '''You are a belief state tracker for task-oriented dialogue systems.

Your job is to extract the updated **user belief state** at the current turn based on:
- The **conversation history**
- The **cumulative belief state** based on the history
- The **new user utterance **

A belief state consists of slot-value pairs that capture the user's stated constraints or preferences, grouped by domain (e.g., hotel, train, restaurant).


# Instructions:
1. Extract **the current belief state**.
2. The cumulative belief state is provided as a guidance. It can be wrong. Please verify it.
3. The **provided cumulative belief state** is a reference and **may contain errors**. Please verify it.
4. If the user has **not yet provided any constraint**, return `-`.
5. Today is 2019-03-01, Friday. (This Saturday is 2019-03-02. This Sunday is 2019-03-03.)


# Output format: <DomainName> (slot1: value1, slot2: value2, ...), <AnotherDomain> (slotX: valueX, ...)
## Valid example output: hotel (price: cheap, internet: yes, people: 4), restaurant (food: italian)
## Invalid example output: hotel (price: cheap), hotel (internet: yes, people: -), restaurant (-)


# Valid domains and slots:

{service_schemas}


Start belief state tracking!

Conversation history:
{chat_history}

Belief state of the history: {belief_history}

User: {user_input}

New belief state: '''


class DialogueRetriever(BaseRetriever):
    _embeddings: OpenAIEmbeddings = PrivateAttr()
    _k: int = PrivateAttr()
    _final_k: int = PrivateAttr()
    _mode: List[str] = PrivateAttr()
    _index: faiss.IndexFlatL2 = PrivateAttr()
    _vectors: List[np.ndarray] = PrivateAttr()
    _docs: List[Document] = PrivateAttr()

    def __init__(self, docs, embeddings, mode, k=3, **kwargs):
        super().__init__(**kwargs)
        self._embeddings = embeddings  # store embedding model
        self._k = k
        self._mode = mode

        texts = [doc.page_content for doc in docs]
        self._docs = docs  # store original docs

        if "user" in RETRIEVE_MODE and "belief" in RETRIEVE_MODE:
            embed_path = USER_BELIEF_EMBED_PATH
        elif "belief" in RETRIEVE_MODE:
            embed_path = BELIEF_EMBED_PATH
        else:
            embed_path = USER_EMBED_PATH

        self._index, self._vectors = self._build_faiss(texts, embed_path)

    def _build_faiss(self, texts, save_path, batch_size=256):
        if os.path.exists(save_path):
            print(f'loading faiss index of length={len(texts)}, {save_path}')
            with open(save_path, "rb") as f:
                vectors = pickle.load(f)
        else:
            print(f'building faiss index of length={len(texts)}, {save_path}')
            vectors = []
            for i in tqdm(range(0, len(texts), batch_size)):
                batch = texts[i: i + batch_size]  # slice batch
                batch_vectors = self._embeddings.embed_documents(batch)  # embed batch
                vectors.extend(batch_vectors)  # store results
            with open(save_path, "wb") as f:
                pickle.dump(vectors, f)

        vectors_np = np.array(vectors).astype("float32")
        dim = vectors_np.shape[1]  # Vector dimension
        index = faiss.IndexFlatL2(dim)  # Use L2 similarity
        index.add(vectors_np)  # Add vectors to FAISS index

        return index, vectors_np

    def get_relevant_documents(self, query):

        q_embed = self._embeddings.embed_query(query)
        D, I = self._index.search(np.array([q_embed]), self._k)

        references = []
        for idx, i in enumerate(I[0]):
            doc = self._docs[i]
            response_text = (f"--- #{idx+1} ---\n{doc.page_content}\n"
                             f"Function calls: {doc.metadata['service_calls']}\n"
                             f"Assistant: {doc.metadata['response']}")
            references.append(Document(page_content=response_text, metadata=doc.metadata))

        return references

    # async def _aget_relevant_documents(self, query: str) -> List[Document]:
    #     return self.get_relevant_documents(query)

def prepare_retriever_tool():

    data = {d['dialogue_id']: d for d in load_dialogs_split('train')}
    dialogues = []
    sanity_check = 0
    for dial_id, content in data.items():
        belief_dict = {}
        for turn_id in range(0, len(content['turns']), 2):
            user_utt = content['turns'][turn_id]['utterance']
            belief_dict, belief = format_belief_span(belief_dict, content['turns'][turn_id]['frames'])
            service_calls = []
            for frame in content['turns'][turn_id + 1]['frames']:
                if not frame.get("service_call"):
                    continue
                service_call = frame["service_call"]["method"]
                service_call += f' ({", ".join([f"{k}: {v}" for k, v in frame["service_call"]["parameters"].items()])})'
                service_calls.append(service_call)
            service_calls = ", ".join(service_calls) if service_calls else "-"
            response = content['turns'][turn_id + 1]['utterance']
            belief = "-" if not belief else belief

            page_content = ''
            page_content += f'User: {user_utt}\n' if 'user' in RETRIEVE_MODE else ''
            page_content += f'Belief state: {belief}\n' if 'belief' in RETRIEVE_MODE else ''
            page_content = page_content.strip()

            metadata = {'user': user_utt,
                        'belief': belief,
                        'service_calls': service_calls,
                        'response': response}
            dialogues.append(Document(page_content=page_content, metadata=metadata))

            if sanity_check > 0:
                print(f'Dialogue: {dial_id}, Turn: {turn_id+1}-{turn_id+2}\n'
                      f'{dialogues[-1].page_content}\n'
                      f'Function calls: {service_calls}\n'
                      f'Assistant: {dialogues[-1].metadata["response"]}\n')
                sanity_check -= 1

    retriever = DialogueRetriever(docs=dialogues, embeddings=OpenAIEmbeddings(), mode=RETRIEVE_MODE, k=3)

    tool = create_retriever_tool(retriever,
                                 name='Reference Response Search',
                                 description='Find similar past conversations and how the assistant responded.'
                                 )
    return tool


RETRIEVER = prepare_retriever_tool()


class SgdAgent(BaseAgent):

    def __init__(self, model_name, service_names, callbacks=[]):
        self.service_names = service_names
        self.sgd_schemas = load_schemas()
        assert all(name in self.sgd_schemas for name in service_names)
        self.retriever = RETRIEVER

        super().__init__(model_name, callbacks)

        self.function_parameters = self.make_function_parameters()

    def make_system_prompt(self):
        services_info = []
        for service_name in self.service_names:
            service_schema = self.sgd_schemas[service_name]
            functions_info = []
            for intent in service_schema['intents']:
                func_info = f'- {service_name}_{intent["name"]}: {intent["description"]}.'
                if not intent['is_transactional']:
                    func_info += ' (Query function)'
                else:
                    func_info += ' (Transaction function)'
                functions_info.append(func_info)
            functions_info = '\n'.join(functions_info)
            service_info = SERVICE_TEMPLATE.format(service_name=service_name,
                                                   service_desc=service_schema['description'],
                                                   functions_info=functions_info)
            services_info.append(service_info)
        services_info = '\n\n'.join(services_info)

        prompt = TEMPLATE.format(services_info=services_info)
        return prompt

    def make_function_schemas(self):
        functions = make_function_schemas(self.service_names)
        return functions

    def make_function_map(self):
        function_map = {}
        for service_name in self.service_names:
            service_schema = self.sgd_schemas[service_name]
            for intent in service_schema['intents']:
                intent_name = intent['name']
                func_name = f'{service_name}_{intent_name}'
                func = partial(sgd_function, service_name=service_name, intent_name=intent_name)
                function_map[func_name] = func
        return function_map
    
    def fix_function_call(self, function_call):
        if not isinstance(function_call, dict):
            return function_call
        if 'name' not in function_call:
            return function_call
        
        name = function_call['name']
        if (fixed_name := name.split('.')[-1]) != name:
            cprint(f'Fix function name: {name} => {fixed_name}', 'yellow')
            function_call['name'] = fixed_name

        return function_call

    def make_function_parameters(self):
        services_params = []
        for service_name in self.service_names:
            service_schema = self.sgd_schemas[service_name]
            services_params.append(f'### {service_name.split("_")[0]}')
            for slot in service_schema['slots']:
                slot_name = slot['name']
                slot_desc = slot['description']
                services_params.append(f'- {slot_name}: {slot_desc}')
        return services_params

    def get_clean_chat_history(self):
        no_ref_lines = []
        no_additional_lines = []
        for i, msg in enumerate(self.messages):
            if msg['role'] == 'user':
                # Skip reference injection from user message
                if "References (Relevant past conversation turns):" in msg['content']:
                    cleaned = msg['content'].split("References (Relevant past conversation turns):")[0].strip()
                    no_ref_lines.append(f"{cleaned}")
                    cleaned = cleaned.split("\n")[0]
                    no_additional_lines.append(f"{cleaned}")
                else:
                    no_ref_lines.append(f"{msg['content']}")
                    cleaned = msg['content'].split("\n")[0]
                    no_additional_lines.append(f"User: {cleaned}")
            elif msg['role'] == 'assistant':
                no_ref_lines.append(f"Assistant: {msg['content']}")
                no_additional_lines.append(f"Assistant: {msg['content']}")
        return no_ref_lines, no_additional_lines

    def belief_state_tracking(self, user_utter, pure_chat_history, chat_history_no_ref):

        belief_history = chat_history_no_ref[-2].split("Belief state:")[-1].strip() if chat_history_no_ref else "-"

        belief_input = BELIEF_TEMPLATE.format(service_schemas='\n'.join(self.function_parameters),
                                              chat_history="\n".join(pure_chat_history) if pure_chat_history else "-",
                                              belief_history=belief_history,
                                              user_input=user_utter)

        message = [{'role': 'user', 'content': belief_input}]
        belief = self.chat(message, include_functions=False).content
        belief = belief.split("New belief state:")[-1].strip()

        print(CYAN_COLOR + f"\nBelief chain: \n "
                           f"-- Belief history: {belief_history}\n "
                           f"-- New belief state: {belief}\n"
              + RESET_COLOR, end='\n')

        return belief

    def __call__(self, user_utter):
        self.turn_idx += 1

        chat_history_no_ref, pure_chat_history = self.get_clean_chat_history()  # no reference, only chat

        # belief state
        belief = ''
        if 'belief' in RETRIEVE_MODE:
            belief = self.belief_state_tracking(user_utter, pure_chat_history, chat_history_no_ref)

        query_text = ""
        query_text += f"User: {user_utter}\n" if 'user' in RETRIEVE_MODE else ""
        query_text += f"Belief state: {belief}\n" if 'belief' in RETRIEVE_MODE else ""
        query_text = query_text.strip()

        user_reformat = ""
        user_reformat += f"User: {user_utter}\n"  # always include user utterance
        user_reformat += f"Belief state: {belief}\n" if 'belief' in RETRIEVE_MODE else ""
        user_reformat = user_reformat.strip()

        # search
        retrieved_context = self.retriever.run(query_text)
        reference_note = f"\n-- DO NOT USE ANY INFORMATION FROM HERE WHEN CALLING FUNCTIONS. THESE ARE ONLY REFERENCES TO DETERMINE APPROPRIATE ACTION. --\n"
        user_utter_with_refs = (f"{user_reformat}\n\n"
                                f"References (Relevant past conversation turns):"
                                f"\n{reference_note}"
                                f"\n{retrieved_context}")

        cprint(f'{user_utter_with_refs}', color='blue', attrs=['bold'], force_color=True, end='\n\n')

        self.messages.append({'role': 'user', 'content': user_utter_with_refs})
        last_function_call = None
        extra_openai_args = {}
        while True:
            msg = self.chat(self.messages, extra_openai_args)
            msg = msg.dict() if isinstance(msg, ChatCompletionMessage) else msg
            # BUG: no assistant message

            # Assistant Response
            if msg['content'] is not None:
                agent_utter = msg['content']

                for callback in self.callbacks:
                    agent_utter = callback.on_turn_end(agent_utter, self.turn_idx)

                self.messages.append({'role': 'assistant', 'content': agent_utter})

                return agent_utter.strip(), query_text, retrieved_context

            # Avoid repeat function calling
            if msg.get('function_call') == last_function_call:
                print('Repeat function calling. Force AI Assistant to response.')
                extra_openai_args = {'function_call': 'none'}
                continue
            last_function_call = msg.get('function_call')

            # Function calling Error
            function_call = msg.get('function_call')
            function_call = self.fix_function_call(function_call)
            passed, check_msg = self.check_function_call(function_call)
            if not passed:
                print()
                print('Function parsing error:')
                print(f'function_call: {msg.get("function_call")}')
                result = check_msg
                if msg.get('function_call') and msg['function_call'].get('name'):
                    name = msg['function_call']['name']
                else:
                    name = None
                print('Result: ' + CYAN_COLOR + f'{result}' + RESET_COLOR)
                self.messages.append({'role': 'function', 'name': name, 'content': result})
                continue

            # Function calling Right
            function_call = msg['function_call']
            name, args = function_call['name'], function_call['arguments']
            func = self.function_map[name]
            args = json.loads(args)
            result = func(**args)
            print()
            print('Function: ' + MAG_COLOR + f'{name}' + RESET_COLOR)
            print('Arguments: ' + GREEN_COLOR + f'{args}' + RESET_COLOR)
            for callback in self.callbacks:
                callback.on_function_call_end(name, args, result)

            print('Result: ' + CYAN_COLOR + f'{result}' + RESET_COLOR)
            self.messages.append({'role': 'function', 'name': name, 'content': result})
