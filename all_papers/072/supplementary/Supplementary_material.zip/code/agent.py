import json
import os.path
import pickle
import re
from typing import Any, Dict, Optional, List

import numpy as np
from langchain import SQLDatabase
from langchain.chat_models import init_chat_model
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from langchain_core.tools import BaseTool
from langchain_experimental.sql.base import SQLDatabaseChain
from langchain.agents import AgentExecutor, ConversationalAgent, Tool, create_tool_calling_agent
from langchain.agents.conversational.output_parser import ConvoOutputParser
from langchain.callbacks.manager import CallbackManagerForChainRun
from langchain.chains import LLMChain
# from langchain.llms import OpenAI
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.schema import AIMessage, HumanMessage
from tqdm import tqdm

from booking import book_hotel, book_restaurant, book_taxi, book_train
# from client import MyOpenAI
from prompts import AGENT_TEMPLATE, DB_TEMPLATE_DICT, BELIEF_TEMPLATE
from utils import (AGENT_COLOR, DB_PATH, HEADER_COLOR, HEADER_WIDTH,
                   RESET_COLOR, USER_COLOR, load_data_split, RETRIEVE_MODE, USER_EMBED_PATH, BELIEF_EMBED_PATH,
                   format_belief_span, MID_COLOR, MID2_COLOR, USER_BELIEF_EMBED_PATH)

from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.tools.retriever import create_retriever_tool

from pydantic import PrivateAttr
import faiss


class DialogueRetriever(BaseRetriever):
    _embeddings: OpenAIEmbeddings = PrivateAttr()
    _k: int = PrivateAttr()
    _final_k: int = PrivateAttr()
    _mode: List[str] = PrivateAttr()
    _index: faiss.IndexFlatL2 = PrivateAttr()
    _vectors: List[np.ndarray] = PrivateAttr()
    _docs: List[Document] = PrivateAttr()

    def __init__(self, docs, embeddings, mode, k=3, **kwargs):
        super().__init__(**kwargs)
        self._embeddings = embeddings  # store embedding model
        self._k = k
        self._mode = mode

        texts = [doc.page_content for doc in docs]
        self._docs = docs  # store original docs

        if "user" in RETRIEVE_MODE and "belief" in RETRIEVE_MODE:
            embed_path = USER_BELIEF_EMBED_PATH
        elif "belief" in RETRIEVE_MODE:
            embed_path = BELIEF_EMBED_PATH
        else:
            embed_path = USER_EMBED_PATH

        self._index, self._vectors = self._build_faiss(texts, embed_path)

    def _build_faiss(self, texts, save_path, batch_size=256):
        if os.path.exists(save_path):
            print(f'loading faiss index of length={len(texts)}, {save_path}')
            with open(save_path, "rb") as f:
                vectors = pickle.load(f)
        else:
            print(f'building faiss index of length={len(texts)}, {save_path}')
            vectors = []
            for i in tqdm(range(0, len(texts), batch_size)):
                batch = texts[i: i + batch_size]  # slice batch
                batch_vectors = self._embeddings.embed_documents(batch)  # embed batch
                vectors.extend(batch_vectors)  # store results
            with open(save_path, "wb") as f:
                pickle.dump(vectors, f)

        vectors_np = np.array(vectors).astype("float32")
        dim = vectors_np.shape[1]  # Vector dimension
        index = faiss.IndexFlatL2(dim)  # Use L2 similarity
        index.add(vectors_np)  # Add vectors to FAISS index

        return index, vectors_np

    def get_relevant_documents(self, query):

        q_embed = self._embeddings.embed_query(query)
        D, I = self._index.search(np.array([q_embed]), self._k)

        references = []
        for idx, i in enumerate(I[0]):
            doc = self._docs[i]
            response_text = f"--- #{idx+1} ---\n{doc.page_content}\nAssistant: {doc.metadata['response']}"
            references.append(Document(page_content=response_text, metadata=doc.metadata))

        return references

    # async def _aget_relevant_documents(self, query: str) -> List[Document]:
    #     return self.get_relevant_documents(query)


class SQLDatabaseChainWithCleanSQL(SQLDatabaseChain):

    def _call(
        self,
        inputs: Dict[str, Any],
        run_manager: Optional[CallbackManagerForChainRun] = None,
    ) -> Dict[str, Any]:
        _run_manager = run_manager or CallbackManagerForChainRun.get_noop_manager()
        input_text = f"{inputs[self.input_key]}\nSQLQuery:"
        _run_manager.on_text(input_text, verbose=self.verbose)
        # If not present, then defaults to None which is all tables.
        table_names_to_use = inputs.get("table_names_to_use")
        table_info = self.database.get_table_info(table_names=table_names_to_use)
        llm_inputs = {
            "input": input_text,
            "top_k": self.top_k,
            "dialect": self.database.dialect,
            "table_info": table_info,
            "stop": ["\nSQLResult:"],
        }
        intermediate_steps = []
        sql_cmd = self.llm_chain.predict(
            callbacks=_run_manager.get_child(), **llm_inputs
        )
        sql_cmd = self.clean_sql(sql_cmd)  # NOTE: This is the new line
        intermediate_steps.append(sql_cmd)
        _run_manager.on_text(sql_cmd, color="green", verbose=self.verbose)
        result = self.database.run(sql_cmd)
        intermediate_steps.append(result)
        _run_manager.on_text("\nSQLResult: ", verbose=self.verbose)
        _run_manager.on_text(result, color="yellow", verbose=self.verbose)
        # If return direct, we just set the final result equal to the sql query
        if self.return_direct:
            final_result = result
        else:
            _run_manager.on_text("\nAnswer:", verbose=self.verbose)
            input_text += f"{sql_cmd}\nSQLResult: {result}\nAnswer:"
            llm_inputs["input"] = input_text
            del llm_inputs["stop"]
            final_result = self.llm_chain.predict(
                callbacks=_run_manager.get_child(), **llm_inputs
            )
            _run_manager.on_text(final_result, color="green", verbose=self.verbose)
        chain_result: Dict[str, Any] = {self.output_key: final_result}
        if self.return_intermediate_steps:
            chain_result["intermediate_steps"] = intermediate_steps
        return chain_result
    
    def clean_sql(self, sql_cmd):
        sql_cmd = sql_cmd.strip()
        if "```sql" in sql_cmd:
            sql_cmd = sql_cmd.split("```sql")[1].strip()  # only the first sql after ```sql in case there are more
        if "SQLQuery:" in sql_cmd:
            sql_cmd = sql_cmd.split("SQLQuery:")[1].strip()  # only the first sql after SQLQuery: in case there are more
        if "```" in sql_cmd:
            sql_cmd = sql_cmd.split("```")[0].strip()
        if sql_cmd[0] == '"' and sql_cmd[-1] == '"':
            sql_cmd = sql_cmd[1:-1]
        if sql_cmd[0] == "'" and sql_cmd[-1] == "'":
            sql_cmd = sql_cmd[1:-1]

        def escape_inside_quotes(match):
            value = match.group(1)
            escaped = value.replace("'", "''")
            return f"'{escaped}'"

        sql_cmd = re.sub(r"'([^']*?)'", escape_inside_quotes, sql_cmd)
        sql_cmd = sql_cmd.replace("'s ", "''s ")

        if '\\' in sql_cmd:
            sql_cmd = sql_cmd.replace("\\", "")
        sql_cmd = sql_cmd.strip()

        sql_cmd = re.sub(r"name (=|LIKE) '(.*'.*)'", r'name \1 "\2"', sql_cmd)
        return sql_cmd


class Agent:

    def __init__(self, model='gpt-4o-mini-2024-07-18'):
        self.model = model
        self.llm = None
        self.retriever_tool = None
        self.agent_executor = None
        self.reset()

    def reset(self):
        self.agent_executor, self.retriever_tool, self.llm = self.prepare_agent_executor(self.model)

    @staticmethod
    def prepare_retriever_tool():

        data = load_data_split('train')
        dialogues = []
        sanity_check = 0
        for dial_id, content in data.items():
            for turn_id in range(0, len(content['log']), 2):
                user_utt = content['log'][turn_id]['text']
                belief = format_belief_span(content['log'][turn_id + 1]['metadata'])
                response = content['log'][turn_id + 1]['text']
                belief = "-" if not belief else belief

                page_content = ''
                page_content += f'User: {user_utt}\n' if 'user' in RETRIEVE_MODE else ''
                page_content += f'Belief state: {belief}\n' if 'belief' in RETRIEVE_MODE else ''
                page_content = page_content.strip()

                metadata = {'user': user_utt,
                            'belief': belief,
                            'response': response}
                dialogues.append(Document(page_content=page_content, metadata=metadata))

                if sanity_check > 0:
                    print(f'Dialogue: {dial_id}, Turn: {turn_id+1}-{turn_id+2}\n'
                          f'{dialogues[-1].page_content}\n'
                          f'Assistant: {dialogues[-1].metadata["response"]}\n')
                    sanity_check -= 1

        retriever = DialogueRetriever(docs=dialogues, embeddings=OpenAIEmbeddings(), mode=RETRIEVE_MODE, k=3)

        tool = create_retriever_tool(retriever,
                                     name='Reference Response Search',
                                     description='Find similar past conversations and how the assistant responded.'
                                     )
        return tool

    @staticmethod
    def prepare_db_tools(llm):
        DB_URI = f'sqlite:///{DB_PATH}'

        def prepare_db_one_tool(domain, name):
            db = SQLDatabase.from_uri(
                database_uri=DB_URI,
                include_tables=[domain],
                sample_rows_in_table_info=5,
            )
            db_prompt = PromptTemplate.from_template(DB_TEMPLATE_DICT[domain])
            sql_chain = SQLDatabaseChainWithCleanSQL.from_llm(
                db=db, llm=llm, prompt=db_prompt, top_k=10, verbose=True)
            tool = Tool(func=sql_chain.run, name=name, description='')
            return tool
        
        # domain (table, prompt), name
        db_info = [
            ('restaurant', 'Restaurant Query'),
            ('hotel', 'Hotel Query'),
            ('attraction', 'Attraction Query'),
            ('train', 'Train Query'),
        ]
        tools = []
        for domain, name in db_info:
            if domain not in DB_TEMPLATE_DICT:  # TODO
                continue
            tool = prepare_db_one_tool(domain, name)
            tools.append(tool)

        return tools

    @staticmethod
    def prepare_book_tools():
        tools = [
            Tool(func=book_restaurant, name='Restaurant Reservation', description=''),
            Tool(func=book_hotel, name='Hotel Reservation', description=''),
            Tool(func=book_train, name='Train Tickets Purchase', description=''),
            Tool(func=book_taxi, name='Taxi Reservation', description=''),
        ]
        return tools

    @staticmethod
    def prepare_agent_executor(model):
        # LLM
        assert (model.startswith('gpt-3.5-') or
                model.startswith('gpt-4o-') or
                model.startswith('gpt-4-'))

        llm = init_chat_model(model, model_provider="openai")

        # Agent
        HUMAN_PREFIX = 'Human'
        AI_PREFIX = 'AI Assistant'

        prompt_temp = PromptTemplate.from_template(AGENT_TEMPLATE)
        llm_chain = LLMChain(
            llm=llm,
            prompt=prompt_temp,
        )

        agent = ConversationalAgent(
            llm_chain=llm_chain,
            ai_prefix=AI_PREFIX,
            output_parser=ConvoOutputParser(ai_prefix=AI_PREFIX)
        )

        memory = ConversationBufferMemory(
            human_prefix=HUMAN_PREFIX,
            ai_prefix=AI_PREFIX,
            memory_key='chat_history',
        )

        # Tools
        retriever_tool = Agent.prepare_retriever_tool()
        db_tools = Agent.prepare_db_tools(llm)
        book_tools = Agent.prepare_book_tools()
        tools = db_tools + book_tools
        # tools = []
        # tools += [Agent.prepare_retriever_tool(memory)]
        # tools += Agent.prepare_db_tools(llm)
        # tools += Agent.prepare_book_tools()

        agent_executor = AgentExecutor.from_agent_and_tools(
            agent=agent,
            tools=tools,
            memory=memory,
            max_iterations=5,
            verbose=True,
            handle_parsing_errors=True
        )
        return agent_executor, retriever_tool, llm

    def get_clean_chat_history(self, memory):
        messages = memory.chat_memory.messages
        no_ref_lines = []
        no_additional_lines = []
        for i, msg in enumerate(messages):
            if isinstance(msg, HumanMessage):
                # Skip reference injection from user message
                if "References (Relevant past conversation turns):" in msg.content:
                    cleaned = msg.content.split("References (Relevant past conversation turns):")[0].strip()
                    no_ref_lines.append(f"{cleaned}")
                    cleaned = cleaned.split("\n")[0]
                    no_additional_lines.append(f"{cleaned}")
                else:
                    no_ref_lines.append(f"{msg.content}")
                    cleaned = msg.content.split("\n")[0]
                    no_additional_lines.append(f"User: {cleaned}")
            elif isinstance(msg, AIMessage):
                no_ref_lines.append(f"Assistant: {msg.content}")
                no_additional_lines.append(f"Assistant: {msg.content}")
        return no_ref_lines, no_additional_lines

    def __call__(self, user_utter, callbacks=None):
        # chat_history = self.agent_executor.memory.load_memory_variables({})["chat_history"]
        chat_history_no_ref, pure_chat_history = self.get_clean_chat_history(self.agent_executor.memory)  # no reference, only chat

        belief = ''
        if 'belief' in RETRIEVE_MODE:
            belief = self.belief_state_tracking(user_utter, pure_chat_history, chat_history_no_ref)

        query_text = ""
        query_text += f"User: {user_utter}\n" if 'user' in RETRIEVE_MODE else ""
        query_text += f"Belief state: {belief}\n" if 'belief' in RETRIEVE_MODE else ""
        query_text = query_text.strip()

        user_reformat = ""
        user_reformat += f"User: {user_utter}\n"  # always include user utterance
        user_reformat += f"Belief state: {belief}\n" if 'belief' in RETRIEVE_MODE else ""
        user_reformat = user_reformat.strip()

        retrieved_context = self.retriever_tool.run(query_text)
        reference_note = f"\n-- DO NOT USE ANY INFORMATION FROM HERE WHEN CALLING TOOLS. THESE ARE ONLY REFERENCES TO DETERMINE APPROPRIATE ACTION. --\n"
        user_utter_with_refs = (f"{user_reformat}\n\n"
                                f"References (Relevant past conversation turns):"
                                f"\n{reference_note}"
                                f"\n{retrieved_context}")
        print(MID_COLOR + f"User with refs: \n{user_utter_with_refs}" + RESET_COLOR, end='\n')

        agent_utter = self.agent_executor.run(user_utter_with_refs, callbacks=callbacks)
        agent_utter.strip()

        return agent_utter, query_text, retrieved_context

    def belief_state_tracking(self, user_utter, pure_chat_history, chat_history_no_ref):
        belief_prompt = PromptTemplate.from_template(BELIEF_TEMPLATE)
        belief_chain = LLMChain(
            llm=self.llm,
            prompt=belief_prompt,
        )

        belief_history = chat_history_no_ref[-2].split("Belief state:")[-1].strip() if chat_history_no_ref else "-"

        belief_input = {
            "chat_history": "\n".join(pure_chat_history) if pure_chat_history else "-",
            "belief_history": belief_history,  # belief based on the prev. user utterance
            "user_input": user_utter
        }
        belief = belief_chain.run(belief_input)

        belief = belief.split("New belief state:")[-1].strip()

        print(MID2_COLOR + f"\nBelief chain: \n "
                           f"-- Belief history: {belief_history}\n "
                           f"-- New belief state: {belief}\n"
              + RESET_COLOR, end='\n')

        return belief
    
    def run(self):
        self.reset()

        turn_idx = 1
        while True:
            print(HEADER_COLOR + '=' * HEADER_WIDTH + f' Turn {turn_idx} ' + '=' * HEADER_WIDTH + RESET_COLOR, end='\n\n')

            # User
            print(USER_COLOR + f'User: ', end='')
            user_input = input('User: ').strip()
            if user_input in ['exit', 'e']:
                break
            print(USER_COLOR + f'{user_input}' + RESET_COLOR, end='\n')

            # Agent
            agent_utter = self(user_input)
            print()
            print(AGENT_COLOR + f'AI Assistant: {agent_utter}' + AGENT_COLOR, end='\n\n')

            turn_idx += 1


if __name__ == '__main__':
    agent = Agent(model='gpt-4o-mini-2024-07-18')
    agent.run()
