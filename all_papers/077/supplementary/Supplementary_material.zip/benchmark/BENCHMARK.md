# GyroCompass — Benchmark Results (Class A: detection + performance)

_Reproducible, no external API. Run: `python benchmark/run_benchmark.py`._

## 1. Ship-readiness audit — detection accuracy vs. baseline

Across **54 labeled cases** (27 real violations + 27 realistic decoys). The decoys (parameterized SQL, env-var reads, placeholder keys, auth-guarded routes, patched deps) are what separate detection from naive pattern matching:

| Detector | Recall | Precision | F1 | FP rate (decoys) |
|---|---|---|---|---|
| Naive regex (grep-style) | 89% | 65% | 0.75 | 48% |
| **GyroCompass** | **100%** | **100%** | **1.00** | **0%** |

### By category

| Category | Recall | Precision | FP rate |
|---|---|---|---|
| auth | 100% | 100% | 0% |
| dependencies | 100% | 100% | 0% |
| injection | 100% | 100% | 0% |
| pii | 100% | 100% | 0% |
| secrets | 100% | 100% | 0% |

## 2. Rule engine — detection + scope precision

3 cases incl. a scope-precision test (same forbidden import is flagged in a route but correctly allowed in the db layer):

- Recall **100%** · Precision **100%** · FP rate **0%**

## 3. Indexing performance

| Repo | Files | Time (s) | Files/sec | Components |
|---|---|---|---|---|
| gyrocompass (self) | 31 | 0.07 | 413.6 | 8 |
| meridian-demo | 33 | 0.02 | 1778.4 | 8 |
| code-graph-rag | 336 | 0.43 | 780.8 | 21 |
| beads (Go) | 1090 | 1.31 | 830.1 | 58 |

---
_Methodology: labeled corpus with realistic decoys (env-var usage, parameterized SQL, placeholder keys, prose, auth-guarded routes, patched deps) so precision and false-positive rate are meaningful. All fixtures in `benchmark/run_benchmark.py`._