# Supplementary Results

Complete per-case results for the eight 7--9B instruction-tuned models
evaluated on the original CheckList sentiment, QQP, and SQuAD behavioral
suites (three diffusion models: LLaDA-8B, LLaDA-MoE, Dream-7B; five
autoregressive baselines: Llama-3.1, Mistral-7B, Qwen2.5-7B, Gemma-2-9B,
OLMo-2-7B).

## Layout

- `runs/<task>/<model>/per_case_results.csv` — one row per scored CheckList
  case: `test_name, test_type, capability, example_idx, predicted_label,
  expected_label, pass`. Case texts are not duplicated here; they are
  reconstructable from the public CheckList release data
  (https://github.com/marcotcr/checklist) referenced by `example_idx`
  within each test.
- `runs/<task>/<model>/summary_slim.json` — per-test aggregates
  (n_cases, n_fails, fail_rate, predicted-label counts) and run totals.
  Note: `n_cases` follows CheckList case semantics, where a case is an
  example group and fails if any member prompt fails; `per_case_results.csv`
  rows are individual prompts, so a naive mean over rows will not equal
  `fail_rate`. The paper's pass rates use the `n_cases`/`n_fails` figures,
  which match the paper's analysis tables cell for cell.
- `runs/<task>/<model>/run_metadata.json` — run configuration (prompts,
  decoding parameters, label sets). Local filesystem paths are redacted.
- `aggregates/` — the derived analysis tables (family and per-model pass
  rates, perturbation-coefficient summaries, bootstrap CIs, label-prior
  audit, option-order probes) that back the paper's figures and tables.

All pass-rate and coefficient numbers reported in the paper are derivable
from these files together with the code artifact submitted separately.
Full raw model generations are excluded for size; per-case predicted labels
and pass/fail outcomes are complete.
