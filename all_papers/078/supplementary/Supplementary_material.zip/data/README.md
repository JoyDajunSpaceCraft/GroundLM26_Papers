# DION-Bench Data Release

Camera-ready data release accompanying

> *When Targeted Grounded Gains Hide Complementary Abstraction Regression:
> DION-Bench and a Conjunctive Evaluation Protocol.*

Zida Yang\*, Guquan You\*, Jiexin Zheng\*, and Yijie Peng\*\*
(\* equal contribution; \*\* corresponding author).
Contact: `pengyijie@nju.edu.cn`.

DION-Bench is generated programmatically from open knowledge bases
(WordNet 3.0 + ConceptNet 5.7, sense-aware MultiDiGraph nodes). Every
OntoNeg-WN item in an *evaluation* split (`dev`, `test`, `conf`) carries
attested lexical evidence for the negation -- a dictionary gloss quoting the
negated pattern, or an explicit negative assertion -- rather than an
inference from a missing graph edge. Reported evaluation scores use only
these certified rows.

The released OntoNeg-WN *training* pool (`onto_neg_wn_train.jsonl`, 1,597
rows) still contains open-world heuristic rows tagged
`provenance.evidence_tier=kg_edge_absence` (1,313/1,597). **Checkpoints
reported in the paper were trained on this mixed pool**, so training-time
evidence noise remains a possible confounder for mechanism interpretations. A
follow-up subset is released as
`onto_neg_wn_train_certified_only.jsonl` (284 rows) for certified-only
retraining. The mixed-pool main ledger remains the multi-method comparison;
the paper's certified-only sensitivity results retrain on this 284-row subset.

Every ConceptShift item carries the two certified IsA ancestor paths that
justify its abstraction; every LogicRepair item is synthesized as a Horn
implication chain and its released MUS is verified with a SAT solver
(Glucose via PySAT). Surface forms for LogicRepair are styled after FOLIO
and ProofWriter, but no instance is taken from either corpus. Quality
statistics quoted in the paper come from the human audits under `audit/`.

## Layout

```
bench/
  onto_neg_wn_{train,dev,test,conf}.jsonl        1,597 / 100 / 500 / 200
  onto_neg_wn_train_certified_only.jsonl         284  (follow-up; not used for paper ckpts)
  concept_shift_{train,dev,test,conf}.jsonl      4,000 / 500 / 1,000 / 500
  logic_repair_{train,dev,test}.jsonl            4,000 / 500 / 1,000
audit/
  v1_stratified_audit.csv       # 500 OntoNeg + 400 ConceptShift + 220 LogicRepair
  conceptshift_1000_reaudit.csv # expanded three-rater re-audit
  specificity_taxonomy.csv      # human error taxonomy, 200 errors per configuration
  README.md
```

Total benchmark items in the primary split files: 13,897. `conf` is the
holdout used only after the decoding rule was fixed; it exists
for the two tasks the evaluation-time rule touches. Evaluation splits are
concept-family disjoint from training.

## Schemas

### OntoNeg-WN

```json
{
  "id": "onto_neg_wn_test_000000",
  "T": "tree farm",
  "A_star": "tundra",
  "E": "mestiza",
  "S": "land",
  "T_id": "wn:tree_farm.n.01",
  "A_star_id": "wn:tundra.n.01",
  "E_id": "wn:mestiza.n.01",
  "S_id": "wn:land.n.04",
  "missing_relation": "HasA | HasProperty",
  "attribute_object_label": "tree",
  "attribute_phrase": "has tree",
  "attribute_negation_phrase": "does not have tree",
  "candidates": ["silva", "forest", "mestiza", "tundra"],
  "candidate_ids": ["..."],
  "distance_T_A": 2,
  "external_relation": "parent_disjoint",
  "task": "inner_negation_selection",
  "attribute_evidence": {
    "attested_on_T_via": "sibling_gloss | category_gloss | sibling_attribute_edge",
    "affirmation_quote": "...",
    "negation_evidence": {"tier": "dictionary_negation | explicit_negative_fact",
                          "source": "WordNet gloss", "pattern": "treeless",
                          "quote": "..."},
    "candidate_exclusivity": {"siblings_with_attribute": ["..."],
                              "external_counterexample": "mestiza",
                              "rule": "..."},
    "graph_path": {"T": "...", "shared_parent": "...", "A_star": "..."}
  },
  "provenance": {"evidence_tier": "dictionary_negation", "certified": true,
                 "shared_parents": ["wn:land.n.04"],
                 "construction": "certified_attribute_exception"}
}
```

`A_star` is the same-category exception: it shares an IsA parent with `T`
and is the only candidate for which the shared-category attribute is
attested *not* to hold, quoted in `negation_evidence`. `E` is an unrelated
counter-example, parent-disjoint and distance-matched where a same-component
match exists. `S_id` is the resampling cluster.

### ConceptShift

```json
{
  "id": "concept_shift_test_000000",
  "T": "agon",
  "A": "ludi saeculares",
  "S": "celebration",
  "T_id": "wn:agon.n.01",
  "A_id": "wn:ludi_saeculares.n.01",
  "S_id": "wn:celebration.n.02",
  "S_alternatives": ["festivity", "diversion"],
  "relation": "Antonym | DistinctFrom",
  "task": "structured_concept_update",
  "provenance": {"lcs_path_depth": 2,
                 "ancestor_path_T": ["wn:agon.n.01", "wn:celebration.n.02"],
                 "ancestor_path_A": ["wn:ludi_saeculares.n.01",
                                     "wn:celebration.n.02"],
                 "edge_source": "shared_hypernym | wordnet_antonym | conceptnet_edge",
                 "sense_resolved": true,
                 "construction": "sense_resolved_lcs"}
}
```

Endpoints are sense-resolved and the ancestor paths walk IsA only. Absolute
abstraction accuracy (AbsAcc) accepts `S` or any audited entry of
`S_alternatives`; the appendix also rescores under a stricter single-gold set
and a permissive set that additionally accepts nodes on the certified
ancestor paths. `S_id` is the resampling cluster.

### LogicRepair

```json
{
  "id": "logic_repair_test_000000",
  "K": ["Uma is a stone.", "All stones are alive.", "..."],
  "a_star": "Uma is not opaque.",
  "MUS": ["Uma is a stone.", "All stones are alive.", "..."],
  "K_prime": ["..."],
  "chain": ["..."],
  "source": "synthetic",
  "task": "minimal_repair",
  "target_sentence": "Uma is a stone.",
  "certificate": {"encoding": "horn_implication_chain", "chain_length": 5,
                  "unsat": true, "minimal": true, "solver": "Glucose4",
                  "mus_size": 6, "nontrivial": true, "hash": "..."},
  "provenance": {"surface_style": "folio | proofwriter | native",
                 "synthetic": true}
}
```

Every released item is verified unsatisfiable and MUS-minimal for the
released gold by the solver under the Horn-chain encoding. Scoring is
against that gold; scoring does not assert uniqueness among all logically valid minimal
repairs. No test item shares a `(K, MUS, a_star)` signature
with a training item.

## Rebuild

```bash
make bench          # PYTHONPATH=src python scripts/build_bench.py
```

Requires the ConceptGraph cache at `data/processed/concept_graph.gpkl` (or
WordNet plus an optional ConceptNet dump to rebuild it). The builder
re-checks every invariant quoted above and refuses to write a split that
violates one.

## License

Benchmark rows derived from WordNet and ConceptNet follow the upstream
licenses of those resources; ConceptNet-derived material inherits
CC BY-SA 4.0. Audit annotations are released under CC BY 4.0.
