# DION-Bench Human Audit Data

Anonymized annotator judgments behind the benchmark-validation and error-taxonomy
numbers in the paper. Every statistic quoted from these files is recomputed by
`scripts/render_paper_tables.py` (Tables: validation, ConceptShift taxonomy) and
`scripts/render_paper_numbers.py` (in-text values), so the sheets are the source
and the paper is the rendering.

## Files

| File | Rows | Contents |
| --- | --- | --- |
| `v1_stratified_audit.csv` | 1,120 | V1 stratified audit: 500 OntoNeg-WN + 400 ConceptShift + 220 LogicRepair. Three raters per item (`rater_1..3` $\in$ {gold, distractor, ambiguous}), `majority`, and a `category` field (correct / ambiguous / noise). |
| `conceptshift_1000_reaudit.csv` | 1,000 | Full-test ConceptShift re-audit, aligned 1:1 with `data/bench/concept_shift_test.jsonl` ids. `S_gold` quotes the benchmark reference abstraction; `rater_{1,2,3}_correct` are binary; `category` / `fine_category` record the disagreement type; `high_confidence` marks unanimous-and-confident rows. |
| `specificity_taxonomy.csv` | 400 | Error taxonomy for 200 ConceptShift errors each from `base` and `self_rewarding_strict` (seed 42). `prediction` is the parsed answer from the released `outputs/predictions/<config>_items.jsonl`; `gold` / `target` quote the benchmark; `taxonomy` is the human label; `specificity_score` is the analysis-time score from `dion.evaluation.mediation`. |
| `validation_summary.json` | -- | V2 LLM-consensus Fleiss $\kappa$ (4 raters, 500 items per task) and V3 single-feature artifact-probe AUCs, plus the Core-split size. |

## Statistic definitions

- **V1 precision** -- share of rows whose `majority` is `gold`, per sub-task.
- **V1 ambiguity** -- share of rows whose `category` is `ambiguous`, per sub-task.
- **V1 agreement** -- mean pairwise Cohen $\kappa$ over the three rater columns, per
  sub-task, no filtering.
- **Re-audit agreement** -- mean pairwise Cohen $\kappa$ over
  `rater_{1,2,3}_correct` on all 1,000 rows, no filtering.
- **Taxonomy shares** -- per-configuration share of each `taxonomy` value over the
  200 labelled errors of that configuration.
- **Subset regressions** -- ConceptShift accuracy of `base` and
  `self_rewarding_strict` restricted to the unanimous-correct rows, the
  rater-disagreement rows, and the deep-path items, recomputed from predictions.

The automatic surface-level classifier in `dion.evaluation.mediation` labels every
error on the test set and is reported separately from these human labels; the
two are close but not identical by construction.

## Ethics

See the paper appendix **Ethics Statement** for the full disclosure (recruitment,
compensation, consent, and IRB/exemption determination). In brief: adult
volunteers were recruited through the authors' institutional research channels
at Peking University, Guangzhou University, and Nanjing University for a
short conceptual-reasoning task over knowledge-base items derived from WordNet
(WordNet License) and ConceptNet (CC BY-SA 4.0); they were paid at or above the
local prevailing wage for comparable labeling; written informed consent covered
research use of anonymized labels; under institutional policy a full IRB
protocol was not required for this lightweight public-item audit. No personal or
sensitive attributes were collected; only anonymized rater ids appear here.
