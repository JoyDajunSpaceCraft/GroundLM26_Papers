# DION-Bench Camera-Ready Supplementary Material

GroundLM 2026 (EMNLP 2026 Workshop) archival long paper

> When Targeted Grounded Gains Hide Complementary Abstraction Regression:
> DION-Bench and a Conjunctive Evaluation Protocol

**Authors.** Zida Yang\*, Guquan You\*, Jiexin Zheng\*, and Yijie Peng\*\*
(\* equal contribution; \*\* corresponding author: pengyijie@nju.edu.cn)

This archive is the camera-ready companion to `main.pdf`. It is **not** anonymous.

## Contents

```
software/     Code, configs, protocol card, result ledger, predictions, stats
data/         DION-Bench splits (13,897 primary rows) and human-audit CSVs
```

Place `data/bench` and `data/audit` under `software/data/` (or keep this
layout and run commands from `software/` after copying `data/` beside it)
before scoring. See `software/README.md` and `data/README.md`.

## CPU-only audit (no GPU)

```bash
cd software
bash scripts/00_setup_env.sh
# copy ../data/bench and ../data/audit to data/bench and data/audit
make verify-ledger
make stats
make smoke
```

`make verify-ledger` recomputes every item-derived ledger row from the
released predictions. The packager re-ran this check before this zip was built.

## License

Code: Apache-2.0. ConceptNet-derived rows inherit CC BY-SA 4.0.
Audit annotations: CC BY 4.0.
