# DION-Bench Protocol

The evaluation protocol described in the paper. Every value below was
fixed before any primary run. The content hash of this file is written to
`outputs/stats/protocol_hash.txt` by `scripts/build_stats_bundle.py`, so a
changed protocol is visible in the released statistics bundle.

## Equivalence margins

| Margin | Metric family | Role |
|--------|---------------|------|
| ±0.5 pp | accuracy / F1 (pp) | Stringent sensitivity view |
| ±1.0 pp | accuracy / F1 (pp) | Operational margin, used for primary decisions |
| ±1.5 pp | accuracy / F1 (pp) | Sensitivity view |
| ±2.0 pp | accuracy / F1 (pp) | Noise-aware sensitivity view |
| ±5% relative | WikiText-2 PPL | Relative non-inferiority for perplexity |

The ±1 pp margin is internally pre-specified, not domain-derived: it is the
smallest round effect this design can resolve. `outputs/stats/equivalence_margin.json`
records, per metric, the across-run standard deviation, the observed two-way
interval half-width, the minimum effect resolvable at 80% power for two
one-sided 5% tests, and how many runs halving the margin would need. Passing at
±1 pp therefore certifies operational equivalence under the pre-specified band,
not a bound tighter than the noise floor. PPL uses a relative band because an
absolute pp band is undefined for perplexity.

## AuditPass decision rule (IUT)

Two conjunctive decisions are defined. **SafeGain** is the primary
conjunctive decision; LocalizedGain is a secondary localisation tag.
Primary "AuditPass" denotes LocalizedGain under cluster-aware intervals.

**SafeGain** (primary)

1. Target superiority on the pre-declared target probe (one-sided α=0.05).
2. Complementary DION-Bench axes: one-sided non-inferiority (Δ > −δ).
3. External retention suite: one-sided non-inferiority; accuracy tasks use
   Δ > −1 pp and WikiText-PPL uses relative Δ > −5%.

**LocalizedGain** (secondary; reported as AuditPass)

1. Target superiority on the pre-declared target probe (one-sided α=0.05).
2. Complementary DION-Bench axes: two-sided TOST equivalence at the
   metric-family margin (large collateral gains also fail).
3. External retention suite: one-sided non-inferiority; accuracy tasks use
   Δ > −1 pp and WikiText-PPL uses relative Δ > −5%.

A constructive positive control (`gain_matched_safe`) matches a Self-Rewarding
OntoNeg gain while keeping complementary axes near Base, so the rules are not
vacuously unreachable. It is not an independently trained SOTA method.

Both rules are conjunctive intersection-union tests: no p-value averaging, and a
configuration fails if any component fails. Benjamini-Hochberg correction
applies to discovery reporting only, never to the conjunctive decision.

Checkpoint-level drift analyses (n=54 checkpoints over 9 runs) are estimated with
method-family fixed effects and run-level random effects; the terminal
method-level correlation over 9 configurations is descriptive.

## Decoding

Greedy decoding (`do_sample: false`) for all primary evaluation.
Stochastic sampling (temperature 0.9, top-p 0.95) is used only for
self-generated training data (Self-Rewarding and Self-Critique candidate
generation). The specificity-penalized decoding rule studied in the analysis
section is without gold labels at evaluation time, uses the same greedy backbone, and its
parameters were fixed before the holdout split was constructed.
Sampling-temperature
sensitivity is outside the primary evaluation protocol (see Limitations).

## Training prompts

Reward-free and self-judge training prompts never include gold answers.
Supervised SFT is the only path that appends gold responses, with prompt tokens
masked in the loss (`labels=-100`).

## Splits

Each test split is touched once per configuration. Development splits are
excluded from every primary number. The holdout splits were built after all
decoding parameters were fixed and are used only for the holdout rows.

| Sub-task | test | dev | holdout | train |
|----------|------|-----|--------------|-------|
| OntoNeg-WN | 500 | 100 | 200 | 1,597 |
| ConceptShift | 1,000 | 500 | 500 | 4,000 |
| LogicRepair | 1,000 | 500 | -- | 4,000 |

OntoNeg-WN evaluation splits contain certified rows only: each item includes an
affirmation and a lexically attested denial. Items whose only warrant is a
missing knowledge-graph edge stay in the training pool, tagged
`kg_edge_absence`. LogicRepair items are sentence-unit SAT-verified (UNSAT of
K ∪ {a*} with MUS minimality certificates).

DION-Bench-Core is the subset of the test set with clean construction
evidence: certified OntoNeg-WN items, high-confidence rows of the ConceptShift
re-audit, and certificate-verified LogicRepair items.

## Statistical layers

1. (S1) Item-level paired bootstrap, runs held fixed.
2. (S2) Cluster-level paired bootstrap over concept families (`S_id`), runs held
   fixed.
3. (S3) Two-way hierarchical bootstrap: resample training runs with replacement,
   then clusters within each drawn run. **This is the primary level**; S1 and S2
   are narrower sensitivity views.
4. (S4) TOST equivalence at the margins above, at all three levels. Clusters are
   drawn once per replicate and shared by both arms, so the test stays paired.
5. (S5) Benjamini-Hochberg correction among discovery tests.

All intervals use 4,000 replicates and α=0.05, with replicate seeds derived from
a content hash so a rerun reproduces them bit-for-bit.

## Reproducibility chain

```
data/bench/*.jsonl                     evaluation items and gold labels
  → outputs/predictions/{config}_items[_conf].jsonl   raw_output only, no gold
  → result_ledger.csv                  aggregates (ledger_validator.py)
  → outputs/stats/*.json               intervals and tests (build_stats_bundle.py)
  → paper/tables/*.tex                 every number in the paper
```

`make verify-ledger` is fail-closed. It refuses a prediction file that carries a
`gold` field or a parser version other than the released one, re-parses every
prediction from its released `raw_output` with the shared versioned parser,
joins to the benchmark rows by id, recomputes OntoNeg INA/OER,
ConceptShift accuracy and LogicRepair set precision/F1 from scratch, and
compares pooled means, across-run dispersion, item counts and run counts to
`result_ledger.csv` at 1e-6. Interval endpoints are redrawn with an
independent seed, so they are compared at `--ci-tol` (0.01 by default): two
independent resamplings of the same data agree only up to Monte-Carlo noise.
It writes a parse-rule report so any fallback rule is visible.
`build_stats_bundle.py` then
recomputes the statistics bundle from the same predictions along an independent
path, and `render_paper_tables.py` and `render_paper_numbers.py` regenerate every
table and every in-text number from the ledger, the bundle and the audit sheets.
