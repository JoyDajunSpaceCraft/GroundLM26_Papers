# Robustness evidence (per-item)

Item-level records matching the aggregates in `configs/cross_backbone.json`,
`configs/contamination.json`, `configs/direct_solvers.json`, and
`audit/validation_summary.json`. Headline locked-protocol numbers remain
in `outputs/predictions/` and are validated by `make verify-ledger`.
