"""DION-Bench: a measurement protocol for reward-free post-training.

See ``paper/`` for the accompanying paper.
"""

from __future__ import annotations

__version__ = "0.1.0"
