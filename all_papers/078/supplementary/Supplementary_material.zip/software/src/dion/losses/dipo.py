"""DIPO: direct internal-preference optimisation (negative ablation).

This stage is included only as a negative ablation; in the headline
configuration ``stage3_steps`` is 0 and the components below are not exercised
during the released training pipeline.

The DPO-style margin loss uses preference pairs ``(y_pos, y_neg)`` selected by
an internal score:

    r_score(x, y) = Delta_T(x, y)
                  + lambda_graph_depth * Delta_GraphDepth(x, y)
                  - lambda_repetition * Rep(y)
                  - lambda_length    * max(0, |y| - L_max)

``Delta_GraphDepth`` is the change in concept-graph depth on ConceptNet hops
between the prompt's anchor and the candidate's predicate; it is a structural
graph signal, distinct from the textual specificity score studied separately
in the analysis.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import torch
import torch.nn.functional as F


@dataclass
class DIPOConfig:
    beta_dpo: float = 0.1
    lambda_graph_depth: float = 0.3
    lambda_repetition: float = 0.2
    lambda_length: float = 0.05
    length_max: int = 256


def repetition_penalty(text: str) -> float:
    """Return the proportion of duplicated 4-grams (deterministic)."""
    tokens = re.findall(r"\S+", text)
    if len(tokens) < 5:
        return 0.0
    grams = list(zip(tokens, tokens[1:], tokens[2:], tokens[3:]))
    if not grams:
        return 0.0
    uniq = len(set(grams))
    return 1.0 - uniq / len(grams)


def internal_score(
    *,
    tension_x: torch.Tensor,
    tension_xy: torch.Tensor,
    depth_delta: torch.Tensor,
    repetition: torch.Tensor,
    length: torch.Tensor,
    cfg: DIPOConfig,
) -> torch.Tensor:
    over = F.relu(length - cfg.length_max)
    return (
        (tension_x - tension_xy)
        + cfg.lambda_graph_depth * depth_delta
        - cfg.lambda_repetition * repetition
        - cfg.lambda_length * over
    )


def dipo_loss(
    *,
    logp_pos_theta: torch.Tensor,
    logp_pos_ref: torch.Tensor,
    logp_neg_theta: torch.Tensor,
    logp_neg_ref: torch.Tensor,
    cfg: DIPOConfig,
) -> dict[str, torch.Tensor]:
    """DPO-style log-sigmoid margin loss with internally generated preferences."""
    margin = (logp_pos_theta - logp_pos_ref) - (logp_neg_theta - logp_neg_ref)
    loss = -F.logsigmoid(cfg.beta_dpo * margin).mean()
    accuracy = (margin > 0).float().mean()
    return {
        "loss": loss,
        "accuracy": accuracy.detach(),
        "margin": margin.detach().mean(),
    }


class DIPOLoss(torch.nn.Module):
    def __init__(self, cfg: DIPOConfig | None = None) -> None:
        super().__init__()
        self.cfg = cfg or DIPOConfig()

    def forward(self, **kwargs) -> dict[str, torch.Tensor]:
        return dipo_loss(cfg=self.cfg, **kwargs)
