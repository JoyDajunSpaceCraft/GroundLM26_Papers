"""ABO: a four-term Bregman objective.

L_ABO = lambda_P * L_preserve  (KL(pi_theta || pi_theta0) so language ability is retained)
      + lambda_A * L_absorb    (KL(q_A || q_S))
      + lambda_R * L_resolve   (margin: T(c_S) <= T(c) - m_T)
      + lambda_C * L_concrete  ((H(q_S) - kappa * log K) ** 2)

The four terms target preservation, absorption of the perturbation
direction, tension reduction, and avoidance of degenerate predicates.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch
import torch.nn.functional as F


def _kl(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Mean KL(p || q) over batch where p, q are (B, K) probabilities."""
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    return (p * (p.log() - q.log())).sum(-1).mean()


def _entropy(p: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    p = p.clamp_min(eps)
    return -(p * p.log()).sum(-1)


@dataclass
class ABOConfig:
    lambda_preserve: float = 0.5
    lambda_absorb: float = 1.0
    lambda_resolve: float = 1.0
    lambda_concrete: float = 0.1
    margin_T: float = 0.02
    kappa_target: float = 0.5


def abo_loss(
    *,
    logp_theta: torch.Tensor,
    logp_theta0: torch.Tensor,
    response_mask: torch.Tensor,
    q_T: torch.Tensor,
    q_A: torch.Tensor,
    q_S: torch.Tensor,
    tension_T: torch.Tensor,
    tension_S: torch.Tensor,
    K: int,
    cfg: ABOConfig,
    chunk_size: int = 16,
) -> dict[str, torch.Tensor]:
    """Compute the four ABO components and the weighted sum.

    Note on KL chunking: with ``V`` ~ 150K, the full ``(B, T, V)`` softmax can
    exceed 1 GB; we loop over the time axis in chunks (default 256), only on
    rows where ``response_mask`` is non-zero, and average over the batch.
    """
    B, T, V = logp_theta.shape
    rm = response_mask.bool()
    L_preserve_sum = logp_theta.new_zeros(B)
    L_preserve_cnt = logp_theta.new_zeros(B)
    for s in range(0, T, chunk_size):
        e = min(s + chunk_size, T)
        m = rm[:, s:e]
        if not m.any():
            continue
        lp = logp_theta[:, s:e, :].float()
        lp0 = logp_theta0[:, s:e, :].float()
        p = lp.exp()
        kl_tok = (p * (lp - lp0)).sum(-1)
        kl_tok = torch.where(m, kl_tok, torch.zeros_like(kl_tok))
        L_preserve_sum = L_preserve_sum + kl_tok.sum(-1)
        L_preserve_cnt = L_preserve_cnt + m.float().sum(-1)
    L_preserve = (L_preserve_sum / L_preserve_cnt.clamp_min(1.0)).mean()

    L_absorb = _kl(q_A, q_S)

    margin = tension_S - tension_T + cfg.margin_T
    L_resolve = F.relu(margin).mean()

    h_target = cfg.kappa_target * math.log(K)
    H_S = _entropy(q_S)
    L_concrete = ((H_S - h_target) ** 2).mean()

    L_total = (
        cfg.lambda_preserve * L_preserve
        + cfg.lambda_absorb * L_absorb
        + cfg.lambda_resolve * L_resolve
        + cfg.lambda_concrete * L_concrete
    )
    return {
        "loss": L_total,
        "preserve": L_preserve.detach(),
        "absorb": L_absorb.detach(),
        "resolve": L_resolve.detach(),
        "concrete": L_concrete.detach(),
        "tension_T": tension_T.detach().mean(),
        "tension_S": tension_S.detach().mean(),
    }


class ABObjective(torch.nn.Module):
    """Stateful wrapper for ``abo_loss`` so it can be saved with the model."""

    def __init__(self, K: int, cfg: ABOConfig | None = None) -> None:
        super().__init__()
        self.K = K
        self.cfg = cfg or ABOConfig()

    def forward(self, **kwargs) -> dict[str, torch.Tensor]:
        return abo_loss(K=self.K, cfg=self.cfg, **kwargs)
