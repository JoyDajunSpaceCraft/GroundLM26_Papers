"""Stage 3 -- direct internal-preference optimisation (negative ablation).

The default released configuration sets ``stage3_steps`` to 0, which makes
this stage a no-op.  Set a positive ``stage3_steps`` value to reproduce the
negative ablation reported in the paper appendix.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.losses.dipo import DIPOConfig, dipo_loss, internal_score, repetition_penalty
from dion.training.data import JsonlDataset, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.train.stage3")


def freeze_for_stage3(model) -> None:
    for n, p in model.named_parameters():
        p.requires_grad = False
    for n, p in model.heads.tras.named_parameters():
        p.requires_grad = True
    for n, p in model.named_parameters():
        if "lora_" in n:
            p.requires_grad = True


def _logp_sequence(model, input_ids, attn, response_mask) -> torch.Tensor:
    out = model(input_ids=input_ids, attention_mask=attn)
    logits = out.logits[:, :-1, :]
    targets = input_ids[:, 1:]
    mask = response_mask[:, 1:]
    logp = torch.log_softmax(logits, dim=-1)
    logp_targets = torch.gather(logp, -1, targets.unsqueeze(-1)).squeeze(-1)
    return (logp_targets * mask).sum(-1)


def run(cfg_path: str) -> None:
    cfg = load_yaml(cfg_path)
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "stage3"
    out_dir.mkdir(parents=True, exist_ok=True)

    stage3_steps = int(cfg["train"].get("stage3_steps", 0))
    if stage3_steps <= 0:
        logger.info("Stage 3 disabled (stage3_steps <= 0); skipping.")
        return

    model, tok = load_dion_model(cfg)
    s2 = Path(cfg["out_dir"]) / "stage2_abo" / "abo_state.pt"
    if s2.exists():
        sd = torch.load(s2, map_location="cpu")
        model.heads.tras.load_state_dict(sd["tras"], strict=False)
        for n, p in model.named_parameters():
            if n in sd.get("lora", {}):
                with torch.no_grad():
                    p.copy_(sd["lora"][n].to(p.device).to(p.dtype))
        logger.info("Loaded TRA + LoRA from Stage 2.")
    model.enable_injection()
    freeze_for_stage3(model)

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=2,
        collate_fn=lambda rows: text_collate(rows, tok, cfg["train"]["seq_len"]),
    )

    params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=stage3_steps, eta_min=1e-6)
    dcfg = DIPOConfig(
        beta_dpo=cfg["dipo"]["beta_dpo"],
        lambda_graph_depth=cfg["dipo"]["lambda_graph_depth"],
        lambda_repetition=cfg["dipo"]["lambda_repetition"],
        lambda_length=cfg["dipo"]["lambda_length"],
        length_max=cfg["dipo"]["length_max"],
    )

    step, accum = 0, cfg["train"]["grad_accum"]
    optim.zero_grad()
    model.train()
    G = cfg["dipo"]["num_candidates_G"]
    while step < stage3_steps:
        for batch in loader:
            batch = {k: v.to(next(model.parameters()).device) for k, v in batch.items()}
            input_ids, attn = batch["input_ids"], batch["attention_mask"]

            model.disable_injection()
            try:
                with torch.no_grad():
                    gens = model.generate(
                        input_ids=input_ids, attention_mask=attn,
                        do_sample=True, num_return_sequences=G,
                        max_new_tokens=64,
                        temperature=0.9, top_p=0.95,
                        pad_token_id=tok.pad_token_id,
                    )
            finally:
                model.enable_injection()
            B, T0 = input_ids.shape
            gens = gens.view(B, G, -1)
            scores = torch.zeros(B, G, device=input_ids.device)
            for g in range(G):
                cand_ids = gens[:, g, :]
                cand_attn = (cand_ids != tok.pad_token_id).long()
                with torch.no_grad():
                    _ = model(input_ids=cand_ids, attention_mask=cand_attn)
                T_xy = model.aggregate_tension()
                if T_xy is None:
                    T_xy = torch.zeros(B, device=input_ids.device)
                _ = model(input_ids=input_ids, attention_mask=attn)
                T_x = model.aggregate_tension()
                if T_x is None:
                    T_x = torch.zeros(B, device=input_ids.device)
                rep = torch.tensor(
                    [repetition_penalty(tok.decode(cand_ids[i].tolist(), skip_special_tokens=True))
                     for i in range(B)], device=input_ids.device, dtype=torch.float32,
                )
                length = cand_attn.sum(-1).float()
                depth_delta = torch.zeros_like(rep)
                scores[:, g] = internal_score(
                    tension_x=T_x, tension_xy=T_xy,
                    depth_delta=depth_delta, repetition=rep, length=length,
                    cfg=dcfg,
                )

            best = scores.argmax(-1)
            worst = scores.argmin(-1)
            pos_ids = torch.gather(gens, 1, best.view(B, 1, 1).expand(-1, 1, gens.size(-1))).squeeze(1)
            neg_ids = torch.gather(gens, 1, worst.view(B, 1, 1).expand(-1, 1, gens.size(-1))).squeeze(1)
            pos_attn = (pos_ids != tok.pad_token_id).long()
            neg_attn = (neg_ids != tok.pad_token_id).long()
            pos_resp = pos_attn.clone()
            neg_resp = neg_attn.clone()

            logp_pos_theta = _logp_sequence(model, pos_ids, pos_attn, pos_resp)
            logp_neg_theta = _logp_sequence(model, neg_ids, neg_attn, neg_resp)

            model.disable_injection()
            with torch.no_grad():
                logp_pos_ref = _logp_sequence(model, pos_ids, pos_attn, pos_resp)
                logp_neg_ref = _logp_sequence(model, neg_ids, neg_attn, neg_resp)
            model.enable_injection()

            comp = dipo_loss(
                logp_pos_theta=logp_pos_theta, logp_pos_ref=logp_pos_ref,
                logp_neg_theta=logp_neg_theta, logp_neg_ref=logp_neg_ref,
                cfg=dcfg,
            )
            loss = comp["loss"] / accum
            loss.backward()

            if (step + 1) % accum == 0:
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                optim.step(); sched.step(); optim.zero_grad()

            if step % cfg["train"]["log_steps"] == 0:
                logger.info(
                    f"[stage3] step {step}/{stage3_steps} "
                    f"loss={loss.item()*accum:.4f} acc={comp['accuracy']:.3f}"
                )
            step += 1
            if step >= stage3_steps:
                break

    torch.save({
        "tras": model.heads.tras.state_dict(),
        "lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n and p.requires_grad},
    }, out_dir / "stage3_state.pt")
    logger.info(f"Saved Stage 3 state to {out_dir/'stage3_state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    args = ap.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
