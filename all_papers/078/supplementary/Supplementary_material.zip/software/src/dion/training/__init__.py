"""Training pipelines for DION's three stages."""
