"""Model + tokenizer loader respecting QLoRA / LoRA / DION configuration."""

from __future__ import annotations

from pathlib import Path

import torch
from peft import LoraConfig, TaskType, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from dion.models.dion_model import DIONConfig, DIONModel


def _resolve_backbone(cfg: dict) -> str:
    primary = (
        cfg["model"].get("name_or_path")
        or cfg["model"].get("backbone")
        or cfg["model"].get("name")
    )
    if primary and Path(primary).exists():
        return primary
    fallback = cfg["model"].get("fallback")
    if fallback and Path(fallback).exists():
        return fallback
    return primary  # let HF resolve


def load_dion_model(cfg: dict, device_map: str | dict = "cuda:0") -> tuple[DIONModel, "AutoTokenizer"]:
    backbone = _resolve_backbone(cfg)
    bnb = BitsAndBytesConfig(
        load_in_4bit=cfg["model"].get("load_in_4bit", True),
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
    )
    tok = AutoTokenizer.from_pretrained(backbone, use_fast=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        backbone,
        torch_dtype=torch.bfloat16,
        attn_implementation=cfg["model"].get("attn_implementation", "flash_attention_2"),
        quantization_config=bnb if cfg["model"].get("load_in_4bit", True) else None,
        device_map=device_map,
    )
    if cfg.get("train", {}).get("gradient_checkpointing", True):
        model.gradient_checkpointing_enable()

    lora = cfg["lora"]
    peft_cfg = LoraConfig(
        r=lora["r"],
        lora_alpha=lora["alpha"],
        lora_dropout=lora["dropout"],
        target_modules=lora["target_modules"],
        bias="none",
        task_type=TaskType.CAUSAL_LM,
    )
    peft_model = get_peft_model(model, peft_cfg)
    peft_model.print_trainable_parameters()
    # Prefer config; LoRA+KL / eval-only paths often disable GC to avoid
    # Fisher-hook + checkpointing autograd conflicts when injection is off.
    if cfg.get("train", {}).get("gradient_checkpointing", True):
        if hasattr(peft_model, "gradient_checkpointing_enable"):
            peft_model.gradient_checkpointing_enable()
    else:
        if hasattr(peft_model, "gradient_checkpointing_disable"):
            peft_model.gradient_checkpointing_disable()
        base = getattr(peft_model, "base_model", peft_model)
        inner = getattr(base, "model", base)
        if hasattr(inner, "gradient_checkpointing_disable"):
            inner.gradient_checkpointing_disable()

    d_model = peft_model.config.hidden_size
    # Defensively cast all numerics to float — PyYAML 1.1 parses values like
    # "1e-6" as strings unless explicitly written "1.0e-6".
    dion_cfg = DIONConfig(
        inject_layers=[int(x) for x in cfg["inject_layers"]],
        layer_weights={int(k): float(v) for k, v in cfg["layer_weights"].items()},
        d_model=int(d_model),
        K=int(cfg["cph"]["K"]),
        rank_a=int(cfg["tra"]["rank_a"]),
        rank_r=int(cfg["fisher"]["rank_r"]),
        eps_curvature=float(cfg["fisher"]["eps_curvature"]),
        delta_norm=float(cfg["fisher"]["delta_norm"]),
        beta_var=float(cfg["din"]["beta_var"]),
        rho_step=float(cfg["din"]["rho_step"]),
        alpha_tra=float(cfg["tra"]["alpha"]),
        d_pool=int(cfg["cph"]["d_pool"]),
    )
    dion_model = DIONModel(peft_model, dion_cfg)
    dion_model.num_samples_m = int(cfg.get("fisher", {}).get("num_samples_m", 4))
    return dion_model, tok
