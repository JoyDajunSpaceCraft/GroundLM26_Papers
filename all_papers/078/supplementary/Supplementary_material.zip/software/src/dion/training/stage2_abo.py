"""Stage 2 -- TRA + LoRA training under the ABO objective.

Trains TRA + LoRA on top of the now-frozen CPH.  This stage requires
running the base model TWICE per batch -- once with TRA active to obtain
``c_S / q_S / log pi_theta``, and once with TRA detached to get
``c_l / q_T / log pi_theta0`` -- toggled via ``model.enable_injection()`` /
``model.disable_injection()``.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.losses.abo import ABOConfig, abo_loss
from dion.training.data import JsonlDataset, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.train.stage2")


def freeze_for_abo(model, *, train_tra: bool = True) -> None:
    for n, p in model.named_parameters():
        p.requires_grad = False
    if train_tra:
        for n, p in model.heads.tras.named_parameters():
            p.requires_grad = True
    for n, p in model.named_parameters():
        if "lora_" in n:
            p.requires_grad = True


def run(cfg_path: str) -> None:
    cfg = load_yaml(cfg_path)
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "stage2_abo"
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    cph_pools = Path(cfg["out_dir"]) / "stage1_cph" / "cph_pools.pt"
    if cph_pools.exists():
        sd = torch.load(cph_pools, map_location="cpu")
        model.heads.cph.load_state_dict(sd["cph"], strict=False)
        model.heads.pools.load_state_dict(sd["pools"], strict=False)
        logger.info("Loaded CPH+Pools from Stage 1.")
    # LoRA+KL references use tra.rank_a=0; Fisher injection under grad-checkpointing
    # breaks (c has no grad_fn). Keep injection off and train LoRA against KL/ABO only.
    use_injection = int((cfg.get("tra") or {}).get("rank_a", 0) or 0) > 0
    if use_injection:
        model.enable_injection()
    else:
        model.disable_injection()
        # Belt-and-suspenders: never leave GC on for pure LoRA+KL.
        cfg.setdefault("train", {})["gradient_checkpointing"] = False
        if hasattr(model.base, "gradient_checkpointing_disable"):
            model.base.gradient_checkpointing_disable()
        logger.info("tra.rank_a=0: Stage-2 runs with injection disabled (LoRA+KL mode)")
    freeze_for_abo(model, train_tra=use_injection)

    # Frozen Base LoRA snapshot for KL anchoring (π_θ0). Copied once before
    # any Stage-2 updates; restored under disable_adapter-style swaps.
    frozen_lora = {
        n: p.detach().clone()
        for n, p in model.named_parameters() if "lora_" in n
    }

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=2,
        collate_fn=lambda rows: text_collate(rows, tok, cfg["train"]["seq_len"]),
    )

    params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        optim, T_max=cfg["train"]["stage2_steps"], eta_min=1e-6,
    )

    abo_cfg = ABOConfig(
        lambda_preserve=cfg["abo"]["lambda_preserve"],
        lambda_absorb=cfg["abo"]["lambda_absorb"],
        lambda_resolve=cfg["abo"]["lambda_resolve"],
        lambda_concrete=cfg["abo"]["lambda_concrete"],
        margin_T=cfg["abo"]["margin_T"],
        kappa_target=cfg["abo"]["kappa_target"],
    )

    def _swap_lora(store: dict) -> dict:
        """Replace current LoRA weights with ``store``; return the displaced copy."""
        displaced = {}
        with torch.no_grad():
            for n, p in model.named_parameters():
                if n in store:
                    displaced[n] = p.detach().clone()
                    p.copy_(store[n].to(device=p.device, dtype=p.dtype))
        return displaced

    step, accum = 0, cfg["train"]["grad_accum"]
    optim.zero_grad()
    model.train()
    while step < cfg["train"]["stage2_steps"]:
        for batch in loader:
            batch = {k: v.to(next(model.parameters()).device) for k, v in batch.items()}
            input_ids, attn = batch["input_ids"], batch["attention_mask"]
            response_mask = (batch["attention_mask"] > 0).float()

            # Reference forward (frozen LoRA) MUST run before the trainable
            # forward: swapping LoRA with p.copy_ while a live autograd graph
            # still points at those parameters triggers inplace version errors.
            if use_injection:
                model.enable_probe()
            current_lora = _swap_lora(frozen_lora)
            with torch.no_grad():
                out_T = model(input_ids=input_ids, attention_mask=attn, labels=batch["labels"])
                logp_theta0 = torch.log_softmax(out_T.logits, dim=-1)
                concepts_T = {k: v.detach().clone() for k, v in model._aux.get("concepts", {}).items()}
                T_T = model.aggregate_tension()
            _swap_lora(current_lora)
            if use_injection:
                model.enable_injection()

            # Trainable forward (current LoRA ± TRA injection)
            out_S = model(input_ids=input_ids, attention_mask=attn, labels=batch["labels"])
            logp_theta = torch.log_softmax(out_S.logits, dim=-1)
            model._aux["lm_logprobs"] = logp_theta.detach()[:, -1, :]
            concepts_S = {k: v for k, v in model._aux.get("concepts", {}).items()}
            T_S = model.aggregate_tension()
            qs_S = {ell: torch.softmax(model.heads.cph.logits(c), -1) for ell, c in concepts_S.items()}

            if use_injection and concepts_T:
                qs_T = {ell: torch.softmax(model.heads.cph.logits(c), -1) for ell, c in concepts_T.items()}
                model._aux["concepts"] = concepts_S

                qs_A = {}
                for ell, c in concepts_T.items():
                    eta = model._aux["etas"][ell]
                    c_A = c + cfg["din"]["rho_step"] * eta
                    qs_A[ell] = torch.softmax(model.heads.cph.logits(c_A), -1)

                losses = []
                for ell in concepts_T:
                    comp = abo_loss(
                        logp_theta=logp_theta,
                        logp_theta0=logp_theta0,
                        response_mask=response_mask,
                        q_T=qs_T[ell], q_A=qs_A[ell], q_S=qs_S[ell],
                        tension_T=T_T if T_T is not None else torch.zeros(input_ids.size(0), device=input_ids.device),
                        tension_S=T_S if T_S is not None else torch.zeros(input_ids.size(0), device=input_ids.device),
                        K=cfg["cph"]["K"], cfg=abo_cfg,
                    )
                    losses.append(comp["loss"])
                loss = torch.stack(losses).mean() / accum
            else:
                # Pure LoRA+KL: token-level KL(π_θ || π_θ0) on response positions.
                kl = (torch.exp(logp_theta) * (logp_theta - logp_theta0)).sum(-1)
                loss = (kl * response_mask).sum() / response_mask.sum().clamp_min(1.0)
                loss = loss / accum
            loss.backward()

            if (step + 1) % accum == 0:
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                optim.step(); sched.step(); optim.zero_grad()

            if step % cfg["train"]["log_steps"] == 0:
                logger.info(f"[stage2] step {step}/{cfg['train']['stage2_steps']} loss={loss.item()*accum:.4f}")
            step += 1
            if step >= cfg["train"]["stage2_steps"]:
                break

    payload = {
        "lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n},
    }
    if use_injection:
        payload["tras"] = model.heads.tras.state_dict()
    torch.save(payload, out_dir / "abo_state.pt")
    logger.info(f"Saved {'TRA + ' if use_injection else ''}LoRA to {out_dir/'abo_state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    args = ap.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
