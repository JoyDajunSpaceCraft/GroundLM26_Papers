"""Dataset utilities used across training stages."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

import torch
from torch.utils.data import Dataset

from dion.utils.io import load_jsonl


class JsonlDataset(Dataset):
    def __init__(self, paths: list[str | Path]) -> None:
        self.rows: list[dict[str, Any]] = []
        for p in paths:
            self.rows.extend(load_jsonl(p))

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        return self.rows[idx]


def onto_neg_prompt(row: dict[str, Any]) -> str:
    """Prompt for OntoNeg WITHOUT gold answer leakage.

    States the shared category, the attested attribute and the target that
    carries it, then asks for the same-category exception.
    """
    cands = ", ".join(row["candidates"])
    rel = row.get("missing_relation", "")
    obj = (
        row.get("attribute_object_label")
        or (row.get("attribute_evidence") or {}).get("object_label")
        or ""
    )
    phrase = row.get("attribute_phrase") or (f"{rel} {obj}".strip() if obj else rel)
    neg_phrase = row.get("attribute_negation_phrase") or f"does not satisfy {phrase}"
    return (
        f"A '{row['S']}' normally {phrase}; for example, '{row['T']}' {phrase}.\n"
        f"Which of the following is the same-category exception that {neg_phrase}?\n"
        f"Options: {cands}\n"
        f"Answer:"
    )


def text_collate(
    rows: Iterable[dict[str, Any]],
    tokenizer,
    seq_len: int = 2048,
    include_gold_response: bool = False,
) -> dict[str, torch.Tensor]:
    """Right-pad text rows.

    Default: prompts never contain gold answers. When ``include_gold_response``
    is True (supervised SFT only), the gold answer is appended as the response
    span and prompt tokens are masked with ``labels=-100``.
    """
    prompts: list[str] = []
    full_texts: list[str] = []
    for r in rows:
        if "text" in r:
            prompts.append(r["text"])
            full_texts.append(r["text"])
            continue
        if "T" in r and "candidates" in r:
            p = onto_neg_prompt(r)
            prompts.append(p)
            if include_gold_response and r.get("A_star"):
                full_texts.append(p + " " + str(r["A_star"]))
            else:
                full_texts.append(p)
        else:
            s = str(r)
            prompts.append(s)
            full_texts.append(s)

    enc = tokenizer(
        full_texts,
        padding="max_length",
        truncation=True,
        max_length=seq_len,
        return_tensors="pt",
    )
    labels = enc["input_ids"].clone()
    if include_gold_response:
        # Mask prompt tokens so loss is response-only.
        prompt_enc = tokenizer(
            prompts,
            padding="max_length",
            truncation=True,
            max_length=seq_len,
            return_tensors="pt",
        )
        prompt_lens = prompt_enc["attention_mask"].sum(dim=1)
        for i, plen in enumerate(prompt_lens.tolist()):
            labels[i, : int(plen)] = -100
    else:
        # Reward-free / self-rewarding paths: no gold supervision in labels.
        labels[:] = -100
    enc["labels"] = labels
    return enc


def split_view(
    input_ids: torch.Tensor,
    attn_mask: torch.Tensor,
    p: float = 0.1,
    seed_base: int = 0,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Stochastic dropout over attention mask for CPH consistency views."""
    keep = (torch.rand(attn_mask.shape, device=attn_mask.device) > p).to(attn_mask.dtype)
    new_mask = attn_mask * keep
    return input_ids, new_mask
