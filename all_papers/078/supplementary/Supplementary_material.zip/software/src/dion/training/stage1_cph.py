"""Stage 1 -- Concept Predicate Head pretraining.

Freezes the base LM and the LoRA adapters; only the CPH and the per-layer
attention pools are trained.  Pure self-supervised: two stochastic views per
input, with JS consistency and a batch-entropy regulariser.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.losses.abo import _entropy  # noqa: F401
from dion.models.cph import cph_loss
from dion.training.data import JsonlDataset, split_view, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.train.stage1")


def freeze_for_cph(model) -> None:
    for n, p in model.named_parameters():
        p.requires_grad = False
    for n, p in model.heads.cph.named_parameters():
        p.requires_grad = True
    for n, p in model.heads.pools.named_parameters():
        p.requires_grad = True


def run(cfg_path: str) -> None:
    cfg = load_yaml(cfg_path)
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "stage1_cph"
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    model.enable_injection()
    freeze_for_cph(model)

    train_paths = [Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"]
    if (Path(cfg["bench"]["output_dir"]) / "concept_shift_train.jsonl").exists():
        train_paths.append(Path(cfg["bench"]["output_dir"]) / "concept_shift_train.jsonl")
    if (Path(cfg["bench"]["output_dir"]) / "logic_repair_train.jsonl").exists():
        train_paths.append(Path(cfg["bench"]["output_dir"]) / "logic_repair_train.jsonl")
    ds = JsonlDataset(train_paths)
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"],
        shuffle=True, num_workers=2,
        collate_fn=lambda rows: text_collate(rows, tok, cfg["train"]["seq_len"]),
    )

    params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        optim, T_max=cfg["train"]["stage1_steps"], eta_min=1e-6,
    )

    step, accum = 0, cfg["train"]["grad_accum"]
    optim.zero_grad()
    model.train()
    while step < cfg["train"]["stage1_steps"]:
        for batch in loader:
            batch = {k: v.to(next(model.parameters()).device) for k, v in batch.items()}
            input_ids, attn = batch["input_ids"], batch["attention_mask"]
            out1 = model(input_ids=input_ids, attention_mask=attn, labels=batch["labels"])
            qs1 = {ell: torch.softmax(model.heads.cph.logits(c), -1)
                   for ell, c in model._aux.get("concepts", {}).items()}

            ids2, attn2 = split_view(input_ids, attn, p=cfg["cph"]["dropout_view_p"])
            _ = model(input_ids=ids2, attention_mask=attn2, labels=batch["labels"])
            qs2 = {ell: torch.softmax(model.heads.cph.logits(c), -1)
                   for ell, c in model._aux.get("concepts", {}).items()}

            loss_components = []
            for ell in qs1:
                loss_components.append(
                    cph_loss(qs1[ell], qs2[ell], lambda_div=cfg["cph"]["lambda_div"])["loss"]
                )
            loss = torch.stack(loss_components).mean() / accum
            loss.backward()

            if (step + 1) % accum == 0:
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                optim.step(); sched.step(); optim.zero_grad()

            if step % cfg["train"]["log_steps"] == 0:
                logger.info(f"[stage1] step {step}/{cfg['train']['stage1_steps']} loss={loss.item()*accum:.4f}")
            step += 1
            if step >= cfg["train"]["stage1_steps"]:
                break

    torch.save({"cph": model.heads.cph.state_dict(),
                "pools": model.heads.pools.state_dict()}, out_dir / "cph_pools.pt")
    logger.info(f"Saved CPH+Pools to {out_dir/'cph_pools.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    args = ap.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
