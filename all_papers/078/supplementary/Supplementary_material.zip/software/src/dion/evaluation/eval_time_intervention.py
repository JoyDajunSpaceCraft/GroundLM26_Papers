"""Context-anchored specificity-penalized decoding (CSD).

A single evaluation-time decoding rule, applied identically to both selection
tasks. It re-scores the candidates a frozen model already produced by adding a
penalty for material that is *not anchored in the query context*: tokens absent
from the target and its stated category or relation, phrases longer than the
target, and candidates that merely echo a leaf instance.

The penalty reads only inference-time inputs — the target, the category or
relation cue supplied in the prompt, and the candidate surface strings. No gold
label, gold abstraction or dataset-specific pattern is consulted, so the same
function applies unchanged to ConceptShift abstraction and to OntoNeg-WN
candidate selection.

Why one rule moves both tasks. On ConceptShift the unanchored material is an
over-specific abstraction (the target itself, or a longer paraphrase of it), so
penalising it raises abstraction accuracy. On OntoNeg-WN the unanchored material
is the parent-disjoint external candidate, whose tokens are by construction
unrelated to the target and the shared category, so penalising it suppresses
external-answer errors and redirects part of that mass onto the exception.

This is distinct from the training-time judge rubrics of Stage 3: it changes no
parameters and is a pure post-hoc re-ranking of an already-generated candidate
set.
"""

from __future__ import annotations

from dataclasses import dataclass

#: Frozen once on ConceptShift dev, then applied unchanged everywhere. See
#: ``configs/intervention_csd.yaml`` for the provenance of these values.
NOVELTY_COEF = 0.30
LENGTH_COEF = 0.25
LEAF_COEF = 1.25


@dataclass(frozen=True)
class CSDConfig:
    """Frozen decoding coefficients."""

    novelty_coef: float = NOVELTY_COEF
    length_coef: float = LENGTH_COEF
    leaf_coef: float = LEAF_COEF
    regenerate: bool = False


def context_tokens(target: str, context: str = "") -> set[str]:
    """Lower-cased tokens the prompt made available to the model."""
    text = f"{target or ''} {(context or '').replace('_', ' ')}".lower()
    return {t for t in text.split() if t}


def specificity_penalty(
    prediction: str,
    target: str,
    context: str = "",
    cfg: CSDConfig | None = None,
    leaf_surfaces: list[str] | None = None,
) -> float:
    """Higher = less anchored in the query context, given only prompt inputs.

    ``context`` carries the non-instance cue the prompt already stated (e.g.
    the ConceptShift relation, or the OntoNeg category+attribute). Instance
    endpoints listed in ``leaf_surfaces`` (typically the two contrast leaves)
    are penalised when echoed, even though they appear in the prompt — that is
    the specificity bias the rule targets.
    """
    cfg = cfg or CSDConfig()
    pred = (prediction or "").strip()
    tgt = (target or "").strip()
    anchored = context_tokens(tgt, context)
    # Instance leaves are prompt-visible but must not count as "safe" anchors.
    for leaf in leaf_surfaces or ():
        for tok in str(leaf).lower().split():
            anchored.discard(tok)
    novel = len({t for t in pred.lower().split() if t} - anchored)
    length_ratio = len(pred) / max(1, len(tgt))
    leaves = {tgt.lower()} | {str(s).lower() for s in (leaf_surfaces or []) if s}
    leaf = 1.0 if pred.lower() in leaves else 0.0
    return (
        cfg.novelty_coef * novel
        + cfg.length_coef * max(0.0, length_ratio - 1.0)
        + cfg.leaf_coef * leaf
    )


def rerank_candidates(
    candidates: list[str],
    target: str,
    context: str = "",
    base_scores: list[float] | None = None,
    cfg: CSDConfig | None = None,
    fallback: str | None = None,
    leaf_surfaces: list[str] | None = None,
) -> str:
    """Return argmax over ``base_score - penalty``; ties keep the model's order."""
    cfg = cfg or CSDConfig()
    if not candidates:
        if fallback is not None:
            return fallback
        raise ValueError("rerank_candidates requires a non-empty candidate list")
    scores = base_scores or [0.0] * len(candidates)
    best, best_val = candidates[0], float("-inf")
    for cand, score in zip(candidates, scores):
        val = float(score) - specificity_penalty(
            cand, target, context, cfg, leaf_surfaces=leaf_surfaces)
        if val > best_val:
            best_val, best = val, cand
    return best


def concept_shift_context(row: dict) -> str:
    """Prompt-visible non-instance cue for ConceptShift: the relation label."""
    return str(row.get("relation", ""))


def onto_neg_context(row: dict) -> str:
    """Prompt-visible cue for OntoNeg-WN: the shared category and the attribute."""
    return f"{row.get('S', '')} {row.get('attribute_object_label', '')}"


def penalized_prompt(row: dict, task: str) -> str:
    """Single-pass instruction variant of the same preference, for ablation."""
    if task == "concept_shift":
        return (
            f"Given target '{row['T']}' and related concept '{row['A']}' "
            f"(relation: {row.get('relation', '')}), name the most general concept "
            f"that includes both. Prefer the abstract category; do not prefer "
            f"concrete details, leaf instances, or longer phrases when a shorter "
            f"abstraction fits.\nAnswer:"
        )
    if task == "onto_neg_wn":
        return (
            f"Within the category '{row.get('S', '')}', which candidate does not "
            f"{row.get('attribute_negation_phrase', 'have the attribute')}? "
            f"Restrict the answer to candidates that belong to that category; do "
            f"not choose an option unrelated to it.\nAnswer:"
        )
    raise ValueError(f"unknown task: {task}")
