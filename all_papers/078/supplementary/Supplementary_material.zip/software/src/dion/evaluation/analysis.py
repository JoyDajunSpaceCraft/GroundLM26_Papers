"""Analysis utilities producing the figures and tables used in the paper.

Implements:
  1. Tension trajectory visualisation
  2. Inner-vs-outer discrimination scatter
  3. Loss-curve plotting
  4. Main results table compilation

Output paths default to ``outputs/figures`` and ``outputs/tables`` so the
released code does not assume any specific paper-source layout.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from dion.evaluation.stats import cluster_bootstrap, paired_bootstrap  # noqa: F401


def plot_tension_trajectory(
    trajectories: list[list[float]],
    out_path: str = "outputs/figures/tension_trajectory.pdf",
    title: str = "Per-instance tension across revision steps",
) -> None:
    fig, ax = plt.subplots(figsize=(5, 3.5))
    for traj in trajectories[:200]:
        ax.plot(range(len(traj)), traj, alpha=0.15, color="steelblue", linewidth=0.6)
    if trajectories:
        means = np.mean([t + [t[-1]] * (4 - len(t)) for t in trajectories[:200]], axis=0)
        ax.plot(range(len(means)), means, color="darkred", linewidth=2.5, label="Mean")
    ax.set_xlabel("Revision step $t$")
    ax.set_ylabel("Tension $\\mathcal{T}(x \\oplus y_t)$")
    ax.set_title(title, fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved tension trajectory to {out_path}")


def plot_ina_oer_comparison(
    results: dict[str, dict[str, float]],
    out_path: str = "outputs/figures/ina_oer_comparison.pdf",
) -> None:
    methods = list(results.keys())
    ina = [results[m].get("INA", 0) for m in methods]
    oer = [results[m].get("OER", 0) for m in methods]

    x = np.arange(len(methods))
    w = 0.35
    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.bar(x - w / 2, ina, w, label="INA up", color="steelblue", edgecolor="black", linewidth=0.5)
    ax.bar(x + w / 2, oer, w, label="OER down", color="salmon", edgecolor="black", linewidth=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(methods, rotation=30, ha="right", fontsize=8)
    ax.set_ylabel("Score")
    ax.set_title("Inner Negation Accuracy vs Outer Error Rate", fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved INA/OER comparison to {out_path}")


def plot_loss_curve(
    log_path: str,
    out_path: str = "outputs/figures/stage2_loss.pdf",
    title: str = "Stage 2 ABO Training Loss",
) -> None:
    import re
    steps, losses = [], []
    with open(log_path) as f:
        for line in f:
            m = re.search(r"step (\d+)/\d+ loss=([0-9.]+)", line)
            if m:
                steps.append(int(m.group(1)))
                losses.append(float(m.group(2)))
    if not steps:
        print(f"No loss data in {log_path}")
        return
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.plot(steps, losses, color="steelblue", linewidth=0.8, alpha=0.7)
    window = max(1, len(losses) // 20)
    if window > 1:
        smoothed = np.convolve(losses, np.ones(window) / window, mode="valid")
        ax.plot(steps[window - 1:], smoothed, color="darkred", linewidth=2, label=f"MA-{window}")
    ax.set_xlabel("Step")
    ax.set_ylabel("Loss")
    ax.set_title(title, fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved loss curve to {out_path}")


def compile_main_table(
    base_results: dict,
    baseline_results: dict,
    dion_results: dict | None = None,
    out_path: str = "outputs/tables/main_results.tex",
) -> str:
    rows = [r"\toprule",
            r"\textbf{Method} & \textbf{INA}$\uparrow$ & \textbf{OER}$\downarrow$ & \textbf{GSM8K} \\",
            r"\midrule"]

    def fmt(d: dict, key: str, pct: bool = True) -> str:
        v = d.get(key)
        if v is None:
            return "---"
        return f"{v*100:.1f}" if pct else f"{v:.3f}"

    rows.append(f"Base & {fmt(base_results.get('onto_neg_wn',{}), 'INA')} & "
                f"{fmt(base_results.get('onto_neg_wn',{}), 'OER')} & "
                f"{fmt(base_results.get('gsm8k',{}), 'score')} \\\\")

    for name, data in baseline_results.items():
        display = name.replace("_", "-").title()
        rows.append(f"{display} & {fmt(data, 'INA')} & {fmt(data, 'OER')} & --- \\\\")

    rows.append(r"\midrule")
    if dion_results:
        rows.append(f"\\dion{{}} (full) & {fmt(dion_results.get('onto_neg_wn',{}), 'INA')} & "
                    f"{fmt(dion_results.get('onto_neg_wn',{}), 'OER')} & "
                    f"{fmt(dion_results.get('gsm8k',{}), 'score')} \\\\")
    else:
        rows.append(r"\dion{} (full) & --- & --- & --- \\")

    rows.append(r"\bottomrule")
    table = "\n".join(rows)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(table)
    print(f"Saved main table to {out_path}")
    return table


def generate_all_analysis(outputs_dir: str = "outputs") -> None:
    od = Path(outputs_dir)

    base = json.loads((od / "base_general_eval.json").read_text()) if (od / "base_general_eval.json").exists() else {}
    baselines = json.loads((od / "baselines_eval.json").read_text()) if (od / "baselines_eval.json").exists() else {}
    dion = json.loads((od / "dion_eval.json").read_text()) if (od / "dion_eval.json").exists() else None

    all_results = {"Base": base.get("onto_neg_wn", {})}
    for k, v in baselines.items():
        all_results[k.replace("_", " ").title()] = v
    if dion and "onto_neg_wn" in dion:
        all_results["DION"] = dion["onto_neg_wn"]
    if len(all_results) >= 2:
        plot_ina_oer_comparison(all_results)

    for stage, title in [("stage1", "Stage 1 CPH"), ("stage2", "Stage 2 ABO")]:
        log = od / f"{stage}.log"
        if log.exists():
            plot_loss_curve(str(log), str(od / "figures" / f"{stage}_loss.pdf"), f"{title} Training Loss")

    compile_main_table(base, baselines, dion)

    print("\n[analysis] All analysis artifacts generated.")


if __name__ == "__main__":
    generate_all_analysis()
