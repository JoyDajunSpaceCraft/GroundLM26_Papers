"""Main evaluation entrypoint.

Loads the trained DION model (or a baseline tag) and computes:
  * INA / OER on OntoNeg-WN test
  * AbsAcc on ConceptShift test (one greedy generation against the full accepted set)
  * MUS-P / MUS-R / MUS-F1 and Kprime-Exact on LogicRepair test

With ``--save_items``, writes validator-compatible per-item records
(``id``, ``seed``, ``raw_output``, ``cluster``, ``parser_version``; no ``gold*``).

With ``--save_csd_parent``, also writes prompt-visible CSD parent fields
(``beam_candidates``, ``prompt_target``, ``prompt_context``, ``prompt_leaves``,
``candidate_logprobs``) so ``scripts/run_csd_intervention.py`` can rerank from
a standard evaluation export.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from dion.evaluation.main_metrics import (
    abstraction_accuracy,
    inner_negation_accuracy,
    logic_repair_f1,
    outer_error_rate,
)
from dion.evaluation.output_parser import (
    PARSER_VERSION,
    parse_abstraction,
    parse_candidate_choice,
    parse_mus,
    parse_repaired_kb,
)
from dion.training.loader import load_dion_model
from dion.utils.io import load_jsonl, load_yaml
from dion.utils.logging_utils import get_logger

logger = get_logger("dion.eval.main")


def _decode_new_tokens(tok, out_ids, prompt_len: int) -> str:
    return tok.decode(out_ids[prompt_len:], skip_special_tokens=True)


def _mean_continuation_logprob(model, tok, prompt: str, continuation: str, device) -> float:
    """Length-normalized mean log-prob of ``continuation`` given ``prompt``."""
    base = model.base if hasattr(model, "base") else model
    full = prompt + " " + continuation
    enc_p = tok(prompt, return_tensors="pt", truncation=True, max_length=512).to(device)
    enc_f = tok(full, return_tensors="pt", truncation=True, max_length=512).to(device)
    prompt_len = enc_p["input_ids"].size(1)
    with torch.no_grad():
        logits = base(**enc_f).logits
    logp = torch.log_softmax(logits[0, :-1], dim=-1)
    tgt = enc_f["input_ids"][0, 1:]
    ans = logp[prompt_len - 1: tgt.size(0)]
    ans_tgt = tgt[prompt_len - 1:]
    if ans_tgt.numel() == 0:
        return float("-inf")
    return float(ans.gather(1, ans_tgt.unsqueeze(-1)).squeeze(-1).mean())


def _onto_csd_fields(row: dict, greedy: str, model, tok, device) -> dict:
    """Prompt-visible OntoNeg parent fields for evaluation-time CSD."""
    from dion.training.data import onto_neg_prompt

    greedy = str(greedy).strip()
    options = [str(c) for c in row["candidates"]]
    beam: list[str] = []
    for c in [greedy, *options]:
        c = str(c).strip()
        if c and c not in beam:
            beam.append(c)
    prompt = onto_neg_prompt(row)
    cand_lp = [_mean_continuation_logprob(model, tok, prompt, c, device) for c in beam]
    return {
        "prompt_target": str(row.get("T", row.get("S", ""))),
        "prompt_context": f"{row.get('S', '')} {row.get('attribute_object_label', '')}".strip(),
        "prompt_leaves": [],
        "prompt_options": options,
        "beam_candidates": beam,
        "candidate_logprobs": cand_lp,
        "logprob": cand_lp[0] if cand_lp else None,
        "score_source": "candidate_logprob",
    }


def _cs_csd_fields(row: dict, greedy: str, model, tok, device, *, beam_size: int = 4) -> dict:
    """Prompt-visible ConceptShift parent fields; beam from frozen-model samples."""
    prompt = (
        f"Given target '{row['T']}' and the related concept '{row['A']}' "
        f"(relation: {row.get('relation','')}), name the most general concept "
        f"that includes both as a single word or short noun phrase.\nAnswer:"
    )
    base = model.base if hasattr(model, "base") else model
    enc = tok(prompt, return_tensors="pt").to(device)
    beam: list[str] = []
    greedy_s = str(greedy).strip()
    if greedy_s:
        beam.append(greedy_s)
    # Prompt-visible endpoints only (never gold S / S_alternatives).
    for c in (str(row.get("T", "")), str(row.get("A", "")),
              f"{row.get('T', '')} {row.get('A', '')}".strip()):
        c = c.strip()
        if c and c not in beam:
            beam.append(c)
    with torch.no_grad():
        outs = base.generate(
            **enc,
            max_new_tokens=16,
            num_beams=max(2, beam_size),
            num_return_sequences=max(1, min(beam_size, 4)),
            do_sample=False,
            pad_token_id=tok.pad_token_id,
        )
    prompt_len = enc["input_ids"].size(1)
    for seq in outs:
        text = _decode_new_tokens(tok, seq, prompt_len).strip()
        if text and text not in beam:
            beam.append(text)
    cand_lp = [_mean_continuation_logprob(model, tok, prompt, c, device) for c in beam]
    return {
        "prompt_target": str(row["T"]),
        "prompt_context": str(row.get("relation", "")),
        "prompt_leaves": [str(row.get("T", "")), str(row.get("A", ""))],
        "beam_candidates": beam,
        "candidate_logprobs": cand_lp,
        "logprob": cand_lp[0] if cand_lp else None,
        "score_source": "candidate_logprob",
    }


def _item_base(row: dict, seed: int, raw: str, *, prediction: str | None = None,
               prediction_mus=None, prediction_k_prime=None, parse_rule: str = "",
               extra: dict | None = None) -> dict:
    cluster = str(row.get("S_id", row["id"]))
    out = {
        "id": row.get("id"),
        "seed": int(seed),
        "raw_output": raw,
        "cluster": cluster,
        "parser_version": PARSER_VERSION,
        "parse_rule": parse_rule,
    }
    if prediction is not None:
        out["prediction"] = prediction
    if prediction_mus is not None:
        out["prediction_mus"] = prediction_mus
    if prediction_k_prime is not None:
        out["prediction_k_prime"] = prediction_k_prime
    if extra:
        out.update(extra)
    return out


def _argmax_candidate(model, tok, row: dict, device) -> tuple[str, str, str]:
    """Unified candidate decision: greedy generation + string match."""
    from dion.training.data import onto_neg_prompt
    prompt = onto_neg_prompt(row)
    enc = tok(prompt, return_tensors="pt", truncation=True, max_length=512).to(device)
    base = model.base if hasattr(model, "base") else model
    with torch.no_grad():
        out = base.generate(
            **enc, max_new_tokens=16, do_sample=False, pad_token_id=tok.pad_token_id,
        )
    text = _decode_new_tokens(tok, out[0], enc["input_ids"].size(1))
    parsed = parse_candidate_choice(text, list(row["candidates"]))
    if not parsed.is_fallback:
        return str(parsed.value), text, parsed.rule

    best, best_lp = row["candidates"][0], float("-inf")
    for cand in row["candidates"]:
        full = prompt + " " + cand
        full_enc = tok(full, return_tensors="pt", truncation=True, max_length=512).to(device)
        with torch.no_grad():
            logits = base(**full_enc).logits
        logp = torch.log_softmax(logits[0, :-1], dim=-1)
        tgt = full_enc["input_ids"][0, 1:]
        prompt_len = enc["input_ids"].size(1)
        ans_logp = logp[prompt_len - 1: tgt.size(0)]
        ans_tgt = tgt[prompt_len - 1:]
        if ans_tgt.numel() == 0:
            continue
        lp = float(ans_logp.gather(1, ans_tgt.unsqueeze(-1)).squeeze(-1).mean())
        if lp > best_lp:
            best_lp, best = lp, cand
    return best, text, "fallback_logprob_rank"


def evaluate_onto_neg_wn(
    model, tok, test_path: str, device: str, seed: int = 42, *,
    save_csd_parent: bool = False,
) -> dict:
    rows = list(load_jsonl(test_path))
    preds, golds, ext, items = [], [], [], []
    for row in rows:
        pred, raw, rule = _argmax_candidate(model, tok, row, device)
        preds.append(pred)
        golds.append(row["A_star"])
        ext.append(row.get("E", ""))
        extra = _onto_csd_fields(row, pred, model, tok, device) if save_csd_parent else None
        items.append(_item_base(row, seed, raw, prediction=pred, parse_rule=rule, extra=extra))
    return {
        "INA": inner_negation_accuracy(preds, golds),
        "OER": outer_error_rate(preds, ext),
        "n": len(rows),
        "items": items,
    }


def _generate_synthesis(model, tok, row: dict, device, max_new_tokens: int = 16):
    prompt = (
        f"Given target '{row['T']}' and the related concept '{row['A']}' "
        f"(relation: {row.get('relation','')}), name the most general concept "
        f"that includes both as a single word or short noun phrase.\nAnswer:"
    )
    enc = tok(prompt, return_tensors="pt").to(device)
    with torch.no_grad():
        out = model.base.generate(
            **enc,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tok.pad_token_id,
        )
    text = _decode_new_tokens(tok, out[0], enc["input_ids"].shape[1])
    parsed = parse_abstraction(text)
    return str(parsed.value), text, parsed.rule


def evaluate_concept_shift(
    model, tok, test_path: str, device: str, seed: int = 42, *,
    save_csd_parent: bool = False,
) -> dict:
    rows = list(load_jsonl(test_path))
    preds, accepted_sets, items = [], [], []
    for row in rows:
        pred, raw, rule = _generate_synthesis(model, tok, row, device)
        pred_norm = pred.lower().strip()
        preds.append(pred_norm)
        accepted = [str(row["S"]).lower().strip()] + [
            str(a).lower().strip() for a in (row.get("S_alternatives") or [])]
        accepted_sets.append(accepted)
        extra = _cs_csd_fields(row, pred, model, tok, device) if save_csd_parent else None
        items.append(_item_base(row, seed, raw, prediction=pred, parse_rule=rule, extra=extra))
    return {
        "AbsAcc-Strict": abstraction_accuracy(
            preds, [[str(r["S"]).lower().strip()] for r in rows]),
        "AbsAcc": abstraction_accuracy(preds, accepted_sets),
        "n": len(rows),
        "items": items,
    }


def evaluate_logic_repair(model, tok, test_path: str, device: str, seed: int = 42) -> dict:
    rows = list(load_jsonl(test_path))
    preds, golds = [], []
    kprime_correct = 0
    items = []
    for row in rows:
        prompt = (
            "Given the knowledge base and an injected proposition, identify the minimal "
            "unsatisfiable subset (one statement per line), then the repaired KB.\n"
            "KB:\n" + "\n".join(f"- {s}" for s in row["K"][:8])
            + f"\nInjection: {row['a_star']}\nMUS:\n"
        )
        enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to(device)
        prompt_len = enc["input_ids"].size(1)
        with torch.no_grad():
            out = model.base.generate(**enc, max_new_tokens=128, do_sample=False)
        text = _decode_new_tokens(tok, out[0], prompt_len)
        mus_parsed = parse_mus(text)
        k_parsed = parse_repaired_kb(text)
        pred_set = set(mus_parsed.value)
        gold_set = set(row["MUS"])
        preds.append(pred_set)
        golds.append(gold_set)
        gold_kprime = set(row.get("K_prime", []))
        pred_k = set(k_parsed.value)
        if pred_k and pred_k == gold_kprime:
            kprime_correct += 1
        items.append(_item_base(
            row, seed, text,
            prediction_mus=sorted(pred_set),
            prediction_k_prime=sorted(pred_k),
            parse_rule=mus_parsed.rule,
        ))
    P, R, F1 = logic_repair_f1(preds, golds)
    return {
        "MUS-Precision": P,
        "MUS-Recall": R,
        "MUS-F1": F1,
        "Kprime-Exact": kprime_correct / max(len(rows), 1),
        "n": len(rows),
        "items": items,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    ap.add_argument("--split", default="test")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--ckpt", default=None, help="Optional state dict to load")
    ap.add_argument("--model_name_or_path", default=None,
                    help="Override backbone path (cross-backbone eval)")
    ap.add_argument("--out", default="outputs/eval_main.json")
    ap.add_argument("--save_items", action="store_true",
                    help="Persist per-item predictions under out stem")
    ap.add_argument(
        "--save_csd_parent", action="store_true",
        help="Also write beam/prompt fields needed by run_csd_intervention.py",
    )
    args = ap.parse_args()

    cfg = load_yaml(args.config)
    if args.model_name_or_path:
        cfg.setdefault("model", {})
        cfg["model"]["name_or_path"] = args.model_name_or_path
        if "name" in cfg["model"]:
            cfg["model"]["name"] = args.model_name_or_path
    bench_dir = Path(cfg["bench"]["output_dir"])
    model, tok = load_dion_model(cfg)
    if args.ckpt and Path(args.ckpt).exists():
        sd = torch.load(args.ckpt, map_location="cpu")
        if "tras" in sd:
            model.heads.tras.load_state_dict(sd["tras"], strict=False)
        for n, p in model.named_parameters():
            if n in sd.get("lora", {}):
                with torch.no_grad():
                    p.copy_(sd["lora"][n].to(p.device).to(p.dtype))
        logger.info(f"Loaded checkpoint {args.ckpt}")

    # Baseline LoRA adapters (tra.rank_a == 0) must not enable DION injection:
    # Fisher estimation inside the forward hook requires grad, but generate()
    # runs under inference/no_grad and crashes otherwise.
    tra_rank = int((cfg.get("tra") or {}).get("rank_a", 0) or 0)
    if tra_rank > 0:
        model.enable_injection()
    else:
        model.disable_injection()
    device = next(model.parameters()).device

    out: dict = {
        "config": Path(args.config).name,
        "backbone": args.model_name_or_path or cfg.get("model", {}).get("name_or_path"),
        "ckpt": args.ckpt,
        "seed": args.seed,
        "parser_version": PARSER_VERSION,
    }
    out["onto_neg_wn"] = evaluate_onto_neg_wn(
        model, tok, str(bench_dir / f"onto_neg_wn_{args.split}.jsonl"), device, args.seed,
        save_csd_parent=args.save_csd_parent,
    )
    out["concept_shift"] = evaluate_concept_shift(
        model, tok, str(bench_dir / f"concept_shift_{args.split}.jsonl"), device, args.seed,
        save_csd_parent=args.save_csd_parent,
    )
    out["logic_repair"] = evaluate_logic_repair(
        model, tok, str(bench_dir / f"logic_repair_{args.split}.jsonl"), device, args.seed,
    )

    out["INA"] = out["onto_neg_wn"]["INA"]
    out["OER"] = out["onto_neg_wn"]["OER"]
    out["AbsAcc"] = out["concept_shift"]["AbsAcc"]
    out["MUS-P"] = out["logic_repair"]["MUS-Precision"]
    out["MUS-R"] = out["logic_repair"]["MUS-Recall"]
    out["MUS-F1"] = out["logic_repair"]["MUS-F1"]
    out["Kprime-Exact"] = out["logic_repair"]["Kprime-Exact"]

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    dump = dict(out)
    if args.save_items:
        items_path = Path(args.out).with_suffix(".items.jsonl")
        with items_path.open("w") as f:
            for task in ("onto_neg_wn", "concept_shift", "logic_repair"):
                for it in out[task].get("items", []):
                    record = {
                        "config": Path(args.config).stem,
                        "task": task,
                        "split": args.split,
                        "checkpoint": "final",
                        **it,
                    }
                    f.write(json.dumps(record, ensure_ascii=False) + "\n")
        logger.info(f"Wrote {items_path}")
    for k in ("onto_neg_wn", "concept_shift", "logic_repair"):
        dump[k] = {kk: vv for kk, vv in out[k].items() if kk != "items"}
    Path(args.out).write_text(json.dumps(dump, indent=2, ensure_ascii=False))
    logger.info(f"Wrote {args.out}")
    print(json.dumps(dump, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
