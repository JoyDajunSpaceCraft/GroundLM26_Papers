"""LLM-as-Judge audit utilities.

Used for the four-LLM consensus reported in the paper. Each judge sees only
the (target, candidates, prediction) triple and is asked which candidate is
the inner negation. The model identifiers below are placeholders that the
caller is expected to override via environment variables (see
``judge_one``).
"""

from __future__ import annotations

import os
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from openai import OpenAI

from dion.utils.logging_utils import get_logger

logger = get_logger("dion.eval.llm_judge")

JUDGES = ("gpt-4.1", "claude-opus-4-6", "deepseek-v3.2", "qwen-max")


def _get_client() -> OpenAI:
    return OpenAI(
        base_url=os.environ.get("DION_JUDGE_BASE", "https://api.openai.com/v1"),
        api_key=os.environ.get("DION_JUDGE_KEY"),
    )


JUDGE_PROMPT = """You are an expert in conceptual reasoning. Identify the INNER NEGATION of a target concept.

DEFINITION: An "inner negation" is another concept that shares the target's IMMEDIATE category but lacks ONE characteristic property the target has. (For example: 'fish' is the inner negation of 'dog' wrt the property 'barks' — both are 'animal', but fish do not bark.) An "external counter-example" is a concept from a DIFFERENT category entirely (like 'bicycle' vs 'dog').

Target: {target}
Missing property: {missing}
Candidates: {candidates}

Return ONLY one candidate label (no other text)."""


@dataclass
class JudgeRow:
    target: str
    missing: str
    candidates: list[str]
    gold: str


def judge_one(row: JudgeRow, model: str, retries: int = 3) -> str:
    client = _get_client()
    prompt = JUDGE_PROMPT.format(
        target=row.target, missing=row.missing,
        candidates=", ".join(row.candidates),
    )
    for attempt in range(retries):
        try:
            r = client.chat.completions.create(
                model=model, messages=[{"role": "user", "content": prompt}],
                temperature=0.0, max_tokens=12,
            )
            text = (r.choices[0].message.content or "").strip()
            for c in row.candidates:
                if c.lower() in text.lower():
                    return c
            return text
        except Exception as e:
            logger.warning(f"judge {model} error {e!r} attempt {attempt+1}")
            time.sleep(2 ** attempt)
    return ""


def judge_batch(
    rows: list[JudgeRow], model: str, max_workers: int = 8,
) -> list[str]:
    out = [""] * len(rows)
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        for i, ans in enumerate(ex.map(lambda r: judge_one(r, model), rows)):
            out[i] = ans
    return out


def fleiss_kappa(matrix: list[list[int]], num_categories: int) -> float:
    """Fleiss' kappa for k judges agreeing on N items with ``num_categories`` choices.

    matrix[i][j] = #judges who selected category j for item i.
    """
    import numpy as np
    M = np.asarray(matrix, dtype=float)
    N = M.shape[0]
    n = float(M.sum(1)[0])
    if N == 0 or n == 0:
        return 0.0
    P = (M * (M - 1)).sum(1) / (n * (n - 1))
    P_bar = P.mean()
    p = M.sum(0) / (N * n)
    P_e = (p ** 2).sum()
    if 1.0 - P_e == 0:
        return 1.0
    return float((P_bar - P_e) / (1.0 - P_e))


def cohen_kappa(a: list[str], b: list[str]) -> float:
    import numpy as np
    cats = sorted(set(a) | set(b))
    idx = {c: i for i, c in enumerate(cats)}
    K = len(cats)
    M = np.zeros((K, K), dtype=float)
    for x, y in zip(a, b):
        if x in idx and y in idx:
            M[idx[x], idx[y]] += 1
    n = M.sum()
    if n == 0:
        return 0.0
    p_o = np.trace(M) / n
    p_e = ((M.sum(0) / n) * (M.sum(1) / n)).sum()
    if 1 - p_e == 0:
        return 1.0
    return float((p_o - p_e) / (1 - p_e))
