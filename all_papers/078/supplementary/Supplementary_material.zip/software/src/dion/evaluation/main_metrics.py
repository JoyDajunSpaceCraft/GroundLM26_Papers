"""Headline DION-Bench metrics."""

from __future__ import annotations

from typing import Iterable

import numpy as np


def inner_negation_accuracy(preds: Iterable[str], golds: Iterable[str]) -> float:
    p = list(preds); g = list(golds)
    if not p:
        return 0.0
    return float(np.mean([1 if a == b else 0 for a, b in zip(p, g)]))


def outer_error_rate(preds: Iterable[str], externals: Iterable[str]) -> float:
    p = list(preds); e = list(externals)
    if not p:
        return 0.0
    return float(np.mean([1 if a == b else 0 for a, b in zip(p, e)]))


def abstraction_accuracy(
    preds: Iterable[str],
    accepted_sets: Iterable[Iterable[str]],
) -> float:
    """Score one generated abstraction against every accepted answer per item.

    ``AbsAcc`` is not a top-k prediction metric: each item has one prediction and
    an unrestricted accepted set containing ``S`` plus all audited
    ``S_alternatives``.
    """
    predictions = list(preds)
    accepted = [set(values) for values in accepted_sets]
    if not predictions:
        return 0.0
    return float(np.mean([
        1 if i < len(accepted) and prediction in accepted[i] else 0
        for i, prediction in enumerate(predictions)
    ]))


def shift_accuracy_at_k(
    preds: list[str],
    golds: list[str],
    candidates_per_item: list[list[str]] | None = None,
    k: int | None = None,
) -> float:
    """Backward-compatible wrapper for :func:`abstraction_accuracy`.

    By default every supplied accepted abstraction is used. ``k`` is retained
    only for callers reproducing an older truncated evaluation and should not be
    used for DION-Bench ``AbsAcc``.
    """
    accepted_sets: list[list[str]] = []
    for i, gold in enumerate(golds):
        values = [gold]
        if candidates_per_item is not None and i < len(candidates_per_item):
            values.extend(candidates_per_item[i])
        deduplicated = list(dict.fromkeys(values))
        accepted_sets.append(deduplicated if k is None else deduplicated[:k])
    return abstraction_accuracy(preds, accepted_sets)


def logic_repair_f1(pred_mus: list[set], gold_mus: list[set]) -> tuple[float, float, float]:
    """Macro-averaged precision / recall / F1 across rows."""
    P, R, F = [], [], []
    for p, g in zip(pred_mus, gold_mus):
        if not p and not g:
            P.append(1.0); R.append(1.0); F.append(1.0); continue
        tp = len(p & g)
        prec = tp / max(1, len(p)); rec = tp / max(1, len(g))
        f1 = 0.0 if (prec + rec) == 0 else 2 * prec * rec / (prec + rec)
        P.append(prec); R.append(rec); F.append(f1)
    return float(np.mean(P)), float(np.mean(R)), float(np.mean(F))
