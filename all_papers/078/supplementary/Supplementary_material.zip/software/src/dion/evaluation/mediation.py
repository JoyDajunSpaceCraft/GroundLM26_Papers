"""Mediation and specificity-bias analysis.

Implements:
  1. Specificity scoring for ConceptShift predictions
  2. Logistic regression for error prediction (AUC reporting)
  3. Sobel-Goodman mediation test
  4. Error taxonomy classification
  5. Multilevel mediation with method-family fixed effects and run-level
     random intercepts

These utilities reproduce the analysis reported in the paper's analysis
section (specificity-bias as a manipulable mechanistic contributor).

Checkpoints are nested inside training runs and runs inside method families,
so ``multilevel_mediation`` is the estimator for the headline decomposition:
it keeps every model on a linear scale (logistic total and direct
coefficients are not comparable because they are non-collapsible), absorbs
method families as fixed effects, shrinks run-level intercepts, and takes its
interval from a run-level cluster bootstrap.  The decomposition is an
association, not a causal effect.
"""

from __future__ import annotations

import math
from collections.abc import Hashable, Sequence
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class MediationResult:
    total_effect: float
    direct_effect: float
    indirect_effect: float
    proportion_mediated: float
    sobel_z: float
    sobel_p: float


@dataclass
class MultilevelMediationResult:
    total_effect: float
    direct_effect: float
    indirect_effect: float
    proportion_associated: float
    ci_lo: float
    ci_hi: float
    n_obs: int
    n_runs: int
    n_families: int
    mediator_coefficient: float = 0.0
    mediator_ci_lo: float = 0.0
    mediator_ci_hi: float = 0.0
    treatment_on_mediator: float = 0.0
    scale: str = "linear"
    interpretation: str = "associational"


def specificity_score(prediction: str, gold: str, target: str) -> float:
    """Post-hoc specificity score for analysis relative to a reference LCS.

    Distinct from the gold-free-at-evaluation penalty in
    ``eval_time_intervention.py``. This helper is used only when scoring
    already-decoded predictions against a known reference abstraction for
    taxonomy / mediation tables.
    """
    pred_tokens = set(prediction.lower().split())
    gold_tokens = set(gold.lower().split())
    target_tokens = set(target.lower().split())

    pred_novelty = len(pred_tokens - gold_tokens - target_tokens)
    length_ratio = len(prediction) / max(len(gold), 1)
    leaf = 1.0 if prediction.strip().lower() == target.strip().lower() else 0.0
    return float(pred_novelty + 0.5 * math.log1p(length_ratio) + 1.25 * leaf)


def is_over_specific(prediction: str, gold: str, target: str) -> bool:
    """Whether a decoded abstraction reads as more specific than the reference.

    The test is surface-level and length-free: the answer either introduces
    material that neither the reference abstraction nor the target mentions, or
    it simply echoes the target instead of abstracting over it. Dropping a
    modifier from the reference is therefore never counted, which keeps the
    under-specification failure mode out of this category.
    """
    pred_tokens = set(prediction.lower().split())
    novel = pred_tokens - set(gold.lower().split()) - set(target.lower().split())
    return bool(novel) or prediction.strip().lower() == target.strip().lower()


def concept_shift_profile(
    predictions: Path, bench: Path, seed: int = 42,
) -> dict[str, object]:
    """Per-item specificity scores and error flags for one ConceptShift run.

    Shared by the mediation analysis and the checkpoint-trajectory builder so
    that the over-specific selection rate has exactly one definition. Gold labels
    are read from the benchmark file and predictions only from ``raw_output``,
    matching what the ledger validator enforces.
    """
    from dion.evaluation.output_parser import parse_abstraction

    def rows(path: Path) -> list[dict]:
        import json
        return [json.loads(line) for line in path.open() if line.strip()]

    gold = {r["id"]: r for r in rows(bench)}
    scores: list[float] = []
    errors: list[int] = []
    over: list[bool] = []
    for item in rows(predictions):
        if item["task"] != "concept_shift" or int(item["seed"]) != seed:
            continue
        row = gold[item["id"]]
        pred = str(parse_abstraction(item["raw_output"]).value)
        accepted = {str(row["S"]).lower()} | {
            str(a).lower() for a in (row.get("S_alternatives") or [])}
        scores.append(specificity_score(pred, str(row["S"]), str(row["T"])))
        over.append(is_over_specific(pred, str(row["S"]), str(row["T"])))
        errors.append(int(pred.lower() not in accepted))
    x = np.asarray(scores, dtype=float)
    y = np.asarray(errors, dtype=int)
    flags = np.asarray(over, dtype=bool)
    return {
        "n_items": int(y.size),
        "error_rate": float(y.mean()),
        "over_specific_selection_rate": float(flags.mean()),
        "specificity_error_share": float(flags[y == 1].mean()) if y.any() else 0.0,
        "scores": x,
        "errors": y,
    }


def logistic_auc(X: np.ndarray, y: np.ndarray, leave_one_out: bool = True) -> float:
    """Fit a logistic model and return AUC (LOO when N is small, else 5-fold).

    X: (N, D) features
    y: (N,) binary labels (1 = error)
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import LeaveOneOut, cross_val_predict

    clf = LogisticRegression(max_iter=500, solver="lbfgs")
    n = len(y)
    cv = LeaveOneOut() if (leave_one_out and n <= 200) else 5
    probs = cross_val_predict(clf, X, y, cv=cv, method="predict_proba")[:, 1]

    n = len(y)
    pos = y.sum()
    neg = n - pos
    if pos == 0 or neg == 0:
        return 0.5

    sorted_idx = np.argsort(-probs)
    tp, fp = 0.0, 0.0
    auc = 0.0
    for i in sorted_idx:
        if y[i] == 1:
            tp += 1
        else:
            fp += 1
            auc += tp
    return auc / (pos * neg) if pos * neg > 0 else 0.5


def sobel_test(a: float, b: float, se_a: float, se_b: float) -> tuple[float, float]:
    """Sobel-Goodman test for indirect effect a*b.

    Returns (z, p_two_sided).
    """
    se_ab = math.sqrt(a**2 * se_b**2 + b**2 * se_a**2)
    if se_ab == 0:
        return 0.0, 1.0
    z = (a * b) / se_ab
    from scipy.stats import norm
    p = 2 * (1 - norm.cdf(abs(z)))
    return float(z), float(p)


def mediation_analysis(
    X: np.ndarray,
    mediator: np.ndarray,
    y: np.ndarray,
) -> MediationResult:
    """Baron-Kenny mediation analysis.

    X: (N,) treatment indicator (1 = Self-Rewarding, 0 = Base)
    mediator: (N,) specificity-selection rate
    y: (N,) outcome (error indicator)
    """
    from sklearn.linear_model import LinearRegression, LogisticRegression

    X_2d = X.reshape(-1, 1)
    lr_a = LinearRegression().fit(X_2d, mediator)
    a = float(lr_a.coef_[0])
    residuals_a = mediator - lr_a.predict(X_2d)
    se_a = float(np.sqrt(np.mean(residuals_a**2) / np.sum((X - X.mean())**2)))

    XM = np.column_stack([X, mediator])
    lr_total = LogisticRegression(max_iter=500).fit(X_2d, y)
    total_effect = float(lr_total.coef_[0, 0])

    lr_direct = LogisticRegression(max_iter=500).fit(XM, y)
    direct_effect = float(lr_direct.coef_[0, 0])
    b = float(lr_direct.coef_[0, 1])
    # Approximate SE of logistic coefficient via inverse Fisher information
    # of the fitted model (diagonal of the covariance matrix).
    try:
        import numpy.linalg as npl
        probs = lr_direct.predict_proba(XM)[:, 1]
        W = probs * (1.0 - probs)
        XMw = XM * np.sqrt(W)[:, None]
        cov = npl.pinv(XMw.T @ XMw)
        se_b = float(np.sqrt(max(cov[1, 1], 1e-12)))
    except Exception:
        se_b = float(np.std(mediator) / max(np.sqrt(len(mediator)), 1.0))

    indirect_effect = total_effect - direct_effect
    proportion = indirect_effect / total_effect if abs(total_effect) > 1e-8 else 0.0

    z, p = sobel_test(a, b, se_a, se_b)

    return MediationResult(
        total_effect=total_effect,
        direct_effect=direct_effect,
        indirect_effect=indirect_effect,
        proportion_mediated=proportion,
        sobel_z=z,
        sobel_p=p,
    )


# Stand-in for an infinite shrinkage weight, applied when the group-variance
# estimate collapses; it drives every group intercept to ~0.
_MAX_LAMBDA = 1e12
_MIN_GROUP_VAR = 1e-12
# Below this the treatment->mediator, mediator->outcome or total path carries
# no signal and the total-direct gap is numerical noise rather than a share.
_NULL_PATH_TOL = 1e-12


def fit_random_intercept_ols(
    y: np.ndarray,
    X: np.ndarray,
    group_ids: Sequence[Hashable],
    max_iter: int = 50,
    tol: float = 1e-8,
) -> tuple[np.ndarray, dict[Hashable, float], float, float]:
    """Ridge-shrunken random-intercept estimator; not full REML.

    ``X`` is the fixed-effects design exactly as the caller built it (any
    intercept or dummy column included).  Each iteration alternates between

      (i)  least squares for the fixed part, using the current group
           intercepts as an offset, and
      (ii) shrunken group intercepts ``b_g = sum(resid_g) / (n_g + lambda)``
           with ``lambda = sigma_resid^2 / sigma_group^2``,

    re-estimating both variance components from the marginal residuals with a
    one-way method-of-moments rule: ``sigma_resid^2`` from within-group
    deviations and ``sigma_group^2`` from the between-group variance of the
    group residual means minus its sampling component.  Estimating the group
    variance from the residuals rather than from the shrunken intercepts is
    what keeps ``lambda`` finite -- feeding the already-shrunken intercepts
    back in would drive the intercepts to zero.

    Returns ``(beta, group_intercepts, sigma_resid, sigma_group)``, with
    ``beta`` aligned to the columns of ``X``.
    """
    y = np.asarray(y, dtype=float).ravel()
    X = np.asarray(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    labels = list(group_ids)
    n, p = X.shape
    if y.size != n or len(labels) != n:
        raise ValueError(f"y ({y.size}), X ({n}) and group_ids ({len(labels)}) must align")
    if n == 0:
        raise ValueError("no observations")

    codes = {label: i for i, label in enumerate(dict.fromkeys(labels))}
    gidx = np.fromiter((codes[label] for label in labels), dtype=int, count=n)
    n_groups = len(codes)
    group_sizes = np.bincount(gidx, minlength=n_groups).astype(float)

    # The design is constant across iterations, so one pseudo-inverse serves
    # every least-squares step.
    pinv_X = np.linalg.pinv(X)
    beta = np.zeros(p)
    b = np.zeros(n_groups)
    s2_resid = 0.0
    s2_group = 0.0
    for _ in range(max(max_iter, 1)):
        beta_new = pinv_X @ (y - b[gidx])
        marginal = y - X @ beta_new
        group_sums = np.bincount(gidx, weights=marginal, minlength=n_groups)
        group_means = group_sums / group_sizes
        within = marginal - group_means[gidx]
        s2_resid = float(within @ within) / max(n - n_groups, 1)
        if n_groups > 1:
            between = float(np.var(group_means, ddof=1))
            s2_group = max(between - s2_resid * float(np.mean(1.0 / group_sizes)), 0.0)
        else:
            s2_group = 0.0
        lam = s2_resid / s2_group if s2_group > _MIN_GROUP_VAR else _MAX_LAMBDA
        b_new = group_sums / (group_sizes + lam)
        delta = max(
            float(np.max(np.abs(beta_new - beta))) if p else 0.0,
            float(np.max(np.abs(b_new - b))),
        )
        beta, b = beta_new, b_new
        if delta < tol:
            break

    intercepts = {label: float(b[i]) for label, i in codes.items()}
    return beta, intercepts, math.sqrt(s2_resid), math.sqrt(s2_group)


def _family_dummies(family_ids: Sequence[Hashable]) -> np.ndarray:
    """Method-family dummies with the first observed level as reference."""
    labels = list(family_ids)
    levels = list(dict.fromkeys(labels))
    if len(levels) < 2:
        return np.zeros((len(labels), 0))
    codes = {level: i for i, level in enumerate(levels)}
    out = np.zeros((len(labels), len(levels) - 1))
    for row, label in enumerate(labels):
        col = codes[label] - 1
        if col >= 0:
            out[row, col] = 1.0
    return out


def _fixed_design(
    treatment: np.ndarray,
    family_ids: Sequence[Hashable],
    mediator: np.ndarray | None = None,
    family_fixed_effects: bool = True,
) -> np.ndarray:
    """Columns: intercept, treatment, [mediator], method-family dummies."""
    cols = [np.ones_like(treatment), treatment]
    if mediator is not None:
        cols.append(mediator)
    if family_fixed_effects:
        cols.extend(_family_dummies(family_ids).T)
    return np.column_stack(cols)


@dataclass
class _LinearPaths:
    a: float  # treatment -> mediator
    b: float  # mediator -> outcome, treatment held fixed
    total: float  # treatment -> outcome
    direct: float  # treatment -> outcome, mediator held fixed


def _fit_linear_paths(
    treatment: np.ndarray,
    mediator: np.ndarray,
    outcome: np.ndarray,
    run_ids: Sequence[Hashable],
    family_ids: Sequence[Hashable],
    family_fixed_effects: bool = True,
) -> _LinearPaths:
    design = _fixed_design(
        treatment, family_ids, family_fixed_effects=family_fixed_effects)
    design_with_mediator = _fixed_design(
        treatment, family_ids, mediator=mediator,
        family_fixed_effects=family_fixed_effects)
    beta_m, *_ = fit_random_intercept_ols(mediator, design, run_ids)
    beta_total, *_ = fit_random_intercept_ols(outcome, design, run_ids)
    beta_direct, *_ = fit_random_intercept_ols(outcome, design_with_mediator, run_ids)
    return _LinearPaths(
        a=float(beta_m[1]),
        b=float(beta_direct[2]),
        total=float(beta_total[1]),
        direct=float(beta_direct[1]),
    )


def _proportion_associated(paths: _LinearPaths) -> float:
    """Share of the total association that runs alongside the mediator.

    On a linear scale the total and direct coefficients are on the same
    footing, so ``total - direct`` is the indirect part (it equals ``a * b``
    up to the differing run-intercept shrinkage of the two outcome models).
    """
    if (
        abs(paths.total) <= _NULL_PATH_TOL
        or abs(paths.a) <= _NULL_PATH_TOL
        or abs(paths.b) <= _NULL_PATH_TOL
    ):
        return 0.0
    return (paths.total - paths.direct) / paths.total


def multilevel_mediation(
    treatment: Sequence[float],
    mediator: Sequence[float],
    outcome: Sequence[float],
    run_ids: Sequence[Hashable],
    family_ids: Sequence[Hashable],
    n_boot: int = 2000,
    alpha: float = 0.05,
    seed: int = 42,
    cluster_ids: Sequence[Hashable] | None = None,
    family_fixed_effects: bool = True,
) -> MultilevelMediationResult:
    """Multilevel mediation decomposition on a linear scale.

    Three models share the same fixed-effects structure -- method-family
    dummies plus shrunken run-level intercepts (``fit_random_intercept_ols``):

      M:        mediator ~ treatment + family + (1 | run)
      Y total:  outcome  ~ treatment + family + (1 | run)
      Y direct: outcome  ~ treatment + mediator + family + (1 | run)

    All three are linear, so ``indirect = total - direct`` is well defined;
    the same subtraction on logistic coefficients would be confounded by
    non-collapsibility.  The interval resamples whole clusters with replacement
    because checkpoints within a cluster are not independent replicates, and
    each resampled cluster is relabelled so a cluster drawn twice contributes
    two intercepts.  ``cluster_ids`` selects the resampling unit and defaults
    to ``run_ids``; passing ``family_ids`` gives the wider method-family
    interval.  Replicates that fail to fit are dropped.

    The reported ``proportion_associated`` is an association under a
    no-unmeasured-confounding assumption that this design cannot test.
    """
    t = np.asarray(treatment, dtype=float).ravel()
    m = np.asarray(mediator, dtype=float).ravel()
    y = np.asarray(outcome, dtype=float).ravel()
    runs = list(run_ids)
    families = list(family_ids)
    n_obs = int(t.size)
    if not (m.size == n_obs and y.size == n_obs and len(runs) == n_obs and len(families) == n_obs):
        raise ValueError("treatment, mediator, outcome, run_ids and family_ids must align")
    if n_obs == 0:
        raise ValueError("no observations")

    paths = _fit_linear_paths(
        t, m, y, runs, families, family_fixed_effects=family_fixed_effects)
    proportion = _proportion_associated(paths)

    rows_by_run: dict[Hashable, list[int]] = {}
    for pos, run in enumerate(runs):
        rows_by_run.setdefault(run, []).append(pos)
    n_runs = len(rows_by_run)

    units = list(cluster_ids) if cluster_ids is not None else runs
    if len(units) != n_obs:
        raise ValueError("cluster_ids must align with the observations")
    rows_by_unit: dict[Hashable, list[int]] = {}
    for pos, unit in enumerate(units):
        rows_by_unit.setdefault(unit, []).append(pos)
    unit_rows = [np.asarray(r, dtype=int) for r in rows_by_unit.values()]
    n_units = len(unit_rows)

    rng = np.random.default_rng(seed)
    replicates: list[float] = []
    mediator_replicates: list[float] = []
    for _ in range(max(n_boot, 0)):
        picked = rng.integers(0, n_units, size=n_units)
        rows = np.concatenate([unit_rows[p] for p in picked])
        # Relabel runs per draw so a unit sampled twice contributes two
        # independent intercepts rather than pooling into one.
        boot_runs = [
            f"{draw}:{runs[i]}"
            for draw, p in enumerate(picked) for i in unit_rows[p]
        ]
        boot_families = [families[i] for i in rows]
        try:
            boot_paths = _fit_linear_paths(
                t[rows], m[rows], y[rows], boot_runs, boot_families,
                family_fixed_effects=family_fixed_effects)
        except (np.linalg.LinAlgError, ValueError, ZeroDivisionError):
            continue
        value = _proportion_associated(boot_paths)
        if math.isfinite(value):
            replicates.append(value)
        if math.isfinite(boot_paths.b):
            mediator_replicates.append(boot_paths.b)

    def interval(values: list[float], fallback: float) -> tuple[float, float]:
        if not values:
            return fallback, fallback
        return (float(np.quantile(values, alpha / 2)),
                float(np.quantile(values, 1 - alpha / 2)))

    ci_lo, ci_hi = interval(replicates, float(proportion))
    m_lo, m_hi = interval(mediator_replicates, paths.b)

    return MultilevelMediationResult(
        total_effect=paths.total,
        direct_effect=paths.direct,
        indirect_effect=paths.total - paths.direct,
        proportion_associated=float(proportion),
        ci_lo=ci_lo,
        ci_hi=ci_hi,
        n_obs=n_obs,
        n_runs=n_runs,
        n_families=len(dict.fromkeys(families)),
        mediator_coefficient=paths.b,
        mediator_ci_lo=m_lo,
        mediator_ci_hi=m_hi,
        treatment_on_mediator=paths.a,
        scale="linear",
        interpretation="associational",
    )


def classify_error_taxonomy(
    prediction: str,
    gold: str,
    target: str,
    candidates: list[str] | None = None,
) -> str:
    """Classify a ConceptShift error into the paper's taxonomy.

    Categories:
      - specificity_bias: prediction is more specific than gold
      - abstraction_error: prediction is a hypernym/broader term
      - lcs_ambiguity: multiple valid LCS candidates exist
      - kg_noise: gold or prediction has quality issues
      - reasoning_error: other reasoning failure
    """
    pred_l = prediction.lower().strip()
    gold_l = gold.lower().strip()

    if pred_l == gold_l:
        return "correct"

    if is_over_specific(prediction, gold, target):
        return "specificity_bias"

    if gold_l in pred_l or pred_l in gold_l:
        return "abstraction_error"

    if candidates and prediction in candidates:
        return "lcs_ambiguity"

    if len(gold) <= 2 or len(prediction) <= 2:
        return "kg_noise"

    return "reasoning_error"
