"""Frontier LLM evaluation on all three DION-Bench tasks (validation V4)."""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

from dion.evaluation.llm_judge import _get_client
from dion.evaluation.main_metrics import (
    inner_negation_accuracy,
    logic_repair_f1,
    shift_accuracy_at_k,
)
from dion.utils.io import load_jsonl
from dion.utils.logging_utils import get_logger

logger = get_logger("dion.eval.frontier")

FRONTIER_MODELS = ("gpt-4.1", "claude-opus-4-6", "deepseek-v3.2", "qwen-max")

ONTO_PROMPT = """Identify the inner negation of the target concept.
An inner negation is a same-category concept that shares the target's immediate hypernym but LACKS the given property.

Target: {target}
Missing property: {missing}
Candidates: {candidates}

Return ONLY the label of the inner negation (one candidate, nothing else)."""

CS_PROMPT = """Given target '{T}' and related concept '{A}' (relation: {relation}),
name the most general concept that includes both as a short noun phrase.
Return ONLY that concept."""

LR_PROMPT = """Knowledge base:
{kb}

Assertion: {a_star}

Return a JSON object with keys "MUS" (list of conflicting sentences) and
"K_prime" (repaired KB sentences)."""


def _call(client, model: str, prompt: str, max_tokens: int = 64, retries: int = 3) -> str:
    for attempt in range(retries):
        try:
            r = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=max_tokens,
            )
            return (r.choices[0].message.content or "").strip()
        except Exception as e:
            logger.warning(f"{model} error {e!r} attempt {attempt+1}")
            time.sleep(2 ** attempt)
    return ""


def evaluate_onto(client, model: str, rows: list[dict]) -> dict:
    preds = []
    for row in rows:
        text = _call(client, model, ONTO_PROMPT.format(
            target=row["T"], missing=row.get("missing_relation", ""),
            candidates=", ".join(row["candidates"]),
        ), max_tokens=16)
        pred = ""
        for c in row["candidates"]:
            if c.lower() in text.lower():
                pred = c
                break
        preds.append(pred)
    golds = [r["A_star"] for r in rows]
    return {"INA": inner_negation_accuracy(preds, golds), "n": len(rows)}


def evaluate_cs(client, model: str, rows: list[dict]) -> dict:
    preds, golds, alts = [], [], []
    for row in rows:
        pred = _call(client, model, CS_PROMPT.format(
            T=row["T"], A=row["A"], relation=row.get("relation", ""),
        ), max_tokens=16)
        preds.append(pred)
        golds.append(row["S"])
        alts.append([row["S"]] + list(row.get("S_alternatives") or []))
    return {
        "AbsAcc": shift_accuracy_at_k(preds, golds, candidates_per_item=alts),
        "n": len(rows),
    }


def evaluate_lr(client, model: str, rows: list[dict]) -> dict:
    mus_preds, mus_golds = [], []
    for row in rows:
        text = _call(client, model, LR_PROMPT.format(
            kb="\n".join(f"- {s}" for s in row["K"]),
            a_star=row["a_star"],
        ), max_tokens=256)
        try:
            obj = json.loads(text[text.find("{"): text.rfind("}") + 1])
            mus = set(obj.get("MUS", []))
        except Exception:
            mus = set()
        mus_preds.append(mus)
        mus_golds.append(set(row["MUS"]))
    p, r, f1 = logic_repair_f1(mus_preds, mus_golds)
    return {"MUS-P": p, "MUS-R": r, "MUS-F1": f1, "n": len(rows)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="test")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--out", default="outputs/frontier_eval.json")
    args = ap.parse_args()

    onto = list(load_jsonl(f"data/bench/onto_neg_wn_{args.split}.jsonl"))[: args.n]
    cs = list(load_jsonl(f"data/bench/concept_shift_{args.split}.jsonl"))[: args.n]
    lr = list(load_jsonl(f"data/bench/logic_repair_{args.split}.jsonl"))[: args.n]

    results = {}
    if not os.environ.get("DION_JUDGE_KEY"):
        logger.warning("DION_JUDGE_KEY not set; writing schema-only stub")
        Path(args.out).write_text(json.dumps({"error": "no_api_key"}, indent=2))
        return

    client = _get_client()
    for model in FRONTIER_MODELS:
        logger.info(f"Evaluating {model} on three tasks ...")
        results[model] = {
            "onto_neg_wn": evaluate_onto(client, model, onto),
            "concept_shift": evaluate_cs(client, model, cs),
            "logic_repair": evaluate_lr(client, model, lr),
        }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(results, indent=2, ensure_ascii=False))
    logger.info(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
