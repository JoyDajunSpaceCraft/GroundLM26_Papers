"""Statistical utilities for the DION-Bench protocol.

Implements the four-layer report described in the paper:
  S1  item-level paired bootstrap
  S2  hierarchical seed-item bootstrap
  S3  TOST equivalence at multiple margins
  S4  Benjamini--Hochberg correction

Plus cluster bootstrap, McNemar exact, Spearman / partial correlations.

Headline decisions use the two-way layer instead of S1: the units of
inference for a post-training method are the training run, the semantic
cluster and the test item, so ``two_way_hierarchical_bootstrap`` and
``two_way_tost`` resample runs first and clusters/items within each
resampled run, and ``audit_decision`` combines those interval estimates into
the AuditPass clauses.  ``equivalence_margin_justification`` derives the
equivalence margin from observed variance and target power instead of
treating it as a constant.
"""

from __future__ import annotations

import math
from collections.abc import Hashable, Mapping, Sequence
from typing import Any

import numpy as np


def paired_bootstrap(
    diff: Sequence[float],
    n_boot: int = 10000,
    alpha: float = 0.05,
    seed: int = 42,
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    arr = np.asarray(diff, dtype=float)
    n = arr.shape[0]
    boots = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boots[i] = arr[idx].mean()
    lo = float(np.quantile(boots, alpha / 2))
    hi = float(np.quantile(boots, 1 - alpha / 2))
    return lo, hi


def hierarchical_seed_item_bootstrap(
    diff_by_seed: dict[int, Sequence[float]],
    n_boot: int = 10000,
    alpha: float = 0.05,
    seed: int = 42,
) -> tuple[float, float, float]:
    """Two-level bootstrap: resample seeds with replacement, then items
    within each resampled seed.  Returns (mean, lo, hi).
    """
    rng = np.random.default_rng(seed)
    keys = list(diff_by_seed.keys())
    arrs = {k: np.asarray(v, dtype=float) for k, v in diff_by_seed.items()}
    if not keys:
        return 0.0, 0.0, 0.0
    boots = np.empty(n_boot)
    for i in range(n_boot):
        sk = rng.choice(keys, size=len(keys), replace=True)
        means = []
        for k in sk:
            a = arrs[k]
            if a.size == 0:
                continue
            idx = rng.integers(0, a.size, size=a.size)
            means.append(a[idx].mean())
        boots[i] = float(np.mean(means)) if means else 0.0
    obs = float(np.mean([a.mean() for a in arrs.values() if a.size]))
    lo = float(np.quantile(boots, alpha / 2))
    hi = float(np.quantile(boots, 1 - alpha / 2))
    return obs, lo, hi


def cluster_bootstrap(
    values: Sequence[float],
    cluster_ids: Sequence,
    n_boot: int = 10000,
    alpha: float = 0.05,
    seed: int = 42,
) -> tuple[float, float, float]:
    """Cluster bootstrap: resample CLUSTERS, not individual rows."""
    rng = np.random.default_rng(seed)
    arr = np.asarray(values, dtype=float)
    cl = np.asarray(cluster_ids)
    uniq = np.unique(cl)
    boots = np.empty(n_boot)
    for i in range(n_boot):
        sampled = rng.choice(uniq, size=uniq.shape[0], replace=True)
        idx = np.concatenate([np.where(cl == c)[0] for c in sampled])
        boots[i] = arr[idx].mean()
    mean = float(arr.mean())
    lo = float(np.quantile(boots, alpha / 2))
    hi = float(np.quantile(boots, 1 - alpha / 2))
    return mean, lo, hi


def tost(
    diff: Sequence[float],
    margin: float,
    n_boot: int = 10000,
    alpha: float = 0.05,
    seed: int = 42,
) -> dict[str, float]:
    """Two one-sided test for equivalence at +/- margin.

    Returns the bootstrap CI and a binary ``pass`` flag indicating whether
    the entire (1 - 2*alpha) bootstrap CI lies inside [-margin, margin].
    """
    rng = np.random.default_rng(seed)
    arr = np.asarray(diff, dtype=float)
    n = arr.shape[0]
    boots = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boots[i] = arr[idx].mean()
    lo = float(np.quantile(boots, alpha))
    hi = float(np.quantile(boots, 1 - alpha))
    return {
        "mean": float(arr.mean()),
        "lo": lo,
        "hi": hi,
        "margin": float(margin),
        "pass": bool(lo > -margin and hi < margin),
    }


def _two_way_inputs(
    diff_by_run: Mapping[Hashable, Sequence[float]],
    cluster_by_run: Mapping[Hashable, Sequence[Hashable]] | None,
) -> tuple[list[np.ndarray], list[list[np.ndarray]] | None]:
    """Normalise the two-way inputs, dropping runs that carry no items.

    Returns the per-run difference arrays and, when cluster ids are supplied,
    the item positions of every semantic cluster inside each retained run.
    Cluster annotation is all-or-nothing: annotating only some runs would
    silently mix two resampling schemes under one label, so a missing or
    mis-sized cluster sequence is an error.
    """
    arrays: list[np.ndarray] = []
    groups: list[list[np.ndarray]] | None = None if cluster_by_run is None else []
    for run_id, diffs in diff_by_run.items():
        arr = np.asarray(diffs, dtype=float).ravel()
        if arr.size == 0:
            continue
        arrays.append(arr)
        if groups is None:
            continue
        if run_id not in cluster_by_run:
            raise ValueError(f"cluster ids missing for run {run_id!r}")
        labels = list(cluster_by_run[run_id])
        if len(labels) != arr.size:
            raise ValueError(
                f"run {run_id!r}: {len(labels)} cluster ids for {arr.size} items"
            )
        by_cluster: dict[Hashable, list[int]] = {}
        for pos, label in enumerate(labels):
            by_cluster.setdefault(label, []).append(pos)
        groups.append([np.asarray(positions, dtype=int) for positions in by_cluster.values()])
    return arrays, groups


def _two_way_draws(
    arrays: list[np.ndarray],
    groups: list[list[np.ndarray]] | None,
    n_boot: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Bootstrap distribution of the mean of per-run means.

    Each replicate resamples run indices with replacement, then resamples
    within every drawn run -- whole clusters when cluster ids are known,
    single items otherwise -- and averages the resulting run means.
    """
    n_runs = len(arrays)
    draws = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        run_idx = rng.integers(0, n_runs, size=n_runs)
        total = 0.0
        for r in run_idx:
            arr = arrays[r]
            if groups is None:
                item_idx = rng.integers(0, arr.size, size=arr.size)
            else:
                clusters = groups[r]
                picked = rng.integers(0, len(clusters), size=len(clusters))
                item_idx = np.concatenate([clusters[c] for c in picked])
            total += float(arr[item_idx].mean())
        draws[i] = total / n_runs
    return draws


def _two_way_observed(
    diff_by_run: Mapping[Hashable, Sequence[float]],
    cluster_by_run: Mapping[Hashable, Sequence[Hashable]] | None,
    n_boot: int,
    seed: int,
) -> tuple[np.ndarray, list[float], int, str]:
    """Shared front-end for the two-way estimators.

    Returns the bootstrap draws, the observed per-run means, the total item
    count and the label of the resampling scheme that was used.
    """
    arrays, groups = _two_way_inputs(diff_by_run, cluster_by_run)
    resampling = "run+item" if groups is None else "run+cluster"
    run_means = [float(arr.mean()) for arr in arrays]
    n_items = int(sum(int(arr.size) for arr in arrays))
    if not arrays:
        return np.zeros(0), run_means, n_items, resampling
    draws = _two_way_draws(arrays, groups, n_boot, np.random.default_rng(seed))
    return draws, run_means, n_items, resampling


def two_way_hierarchical_bootstrap(
    diff_by_run: Mapping[Hashable, Sequence[float]],
    cluster_by_run: Mapping[Hashable, Sequence[Hashable]] | None = None,
    n_boot: int = 10000,
    alpha: float = 0.05,
    seed: int = 42,
) -> dict[str, Any]:
    """Two-way hierarchical bootstrap over training runs and clusters/items.

    ``diff_by_run`` maps a training run id to that run's per-item paired
    differences; ``cluster_by_run`` optionally maps the same run ids to the
    semantic cluster id of each item.  The estimand is the grand mean of the
    per-run means, so a method backed by three training runs cannot borrow
    precision from the number of test items.

    ``seed_sd`` reports the spread of the observed run means (the seed-level
    distribution) alongside the interval.
    """
    draws, run_means, n_items, resampling = _two_way_observed(
        diff_by_run, cluster_by_run, n_boot, seed
    )
    mean = float(np.mean(run_means)) if run_means else 0.0
    lo = float(np.quantile(draws, alpha / 2)) if draws.size else 0.0
    hi = float(np.quantile(draws, 1 - alpha / 2)) if draws.size else 0.0
    return {
        "mean": mean,
        "lo": lo,
        "hi": hi,
        "n_runs": len(run_means),
        "n_items": n_items,
        "run_means": sorted(run_means),
        "seed_sd": float(np.std(run_means, ddof=1)) if len(run_means) > 1 else 0.0,
        "resampling": resampling,
    }


def two_way_tost(
    diff_by_run: Mapping[Hashable, Sequence[float]],
    margin: float,
    cluster_by_run: Mapping[Hashable, Sequence[Hashable]] | None = None,
    n_boot: int = 10000,
    alpha: float = 0.05,
    seed: int = 42,
) -> dict[str, Any]:
    """Run-aware TOST equivalence at +/- ``margin``.

    Uses the same run-then-cluster/item resampling as
    ``two_way_hierarchical_bootstrap`` and reads the verdict off the
    (1 - 2*alpha) interval spanned by the ``alpha`` and ``1 - alpha``
    quantiles.  The verdict key is ``equivalent`` -- equivalence on one axis
    is not the protocol's overall ``AuditPass`` decision, which additionally
    requires target superiority and retention non-inferiority.
    """
    draws, run_means, _, resampling = _two_way_observed(
        diff_by_run, cluster_by_run, n_boot, seed
    )
    mean = float(np.mean(run_means)) if run_means else 0.0
    lo = float(np.quantile(draws, alpha)) if draws.size else 0.0
    hi = float(np.quantile(draws, 1 - alpha)) if draws.size else 0.0
    equivalent = bool(draws.size and lo > -margin and hi < margin)
    return {
        "mean": mean,
        "lo": lo,
        "hi": hi,
        "margin": float(margin),
        "equivalent": equivalent,
        "n_runs": len(run_means),
        "resampling": resampling,
        "seed_sd": float(np.std(run_means, ddof=1)) if len(run_means) > 1 else 0.0,
    }


#: Complementary metrics where a positive ``method − base`` delta is a regression.
LOWER_IS_BETTER_COMPLEMENTARY = frozenset({"OER"})


def metric_higher_is_better(
    name: str,
    *,
    scale: str | None = None,
    higher_is_better: bool | None = None,
) -> bool:
    """Return whether larger values (or positive method−base deltas) are better."""
    if higher_is_better is not None:
        return bool(higher_is_better)
    if scale == "relative_percent":
        # Relative PPL / analogous lower-is-better relative scales.
        return False
    return str(name) not in LOWER_IS_BETTER_COMPLEMENTARY


def noninferiority_pass(
    lo: float,
    hi: float,
    margin: float,
    *,
    higher_is_better: bool,
) -> bool:
    """One-sided non-inferiority on a signed effect interval.

    Effects are always ``method − base`` in the metric's native units.
    For higher-is-better metrics, worsening is negative, so NI requires
    ``lo > -margin``.  For lower-is-better metrics (OER, PPL relative %),
    worsening is positive, so NI requires ``hi < +margin``.
    """
    if higher_is_better:
        return bool(lo > -margin)
    return bool(hi < margin)


def audit_decision(
    target: Mapping[str, Any],
    complementary: Mapping[str, Mapping[str, Any]],
    retention: Mapping[str, Mapping[str, Any]],
    margin_pp: float = 1.0,
    alpha: float = 0.05,
) -> dict[str, Any]:
    """Combine interval estimates into the protocol-specific AuditPass clauses.

    ``target`` holds the target-axis effect in percentage points (at least
    ``mean`` and ``lo``); ``complementary`` maps each complementary axis to a
    ``two_way_tost`` result; ``retention`` maps each retention probe to its
    percentage-point (or relative-percent) effect.  Every clause is reported
    separately:

      SafeGain       = target superiority + complementary non-inferiority
                       + retention non-inferiority
      LocalizedGain  = target superiority + complementary TOST equivalence
                       + retention non-inferiority
      AuditPass      = LocalizedGain under the supplied decision intervals

    Metric direction is respected: lower-is-better complementary axes (OER)
    and relative PPL use an upper-bound NI rule so improvements cannot fail
    NI and degradations cannot pass it.  ``alpha`` is already baked into the
    intervals and is recorded only so the decision carries the confidence
    level it was taken at.
    """
    failed: list[str] = []

    target_superiority = float(target["lo"]) > 0.0
    if not target_superiority:
        failed.append("TargetSuperiority")

    complementary_equivalence = True
    complementary_ni = True
    for name, result in complementary.items():
        if not bool(result.get("equivalent", False)):
            complementary_equivalence = False
            failed.append(f"ComplementaryEquivalence[{name}]")
        hib = metric_higher_is_better(
            name, higher_is_better=result.get("higher_is_better"),
        )
        lo = float(result["lo"])
        hi = float(result.get("hi", result["lo"]))
        if not noninferiority_pass(lo, hi, margin_pp, higher_is_better=hib):
            complementary_ni = False
            failed.append(f"ComplementaryNI[{name}]")

    retention_ni = True
    retention_details: dict[str, dict[str, Any]] = {}
    for name, result in retention.items():
        if not bool(result.get("available", True)):
            retention_ni = False
            retention_details[name] = {
                "pass": False,
                "available": False,
                "reason": result.get("reason", "missing retention estimate"),
            }
            failed.append(f"RetentionNI[{name}]")
            continue
        relative = result.get("scale") == "relative_percent"
        margin = float(result.get("margin", 5.0 if relative else margin_pp))
        lo = float(result["lo"])
        hi = float(result.get("hi", result["lo"]))
        hib = metric_higher_is_better(
            name,
            scale=result.get("scale"),
            higher_is_better=result.get("higher_is_better"),
        )
        passed = noninferiority_pass(lo, hi, margin, higher_is_better=hib)
        retention_details[name] = {
            "lo": lo,
            "hi": hi,
            "margin": margin,
            "scale": "relative_percent" if relative else "percentage_points",
            "higher_is_better": hib,
            "pass": passed,
            "available": True,
        }
        if not passed:
            retention_ni = False
            failed.append(f"RetentionNI[{name}]")

    safe_gain = bool(target_superiority and complementary_ni and retention_ni)
    localized_gain = bool(
        target_superiority and complementary_equivalence and retention_ni
    )
    return {
        "TargetSuperiorityPass": target_superiority,
        "ComplementaryEquivalencePass": complementary_equivalence,
        "RetentionNIPass": retention_ni,
        "RetentionNI": retention_details,
        "SafeGain": safe_gain,
        "LocalizedGain": localized_gain,
        "AuditPass": localized_gain,
        "failed_clauses": failed,
        "target_mean_pp": float(target["mean"]),
        "margin_pp": float(margin_pp),
        "alpha": float(alpha),
    }


# Normal quantiles for the alpha / power combinations the protocol uses, in
# case SciPy is not installed.
_Z_TABLE: dict[float, float] = {
    0.700: 0.5244005127,
    0.800: 0.8416212336,
    0.900: 1.2815515655,
    0.950: 1.6448536270,
    0.975: 1.9599639845,
    0.990: 2.3263478740,
    0.995: 2.5758293035,
}


def _z(p: float) -> float:
    try:
        from scipy.stats import norm

        return float(norm.ppf(p))
    except ImportError:
        nearest = min(_Z_TABLE, key=lambda key: abs(key - p))
        if abs(nearest - p) > 1e-6:
            raise ValueError(
                f"SciPy unavailable and no tabulated normal quantile for p={p}; "
                f"tabulated values: {sorted(_Z_TABLE)}"
            ) from None
        return _Z_TABLE[nearest]


def equivalence_margin_justification(
    run_sd: float,
    n_runs: int,
    margin: float,
    observed_half_width: float = 0.0,
    power: float = 0.8,
    alpha: float = 0.05,
) -> dict[str, Any]:
    """Tie the equivalence margin to observed variance and target power.

    The unit of inference is the training run, so precision is set by
    ``n_runs`` and never by the number of test items: pooling items across runs
    would report a design that resolves effects it cannot actually resolve.
    ``run_sd`` is the across-run standard deviation of the effect and
    ``observed_half_width`` the half-width of the two-way hierarchical
    ``1 - 2*alpha`` interval, which also carries the cluster noise the run
    standard error alone omits; when it is absent the run standard error is
    used instead.

      min_resolvable_effect = (z_{1-alpha} + z_power) * total_se, the smallest
                              effect the design resolves at ``power``

    ``margin_is_resolvable`` says whether the supplied margin reaches that
    floor, and ``runs_required_for_half_margin`` how many runs halving it would
    take.  All quantities carry the unit of ``run_sd``.
    """
    if n_runs <= 0:
        raise ValueError("n_runs must be positive")
    if run_sd < 0 or observed_half_width < 0 or margin < 0:
        raise ValueError("run_sd, observed_half_width and margin must be non-negative")
    run_se = float(run_sd) / math.sqrt(n_runs)
    total_se = float(observed_half_width) / _z(1 - alpha) if observed_half_width else run_se
    mre = (_z(1 - alpha) + _z(power)) * total_se
    return {
        "run_sd": float(run_sd),
        "n_runs": int(n_runs),
        "run_standard_error": run_se,
        "observed_ci90_half_width": float(observed_half_width),
        "implied_total_standard_error": total_se,
        "min_resolvable_effect": float(mre),
        "margin": float(margin),
        "margin_is_resolvable": bool(margin >= mre),
        "runs_required_for_half_margin": (
            int(math.ceil(n_runs * (mre / (margin / 2)) ** 2)) if margin else 0),
        "power": float(power),
        "alpha": float(alpha),
    }


def bh_correct(pvalues: Sequence[float], alpha: float = 0.05) -> list[bool]:
    """Benjamini--Hochberg step-up procedure.

    Returns a boolean list of the same length as ``pvalues``: ``True`` if
    the corresponding p-value is rejected at FDR = alpha.
    """
    p = np.asarray(pvalues, dtype=float)
    n = p.shape[0]
    if n == 0:
        return []
    order = np.argsort(p)
    ranked = p[order]
    thresh = alpha * (np.arange(1, n + 1) / n)
    passed = ranked <= thresh
    if not passed.any():
        max_k = -1
    else:
        max_k = int(np.max(np.where(passed)[0]))
    out = np.zeros(n, dtype=bool)
    for rk in range(max_k + 1):
        out[order[rk]] = True
    return out.tolist()


def mcnemar_pvalue(b: int, c: int) -> float:
    """Two-sided exact McNemar p-value for paired binary outcomes."""
    from scipy.stats import binomtest

    n = b + c
    if n == 0:
        return 1.0
    return float(binomtest(min(b, c), n, p=0.5).pvalue)


def _rank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(x) + 1)
    return ranks


def spearman(x: Sequence[float], y: Sequence[float]) -> float:
    """Spearman rank correlation (no SciPy dependency)."""
    a = np.asarray(x, dtype=float)
    b = np.asarray(y, dtype=float)
    if a.size == 0 or b.size == 0 or a.size != b.size:
        return 0.0
    ra = _rank(a)
    rb = _rank(b)
    ra -= ra.mean(); rb -= rb.mean()
    denom = (np.sqrt((ra ** 2).sum()) * np.sqrt((rb ** 2).sum()))
    if denom == 0:
        return 0.0
    return float((ra * rb).sum() / denom)


def spearman_partial(
    x: Sequence[float],
    y: Sequence[float],
    controls: Sequence[Sequence[float]],
) -> float:
    """Partial Spearman correlation between ranks of x and y, controlling for
    the rank-residuals against the columns of ``controls``.
    """
    a = _rank(np.asarray(x, dtype=float))
    b = _rank(np.asarray(y, dtype=float))
    if a.size == 0 or a.size != b.size:
        return 0.0
    if not controls:
        return spearman(a, b)
    Z = np.stack([_rank(np.asarray(c, dtype=float)) for c in controls], axis=1)
    Z = np.concatenate([np.ones((Z.shape[0], 1)), Z], axis=1)
    coef_a, *_ = np.linalg.lstsq(Z, a, rcond=None)
    coef_b, *_ = np.linalg.lstsq(Z, b, rcond=None)
    res_a = a - Z @ coef_a
    res_b = b - Z @ coef_b
    res_a -= res_a.mean(); res_b -= res_b.mean()
    denom = np.sqrt((res_a ** 2).sum()) * np.sqrt((res_b ** 2).sum())
    if denom == 0:
        return 0.0
    return float((res_a * res_b).sum() / denom)
