"""General-capability retention evaluations.

The recommended drop limit for conservative configurations is approximately
1.5 percentage points per task.  The suite is GSM8K, MMLU-Pro, HellaSwag,
ARC-Challenge, TruthfulQA-MC1, and a WikiText perplexity probe; this matches
the headline retention table reported in the paper.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Callable

import numpy as np
from datasets import load_dataset

from dion.utils.logging_utils import get_logger

logger = get_logger("dion.eval.general")


@dataclass
class RetentionResult:
    task: str
    n: int
    score: float
    raw: list[float]


def _extract_letter(text: str) -> str:
    m = re.search(r"\b([A-E])\b", text)
    return m.group(1) if m else ""


def _extract_number(text: str) -> str:
    m = re.search(r"-?\d+(\.\d+)?", text)
    return m.group(0) if m else ""


def eval_mmlu_pro(
    model_call: Callable[[str], str],
    n_examples: int = 1000,
    seed: int = 42,
) -> RetentionResult:
    ds = load_dataset("TIGER-Lab/MMLU-Pro", split="test")
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(ds))[:n_examples]
    raw = []
    for i in idx:
        row = ds[int(i)]
        opts = row["options"]
        prompt = (
            f"{row['question']}\n"
            + "\n".join(f"{chr(65+j)}. {o}" for j, o in enumerate(opts))
            + "\nAnswer with a single letter:"
        )
        ans = model_call(prompt).strip()
        pred = _extract_letter(ans)
        gold = chr(65 + row["answer_index"])
        raw.append(1.0 if pred == gold else 0.0)
    return RetentionResult("MMLU-Pro", len(raw), float(np.mean(raw)), raw)


def eval_gsm8k(model_call: Callable[[str], str], n_examples: int = 500) -> RetentionResult:
    # Prefer openai/gsm8k — matches common HF cache layouts (openai___gsm8k).
    try:
        ds = load_dataset("openai/gsm8k", "main", split="test")
    except Exception:
        ds = load_dataset("gsm8k", "main", split="test")
    n = min(n_examples, len(ds))
    raw = []
    for i in range(n):
        row = ds[i]
        prompt = f"Solve. Provide ONLY the final number.\n{row['question']}\nAnswer:"
        ans = model_call(prompt).strip()
        pred = _extract_number(ans)
        gold = _extract_number(row["answer"].split("####")[-1])
        raw.append(1.0 if pred == gold else 0.0)
    return RetentionResult("GSM8K", n, float(np.mean(raw)), raw)


def eval_hellaswag(model_call: Callable[[str], str], n_examples: int = 1000) -> RetentionResult:
    ds = load_dataset("hellaswag", split="validation")
    n = min(n_examples, len(ds))
    raw = []
    for i in range(n):
        row = ds[i]
        endings = row["endings"]
        prompt = (
            f"Context: {row['ctx']}\n"
            + "\n".join(f"{chr(65+j)}. {e}" for j, e in enumerate(endings))
            + "\nWhich ending is most likely? Answer with a single letter:"
        )
        ans = model_call(prompt).strip()
        pred = _extract_letter(ans)
        gold = chr(65 + int(row["label"]))
        raw.append(1.0 if pred == gold else 0.0)
    return RetentionResult("HellaSwag", n, float(np.mean(raw)), raw)


def eval_arc_c(model_call: Callable[[str], str], n_examples: int = 1000) -> RetentionResult:
    ds = load_dataset("ai2_arc", "ARC-Challenge", split="test")
    n = min(n_examples, len(ds))
    raw = []
    for i in range(n):
        row = ds[i]
        choices = row["choices"]["text"]
        labels = row["choices"]["label"]
        prompt = (
            f"{row['question']}\n"
            + "\n".join(f"{lab}. {c}" for lab, c in zip(labels, choices))
            + "\nAnswer with the letter:"
        )
        ans = model_call(prompt).strip()
        pred = _extract_letter(ans)
        raw.append(1.0 if pred == row["answerKey"] else 0.0)
    return RetentionResult("ARC-C", n, float(np.mean(raw)), raw)


def eval_truthfulqa(model_call: Callable[[str], str]) -> RetentionResult:
    ds = load_dataset("truthful_qa", "multiple_choice", split="validation")
    raw = []
    for row in ds:
        opts = row["mc1_targets"]["choices"]
        prompt = (
            f"{row['question']}\n"
            + "\n".join(f"{chr(65+j)}. {c}" for j, c in enumerate(opts))
            + "\nAnswer with a single letter:"
        )
        ans = model_call(prompt).strip()
        pred = _extract_letter(ans)
        gold_idx = int(np.argmax(row["mc1_targets"]["labels"]))
        raw.append(1.0 if pred == chr(65 + gold_idx) else 0.0)
    return RetentionResult("TruthfulQA-MC1", len(raw), float(np.mean(raw)), raw)


def eval_wikitext_ppl(
    score_fn: Callable[[str], float],
    n_examples: int = 500,
    seed: int = 42,
) -> RetentionResult:
    """WikiText perplexity probe.

    ``score_fn`` is expected to return the average per-token negative
    log-likelihood (in nats) for a passage; we exponentiate the mean to
    recover the perplexity.
    """
    ds = load_dataset("Salesforce/wikitext", "wikitext-2-raw-v1", split="test")
    rng = np.random.default_rng(seed)
    indices = rng.permutation(len(ds))[:n_examples]
    nlls: list[float] = []
    for i in indices:
        text = (ds[int(i)]["text"] or "").strip()
        if len(text) < 32:
            continue
        nll = float(score_fn(text))
        if math.isfinite(nll):
            nlls.append(nll)
    score = float(math.exp(np.mean(nlls))) if nlls else float("inf")
    return RetentionResult("WikiText-PPL", len(nlls), score, nlls)
