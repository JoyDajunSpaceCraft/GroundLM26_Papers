"""Single source of truth for turning raw model output into a scored prediction.

Every consumer -- the evaluation entrypoint, the intervention rerun, and the
ledger validator -- imports these functions, so a shipped ``raw_output`` field
is scored by exactly the code that produced it. ``PARSER_VERSION`` is written
into every prediction file and re-checked at validation time; bumping it
invalidates artifacts produced by an older parser instead of silently changing
numbers.

Parsing never consults gold: candidate lists come from the benchmark row, and
the returned :class:`ParseResult` records whether the primary rule fired or a
documented fallback was used, so fallback rates can be reported.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

PARSER_VERSION = "dion-parser-1.1.0"

_MUS_STOP = ("repaired", "k'", "k_prime", "repair:")
_KPRIME_HEADERS = ("repaired knowledge base", "repaired kb", "k_prime", "k'")
_MUS_HEADERS = (
    "minimal unsatisfiable subset", "minimal unsatisfiable core",
    "minimal unsatisfiable set", "mus",
)
_LEAD_STRIP = re.compile(
    r"^\s*(?:(?:answer|the answer is|prediction|output)\s*[:\-]?|a\s*[:\-])\s*", re.I)
_CS_LEAD = re.compile(
    r"^\s*(?:the\s+)?(?:most general|least common)\s+(?:concept|subsumer|category)"
    r"(?:\s+is)?\s*[:\-]?\s*", re.I)


@dataclass(frozen=True)
class ParseResult:
    """Parsed prediction plus how it was obtained."""

    value: str | list[str]
    rule: str

    @property
    def is_fallback(self) -> bool:
        return self.rule.startswith("fallback")


def _mentions(text: str, candidate: str) -> bool:
    """Whole-token containment, so ``a`` does not match inside ``apply``."""
    pattern = r"(?<![\w-])" + re.escape(candidate.lower()) + r"(?![\w-])"
    return re.search(pattern, text.lower()) is not None


def _first_line(text: str) -> str:
    for line in text.splitlines():
        line = line.strip()
        if line:
            return line
    return ""


def parse_candidate_choice(text: str, candidates: list[str]) -> ParseResult:
    """Pick the candidate a generation names.

    The longest matching candidate wins, so a candidate that is a substring of
    another (``lamp`` inside ``ultraviolet lamp``) cannot shadow it. When no
    candidate appears we return the empty string and mark the item as a parse
    failure; the caller decides whether to fall back to a log-probability
    ranking, and that decision is recorded rather than hidden.
    """
    body = _LEAD_STRIP.sub("", _first_line(text)) or text
    hits = [c for c in candidates if c and _mentions(text, c)]
    if hits:
        best = max(hits, key=lambda c: (len(c), c))
        rule = "first_line" if _mentions(body, best) else "generation_span"
        return ParseResult(best, rule)
    return ParseResult("", "fallback_no_candidate_match")


def parse_abstraction(text: str) -> ParseResult:
    """Read the short noun phrase a generation offers as the abstraction."""
    line = _first_line(text)
    stripped = _CS_LEAD.sub("", _LEAD_STRIP.sub("", line))
    value = stripped.strip().strip("\"'").strip(" .,;:!?")
    if not value:
        return ParseResult("", "fallback_empty_generation")
    return ParseResult(value, "first_line" if value == line else "lead_stripped")


def parse_mus(text: str) -> ParseResult:
    """Extract the minimal unsatisfiable subset from a generation.

    Statements are read one per line, matching the prompt instruction, and a
    single line that packs the whole set behind a header
    (``Minimal unsatisfiable subset: a; b; c``, optionally bracketed) is split
    on semicolons. Parsing stops at a repaired-KB marker.
    """
    statements: list[str] = []
    rule = "per_line"
    for raw in text.splitlines():
        line = raw.strip().lstrip("-*\u2022").strip()
        if not line:
            continue
        low = line.lower()
        if any(low.startswith(stop) for stop in _MUS_STOP):
            break
        header = next((h for h in _MUS_HEADERS if low.startswith(h)), None)
        if header is not None:
            line = line[len(header):].lstrip(" :\u2014-").strip()
            if not line:
                continue
        if line.startswith("[") and line.endswith("]"):
            line = line[1:-1].strip()
        if ";" in line:
            parts = [p.strip() for p in line.split(";")]
            statements.extend(p for p in parts if p)
            rule = "semicolon_list"
            continue
        statements.append(line)
    if not statements:
        return ParseResult([], "fallback_empty_mus")
    seen: dict[str, None] = {}
    for s in statements:
        seen.setdefault(s, None)
    return ParseResult(list(seen), rule)


def parse_repaired_kb(text: str) -> ParseResult:
    """Extract the repaired knowledge base following a K' marker.

    The accepted surface forms mirror :func:`parse_mus`: one statement per line
    or a semicolon-separated list after ``Repaired KB:``, ``K':`` or
    ``K_prime:``. Parsing is gold-independent and preserves first occurrence
    order.
    """
    statements: list[str] = []
    rule = "per_line"
    in_repair = False
    for raw in text.splitlines():
        line = raw.strip().lstrip("-*\u2022").strip()
        if not line:
            continue
        if not in_repair:
            low = line.lower()
            header = next((h for h in _KPRIME_HEADERS if low.startswith(h)), None)
            if header is None:
                continue
            in_repair = True
            line = line[len(header):].lstrip(" :\u2014-").strip()
            if not line:
                continue
        if line.startswith("[") and line.endswith("]"):
            line = line[1:-1].strip()
        if ";" in line:
            statements.extend(part for part in (
                part.strip() for part in line.split(";")) if part)
            rule = "semicolon_list"
        else:
            statements.append(line)
    if not statements:
        return ParseResult([], "fallback_empty_kprime")
    seen: dict[str, None] = {}
    for statement in statements:
        seen.setdefault(statement, None)
    return ParseResult(list(seen), rule)


def render_candidate_choice(prediction: str) -> str:
    """Canonical surface form for a candidate choice, for round-trip tests."""
    return f"Answer: {prediction}"


def render_abstraction(prediction: str) -> str:
    return f" {prediction}"


def render_mus(statements: list[str]) -> str:
    return "\n".join(f"- {s}" for s in statements)
