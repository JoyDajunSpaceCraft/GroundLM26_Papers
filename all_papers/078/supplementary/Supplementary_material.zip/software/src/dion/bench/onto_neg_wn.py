"""OntoNeg-WN constructor: attested attribute exceptions.

The gold answer is never inferred from a missing knowledge-graph edge. Every
emitted row carries positive evidence that the attribute really does not hold
for ``A*``, drawn from one of three tiers:

``explicit_negative_fact``
    ConceptNet asserts ``Not<relation>(A*, o)`` for exactly the attribute that
    the shared category attests.
``dictionary_negation``
    The WordNet gloss of ``A*`` explicitly denies the attribute
    (``flightless``, ``without seeds``, ``unable to fly``, ...).
A third tier, ``kg_edge_absence``, is the open-world heuristic. It is only ever
used to enlarge the *training* pool and is tagged as such in provenance; the
locked evaluation splits contain certified rows only.

Contrastive attribute values are deliberately *not* treated as negation:
attributes are multi-valued, so attesting ``(r, o')`` for some ``o'`` opposed to
``o`` does not entail that ``(r, o)`` fails.

Structure of a row: a shared category ``S`` attests attribute ``(r, o)``; the
target ``T`` inherits it; ``A*`` is the certified exception; two sibling
distractors also attest ``(r, o)``; and a parent-disjoint external ``E``
completes the four candidates.
"""

from __future__ import annotations

import random
import re
from pathlib import Path

from dion.bench.concept_graph import ConceptGraph
from dion.utils.io import save_jsonl
from dion.utils.logging_utils import get_logger

logger = get_logger("dion.bench.onto_neg_wn")

_LABEL_BLACKLIST_SUBSTR = (
    "another way to say",
    "way to say",
    "in other words",
    "another name for",
)
_LABEL_BLACKLIST_EXACT = {"id", "a", "an", "the", "of", "to", "is", "also", "yield"}
#: Attribute relations that denote a checkable property of a category.
#: ``Desires`` is excluded (a preference is not a property, so its negation is
#: not an attribute exception) and so is ``CapableOf`` (its objects are bare verb
#: phrases whose negation is rarely a category-level default).
_RELEVANT_ATTRS = ("UsedFor", "HasProperty", "HasA", "MadeOf")

#: Attribute objects that are evaluative, epistemic or otherwise not checkable
#: against a category default.
_ABSTRACT_ATTR_OBJECTS = frozenset({
    "willing", "knowing", "aware", "same", "important", "good", "bad", "nice",
    "exist", "make", "happen", "true", "false", "usual", "common", "certain",
    "sure", "likely", "possible", "necessary", "real", "normal", "natural",
    "interesting", "boring", "pleasant", "desirable", "acceptable", "relevant",
    "changed", "known", "wanted", "expected", "intended", "planned", "use",
    "value", "worth", "meaning", "purpose", "reason", "sense", "way", "kind",
    "sort", "type", "part", "thing", "stuff", "matter", "form", "state",
})

#: A shared category wider than this has no coherent default attribute
#: (e.g. ``human`` with thousands of hyponyms), so it cannot license a default.
_MAX_CATEGORY_WIDTH = 200

CERTIFIED_TIERS = (
    "explicit_negative_fact",
    "dictionary_negation",
)
HEURISTIC_TIER = "kg_edge_absence"

#: Surface realisations. ``CapableOf`` objects are bare verb phrases, so they are
#: realised with a modal rather than ``is capable of`` to stay grammatical.
RELATION_PHRASE = {
    "CapableOf": "can",
    "UsedFor": "is used for",
    "HasProperty": "is",
    "HasA": "has",
    "MadeOf": "is made of",
}
RELATION_NEG_PHRASE = {
    "CapableOf": "cannot",
    "UsedFor": "is not used for",
    "HasProperty": "is not",
    "HasA": "does not have",
    "MadeOf": "is not made of",
}

_LESS_RE = re.compile(r"\b([a-z]{3,})less\b")
_WITHOUT_RE = re.compile(
    r"\b(?:without|lacking|lacks|devoid of|having no|with no|not having|free of|free from|"
    r"absence of|lack of|deprived of|stripped of|bereft of|deficient in)\s+"
    r"((?:a |an |the |any )?[a-z][a-z\- ]{2,30})"
)
_UNABLE_RE = re.compile(
    r"\b(?:unable to|incapable of|cannot|can not|not able to|not capable of|"
    r"does not|do not|never|fails to|failing to)\s+"
    r"([a-z][a-z\- ]{2,30})"
)
_NON_RE = re.compile(r"\bnon-?([a-z]{4,})\b")
_UN_RE = re.compile(r"\bun([a-z]{4,})\b")

_PHRASE_STOP_TAIL = {
    "a", "an", "the", "of", "or", "and", "in", "on", "to", "for", "with", "by",
    "any", "its", "their", "other", "such", "some", "that", "which", "who", "it",
}

#: Stems whose ``-less`` / ``un-`` form is a function word rather than the
#: negation of an attribute (``regardless``, ``nevertheless``, ``until``).
_FALSE_NEGATION_STEMS = {
    "regard", "never", "neither", "none", "nonethe", "til", "less", "unt",
    "der", "iver", "ion", "ess", "able", "til", "que", "ique", "til",
}


def _is_acceptable_label(label: str) -> bool:
    if not label or not isinstance(label, str):
        return False
    s = label.strip().lower()
    if not s or s in _LABEL_BLACKLIST_EXACT or len(s) <= 1:
        return False
    return not any(sub in s for sub in _LABEL_BLACKLIST_SUBSTR)


def _clean_phrase(phrase: str, max_words: int = 2) -> str:
    """Reduce a gloss fragment to a short attribute phrase, or return ''."""
    p = phrase.strip().strip(",;:.").lower()
    p = re.sub(r"^(a|an|the)\s+", "", p)
    toks = [t for t in p.split() if t][:max_words]
    while toks and toks[-1] in _PHRASE_STOP_TAIL:
        toks.pop()
    while toks and toks[0] in _PHRASE_STOP_TAIL:
        toks.pop(0)
    if not toks or any(not t.isalpha() for t in toks):
        return ""
    return " ".join(toks)


_LEXICON: dict[str, frozenset[str]] = {}


def _lexicon(pos: str) -> frozenset[str]:
    """Lemma surfaces of one part of speech, used to reject malformed phrases."""
    got = _LEXICON.get(pos)
    if got is None:
        from nltk.corpus import wordnet as wn

        got = frozenset(
            name.replace("_", " ").lower() for name in wn.all_lemma_names(pos=pos)
        )
        _LEXICON[pos] = got
    return got


def _is_lexical_attribute(label: str, pos: str = "n") -> bool:
    """Accept only short phrases whose head is an attested, checkable lemma."""
    if not _is_acceptable_label(label):
        return False
    toks = label.strip().lower().split()
    if not 1 <= len(toks) <= 2:
        return False
    if any(t in _FALSE_NEGATION_STEMS for t in toks):
        return False
    if toks[-1] in _ABSTRACT_ATTR_OBJECTS or _stem(toks[-1]) in _ABSTRACT_ATTR_OBJECTS:
        return False
    if any(len(t) < 3 or not t.isalpha() for t in toks):
        return False
    if any(t in _PHRASE_STOP_TAIL for t in toks):
        return False
    head = toks[-1]
    if head in _lexicon(pos):
        return True
    stem = _stem(head)
    return stem in _lexicon(pos)


def _attr_map(graph: ConceptGraph, node: str) -> dict[str, list[str]]:
    """Attribute objects on ``node``, following its monosemous sense alias."""
    out: dict[str, list[str]] = {}
    probes = [node]
    sense = graph.monosemous_sense(node)
    if sense and sense != node:
        probes.append(sense)
    if node.startswith("wn:"):
        probes.extend(graph.sense_aliases(node))
    for probe in probes:
        for rel, objs in graph.attributes(probe).items():
            if rel not in _RELEVANT_ATTRS:
                continue
            bucket = out.setdefault(rel, [])
            for obj in objs:
                if obj not in bucket:
                    bucket.append(obj)
    return out


def _attr_labels(graph: ConceptGraph, node: str) -> dict[str, set[str]]:
    return {
        rel: {graph.label(o).lower() for o in objs if _is_acceptable_label(graph.label(o))}
        for rel, objs in _attr_map(graph, node).items()
    }


def _has_attribute(graph: ConceptGraph, node: str, rel: str, obj_label: str) -> bool:
    return obj_label.lower() in _attr_labels(graph, node).get(rel, set())


def gloss_negation_cues(gloss: str) -> list[tuple[str, str, str]]:
    """Extract ``(relation, object_label, matched_pattern)`` denials from a gloss.

    Only denials whose object is a short, attested lemma survive, so fragments
    such as ``permission of the`` never become attributes.
    """
    if not gloss:
        return []
    out: list[tuple[str, str, str]] = []
    for m in _LESS_RE.finditer(gloss):
        stem = m.group(1)
        if _is_lexical_attribute(stem, "n"):
            out.append(("HasA", stem, m.group(0)))
    for m in _WITHOUT_RE.finditer(gloss):
        phrase = _clean_phrase(m.group(1))
        if _is_lexical_attribute(phrase, "n"):
            out.append(("HasA", phrase, m.group(0)))
    for m in _NON_RE.finditer(gloss):
        stem = m.group(1)
        if _is_lexical_attribute(stem, "a") or _is_lexical_attribute(stem, "n"):
            out.append(("HasProperty", stem, m.group(0)))
    for m in _UN_RE.finditer(gloss):
        stem = m.group(1)
        # ``un`` must be a negating prefix: the remainder has to be a real word.
        if _is_lexical_attribute(stem, "a"):
            out.append(("HasProperty", stem, m.group(0)))
    return out


def _stem(word: str) -> str:
    w = word.lower()
    for suf in ("ing", "es", "s"):
        if len(w) > 4 and w.endswith(suf):
            return w[: -len(suf)]
    return w


def _gloss_denies_label(gloss: str, obj_label: str) -> str | None:
    if not gloss or not obj_label:
        return None
    stem = _stem(obj_label.strip().split()[-1])
    if len(stem) < 3:
        return None
    if stem in _FALSE_NEGATION_STEMS:
        return None
    esc = re.escape(stem)
    for probe in (rf"\b{esc}\w{{0,3}}less\b", rf"\bnon-?{esc}\w{{0,4}}\b", rf"\bun{esc}\w{{0,4}}\b"):
        m = re.search(probe, gloss)
        if m:
            return m.group(0)
    for cue in ("without", "lacking", "lacks", "devoid of", "having no", "with no",
                "not having", "free of", "free from", "absence of", "lack of",
                "deprived of", "stripped of", "bereft of", "deficient in",
                "unable to", "incapable of", "cannot", "can not", "not able to",
                "not capable of", "does not", "do not", "never", "fails to",
                "failing to"):
        for m in re.finditer(re.escape(cue), gloss):
            if stem in gloss[m.end(): m.end() + 55]:
                return f"{cue} ... {stem}"
    return None


_AFFIRM_BLOCKERS = (
    "without", "lacking", "lacks", "devoid", "having no", "with no", "not having",
    "free of", "free from", "absence of", "lack of", "deprived", "stripped of",
    "bereft", "deficient", "unable", "incapable", "cannot", "can not",
    "not able", "not capable", "does not", "do not", "never", "fails to",
    "failing to", "rather than", "instead of", "as opposed to", "unlike",
)


def gloss_affirms(gloss: str, obj_label: str) -> str | None:
    """Return the quoted fragment where ``gloss`` positively asserts the attribute.

    A hit is rejected when the occurrence is itself negated (``featherless``,
    ``non-metallic``, ``without wings``), so the same lexical resource yields both
    the category default and its exception under symmetric rules.
    """
    if not gloss or not obj_label:
        return None
    stem = _stem(obj_label.strip().split()[-1])
    if len(stem) < 4 or stem in _FALSE_NEGATION_STEMS:
        return None
    esc = re.escape(stem)
    for m in re.finditer(rf"\b{esc}\w{{0,4}}\b", gloss.lower()):
        start, end = m.start(), m.end()
        # Morphological negation attached to the very same token.
        if re.match(rf"^{esc}\w{{0,3}}less$", m.group(0)):
            continue
        prefix = gloss.lower()[max(0, start - 4): start]
        if prefix.endswith(("non", "non-", "un", "in", "im")):
            continue
        window = gloss.lower()[max(0, start - 60): start]
        if any(cue in window for cue in _AFFIRM_BLOCKERS):
            continue
        left = max(0, start - 28)
        return gloss[left: min(len(gloss), end + 14)].strip()
    return None


def negation_evidence(
    graph: ConceptGraph, node: str, rel: str, obj_label: str,
) -> dict | None:
    """Positive evidence that ``(rel, obj_label)`` does not hold on ``node``."""
    for neg_obj in graph.negative_facts(node, rel):
        if graph.label(neg_obj).lower() == obj_label.lower():
            return {
                "tier": "explicit_negative_fact",
                "source": "ConceptNet 5.7",
                "assertion": f"Not{rel}({graph.label(node)}, {obj_label})",
            }
    pattern = _gloss_denies_label(graph.gloss(node), obj_label)
    if pattern:
        return {
            "tier": "dictionary_negation",
            "source": "WordNet gloss",
            "pattern": pattern,
            "quote": graph.gloss(node)[:160],
        }
    return None


def _wn_children(graph: ConceptGraph) -> dict[str, list[str]]:
    kids: dict[str, list[str]] = {}
    for parent, children in graph._ensure_children().items():
        kids[parent] = list(children)
    return kids


#: How many IsA steps a candidate may sit below the shared category ``S``.
#: Attribute defaults are inherited transitively, so a bounded subtree keeps the
#: category coherent while giving every seed enough contrast candidates.
SUBTREE_DEPTH = 2


def _subtree(children: dict[str, list[str]], root: str, depth: int) -> list[str]:
    """Nodes at most ``depth`` IsA steps below ``root`` (root excluded)."""
    seen: set[str] = set()
    frontier = [root]
    for _ in range(depth):
        nxt: list[str] = []
        for node in frontier:
            for kid in children.get(node, ()):
                if kid not in seen and kid != root:
                    seen.add(kid)
                    nxt.append(kid)
        if not nxt:
            break
        frontier = nxt
    return list(seen)


def _ancestors_within(graph: ConceptGraph, node: str, depth: int) -> list[str]:
    """Ancestors at most ``depth`` IsA steps above ``node``, nearest first."""
    out: list[str] = []
    seen = {node}
    frontier = [node]
    for _ in range(depth):
        nxt: list[str] = []
        for cur in frontier:
            for parent in graph.hypernyms(cur):
                if parent in seen:
                    continue
                seen.add(parent)
                out.append(parent)
                nxt.append(parent)
        if not nxt:
            break
        frontier = nxt
    return out


def _external_pool(graph: ConceptGraph, rng: random.Random, size: int = 40000) -> list[str]:
    pool: list[str] = []
    nodes = [n for n in graph.g.nodes() if n.startswith("wn:")]
    rng.shuffle(nodes)
    for node in nodes:
        if not _is_acceptable_label(graph.label(node)):
            continue
        if not graph.hypernyms(node):
            continue
        pool.append(node)
        if len(pool) >= size:
            break
    return pool


def _pick_external(
    graph: ConceptGraph,
    parent_set: set[str],
    used_labels: set[str],
    pool: list[str],
    rng: random.Random,
    exclude: set[str],
    e_label_counts: dict[str, int],
    max_share: int,
    forbidden: frozenset[str],
) -> str | None:
    for _ in range(64):
        cand = pool[rng.randrange(len(pool))]
        if cand in exclude or cand in forbidden:
            continue
        label = graph.label(cand)
        if label.lower() in used_labels:
            continue
        if e_label_counts.get(label, 0) >= max_share:
            continue
        if set(graph.hypernyms(cand)) & parent_set:
            continue
        return cand
    return None


def _build_row(
    graph: ConceptGraph,
    *,
    parent: str,
    rel: str,
    obj_label: str,
    target: str,
    a_star: str,
    distractors: list[str],
    external: str,
    evidence: dict,
    attested_via: str,
    affirmation: str,
    rng: random.Random,
    row_id: str,
) -> dict:
    cand_ids = [a_star, external, *distractors]
    rng.shuffle(cand_ids)
    shared_parents = sorted(set(graph.hypernyms(target)) & set(graph.hypernyms(a_star)))
    tier = evidence["tier"]
    return {
        "id": row_id,
        "T": graph.label(target),
        "A_star": graph.label(a_star),
        "E": graph.label(external),
        "S": graph.label(parent),
        "T_id": target,
        "A_star_id": a_star,
        "E_id": external,
        "S_id": parent,
        "missing_relation": rel,
        "attribute_object_label": obj_label,
        "attribute_phrase": f"{RELATION_PHRASE.get(rel, rel)} {obj_label}",
        "attribute_negation_phrase": f"{RELATION_NEG_PHRASE.get(rel, 'does not ' + rel)} {obj_label}",
        "candidates": [graph.label(c) for c in cand_ids],
        "candidate_ids": cand_ids,
        "distance_T_A": 2,
        "external_relation": "parent_disjoint",
        "task": "inner_negation_selection",
        "attribute_evidence": {
            "relation": rel,
            "object_label": obj_label,
            "attested_on_T_via": attested_via,
            "affirmation_quote": affirmation,
            "distractor_attribute_status": {
                graph.label(d): (
                    "attested" if _has_attribute(graph, d, rel, obj_label)
                    else "inherited_no_counterevidence"
                )
                for d in distractors
            },
            "shared_parent": parent,
            "negation_evidence": evidence,
            "candidate_exclusivity": {
                "gold": graph.label(a_star),
                "siblings_with_attribute": [graph.label(d) for d in distractors],
                "external_counterexample": graph.label(external),
                "rule": (
                    "A_star is the only candidate with attested evidence that the "
                    "shared-category attribute does not hold"
                ),
            },
            "graph_path": {
                "T": target,
                "shared_parent": parent,
                "A_star": a_star,
                "E": external,
            },
        },
        "provenance": {
            "evidence_tier": tier,
            "certified": tier in CERTIFIED_TIERS,
            "shared_parents": shared_parents or [parent],
            "construction": "certified_attribute_exception",
            "graph": "WordNet+ConceptNet",
            "sense_sources": {
                "T": "wn" if target.startswith("wn:") else "cn",
                "A_star": "wn" if a_star.startswith("wn:") else "cn",
                "S": "wn" if parent.startswith("wn:") else "cn",
            },
        },
    }


def assert_row(graph: ConceptGraph, row: dict) -> None:
    """Validate structural and evidential invariants of one row."""
    cand_ids = list(row["candidate_ids"])
    assert len(cand_ids) == 4, "four candidates required"
    assert len(set(cand_ids)) == 4, "candidate IDs must be unique"
    assert len({c.lower() for c in row["candidates"]}) == 4, "candidate labels must differ"
    a_id, e_id = row["A_star_id"], row["E_id"]
    assert a_id in cand_ids and e_id in cand_ids, "A* and E must be candidates"

    rel = row["missing_relation"]
    obj = row["attribute_object_label"]
    assert obj and _is_acceptable_label(obj), "attribute object label required"

    parent = row["S_id"]
    subtree = set(_subtree(graph._ensure_children(), parent, SUBTREE_DEPTH))
    siblings = [c for c in cand_ids if c in subtree]
    assert len(siblings) == 3, "three in-category candidates required"
    assert [c for c in cand_ids if c not in subtree] == [e_id], (
        "external is the only out-of-category candidate"
    )
    for sib in siblings:
        assert parent in _ancestors_within(graph, sib, SUBTREE_DEPTH), (
            "in-category candidates must inherit from S within the bounded subtree"
        )

    ev = (row["attribute_evidence"] or {}).get("negation_evidence") or {}
    assert ev.get("tier"), "negation evidence tier required"
    if ev["tier"] in CERTIFIED_TIERS:
        recomputed = negation_evidence(graph, a_id, rel, obj)
        assert recomputed is not None, "A* negation evidence must be reproducible"
        assert recomputed["tier"] == ev["tier"], "evidence tier must match the graph"
    for sib in siblings:
        if sib == a_id:
            continue
        assert negation_evidence(graph, sib, rel, obj) is None, (
            "distractors must not carry negation evidence"
        )
    assert not (set(graph.hypernyms(e_id)) & set(graph.hypernyms(row["T_id"]))), (
        "external must be parent-disjoint"
    )


def _certified_rows(
    graph: ConceptGraph,
    rng: random.Random,
    quota: int,
    ext_pool: list[str],
) -> list[dict]:
    """Mine dictionary / negative-fact / contrast certified exceptions."""
    children = _wn_children(graph)
    rows: list[dict] = []
    e_label_counts: dict[str, int] = {}
    max_share = max(4, quota // 40)

    # Candidate exceptions: any node whose gloss denies something, plus any node
    # carrying an explicit negative fact.
    seeds: list[tuple[str, str, str]] = []  # (a_star, rel, obj_label)
    for node, data in graph.g.nodes(data=True):
        gloss = data.get("gloss") or ""
        if gloss:
            for rel, obj_label, _pat in gloss_negation_cues(gloss):
                seeds.append((node, rel, obj_label))
    for u, v, _k, d in graph.g.out_edges(keys=True, data=True):
        rel = d.get("rel", "")
        if not rel.startswith("Not") or rel[3:] not in _RELEVANT_ATTRS:
            continue
        label = graph.label(v)
        if not _is_lexical_attribute(label, "n") and not _is_lexical_attribute(label, "a"):
            continue
        sense = graph.monosemous_sense(u) or u
        seeds.append((sense, rel[3:], label))
    rng.shuffle(seeds)
    logger.info(f"OntoNeg: {len(seeds)} candidate exception seeds")

    seen_keys: set[tuple[str, str, str]] = set()
    for a_star, rel, obj_label in seeds:
        if len(rows) >= quota:
            break
        key = (a_star, rel, _stem(obj_label.split()[-1]))
        if key in seen_keys:
            continue
        evidence = negation_evidence(graph, a_star, rel, obj_label)
        if evidence is None:
            continue
        a_label = graph.label(a_star).lower()
        a_ancestors = set(_ancestors_within(graph, a_star, SUBTREE_DEPTH))
        emitted_for_seed = 0
        # A* sits at most SUBTREE_DEPTH IsA steps below the shared category, whose
        # attribute default it inherits and then violates.
        for parent in _ancestors_within(graph, a_star, SUBTREE_DEPTH):
            if emitted_for_seed >= 4:
                break
            p_label = graph.label(parent).lower()
            # A near-synonym of its own category cannot be a contrastive exception.
            if p_label in a_label or a_label in p_label:
                continue
            all_kids = _subtree(children, parent, SUBTREE_DEPTH)
            if not 4 <= len(all_kids) <= _MAX_CATEGORY_WIDTH:
                continue
            kids = [
                k for k in all_kids
                if k != a_star and k not in a_ancestors
                and _is_acceptable_label(graph.label(k))
                and p_label not in graph.label(k).lower()
            ]
            if len(kids) < 3:
                continue
            rng.shuffle(kids)
            clean = [k for k in kids if negation_evidence(graph, k, rel, obj_label) is None]
            if len(clean) < 3:
                continue
            # The target must positively attest the attribute. Without such an
            # anchor the item would only test a trivially true negative fact
            # rather than a category default that A* violates.
            target, attested_via, affirmation = None, "", ""
            parent_quote = gloss_affirms(graph.gloss(parent), obj_label)
            for k in clean:
                if _has_attribute(graph, k, rel, obj_label):
                    target, attested_via = k, "sibling_attribute_edge"
                    affirmation = f"{rel}({graph.label(k)}, {obj_label})"
                    break
                quote = gloss_affirms(graph.gloss(k), obj_label)
                if quote:
                    target, attested_via = k, "sibling_gloss"
                    affirmation = quote
                    break
                if parent_quote:
                    target, attested_via = k, "category_gloss"
                    affirmation = parent_quote
                    break
            if target is None:
                continue
            rest = [k for k in clean if k != target]
            rest.sort(key=lambda k: 0 if _has_attribute(graph, k, rel, obj_label)
                      or gloss_affirms(graph.gloss(k), obj_label) else 1)
            if len(rest) < 2:
                continue
            distractors = rest[:2]
            used = {graph.label(x).lower() for x in [target, a_star, *distractors]}
            if len(used) < 4:
                continue
            external = _pick_external(
                graph,
                set(graph.hypernyms(target)) | {parent},
                used,
                ext_pool,
                rng,
                {target, a_star, *distractors},
                e_label_counts,
                max_share,
                forbidden=frozenset(all_kids) | {parent},
            )
            if external is None:
                continue
            row = _build_row(
                graph,
                parent=parent,
                rel=rel,
                obj_label=obj_label,
                target=target,
                a_star=a_star,
                distractors=distractors,
                external=external,
                evidence=evidence,
                attested_via=attested_via,
                affirmation=affirmation,
                rng=rng,
                row_id=f"otn_{len(rows):06d}",
            )
            try:
                assert_row(graph, row)
            except AssertionError:
                continue
            e_label_counts[graph.label(external)] = e_label_counts.get(graph.label(external), 0) + 1
            rows.append(row)
            seen_keys.add(key)
            emitted_for_seed += 1
    logger.info(f"OntoNeg: certified rows={len(rows)}")
    return rows


def _heuristic_rows(
    graph: ConceptGraph,
    rng: random.Random,
    quota: int,
    ext_pool: list[str],
    banned_families: set[str],
) -> list[dict]:
    """Training-pool rows where the attribute is merely unattested on ``A*``.

    Tagged ``kg_edge_absence``; never used in the locked evaluation splits.
    """
    children = _wn_children(graph)
    parents = [p for p, kids in children.items() if len(kids) >= 4 and p not in banned_families]
    rng.shuffle(parents)
    rows: list[dict] = []
    e_label_counts: dict[str, int] = {}
    max_share = max(4, quota // 40)
    for parent in parents:
        if len(rows) >= quota:
            break
        kids = [
            k for k in _subtree(children, parent, SUBTREE_DEPTH)
            if _is_acceptable_label(graph.label(k))
        ]
        if not 4 <= len(kids) <= _MAX_CATEGORY_WIDTH:
            continue
        by_attr: dict[tuple[str, str], list[str]] = {}
        for kid in kids:
            for rel, labels in _attr_labels(graph, kid).items():
                for label in labels:
                    if _is_acceptable_label(label):
                        by_attr.setdefault((rel, label), []).append(kid)
        for (rel, obj_label), having in by_attr.items():
            if len(rows) >= quota or len(having) < 3:
                continue
            hset = set(having)
            lacking = [
                k for k in kids
                if k not in hset and negation_evidence(graph, k, rel, obj_label) is None
            ]
            if not lacking:
                continue
            rng.shuffle(having)
            rng.shuffle(lacking)
            target, d1, d2 = having[:3]
            a_star = lacking[0]
            used = {graph.label(x).lower() for x in [target, a_star, d1, d2]}
            if len(used) < 4:
                continue
            external = _pick_external(
                graph, set(graph.hypernyms(target)) | {parent}, used, ext_pool, rng,
                {target, a_star, d1, d2}, e_label_counts, max_share,
                forbidden=frozenset(kids) | {parent},
            )
            if external is None:
                continue
            row = _build_row(
                graph,
                parent=parent,
                rel=rel,
                obj_label=obj_label,
                target=target,
                a_star=a_star,
                distractors=[d1, d2],
                external=external,
                evidence={
                    "tier": HEURISTIC_TIER,
                    "source": "ConceptNet edge absence",
                    "assertion": (
                        f"{rel}({graph.label(a_star)}, {obj_label}) is unattested; "
                        "absence is not a semantic negation"
                    ),
                },
                attested_via="sibling_attribute_edge",
                affirmation=f"{rel}({graph.label(target)}, {obj_label})",
                rng=rng,
                row_id=f"otn_h_{len(rows):06d}",
            )
            try:
                assert_row(graph, row)
            except AssertionError:
                continue
            e_label_counts[graph.label(external)] = e_label_counts.get(graph.label(external), 0) + 1
            rows.append(row)
    logger.info(f"OntoNeg: heuristic training rows={len(rows)}")
    return rows


def _family_disjoint_split(
    rows: list[dict], sizes: dict[str, int], rng: random.Random,
) -> dict[str, list[dict]]:
    """Assign whole ``S_id`` families to splits so no category is shared."""
    by_family: dict[str, list[dict]] = {}
    for r in rows:
        by_family.setdefault(r["S_id"], []).append(r)
    families = sorted(by_family, key=lambda f: (len(by_family[f]), f))
    rng.shuffle(families)
    out: dict[str, list[dict]] = {name: [] for name in sizes}
    order = sorted(sizes, key=lambda k: sizes[k])  # fill smallest quota first
    for fam in families:
        bucket = by_family[fam]
        for name in order:
            if len(out[name]) + len(bucket) <= sizes[name]:
                out[name].extend(bucket)
                break
    return out


def build_onto_neg_wn(
    *,
    graph: ConceptGraph,
    out_path: str,
    train_size: int,
    dev_size: int,
    test_size: int,
    conf_size: int = 0,
    distance_d0: int = 2,
    seed: int = 42,
) -> dict[str, int]:
    """Construct OntoNeg-WN splits.

    ``test``/``dev``/``conf`` contain certified rows only. ``train`` is allowed to
    fall back to the ``kg_edge_absence`` tier, tagged in provenance.
    """
    rng = random.Random(seed)
    ext_pool = _external_pool(graph, rng)
    logger.info(f"OntoNeg: external pool={len(ext_pool)}")

    eval_quota = test_size + dev_size + conf_size
    certified = _certified_rows(graph, rng, quota=int(eval_quota * 1.5) + 200, ext_pool=ext_pool)
    if len(certified) < eval_quota:
        raise RuntimeError(
            f"only {len(certified)} certified OntoNeg rows for an evaluation quota of {eval_quota}"
        )

    eval_sizes = {"test": test_size, "dev": dev_size}
    if conf_size:
        eval_sizes["conf"] = conf_size
    splits = _family_disjoint_split(certified, eval_sizes, rng)
    for name, size in eval_sizes.items():
        if len(splits[name]) < size:
            raise RuntimeError(f"family-disjoint split short for {name}: {len(splits[name])}/{size}")
        splits[name] = splits[name][:size]

    eval_families = {r["S_id"] for name in eval_sizes for r in splits[name]}
    eval_ids = {id(r) for name in eval_sizes for r in splits[name]}
    train_rows = [
        r for r in certified
        if id(r) not in eval_ids and r["S_id"] not in eval_families
    ]
    if len(train_rows) < train_size:
        train_rows.extend(
            _heuristic_rows(
                graph, rng, quota=train_size - len(train_rows) + 200,
                ext_pool=ext_pool, banned_families=eval_families,
            )
        )
    rng.shuffle(train_rows)
    splits["train"] = train_rows[:train_size]

    out: dict[str, int] = {}
    out_dir = Path(out_path)
    for name, items in splits.items():
        for i, row in enumerate(items):
            row["id"] = f"onto_neg_wn_{name}_{i:06d}"
        out[name] = save_jsonl(out_dir / f"onto_neg_wn_{name}.jsonl", items)
    logger.info("OntoNeg-WN built — " + " ".join(f"{k}={v}" for k, v in out.items()))
    return out
