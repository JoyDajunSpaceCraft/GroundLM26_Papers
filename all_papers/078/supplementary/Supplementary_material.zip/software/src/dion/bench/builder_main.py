"""End-to-end builder for DION-Bench.

Run:
    python -m dion.bench.builder_main --config configs/dion_main.yaml
"""

from __future__ import annotations

import argparse
from pathlib import Path

from dion.bench.concept_graph import ConceptGraph
from dion.bench.concept_shift import build_concept_shift
from dion.bench.logic_repair import build_logic_repair
from dion.bench.onto_neg_wn import build_onto_neg_wn
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.bench.builder")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/dion_main.yaml")
    parser.add_argument(
        "--conceptnet",
        type=str,
        default="data/raw/conceptnet-assertions-5.7.0.csv.gz",
    )
    parser.add_argument("--cache_graph", type=str, default="data/processed/concept_graph.gpkl")
    parser.add_argument(
        "--task",
        type=str,
        default="all",
        choices=["all", "onto_neg_wn", "concept_shift", "logic_repair"],
    )
    args = parser.parse_args()

    cfg = load_yaml(args.config)
    set_seed(cfg.get("seed", 42))
    out_dir = cfg["bench"]["output_dir"]
    Path(out_dir).mkdir(parents=True, exist_ok=True)

    needs_graph = args.task in {"all", "onto_neg_wn", "concept_shift"}
    graph = None
    if needs_graph:
        cache = Path(args.cache_graph)
        if cache.exists():
            logger.info(f"Loading cached concept graph: {cache}")
            graph = ConceptGraph.load(cache)
        else:
            graph = ConceptGraph()
            logger.info("Loading WordNet ...")
            graph.load_wordnet(max_synsets=20000)
            if Path(args.conceptnet).exists():
                logger.info(f"Loading ConceptNet from {args.conceptnet} ...")
                added = graph.load_conceptnet(args.conceptnet)
                logger.info(f"ConceptNet edges added: {added}")
            graph.save(cache)
        logger.info(f"Concept graph stats: {graph.stats()}")

    if args.task in {"all", "onto_neg_wn"}:
        params = cfg["bench"]["onto_neg_wn"]
        build_onto_neg_wn(
            graph=graph,
            out_path=out_dir,
            train_size=params["train_size"],
            dev_size=params["dev_size"],
            test_size=params["test_size"],
            conf_size=params.get("conf_size", 0),
            distance_d0=params.get("distance_d0", 2),
            seed=cfg.get("seed", 42),
        )

    if args.task in {"all", "concept_shift"}:
        params = cfg["bench"]["concept_shift"]
        build_concept_shift(
            out_path=out_dir,
            train_size=params["train_size"],
            dev_size=params["dev_size"],
            test_size=params["test_size"],
            conf_size=params.get("conf_size", 0),
            seed=cfg.get("seed", 42),
            graph=graph,
        )

    if args.task in {"all", "logic_repair"}:
        params = cfg["bench"]["logic_repair"]
        build_logic_repair(
            out_path=out_dir,
            train_size=params["train_size"],
            dev_size=params["dev_size"],
            test_size=params["test_size"],
            seed=cfg.get("seed", 42),
        )


if __name__ == "__main__":
    main()
