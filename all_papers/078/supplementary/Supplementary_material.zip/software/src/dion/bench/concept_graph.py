"""Unified concept graph over WordNet + ConceptNet.

Nodes are sense-aware IDs:
  * WordNet: ``wn:<synset.name()>`` (e.g. ``wn:dog.n.01``)
  * ConceptNet: ``cn:<surface>`` or ``cn:<surface>|<pos>[/<sense>]`` when
    ConceptNet URI carries POS/sense suffixes (e.g. ``cn:fly|v``)

Each node also stores a human-readable ``label`` (surface form). Edges live in
a ``MultiDiGraph`` so multiple typed relations between the same pair are kept.
LCS walks only ``IsA`` (not ``PartOf``). Hyponyms are indexed via reverse IsA.

Negative ConceptNet relations (``NotCapableOf``, ``NotHasProperty``,
``NotUsedFor``, ``NotDesires``) are loaded as ``Not<Relation>`` edges so that
constructors can require *attested* negation instead of inferring absence from a
missing edge. WordNet glosses are attached to synset nodes for the same purpose.

WordNet senses and ConceptNet surface nodes are linked only for **monosemous**
lemmas (a single WordNet noun sense), so alignment never conflates senses.
"""

from __future__ import annotations

import csv
import gzip
import re
from collections import defaultdict
from pathlib import Path
from typing import Iterable

import networkx as nx

CONCEPTNET_RELATIONS = {
    "/r/IsA",
    "/r/PartOf",
    "/r/UsedFor",
    "/r/HasA",
    "/r/CapableOf",
    "/r/HasProperty",
    "/r/MadeOf",
    "/r/AtLocation",
    "/r/Causes",
    "/r/RelatedTo",
    "/r/Antonym",
    "/r/DistinctFrom",
    "/r/Synonym",
    "/r/SimilarTo",
    "/r/NotCapableOf",
    "/r/NotHasProperty",
    "/r/NotUsedFor",
    "/r/NotDesires",
}

NEGATIVE_RELATIONS = {
    "NotCapableOf": "CapableOf",
    "NotHasProperty": "HasProperty",
    "NotUsedFor": "UsedFor",
    "NotDesires": "Desires",
}

# Lexical negation scopes used to certify a denied attribute from a gloss.
_GLOSS_SCOPES = (
    "without", "lacking", "lacks", "devoid of", "having no", "with no",
    "not having", "free of", "free from", "unable to", "incapable of",
    "cannot", "can not", "not able to", "does not", "do not", "never",
    "not capable of",
)


def _ensure_wordnet() -> None:
    import nltk
    try:
        nltk.data.find("corpora/wordnet.zip")
    except LookupError:
        nltk.download("wordnet")
    try:
        nltk.data.find("corpora/omw-1.4.zip")
    except LookupError:
        nltk.download("omw-1.4")


def wn_node(synset_name: str) -> str:
    return f"wn:{synset_name}"


def cn_node(surface: str, sense_suffix: str = "") -> str:
    base = surface.strip().lower()
    if sense_suffix:
        return f"cn:{base}|{sense_suffix.strip().lower()}"
    return f"cn:{base}"


def _cn_uri_parts(uri: str) -> tuple[str, str]:
    """Return (surface, pos/sense suffix) from a ConceptNet concept URI."""
    parts = uri.split("/")
    # /c/en/<surface>[/<pos>[/<sense>...]]
    surface = parts[3].replace("_", " ") if len(parts) > 3 else uri
    suffix = "/".join(parts[4:]) if len(parts) > 4 else ""
    return surface, suffix


def node_label(graph: "ConceptGraph", node: str) -> str:
    if node not in graph.g:
        raw = node.split(":", 1)[-1]
        raw = raw.split("|", 1)[0]
        return raw.replace("_", " ")
    return graph.g.nodes[node].get(
        "label",
        node.split(":", 1)[-1].split("|", 1)[0].replace("_", " "),
    )


class ConceptGraph:
    """Sense-aware MultiDiGraph over WordNet + ConceptNet."""

    def __init__(self) -> None:
        self.g: nx.MultiDiGraph = nx.MultiDiGraph()
        self._wn_loaded = False
        self._children: dict[str, list[str]] | None = None

    def _invalidate_children(self) -> None:
        self._children = None

    def _ensure_children(self) -> dict[str, list[str]]:
        if self._children is not None:
            return self._children
        children: dict[str, list[str]] = defaultdict(list)
        for u, v, _, d in self.g.out_edges(keys=True, data=True):
            if d.get("rel") == "IsA":
                children[v].append(u)
        self._children = dict(children)
        return self._children

    # ------------------------------------------------- WordNet
    def load_wordnet(self, max_synsets: int | None = None) -> None:
        _ensure_wordnet()
        from nltk.corpus import wordnet as wn

        cnt = 0
        for syn in wn.all_synsets(pos=wn.NOUN):
            if max_synsets and cnt >= max_synsets:
                break
            cnt += 1
            head = wn_node(syn.name())
            label = syn.name().split(".")[0].replace("_", " ")
            self.g.add_node(
                head, source="wn", label=label, synset=syn.name(),
                gloss=syn.definition().lower(),
            )
            for hyp in syn.hypernyms():
                tgt = wn_node(hyp.name())
                tlabel = hyp.name().split(".")[0].replace("_", " ")
                self.g.add_node(tgt, source="wn", label=tlabel, synset=hyp.name())
                self.g.add_edge(head, tgt, rel="IsA", source="wn", key="IsA")
            for part in syn.part_meronyms():
                tgt = wn_node(part.name())
                tlabel = part.name().split(".")[0].replace("_", " ")
                self.g.add_node(tgt, source="wn", label=tlabel, synset=part.name())
                self.g.add_edge(head, tgt, rel="HasPart", source="wn", key="HasPart")
            # Lemma antonyms → DistinctFrom / Antonym edges for ConceptShift.
            for lemma in syn.lemmas():
                for ant in lemma.antonyms():
                    ant_syn = ant.synset()
                    if ant_syn.pos() != wn.NOUN:
                        continue
                    tgt = wn_node(ant_syn.name())
                    tlabel = ant_syn.name().split(".")[0].replace("_", " ")
                    self.g.add_node(tgt, source="wn", label=tlabel, synset=ant_syn.name())
                    self.g.add_edge(head, tgt, rel="Antonym", source="wn", key="Antonym")
        self._wn_loaded = True
        self._invalidate_children()

    # ------------------------------------------------- ConceptNet
    def load_conceptnet(
        self,
        path: str | Path,
        languages: tuple[str, ...] = ("en",),
        relations: Iterable[str] = CONCEPTNET_RELATIONS,
    ) -> int:
        path = Path(path)
        opener = gzip.open if path.suffix == ".gz" else open
        rels = set(relations)
        keep = 0
        with opener(path, "rt", encoding="utf-8", errors="replace") as f:
            r = csv.reader(f, delimiter="\t")
            for row in r:
                if len(row) < 5:
                    continue
                _id, rel, start, end, _meta = row[:5]
                if rel not in rels:
                    continue
                if not start.startswith("/c/" + languages[0] + "/"):
                    continue
                if not end.startswith("/c/" + languages[0] + "/"):
                    continue
                src_surf, src_sfx = _cn_uri_parts(start)
                tgt_surf, tgt_sfx = _cn_uri_parts(end)
                src = cn_node(src_surf, src_sfx)
                tgt = cn_node(tgt_surf, tgt_sfx)
                rel_short = rel.rsplit("/", 1)[-1]
                self.g.add_node(src, source="cn", label=src_surf, cn_uri=start)
                self.g.add_node(tgt, source="cn", label=tgt_surf, cn_uri=end)
                self.g.add_edge(src, tgt, rel=rel_short, source="cn", key=rel_short)
                keep += 1
        self._invalidate_children()
        return keep

    # ------------------------------------------------- monosemous alignment
    def link_monosemous_lemmas(self) -> int:
        """Add ``SenseOf`` edges between ConceptNet nodes and unambiguous senses.

        Only lemmas with exactly one WordNet noun synset are linked, so an
        aligned ConceptNet node inherits a single, unambiguous sense.
        """
        _ensure_wordnet()
        from nltk.corpus import wordnet as wn

        mono: dict[str, str] = {}
        for lemma in wn.all_lemma_names(pos=wn.NOUN):
            syns = wn.synsets(lemma, pos=wn.NOUN)
            if len(syns) == 1:
                mono[lemma.replace("_", " ").lower()] = wn_node(syns[0].name())
        added = 0
        for node in list(self.g.nodes()):
            if not node.startswith("cn:"):
                continue
            surface, _, suffix = node[3:].partition("|")
            if suffix and not suffix.startswith("n"):
                continue
            target = mono.get(surface)
            if target is None or target not in self.g:
                continue
            self.g.add_edge(node, target, rel="SenseOf", source="align", key="SenseOf")
            self.g.add_edge(target, node, rel="SenseAlias", source="align", key="SenseAlias")
            added += 1
        self._invalidate_children()
        return added

    def monosemous_sense(self, node: str) -> str | None:
        """The unambiguous WordNet sense aligned to ``node``, if any."""
        if node.startswith("wn:"):
            return node
        for _, t, _k, d in self.g.out_edges(node, keys=True, data=True):
            if d.get("rel") == "SenseOf":
                return t
        return None

    def sense_aliases(self, node: str) -> list[str]:
        if not node.startswith("wn:"):
            return []
        return [
            t for _, t, _k, d in self.g.out_edges(node, keys=True, data=True)
            if d.get("rel") == "SenseAlias"
        ]

    # ------------------------------------------------- negation evidence
    def gloss(self, node: str) -> str:
        if node not in self.g:
            return ""
        own = self.g.nodes[node].get("gloss", "")
        if own:
            return own
        sense = self.monosemous_sense(node)
        if sense and sense != node and sense in self.g:
            return self.g.nodes[sense].get("gloss", "")
        return ""

    def negative_facts(self, node: str, relation: str) -> set[str]:
        """Objects for which ``Not<relation>`` is attested on ``node``."""
        want = f"Not{relation}"
        out: set[str] = set()
        for probe in [node, *([s] if (s := self.monosemous_sense(node)) and s != node else [])]:
            if probe not in self.g:
                continue
            for _, t, _k, d in self.g.out_edges(probe, keys=True, data=True):
                if d.get("rel") == want:
                    out.add(t)
            for alias in self.sense_aliases(probe):
                for _, t, _k, d in self.g.out_edges(alias, keys=True, data=True):
                    if d.get("rel") == want:
                        out.add(t)
        return out

    def gloss_denies(self, node: str, attribute_label: str) -> str | None:
        """Return the gloss pattern denying ``attribute_label``, else ``None``."""
        gloss = self.gloss(node)
        if not gloss or not attribute_label:
            return None
        head = attribute_label.strip().split()[-1].lower()
        stem = head
        for suf in ("ing", "es", "s"):
            if len(stem) > 4 and stem.endswith(suf):
                stem = stem[: -len(suf)]
                break
        if len(stem) < 3:
            return None
        esc = re.escape(stem)
        if re.search(rf"\b{esc}\w{{0,3}}less\b", gloss):
            return f"{stem}less"
        if re.search(rf"\bnon-?{esc}\w{{0,4}}\b", gloss):
            return f"non-{stem}"
        for cue in _GLOSS_SCOPES:
            for m in re.finditer(re.escape(cue), gloss):
                if stem in gloss[m.end(): m.end() + 55]:
                    return f"{cue} ... {stem}"
        return None

    def contrastive_values(self, node: str) -> set[str]:
        """Nodes explicitly opposed to ``node`` (Antonym / DistinctFrom)."""
        out: set[str] = set()
        if node in self.g:
            for _, t, _k, d in self.g.out_edges(node, keys=True, data=True):
                if d.get("rel") in ("Antonym", "DistinctFrom"):
                    out.add(t)
            for s, _, _k, d in self.g.in_edges(node, keys=True, data=True):
                if d.get("rel") in ("Antonym", "DistinctFrom"):
                    out.add(s)
        return out

    # ------------------------------------------------- queries
    def label(self, node: str) -> str:
        return node_label(self, node)

    def hypernyms(self, node: str, k: int | None = None) -> list[str]:
        """Return IsA parents. ``k=None`` returns all parents (needed for
        sibling checks on dense ConceptNet nodes)."""
        if node not in self.g:
            return []
        out: list[str] = []
        for _, t, _, d in self.g.out_edges(node, keys=True, data=True):
            if d.get("rel") == "IsA":
                out.append(t)
                if k is not None and len(out) >= k:
                    break
        return out

    def hyponyms(self, node: str, k: int | None = None) -> list[str]:
        """Children under IsA (true siblings live among these)."""
        kids = self._ensure_children().get(node, [])
        if k is None:
            return list(kids)
        return list(kids)[:k]

    def siblings(self, node: str, max_per_parent: int = 30) -> list[str]:
        """Same-category siblings: other hyponyms of each IsA parent."""
        out: list[str] = []
        seen: set[str] = set()
        for p in self.hypernyms(node):
            per = 0
            for sib in self.hyponyms(p):
                if sib == node or sib in seen:
                    continue
                seen.add(sib)
                out.append(sib)
                per += 1
                if per >= max_per_parent:
                    break
        return out

    def attributes(self, node: str) -> dict[str, list[str]]:
        out: dict[str, list[str]] = defaultdict(list)
        if node not in self.g:
            return out
        for _, t, _, d in self.g.out_edges(node, keys=True, data=True):
            out[d.get("rel", "")].append(t)
        return out

    def least_common_subsumer(self, a: str, b: str, max_depth: int = 6) -> str | None:
        """LCS over IsA ancestors only (sense-preserving)."""
        ancA = self._ancestors_with_depth(a, max_depth)
        ancB = self._ancestors_with_depth(b, max_depth)
        common = set(ancA) & set(ancB)
        if not common:
            return None
        return min(common, key=lambda c: ancA[c] + ancB[c])

    def _ancestors_with_depth(self, node: str, max_depth: int) -> dict[str, int]:
        seen = {node: 0}
        frontier = [node]
        for d in range(1, max_depth + 1):
            new_frontier = []
            for u in frontier:
                if u not in self.g:
                    continue
                for _, v, _, e in self.g.out_edges(u, keys=True, data=True):
                    if e.get("rel") != "IsA":
                        continue
                    if v in seen:
                        continue
                    seen[v] = d
                    new_frontier.append(v)
            frontier = new_frontier
            if not frontier:
                break
        return seen

    def neighbours(self, node: str) -> list[tuple[str, str]]:
        """Out-neighbours with relation type (not hyponyms)."""
        if node not in self.g:
            return []
        return [
            (v, e["rel"])
            for _, v, _, e in self.g.out_edges(node, keys=True, data=True)
            if "rel" in e
        ]

    def graph_distance(self, a: str, b: str, cutoff: int = 5) -> int:
        if a not in self.g or b not in self.g:
            return cutoff + 1
        if a == b:
            return 0
        ug = self.g.to_undirected(as_view=True)
        try:
            lengths = nx.single_source_shortest_path_length(ug, a, cutoff=cutoff)
        except Exception:
            return cutoff + 1
        return lengths.get(b, cutoff + 1)

    # ------------------------------------------------- I/O
    def save(self, path: str | Path) -> None:
        import pickle

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self.g, f, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls, path: str | Path) -> "ConceptGraph":
        import pickle

        cg = cls()
        with open(path, "rb") as f:
            g = pickle.load(f)
        if isinstance(g, nx.MultiDiGraph):
            cg.g = g
        else:
            # Migrate legacy DiGraph caches.
            mdg = nx.MultiDiGraph()
            for n, d in g.nodes(data=True):
                mdg.add_node(n, **d)
            for u, v, d in g.edges(data=True):
                mdg.add_edge(u, v, key=d.get("rel", "rel"), **d)
            cg.g = mdg
        cg._wn_loaded = True
        return cg

    def stats(self) -> dict[str, int]:
        rels: dict[str, int] = defaultdict(int)
        for _, _, _, d in self.g.edges(keys=True, data=True):
            rels[d.get("rel", "?")] += 1
        return {
            "nodes": self.g.number_of_nodes(),
            "edges": self.g.number_of_edges(),
            **{f"rel_{k}": v for k, v in rels.items()},
        }
