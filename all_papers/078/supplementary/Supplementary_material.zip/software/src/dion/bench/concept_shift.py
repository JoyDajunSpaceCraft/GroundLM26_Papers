"""ConceptShift constructor.

Each row asks for the least common subsumer ``S`` of a contrasted pair
``(T, A)``. Three properties keep the label semantically defensible:

* **Sense-resolved endpoints.** ``T``, ``A`` and ``S`` are always WordNet
  synsets, so no node is an ambiguous surface string. ConceptNet contributes
  contrast edges only after they are projected onto monosemous senses.
* **Short certified ancestor paths.** ``S`` must be reachable from both
  endpoints along ``IsA`` edges within a small depth bound, and both paths are
  stored. This rules out long polysemy-driven walks.
* **Independently verified soft golds.** ``S_alternatives`` holds only other
  lemmas of the same synset and dominating parents that still subsume both
  endpoints. Definitional glosses, function words and slurs are rejected.

The contrast relation is never relabelled: ``Antonym`` rows come from attested
antonym edges, and ``DistinctFrom`` rows come either from an attested
ConceptNet ``DistinctFrom`` edge or from co-hyponymy under a shared parent,
which is recorded in ``provenance.edge_source``.
"""

from __future__ import annotations

import random
import re
from pathlib import Path

from dion.bench.concept_graph import ConceptGraph
from dion.utils.io import save_jsonl
from dion.utils.logging_utils import get_logger

logger = get_logger("dion.bench.concept_shift")

#: Maximum IsA steps from either endpoint to the subsumer.
MAX_ANCESTOR_STEPS = 4

_DEFINITIONAL_SUBSTR = (
    "another name for",
    "another way to say",
    "way to say",
    "in other words",
    "used to",
    "refers to",
    "term for",
    "kind of",
    "sort of",
)
_FUNCTION_WORDS = {
    "also", "yield", "id", "a", "an", "the", "of", "to", "is", "it", "such",
    "other", "any", "some", "thing", "stuff", "etc",
}
#: Offensive or clinical-slur senses that must never surface as an accepted gold.
_OFFENSIVE_SUBSTR = (
    "homosexual", "faggot", "nigger", "retard", "slut", "whore", "spastic",
    "cripple", "mongoloid", "wetback", "kike", "chink", "tranny",
)


def is_clean_label(label: str, *, max_words: int = 3) -> bool:
    """Reject definitional glosses, function words, slurs and long phrases."""
    if not label or not isinstance(label, str):
        return False
    s = label.strip().lower()
    if not s or len(s) < 2 or s in _FUNCTION_WORDS:
        return False
    if len(s.split()) > max_words:
        return False
    if not re.fullmatch(r"[a-z][a-z\-' ]*", s):
        return False
    if any(sub in s for sub in _DEFINITIONAL_SUBSTR):
        return False
    return not any(sub in s for sub in _OFFENSIVE_SUBSTR)


def _isa_path_to(
    graph: ConceptGraph, start: str, goal: str, max_depth: int = MAX_ANCESTOR_STEPS,
) -> list[str] | None:
    """Shortest ``IsA`` path ``start -> ... -> goal`` inclusive, or None.

    Only WordNet nodes are traversed, so a path never crosses an ambiguous
    ConceptNet surface node.
    """
    if start == goal:
        return [start]
    if not start.startswith("wn:") or not goal.startswith("wn:"):
        return None
    parents: dict[str, str | None] = {start: None}
    frontier = [start]
    for _ in range(max_depth):
        nxt: list[str] = []
        for u in frontier:
            for p in graph.hypernyms(u):
                if not p.startswith("wn:") or p in parents:
                    continue
                parents[p] = u
                if p == goal:
                    path = [goal]
                    cur: str | None = u
                    while cur is not None:
                        path.append(cur)
                        cur = parents[cur]
                    path.reverse()
                    return path
                nxt.append(p)
        frontier = nxt
        if not frontier:
            break
    return None


def _wn_ancestors(graph: ConceptGraph, node: str, max_depth: int) -> dict[str, int]:
    seen = {node: 0}
    frontier = [node]
    for d in range(1, max_depth + 1):
        nxt: list[str] = []
        for u in frontier:
            for p in graph.hypernyms(u):
                if not p.startswith("wn:") or p in seen:
                    continue
                seen[p] = d
                nxt.append(p)
        frontier = nxt
        if not frontier:
            break
    return seen


def certified_lcs(
    graph: ConceptGraph, u: str, v: str, max_steps: int = MAX_ANCESTOR_STEPS,
) -> tuple[str, list[str], list[str]] | None:
    """Least common ``IsA`` subsumer with both ancestor paths, or None.

    Requires WordNet endpoints, a subsumer distinct from both endpoints, and
    ancestor paths no longer than ``max_steps``.
    """
    if not (u.startswith("wn:") and v.startswith("wn:")) or u == v:
        return None
    anc_u = _wn_ancestors(graph, u, max_steps)
    anc_v = _wn_ancestors(graph, v, max_steps)
    common = set(anc_u) & set(anc_v)
    common.discard(u)
    common.discard(v)
    if not common:
        return None
    subsumer = min(common, key=lambda c: (anc_u[c] + anc_v[c], c))
    if not is_clean_label(graph.label(subsumer)):
        return None
    path_u = _isa_path_to(graph, u, subsumer, max_steps)
    path_v = _isa_path_to(graph, v, subsumer, max_steps)
    if not path_u or not path_v:
        return None
    return subsumer, path_u, path_v


def _synset_lemmas(graph: ConceptGraph, node: str) -> list[str]:
    """Other lemmas of the same WordNet synset (true synonyms)."""
    synset_name = graph.g.nodes.get(node, {}).get("synset") if node in graph.g else None
    if not synset_name:
        return []
    try:
        from nltk.corpus import wordnet as wn

        return [
            lemma.name().replace("_", " ").lower()
            for lemma in wn.synset(synset_name).lemmas()
        ]
    except Exception:
        return []


def s_alternatives(graph: ConceptGraph, subsumer: str, u: str, v: str) -> list[str]:
    """Accepted soft golds: same-synset lemmas and still-dominating parents."""
    primary = graph.label(subsumer).lower()
    seen = {primary}
    alts: list[str] = []
    for lemma in _synset_lemmas(graph, subsumer):
        if lemma in seen or not is_clean_label(lemma):
            continue
        seen.add(lemma)
        alts.append(lemma)
    for parent in graph.hypernyms(subsumer):
        if parent in {u, v} or not parent.startswith("wn:"):
            continue
        label = graph.label(parent).lower()
        if label in seen or not is_clean_label(label):
            continue
        # A parent only counts if it still subsumes both endpoints.
        if _isa_path_to(graph, u, parent, MAX_ANCESTOR_STEPS + 1) is None:
            continue
        if _isa_path_to(graph, v, parent, MAX_ANCESTOR_STEPS + 1) is None:
            continue
        seen.add(label)
        alts.append(label)
    return alts[:4]


def _row_from_pair(
    graph: ConceptGraph,
    u: str,
    v: str,
    relation: str,
    row_id: str,
    *,
    edge_source: str,
) -> dict | None:
    if not (is_clean_label(graph.label(u)) and is_clean_label(graph.label(v))):
        return None
    cert = certified_lcs(graph, u, v)
    if cert is None:
        return None
    subsumer, path_u, path_v = cert
    return {
        "id": row_id,
        "T": graph.label(u),
        "A": graph.label(v),
        "S": graph.label(subsumer),
        "T_id": u,
        "A_id": v,
        "S_id": subsumer,
        "S_alternatives": s_alternatives(graph, subsumer, u, v),
        "relation": relation,
        "task": "structured_concept_update",
        "provenance": {
            "lcs_path_depth": (len(path_u) - 1) + (len(path_v) - 1),
            "ancestor_path_T": path_u,
            "ancestor_path_A": path_v,
            "edge_source": edge_source,
            "sense_resolved": True,
            "sense_sources": {"T": "wn", "A": "wn", "S": "wn"},
            "construction": "sense_resolved_lcs",
            "graph": "WordNet+ConceptNet",
        },
    }


def _attested_contrast_pairs(graph: ConceptGraph) -> list[tuple[str, str, str, str]]:
    """``(u, v, relation, edge_source)`` for attested contrast edges.

    ConceptNet endpoints are projected onto monosemous WordNet senses; pairs
    that cannot be resolved to a single sense are dropped.
    """
    pairs: list[tuple[str, str, str, str]] = []
    seen: set[tuple[str, str]] = set()
    for u, v, _k, d in graph.g.edges(keys=True, data=True):
        relation = d.get("rel", "")
        if relation not in {"Antonym", "DistinctFrom"}:
            continue
        su = u if u.startswith("wn:") else graph.monosemous_sense(u)
        sv = v if v.startswith("wn:") else graph.monosemous_sense(v)
        if not su or not sv or su == sv:
            continue
        key = (su, sv) if su < sv else (sv, su)
        if key in seen:
            continue
        seen.add(key)
        source = "wordnet_antonym" if d.get("source") == "wn" else "conceptnet_edge"
        pairs.append((su, sv, relation, source))
    return pairs


def _cohyponym_pairs(
    graph: ConceptGraph, rng: random.Random, quota: int, banned: set[tuple[str, str]],
) -> list[tuple[str, str, str, str]]:
    """Distinct co-hyponyms of a shared parent, labelled ``DistinctFrom``.

    Two different hyponyms of the same category are genuinely distinct concepts,
    so the label is attested by the hierarchy rather than assigned.
    """
    children = graph._ensure_children()
    parents = [
        p for p, kids in children.items()
        if p.startswith("wn:") and 2 <= len(kids) <= 60
    ]
    rng.shuffle(parents)
    out: list[tuple[str, str, str, str]] = []
    for parent in parents:
        if len(out) >= quota:
            break
        kids = [
            k for k in children[parent]
            if k.startswith("wn:") and is_clean_label(graph.label(k))
        ]
        if len(kids) < 2:
            continue
        rng.shuffle(kids)
        for i in range(0, len(kids) - 1, 2):
            if len(out) >= quota:
                break
            u, v = kids[i], kids[i + 1]
            key = (u, v) if u < v else (v, u)
            if key in banned:
                continue
            banned.add(key)
            out.append((u, v, "DistinctFrom", "shared_hypernym"))
    return out


def _family_disjoint_split(
    rows: list[dict], sizes: dict[str, int], rng: random.Random,
) -> dict[str, list[dict]]:
    by_family: dict[str, list[dict]] = {}
    for r in rows:
        by_family.setdefault(r["S_id"], []).append(r)
    families = sorted(by_family, key=lambda f: (len(by_family[f]), f))
    rng.shuffle(families)
    out: dict[str, list[dict]] = {name: [] for name in sizes}
    order = sorted(sizes, key=lambda k: sizes[k])
    for fam in families:
        bucket = by_family[fam]
        for name in order:
            if len(out[name]) + len(bucket) <= sizes[name]:
                out[name].extend(bucket)
                break
    return out


def build_concept_shift(
    *,
    out_path: str,
    train_size: int,
    dev_size: int,
    test_size: int,
    conf_size: int = 0,
    seed: int = 42,
    graph: ConceptGraph | None = None,
) -> dict[str, int]:
    """Construct ConceptShift splits with concept-family-disjoint holdouts."""
    rng = random.Random(seed)
    if graph is None:
        cache = Path("data/processed/concept_graph.gpkl")
        if not cache.exists():
            raise RuntimeError(f"missing concept graph cache: {cache}")
        graph = ConceptGraph.load(cache)

    quota = train_size + dev_size + test_size + conf_size
    attested = _attested_contrast_pairs(graph)
    rng.shuffle(attested)
    logger.info(f"ConceptShift: attested contrast pairs={len(attested)}")

    rows: list[dict] = []
    used: set[tuple[str, str]] = set()
    for u, v, relation, source in attested:
        if len(rows) >= quota:
            break
        key = (u, v) if u < v else (v, u)
        used.add(key)
        row = _row_from_pair(graph, u, v, relation, f"cs_{len(rows):06d}", edge_source=source)
        if row is not None:
            rows.append(row)
    logger.info(f"ConceptShift: rows from attested edges={len(rows)}")

    if len(rows) < int(quota * 1.3):
        need = int(quota * 1.3) - len(rows)
        for u, v, relation, source in _cohyponym_pairs(graph, rng, need * 3, used):
            if len(rows) >= int(quota * 1.3):
                break
            row = _row_from_pair(
                graph, u, v, relation, f"cs_{len(rows):06d}", edge_source=source,
            )
            if row is not None:
                rows.append(row)
    logger.info(f"ConceptShift: total candidate rows={len(rows)}")
    if len(rows) < quota:
        raise RuntimeError(f"ConceptShift underfilled: {len(rows)} < {quota}")

    sizes = {"test": test_size, "dev": dev_size, "train": train_size}
    if conf_size:
        sizes["conf"] = conf_size
    splits = _family_disjoint_split(rows, sizes, rng)
    for name, size in sizes.items():
        if len(splits[name]) < size:
            raise RuntimeError(
                f"ConceptShift family-disjoint split short for {name}: "
                f"{len(splits[name])}/{size}"
            )
        splits[name] = splits[name][:size]

    out: dict[str, int] = {}
    out_dir = Path(out_path)
    for name, items in splits.items():
        for i, row in enumerate(items):
            row["id"] = f"concept_shift_{name}_{i:06d}"
        out[name] = save_jsonl(out_dir / f"concept_shift_{name}.jsonl", items)
    logger.info("ConceptShift built — " + " ".join(f"{k}={v}" for k, v in out.items()))
    return out
