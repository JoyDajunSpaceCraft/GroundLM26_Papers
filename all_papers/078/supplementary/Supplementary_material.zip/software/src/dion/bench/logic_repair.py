"""LogicRepair constructor for certified Horn implication chains."""

from __future__ import annotations

import hashlib
import random
import re
from pathlib import Path

from dion.utils.io import save_jsonl
from dion.utils.logging_utils import get_logger

logger = get_logger("dion.bench.logic_repair")

_FACT_RE = re.compile(
    r"^(?P<subject>[A-Z][A-Za-z'-]*) is "
    r"(?P<neg>not )?(?:(?:a|an) )?(?P<predicate>[a-z][A-Za-z'-]*)\.$"
)
_THING_RULE_RE = re.compile(
    r"^All (?P<antecedent>[a-z][A-Za-z'-]*) things are "
    r"(?P<consequent>[a-z][A-Za-z'-]*)\.$"
)
_CLASS_RULE_RE = re.compile(
    r"^All (?P<antecedent>[a-z][A-Za-z'-]*) are "
    r"(?P<consequent>[a-z][A-Za-z'-]*)\.$"
)


def _try_import_pysat():
    try:
        from pysat.solvers import Glucose4  # type: ignore

        return Glucose4
    except Exception:
        return None


_GLUCOSE = _try_import_pysat()


def _pluralize(noun: str) -> str:
    if noun.endswith("y") and len(noun) > 1 and noun[-2] not in "aeiou":
        return f"{noun[:-1]}ies"
    if noun.endswith(("s", "x", "z", "ch", "sh")):
        return f"{noun}es"
    return f"{noun}s"


def _singularize(noun: str) -> str:
    if noun.endswith("ies") and len(noun) > 3:
        return f"{noun[:-3]}y"
    if noun.endswith(("ses", "xes", "zes", "ches", "shes")):
        return noun[:-2]
    if noun.endswith("s") and not noun.endswith("ss"):
        return noun[:-1]
    return noun


def _parse_fact(sentence: str) -> tuple[str, str, bool] | None:
    match = _FACT_RE.fullmatch(sentence.strip())
    if match is None:
        return None
    return (
        match.group("subject"),
        match.group("predicate"),
        match.group("neg") is not None,
    )


def _parse_rule(
    sentence: str,
    expected_antecedent: str | None = None,
) -> tuple[str, str] | None:
    stripped = sentence.strip()
    match = _THING_RULE_RE.fullmatch(stripped)
    if match is not None:
        antecedent = match.group("antecedent")
        if expected_antecedent is not None and antecedent != expected_antecedent:
            return None
        return antecedent, match.group("consequent")
    match = _CLASS_RULE_RE.fullmatch(stripped)
    if match is not None:
        antecedent_surface = match.group("antecedent")
        if expected_antecedent is not None:
            accepted_surfaces = {
                _pluralize(expected_antecedent),
                f"{expected_antecedent}s",
            }
            if antecedent_surface not in accepted_surfaces:
                return None
            antecedent = expected_antecedent
        else:
            antecedent = _singularize(antecedent_surface)
        return antecedent, match.group("consequent")
    return None


def _encode_horn_theory(sentences: list[str]) -> list[list[int]]:
    facts = [
        fact
        for sentence in sentences
        if (fact := _parse_fact(sentence)) is not None
    ]
    fact_predicates = sorted({predicate for _, predicate, _ in facts})
    rules: list[tuple[str, str]] = []
    for sentence in sentences:
        if _parse_fact(sentence) is not None:
            continue
        rule = next(
            (
                parsed
                for predicate in fact_predicates
                if (parsed := _parse_rule(sentence, predicate)) is not None
            ),
            None,
        )
        if rule is None:
            rule = _parse_rule(sentence)
        if rule is not None:
            rules.append(rule)

    atoms: dict[tuple[str, str], int] = {}

    def _atom(subject: str, predicate: str) -> int:
        key = (subject, predicate)
        if key not in atoms:
            atoms[key] = len(atoms) + 1
        return atoms[key]

    clauses: list[list[int]] = []
    subjects = sorted({subject for subject, _, _ in facts})
    for subject, predicate, negated in facts:
        atom = _atom(subject, predicate)
        clauses.append([-atom] if negated else [atom])
    for antecedent, consequent in rules:
        for subject in subjects:
            clauses.append([
                -_atom(subject, antecedent),
                _atom(subject, consequent),
            ])
    return clauses


def _sat_unsat(clauses: list[list[int]]) -> bool:
    if _GLUCOSE is not None:
        with _GLUCOSE(bootstrap_with=clauses) as solver:
            return not solver.solve()

    derived = {
        clause[0]
        for clause in clauses
        if len(clause) == 1 and clause[0] > 0
    }
    forbidden = {
        -clause[0]
        for clause in clauses
        if len(clause) == 1 and clause[0] < 0
    }
    rules: list[tuple[int, int]] = []
    for clause in clauses:
        if len(clause) != 2:
            continue
        negative = [literal for literal in clause if literal < 0]
        positive = [literal for literal in clause if literal > 0]
        if len(negative) == 1 and len(positive) == 1:
            rules.append((-negative[0], positive[0]))

    changed = True
    while changed:
        changed = False
        for antecedent, consequent in rules:
            if antecedent in derived and consequent not in derived:
                derived.add(consequent)
                changed = True
    return bool(derived & forbidden)


def verify_mus(K: list[str], a_star: str, target: str, mus: list[str]) -> tuple[bool, dict]:
    """Verify a nontrivial Horn-chain MUS and deletion minimality."""
    if len(mus) not in {4, 5, 6}:
        return False, {"reason": "invalid_mus_size"}
    if len(mus) != len(set(mus)):
        return False, {"reason": "duplicate_mus_sentence"}
    if mus[0] != target or mus[-1] != a_star:
        return False, {"reason": "invalid_mus_order"}
    if a_star in K:
        return False, {"reason": "injection_already_in_theory"}
    if any(sentence not in K for sentence in mus[:-1]):
        return False, {"reason": "mus_sentence_missing_from_theory"}

    target_fact = _parse_fact(target)
    if target_fact is None or target_fact[2]:
        return False, {"reason": "invalid_target_fact"}
    subject, current_predicate, _ = target_fact
    for sentence in mus[1:-1]:
        rule = _parse_rule(sentence, current_predicate)
        if rule is None:
            return False, {"reason": "disconnected_chain", "sentence": sentence}
        _, current_predicate = rule

    injected_fact = _parse_fact(a_star)
    if injected_fact != (subject, current_predicate, True):
        return False, {"reason": "invalid_chain_negation"}

    base = _encode_horn_theory(K)
    if _sat_unsat(base):
        return False, {"reason": "base_theory_unsat"}
    full = _encode_horn_theory([*K, a_star])
    if not _sat_unsat(full):
        return False, {"reason": "full_theory_sat"}

    for index, dropped in enumerate(mus):
        subset = mus[:index] + mus[index + 1:]
        if _sat_unsat(_encode_horn_theory(subset)):
            return False, {"reason": "non_minimal", "drop": dropped}

    cert = {
        "encoding": "horn_implication_chain",
        "chain_length": len(mus) - 1,
        "target": target,
        "unsat": True,
        "minimal": True,
        "solver": "Glucose4" if _GLUCOSE is not None else "horn_forward_chaining",
        "hash": hashlib.sha1(
            "||".join(mus).encode("utf-8")
        ).hexdigest()[:16],
        "mus_size": len(mus),
        "nontrivial": True,
    }
    return True, cert


def build_logic_repair(
    *,
    out_path: str,
    train_size: int,
    dev_size: int,
    test_size: int,
    seed: int = 42,
    verify: bool | None = None,
) -> dict[str, int]:
    """Build LogicRepair splits; every kept item carries a solver certificate."""
    rng = random.Random(seed)
    total = train_size + dev_size + test_size
    if verify is None:
        verify = True
    rows = _synthesize_logic_rows(total, rng, verify)
    if len(rows) < total:
        logger.warning(f"LogicRepair synthesis underfilled: {len(rows)}/{total}")

    rng.shuffle(rows)
    splits = {
        "train": rows[:train_size],
        "dev": rows[train_size:train_size + dev_size],
        "test": rows[train_size + dev_size:train_size + dev_size + test_size],
    }
    out: dict[str, int] = {}
    out_dir = Path(out_path)
    for name, items in splits.items():
        out[name] = save_jsonl(out_dir / f"logic_repair_{name}.jsonl", items)
    logger.info(f"LogicRepair built — train={out['train']} dev={out['dev']} test={out['test']}")
    return out


def _synthesize_logic_rows(n: int, rng: random.Random, verify: bool) -> list[dict]:
    """Generate certified Horn-chain repair instances."""
    nouns = [
        "cat", "dog", "bird", "tree", "car", "book", "river", "metal", "lion", "eagle",
        "whale", "oak", "truck", "novel", "lake", "town", "alloy", "sparrow", "shark",
        "pine", "essay", "stream", "stone", "wolf", "hawk", "trout", "maple", "van",
        "poem", "pond", "harbor", "bear", "owl", "crab", "train", "letter", "creek",
        "port", "copper", "robot", "planet", "comet", "vessel", "fabric", "gem",
    ]
    props = [
        "red", "large", "quiet", "alive", "metallic", "warm", "visible", "solid",
        "cold", "soft", "heavy", "bright", "fragile", "opaque", "smooth", "hollow",
        "wet", "dry", "sharp", "round", "flat", "thin", "thick", "dark", "ancient",
        "rural", "calm", "nimble",
    ]
    names = [
        "Ada", "Ben", "Chen", "Dia", "Eli", "Fay", "Gus", "Hiro", "Ivy", "Jin",
        "Kai", "Lia", "Mo", "Nia", "Omar", "Pia", "Quinn", "Rae", "Sam", "Tess",
        "Uma", "Vic", "Wen", "Xan", "Yara", "Zoe", "Abe", "Bea", "Cid", "Dee",
    ]
    styles = ("folio", "proofwriter", "native")
    out: list[dict] = []
    seen: set[str] = set()
    attempts = 0
    max_attempts = max(n * 20, 1000)
    while len(out) < n and attempts < max_attempts:
        attempts += 1
        style = styles[len(out) % len(styles)]
        subject = rng.choice(names)
        noun = rng.choice(nouns)
        rule_count = rng.randint(2, 4)
        selected_props = rng.sample(props, rule_count + 2)
        chain_props = selected_props[:rule_count]
        distractor_prop, secondary_prop = selected_props[-2:]

        target = f"{subject} is a {noun}."
        rules = [f"All {_pluralize(noun)} are {chain_props[0]}."]
        rules.extend(
            f"All {antecedent} things are {consequent}."
            for antecedent, consequent in zip(chain_props, chain_props[1:])
        )
        chain = [target, *rules]
        a_star = f"{subject} is not {chain_props[-1]}."
        mus = [*chain, a_star]

        other_subject = rng.choice([name for name in names if name != subject])
        other_noun = rng.choice([candidate for candidate in nouns if candidate != noun])
        if style == "folio":
            distractor_pool = [
                f"{other_subject} is a {other_noun}.",
                f"All {_pluralize(other_noun)} are {distractor_prop}.",
                f"All {secondary_prop} things are {distractor_prop}.",
            ]
        elif style == "proofwriter":
            distractor_pool = [
                f"{other_subject} is {distractor_prop}.",
                f"All {distractor_prop} things are {secondary_prop}.",
                f"{other_subject} is a {other_noun}.",
            ]
        else:
            distractor_pool = [
                f"All {_pluralize(other_noun)} are {distractor_prop}.",
                f"{other_subject} is a {other_noun}.",
                f"{other_subject} is {secondary_prop}.",
            ]
        distractors = distractor_pool[:rng.randint(0, len(distractor_pool))]
        kb = [*chain, *distractors]
        rng.shuffle(kb)

        sig = "||".join(chain) + "||" + a_star
        if sig in seen:
            continue
        ok, cert = verify_mus(kb, a_star, target, mus)
        if not ok:
            continue
        seen.add(sig)
        out.append({
            "id": f"lr_synthetic_{len(out):06d}",
            "K": kb,
            "a_star": a_star,
            "MUS": mus,
            "K_prime": [p for p in kb if p != target],
            "source": "synthetic",
            "task": "minimal_repair",
            "certificate": cert,
            "target_sentence": target,
            "chain": chain,
            "provenance": {
                "surface_style": style,
                "synthetic": True,
            },
        })
    return out
