"""Concept Predicate Head q_phi(z | c_l).

    q_phi(z | c) = softmax(W_z c + b_z),  z in {1, ..., K}

Trained with two self-supervised signals:
  (a) view consistency: JS divergence across two stochastic views of x.
  (b) batch diversity: -H(qbar) (so the codebook is used).
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConceptPredicateHead(nn.Module):
    def __init__(self, d_model: int, K: int = 512) -> None:
        super().__init__()
        self.K = K
        self.W_z = nn.Linear(d_model, K, bias=True)
        nn.init.xavier_uniform_(self.W_z.weight)
        nn.init.zeros_(self.W_z.bias)

    def logits(self, c: torch.Tensor) -> torch.Tensor:
        """(B, D) → (B, K)"""
        return self.W_z(c)

    def forward(self, c: torch.Tensor) -> torch.Tensor:
        """Return q_φ(z|c) ∈ Δ^{K-1}, shape (B, K)."""
        return F.softmax(self.W_z(c), dim=-1)


def js_divergence(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Symmetric Jensen–Shannon divergence between two distributions.

    Args:
        p, q: (..., K) probabilities summing to 1 along last dim.
    Returns:
        scalar tensor (mean over batch).
    """
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    m = 0.5 * (p + q)
    kl_pm = (p * (p.log() - m.log())).sum(-1)
    kl_qm = (q * (q.log() - m.log())).sum(-1)
    return (0.5 * (kl_pm + kl_qm)).mean()


def batch_entropy(q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """H(¯q) where ¯q = (1/B) Σ q_i — to be MAXIMIZED for batch diversity."""
    q_bar = q.mean(0).clamp_min(eps)
    return -(q_bar * q_bar.log()).sum()


def cph_loss(
    q_view1: torch.Tensor,
    q_view2: torch.Tensor,
    lambda_div: float = 0.05,
) -> dict[str, torch.Tensor]:
    """L_CPH = L_cons + λ · L_div, with L_div = -H(¯q)."""
    l_cons = js_divergence(q_view1, q_view2)
    H_bar = batch_entropy(0.5 * (q_view1 + q_view2))
    l_div = -H_bar
    l_total = l_cons + lambda_div * l_div
    return {
        "loss": l_total,
        "cons": l_cons.detach(),
        "diversity_H": H_bar.detach(),
    }


def predicate_entropy(q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """H(q_φ(·|c)) per sample, shape (B,)."""
    q = q.clamp_min(eps)
    return -(q * q.log()).sum(-1)
