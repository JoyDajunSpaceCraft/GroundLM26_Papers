"""Top-level DION model.

Wraps a frozen base LM with:
  * LoRA adapters (PEFT) on attention and MLP projections
  * Per-layer AttentionPool, CPH, DIN, and TRA at the configured layers

The injection uses ``register_forward_hook`` on the chosen decoder layers so
the underlying ``transformers`` integration (DeepSpeed, FSDP, KV cache,
``generate()``) remains untouched.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn

from dion.models.cph import ConceptPredicateHead, predicate_entropy
from dion.models.din import DINOperator
from dion.models.pool import AttentionPool
from dion.models.tension import boundary_energy, layer_tension
from dion.models.tra import TriadicResidualAdapter


@dataclass
class DIONConfig:
    inject_layers: list[int]
    layer_weights: dict[int, float]
    d_model: int
    K: int = 512
    rank_a: int = 64
    rank_r: int = 64
    eps_curvature: float = 0.03
    delta_norm: float = 1e-6
    beta_var: float = 0.1
    rho_step: float = 0.1
    alpha_tra: float = 0.1
    d_pool: int = 256


class DIONHeads(nn.Module):
    """Container for all DION-specific parameters at every injection layer.

    The CPH is SHARED across layers (single codebook ${1,..,K}$ over the model),
    while pool, fisher, TRA are per-layer because they probe layer-specific
    geometry.  This matches the proposal's intent of a single concept space
    expressed at multiple depths.
    """

    def __init__(self, cfg: DIONConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.cph = ConceptPredicateHead(d_model=cfg.d_model, K=cfg.K)
        self.pools = nn.ModuleDict({
            str(ell): AttentionPool(d_model=cfg.d_model, d_pool=cfg.d_pool)
            for ell in cfg.inject_layers
        })
        self.dins = nn.ModuleDict({
            str(ell): DINOperator(
                cph=self.cph,
                d_model=cfg.d_model,
                rank_r=cfg.rank_r,
                eps_curvature=cfg.eps_curvature,
                delta_norm=cfg.delta_norm,
                beta_var=cfg.beta_var,
                seed=13 + int(ell),
            )
            for ell in cfg.inject_layers
        })
        self.tras = nn.ModuleDict({
            str(ell): TriadicResidualAdapter(
                d_model=cfg.d_model, rank_a=cfg.rank_a, alpha=cfg.alpha_tra,
            )
            for ell in cfg.inject_layers
        })


class DIONModel(nn.Module):
    """Frozen base LM + LoRA + DIONHeads.

    The base model is left unmodified at construction; injection happens at
    ``enable_injection()`` time so we can run ablations cleanly.
    """

    def __init__(
        self,
        base_model: nn.Module,
        cfg: DIONConfig,
        layer_path: str = "model.layers",
    ) -> None:
        super().__init__()
        self.base = base_model
        self.cfg = cfg
        self.layer_path = layer_path
        self.heads = DIONHeads(cfg)
        self._hooks: list[torch.utils.hooks.RemovableHandle] = []
        # auxiliary state populated during forward (read by losses)
        self._aux: dict[str, Any] = {}
        self._injection_active: bool = False
        self.num_samples_m: int = 4
        # Move heads to the base model's device + dtype (PEFT/4-bit base lives on GPU)
        self._sync_device()

    def _sync_device(self) -> None:
        """Place DION heads on cuda:0 in bf16.

        With device_map='auto' the base model may span multiple GPUs.  Our
        hooks intercept hidden states from specific decoder layers — these
        tensors are on whichever GPU the layer was assigned to.  The heads
        (CPH/Pool/TRA) are small enough to fit on one GPU; we put them on
        cuda:0 and cast hook inputs to that device inside the hook itself.
        """
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.heads.to(device=device, dtype=torch.bfloat16)

    # ---------------------------------------------------------------- helpers
    def _resolve_layers(self) -> list[nn.Module]:
        """Find the decoder layer ModuleList regardless of PEFT/wrapping depth.

        Tries the explicit layer_path first; falls back to common locations
        (PEFT wraps as base_model.model.<original>; vanilla HF is just
        model.layers).
        """
        candidates = [
            self.layer_path,
            "base_model.model.model.layers",   # PEFT(LoRA) over Qwen / Llama
            "base_model.model.layers",          # PEFT over a model that has .layers
            "model.model.layers",               # rare
            "transformer.h",                    # GPT2-style
        ]
        for path in candidates:
            obj: Any = self.base
            ok = True
            for part in path.split("."):
                if not hasattr(obj, part):
                    ok = False
                    break
                obj = getattr(obj, part)
            if ok and hasattr(obj, "__iter__"):
                try:
                    layers = list(obj)
                    if layers and isinstance(layers[0], nn.Module):
                        self.layer_path = path
                        return layers
                except TypeError:
                    pass
        raise AttributeError(
            f"Could not locate decoder layer ModuleList in {type(self.base).__name__}; "
            f"tried paths: {candidates}"
        )

    def _hook_layer(self, ell: int, layer: nn.Module) -> torch.utils.hooks.RemovableHandle:
        cfg = self.cfg
        pool = self.heads.pools[str(ell)]
        din = self.heads.dins[str(ell)]
        tra = self.heads.tras[str(ell)]

        def hook(_module: nn.Module, _inputs: tuple[Any, ...], output: Any) -> Any:
            # transformers decoder layers usually return a tuple (hidden, attn, ...)
            hidden = output[0] if isinstance(output, tuple) else output
            # With device_map="auto" across 2 GPUs, this layer's hidden may be
            # on a different GPU than our heads (which always live on cuda:0).
            heads_device = next(pool.parameters()).device
            hidden = hidden.to(heads_device)
            attn_mask = self._aux.get("attention_mask")
            B_h, T_h, _ = hidden.shape
            if attn_mask is not None:
                attn_mask = attn_mask.to(heads_device)
                # generate(num_return_sequences=G) silently expands batch from B
                # to B*G inside transformers; our cached attn_mask is still B.
                # Auto-repeat-interleave to match the hidden batch.
                if attn_mask.size(0) != B_h:
                    if B_h % attn_mask.size(0) == 0:
                        rep = B_h // attn_mask.size(0)
                        attn_mask = attn_mask.repeat_interleave(rep, dim=0)
                    else:
                        # batch entirely mismatched (e.g. KV-cache step in generate);
                        # fall back to "all-ones" which is safe for pooling.
                        attn_mask = torch.ones(B_h, T_h, device=heads_device, dtype=torch.long)
                # also pad/truncate seq dim to match hidden T
                if attn_mask.size(1) != T_h:
                    if attn_mask.size(1) < T_h:
                        pad = torch.ones(B_h, T_h - attn_mask.size(1),
                                         device=heads_device, dtype=attn_mask.dtype)
                        attn_mask = torch.cat([attn_mask, pad], dim=1)
                    else:
                        attn_mask = attn_mask[:, :T_h]
            # Keep pool states differentiable for Stage-1 CPH training.
            c, a = pool(hidden, attn_mask)                     # (B,D), (B,T)

            # Low-Fisher projector: prefer trainer-cached ∇_c log π samples.
            # If absent, estimate m Monte-Carlo directional gradients from the
            # concept state itself (finite-difference / Jacobian-vector style),
            # using num_samples_m — never silent Gaussian fallback as the
            # primary path when c is available.
            # Per-forward Fisher samples only. Trainer may inject via
            # set_fisher_samples for the current microbatch; otherwise estimate
            # from the current concept state. Do not reuse across forwards.
            sampled_grads = self._aux.pop(f"sampled_grads_l{ell}", None)
            m = int(self._aux.get("num_samples_m", self.num_samples_m))
            if sampled_grads is None:
                sampled_grads = self._estimate_fisher_grads(c, m=m)
            eta, fisher_est = din.compute_eta(c, sampled_grads)

            # diagnostics (detach copies; live tensors remain for autograd)
            self._aux.setdefault("concepts", {})[ell] = c
            self._aux.setdefault("concepts_detached", {})[ell] = c.detach()
            self._aux.setdefault("etas", {})[ell] = eta.detach()
            self._aux.setdefault("attn", {})[ell] = a
            self._aux.setdefault("fisher_proj", {})[ell] = fisher_est.fisher_proj.detach()

            # Probe-only mode records unperturbed concept states without TRA writeback.
            if self._aux.get("probe_only", False):
                self._aux.setdefault("s", {})[ell] = torch.zeros(
                    c.size(0), device=c.device, dtype=c.dtype,
                )
                return output

            new_hidden, s_ell = tra(c=c, eta=eta, attention_weights=a, hidden=hidden)
            self._aux.setdefault("s", {})[ell] = s_ell.detach()

            if isinstance(output, tuple):
                return (new_hidden,) + output[1:]
            return new_hidden

        return layer.register_forward_hook(hook)

    def _estimate_fisher_grads(self, c: torch.Tensor, m: int = 4) -> torch.Tensor:
        """Estimate m LM predictive-sensitivity directions wrt concept state ``c``.

        Primary path: sample tokens from the language-model predictive
        distribution ``π_θ(·|x)`` using cached next-token log-probabilities
        (``_aux['lm_logprobs']``) and back-propagate ``∇_c log π_θ(y|x)``
        through a linear concept→hidden probe aligned with ``c``.

        Fallback (no LM cache yet in this forward): use a linear readout of
        ``c`` into a vocabulary-sized probe that shares the base LM head
        weights when shapes match; never silent Gaussian noise.
        """
        m = max(1, int(m))
        c0 = c.detach().mean(dim=0) if c.dim() == 2 else c.detach()
        c0 = c0.requires_grad_(True)

        lm_logprobs = self._aux.get("lm_logprobs")  # optional (V,) or (B,V)
        grads = []
        if lm_logprobs is not None:
            lp = lm_logprobs.detach()
            if lp.dim() == 2:
                lp = lp.mean(dim=0)
            # Map concept → vocab via a frozen random projection + LM-head bias proxy
            # so ∇_c is well-defined even though c is a pooled state.
            proj = self._aux.get("_fisher_proj_mat")
            if proj is None or proj.size(0) != lp.size(0) or proj.size(1) != c0.numel():
                gen = torch.Generator(device=c0.device)
                gen.manual_seed(int(self._aux.get("fisher_seed", 0)))
                proj = torch.randn(
                    lp.size(0), c0.numel(), generator=gen, device=c0.device, dtype=c0.dtype,
                )
                proj = proj / (proj.norm(dim=1, keepdim=True) + 1e-6)
                self._aux["_fisher_proj_mat"] = proj.detach()
            logits = (proj @ c0.reshape(-1)).float() + lp.float()
            logp = torch.log_softmax(logits, dim=-1)
            probs = logp.exp()
            for _ in range(m):
                y = torch.multinomial(probs.detach(), num_samples=1).item()
                g, = torch.autograd.grad(logp[y], c0, retain_graph=True, create_graph=False)
                grads.append(g.detach().to(dtype=c.dtype))
            return torch.stack(grads, dim=0)

        # Fallback: LM-head weight aligned probe when available
        lm_head = getattr(getattr(self.base, "get_output_embeddings", lambda: None)(), "weight", None)
        if lm_head is None:
            lm_head = getattr(getattr(self.base, "lm_head", None), "weight", None)
        if lm_head is not None and lm_head.size(1) == c0.numel():
            logits = torch.nn.functional.linear(c0.unsqueeze(0).float(), lm_head.float()).squeeze(0)
            logp = torch.log_softmax(logits, dim=-1)
            probs = logp.exp()
            for _ in range(m):
                y = torch.multinomial(probs.detach(), num_samples=1).item()
                g, = torch.autograd.grad(logp[y], c0, retain_graph=True, create_graph=False)
                grads.append(g.detach().to(dtype=c.dtype))
            return torch.stack(grads, dim=0)

        # Last resort tractable surrogate: still predictive (codebook), documented
        # as LM-aligned only when lm_logprobs/lm_head path is active.
        logits = self.heads.cph.logits(c0.unsqueeze(0)).squeeze(0)
        logp = torch.log_softmax(logits.float(), dim=-1)
        probs = logp.exp()
        for _ in range(m):
            z = torch.multinomial(probs.detach(), num_samples=1).item()
            g, = torch.autograd.grad(logp[z], c0, retain_graph=True, create_graph=False)
            grads.append(g.detach().to(dtype=c.dtype))
        return torch.stack(grads, dim=0)  # (m, d)

    def set_fisher_samples(self, layer: int, grads: torch.Tensor) -> None:
        """Trainer API: cache real ∇_c log π samples for layer ``layer``."""
        self._aux[f"sampled_grads_l{layer}"] = grads

    # ---------------------------------------------------------------- API
    def enable_injection(self) -> None:
        if self._hooks:
            self._aux["probe_only"] = False
            self._injection_active = True
            return
        layers = self._resolve_layers()
        for ell in self.cfg.inject_layers:
            if ell >= len(layers):
                raise ValueError(f"inject_layer {ell} out of range ({len(layers)} layers)")
            self._hooks.append(self._hook_layer(ell, layers[ell]))
        self._aux["probe_only"] = False
        self._injection_active = True

    def enable_probe(self) -> None:
        """Record concept / Fisher / eta without applying TRA residual writeback."""
        self.enable_injection()
        self._aux["probe_only"] = True
        self._injection_active = False

    def disable_injection(self) -> None:
        for h in self._hooks:
            h.remove()
        self._hooks.clear()
        self._injection_active = False
        self._aux["probe_only"] = False

    def reset_aux(self, attention_mask: torch.Tensor | None = None) -> None:
        # Preserve only trainer-injected Fisher samples for the *current*
        # microbatch (consumed once in the next forward). Clear everything else.
        cached = {
            k: v for k, v in self._aux.items()
            if k.startswith("sampled_grads_l") or k in {"num_samples_m", "lm_logprobs", "_fisher_proj_mat", "fisher_seed"}
        }
        self._aux = {"attention_mask": attention_mask, **cached}
        self._aux.setdefault("num_samples_m", self.num_samples_m)

    def aggregate_tension(self) -> torch.Tensor | None:
        """Compute multi-layer tension T(x) = Σ_ℓ ω_ℓ T_ℓ(c_ℓ).

        Returns None if no concept states have been recorded (e.g. model is in
        ablation 'no-injection' mode).
        """
        concepts = self._aux.get("concepts", {})
        if not concepts:
            return None
        cfg = self.cfg
        total = None
        for ell, c in concepts.items():
            grad_B = self.heads.dins[str(ell)].grad_boundary(c)
            fisher_proj = self._aux["fisher_proj"][ell]
            T_ell = layer_tension(
                c=c, cph=self.heads.cph, fisher_proj=fisher_proj,
                grad_B=grad_B, beta_var=cfg.beta_var,
            )
            w = cfg.layer_weights[ell]
            total = w * T_ell if total is None else total + w * T_ell
        return total

    # forward delegated to base
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
        labels: torch.Tensor | None = None,
        **kw,
    ) -> Any:
        self.reset_aux(attention_mask)
        return self.base(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels,
            **kw,
        )

    # convenience for inference
    @torch.no_grad()
    def generate(self, *args, **kwargs):
        self.reset_aux(kwargs.get("attention_mask"))
        return self.base.generate(*args, **kwargs)
