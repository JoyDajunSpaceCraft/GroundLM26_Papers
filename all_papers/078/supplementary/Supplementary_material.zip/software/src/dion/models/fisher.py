"""Low-rank Fisher information of the conditional output distribution wrt c_l.

    F_l(c) = E_{y ~ pi}[ grad_c log pi(y|x) * grad_c log pi(y|x)^T ]
    R_l    in R^{d x r}  (random Gaussian projection, fixed)
    g_j    = grad_c log pi(y_j|x) for y_j ~ pi,  j = 1..m
    F~_l(c) = (1 / m) sum_j (R_l^T g_j) (R_l^T g_j)^T  in R^{r x r}

Eigendecomposition F~_l = U_l Lambda_l U_l^T defines the low-curvature
projection P_{l, eps} = U_{l, eps} U_{l, eps}^T over indices {i : lambda_i
<= eps * lambda_r}.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn


@dataclass
class LowRankFisherEstimate:
    F_tilde: torch.Tensor          # (r, r) symmetric PSD
    eigvals: torch.Tensor          # (r,)  ascending
    eigvecs: torch.Tensor          # (r, r) columns = eigvecs (ascending)
    P_low: torch.Tensor            # (r, r) projector onto low-curvature subspace
    fisher_proj: torch.Tensor      # (r, d) = P_{ℓ,ε} R_ℓ^T  (commonly used)


class LowRankFisher(nn.Module):
    """Random-projection low-rank Fisher estimator for one layer ℓ.

    The random projection matrix R is FIXED across training (not learned),
    seeded once for reproducibility.  This matches §5.1 of the proposal and
    avoids re-introducing trainable parameters that could drift.
    """

    def __init__(
        self,
        d: int,
        r: int = 64,
        eps_curvature: float = 0.03,
        seed: int = 13,
    ) -> None:
        super().__init__()
        gen = torch.Generator(device="cpu").manual_seed(seed)
        R = torch.randn(d, r, generator=gen) / (d**0.5)
        self.register_buffer("R", R)        # (d, r)
        self.r = r
        self.eps_curvature = eps_curvature

    def forward(self, grads_c: torch.Tensor) -> LowRankFisherEstimate:
        """Compute the low-rank Fisher estimate from m sampled gradients.

        Args:
            grads_c: (m, d)  — per-sample gradients ∇_c log π(y_j|x).
        Returns:
            LowRankFisherEstimate.

        Notes:
            ``torch.linalg.eigh`` on CUDA does not support bfloat16 (as of
            torch 2.5).  We therefore compute the small (r×r) eigendecomposition
            in float32 and cast results back to the input dtype, which is
            numerically the right thing to do anyway because Fisher curvature
            estimates are sensitive to low-precision accumulation.
        """
        if grads_c.dim() != 2:
            raise ValueError(f"grads_c must be (m, d), got {grads_c.shape}")
        in_dtype = grads_c.dtype
        device = grads_c.device

        # Compute Fisher in fp32 for numerical stability of eigendecomposition.
        gf = grads_c.to(dtype=torch.float32)
        Rf = self.R.to(device=device, dtype=torch.float32)
        proj_grads = gf @ Rf                                       # (m, r) fp32
        F = (proj_grads.unsqueeze(-1) * proj_grads.unsqueeze(-2)).mean(0)
        F = 0.5 * (F + F.transpose(-1, -2))

        eigvals, eigvecs = torch.linalg.eigh(F)                    # fp32 ascending
        thresh = self.eps_curvature * eigvals[-1].clamp_min(1e-12)
        low_mask = eigvals <= thresh                                # (r,)
        U_low = eigvecs[:, low_mask]                                # (r, k)
        P_low = U_low @ U_low.transpose(-1, -2)                     # (r, r)
        fisher_proj = P_low @ Rf.transpose(-1, -2)                  # (r, d)

        # Cast back to compute dtype for downstream tensor ops.
        return LowRankFisherEstimate(
            F_tilde=F.to(in_dtype),
            eigvals=eigvals.to(in_dtype),
            eigvecs=eigvecs.to(in_dtype),
            P_low=P_low.to(in_dtype),
            fisher_proj=fisher_proj.to(in_dtype),
        )
