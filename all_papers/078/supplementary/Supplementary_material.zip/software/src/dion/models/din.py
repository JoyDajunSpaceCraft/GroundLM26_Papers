"""Boundary-tension direction operator eta_l(c_l).

    eta_l(c) = (R_l P_{l, eps} R_l^T grad_c B_l(c))
             / (||R_l P_{l, eps} R_l^T grad_c B_l(c)||_2 + delta)

A low-Fisher-curvature direction along which the semantic-boundary energy
rises -- a direction the model is INSENSITIVE to (low Fisher) but where
concept-predicate disagreement is HIGH (large ||grad B||).
"""

from __future__ import annotations

import torch
import torch.nn as nn

from dion.models.cph import ConceptPredicateHead
from dion.models.fisher import LowRankFisher, LowRankFisherEstimate
from dion.models.tension import boundary_energy


class DINOperator(nn.Module):
    """Per-layer boundary-tension direction operator.

    Holds the layer's random projection (LowRankFisher) and CPH reference,
    and exposes ``compute_eta`` for use in the TRA forward path.
    """

    def __init__(
        self,
        cph: ConceptPredicateHead,
        d_model: int,
        rank_r: int = 64,
        eps_curvature: float = 0.03,
        delta_norm: float = 1e-6,
        beta_var: float = 0.1,
        seed: int = 13,
    ) -> None:
        super().__init__()
        self.cph = cph
        self.fisher = LowRankFisher(d=d_model, r=rank_r, eps_curvature=eps_curvature, seed=seed)
        self.delta_norm = delta_norm
        self.beta_var = beta_var

    def grad_boundary(self, c: torch.Tensor) -> torch.Tensor:
        """∇_c B_ℓ(c) — exact backward through the CPH (no surrogate).

        Args:
            c: (B, D).
        Returns:
            grad: (B, D) detached gradient.

        Notes:
            We wrap in ``torch.enable_grad()`` because this is invoked from a
            forward hook where the surrounding model may run inside an
            inference-mode context (e.g. when generating, or with KV cache).
            The ``c_grad`` leaf is a fresh tensor with requires_grad=True.
        """
        with torch.enable_grad():
            c_grad = c.detach().clone().to(torch.float32).requires_grad_(True)
            cph_dtype = next(self.cph.parameters()).dtype
            # cast to cph dtype for the energy computation, but keep grad to c_grad
            c_in = c_grad.to(cph_dtype)
            B = boundary_energy(c_in, self.cph, beta_var=self.beta_var).sum()
            grad = torch.autograd.grad(
                B, c_grad, create_graph=False, retain_graph=False, allow_unused=False,
            )[0]
        return grad.detach().to(c.dtype)

    def estimate_fisher(self, sampled_grads: torch.Tensor) -> LowRankFisherEstimate:
        return self.fisher(sampled_grads)

    def compute_eta(
        self,
        c: torch.Tensor,
        sampled_grads: torch.Tensor,
    ) -> tuple[torch.Tensor, LowRankFisherEstimate]:
        """Compute η_ℓ(c) and return the underlying Fisher estimate (for diagnostics).

        Args:
            c: (B, D).
            sampled_grads: (m, D) gradients of log π wrt c (detached).
        Returns:
            eta: (B, D) unit-norm low-curvature negation direction.
            estimate: LowRankFisherEstimate.
        """
        estimate = self.fisher(sampled_grads)
        grad_B = self.grad_boundary(c)                   # (B, D)
        proj = grad_B @ estimate.fisher_proj.transpose(-1, -2)   # (B, r)
        back = proj @ estimate.fisher_proj                # (B, D)
        norm = back.norm(dim=-1, keepdim=True).clamp_min(self.delta_norm)
        eta = back / norm
        return eta, estimate
