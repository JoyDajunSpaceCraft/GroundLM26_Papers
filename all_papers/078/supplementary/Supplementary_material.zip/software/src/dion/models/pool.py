from __future__ import annotations

import torch
import torch.nn as nn


class AttentionPool(nn.Module):
    """Token-level attention pooling.

        a_{l,t} = softmax_t( u_p^T tanh(W_p h_{l,t}) )
        c_l     = sum_t a_{l,t} h_{l,t}

    Returns both the pooled concept state ``c`` and the attention weights ``a``
    (used by TRA to broadcast the residual update back to tokens).
    """

    def __init__(self, d_model: int, d_pool: int = 256) -> None:
        super().__init__()
        self.W_p = nn.Linear(d_model, d_pool, bias=True)
        self.u_p = nn.Linear(d_pool, 1, bias=False)
        nn.init.xavier_uniform_(self.W_p.weight)
        nn.init.zeros_(self.W_p.bias)
        nn.init.xavier_uniform_(self.u_p.weight)

    def forward(
        self,
        hidden: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Args:
            hidden: (B, T, D)
            attention_mask: (B, T) with 1 = valid, 0 = pad.
        Returns:
            c: (B, D) pooled concept state
            a: (B, T) attention weights (sum=1 over T)
        """
        scores = self.u_p(torch.tanh(self.W_p(hidden))).squeeze(-1)  # (B, T)
        if attention_mask is not None:
            scores = scores.masked_fill(attention_mask == 0, float("-inf"))
        a = torch.softmax(scores, dim=-1)  # (B, T)
        c = torch.einsum("bt,btd->bd", a, hidden)  # (B, D)
        return c, a
