"""Triadic Residual Adapter (TRA).

Three branches combined via concept-level gates and broadcast back to tokens
via the same attention weights ``a`` from the AttentionPool.

ZERO-INIT INVARIANT:
    All output projections are zero-initialised so that on initialisation the
    layer output equals the base layer output exactly (the Initialization
    Sanity Property in the paper). The base model is preserved at step 0.
"""

from __future__ import annotations

import torch
import torch.nn as nn


def _zero_linear(in_dim: int, out_dim: int, bias: bool = True) -> nn.Linear:
    layer = nn.Linear(in_dim, out_dim, bias=bias)
    nn.init.zeros_(layer.weight)
    if bias:
        nn.init.zeros_(layer.bias)
    return layer


class TriadicResidualAdapter(nn.Module):
    def __init__(self, d_model: int, rank_a: int = 64, alpha: float = 0.1) -> None:
        super().__init__()
        self.d = d_model
        self.r = rank_a
        self.alpha = alpha

        self.V_d = nn.Linear(d_model, rank_a, bias=True)
        self.U_d = _zero_linear(rank_a, d_model)

        self.V_n = nn.Linear(d_model, rank_a, bias=True)
        self.U_n = _zero_linear(rank_a, d_model)

        self.V_s = nn.Linear(3 * d_model, rank_a, bias=True)
        self.U_s = _zero_linear(rank_a, d_model)

        self.W_gate_d = nn.Linear(2 * d_model, d_model, bias=True)
        self.W_gate_n = nn.Linear(2 * d_model, d_model, bias=True)
        self.W_gate_s = nn.Linear(2 * d_model, d_model, bias=True)

        nn.init.xavier_uniform_(self.V_d.weight); nn.init.zeros_(self.V_d.bias)
        nn.init.xavier_uniform_(self.V_n.weight); nn.init.zeros_(self.V_n.bias)
        nn.init.xavier_uniform_(self.V_s.weight); nn.init.zeros_(self.V_s.bias)
        for layer in (self.W_gate_d, self.W_gate_n, self.W_gate_s):
            nn.init.xavier_uniform_(layer.weight)
            nn.init.zeros_(layer.bias)

        self.act = nn.SiLU()

    def forward(
        self,
        c: torch.Tensor,                   # (B, D)
        eta: torch.Tensor,                 # (B, D)
        attention_weights: torch.Tensor,   # (B, T)
        hidden: torch.Tensor,              # (B, T, D) original layer output
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Return the updated hidden state and the concept-level update ``s_l``."""
        d_branch = self.U_d(self.act(self.V_d(c)))     # (B, D)
        n_branch = self.U_n(self.act(self.V_n(eta)))    # (B, D)

        u = torch.cat([c, eta, c * eta], dim=-1)        # (B, 3D)
        s_branch = self.U_s(self.act(self.V_s(u)))      # (B, D)

        gate_in = torch.cat([c, eta], dim=-1)           # (B, 2D)
        g_d = torch.sigmoid(self.W_gate_d(gate_in))
        g_n = torch.sigmoid(self.W_gate_n(gate_in))
        g_s = torch.sigmoid(self.W_gate_s(gate_in))

        s_ell = g_d * d_branch + g_n * n_branch + g_s * s_branch  # (B, D)

        delta = attention_weights.unsqueeze(-1) * s_ell.unsqueeze(1)   # (B, T, D)
        out = hidden + self.alpha * delta
        return out, s_ell
