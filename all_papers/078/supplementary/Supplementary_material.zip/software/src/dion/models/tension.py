"""Semantic boundary energy B_l(c) and per-layer / multi-layer tension T_l.

    B_l(c) = H_phi(c) / log K        (semantic indeterminacy)
           + beta * Var_{z~q_phi}[s_z(c)]   (predicate boundary competition)

    T_l(c) = ||P_{l,eps} R_l^T grad_c B_l||^2 * H_phi(c) / log K
    T(x)   = sum_l omega_l T_l(c_l(x))
"""

from __future__ import annotations

import math
import torch

from dion.models.cph import ConceptPredicateHead, predicate_entropy


def boundary_energy(
    c: torch.Tensor,
    cph: ConceptPredicateHead,
    beta_var: float = 0.1,
) -> torch.Tensor:
    """Compute B_ℓ(c) per sample, shape (B,).

    Args:
        c: (B, D) concept state.
        cph: shared Concept Predicate Head.
        beta_var: weight for the predicate-variance term.
    """
    logits = cph.logits(c)                    # (B, K)
    q = torch.softmax(logits, dim=-1)         # (B, K)

    H_phi = predicate_entropy(q)              # (B,)
    log_K = math.log(cph.K)
    indeterminacy = H_phi / log_K             # (B,)

    mean = (q * logits).sum(-1, keepdim=True) # (B, 1)
    var = (q * (logits - mean).pow(2)).sum(-1)  # (B,)

    return indeterminacy + beta_var * var


def layer_tension(
    c: torch.Tensor,
    cph: ConceptPredicateHead,
    fisher_proj: torch.Tensor,
    grad_B: torch.Tensor,
    beta_var: float = 0.1,
) -> torch.Tensor:
    """T_ℓ(c) per sample, shape (B,).

    Args:
        c: (B, D)
        cph: Concept Predicate Head.
        fisher_proj: P_{ℓ,ε} R_ℓ^T  shape (R, D).  
            Concretely the projection used in DINOperator: it maps a (D,) vector
            into a low-curvature subspace of dim ≤ R; we then take its Euclidean norm.
        grad_B: (B, D) gradient of B_ℓ wrt c.
        beta_var: same as boundary_energy.
    """
    logits = cph.logits(c)
    q = torch.softmax(logits, dim=-1)
    H_phi = predicate_entropy(q)
    log_K = math.log(cph.K)
    indeterminacy = H_phi / log_K              # (B,)

    proj = grad_B @ fisher_proj.transpose(-1, -2)  # (B, R)
    norm_sq = (proj * proj).sum(-1)            # (B,)
    return norm_sq * indeterminacy
