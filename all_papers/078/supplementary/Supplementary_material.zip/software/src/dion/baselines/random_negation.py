"""Random-negation control baseline.

Replaces the boundary-tension direction with a unit-norm Gaussian random
vector and trains under the same ABO objective as the main DION pipeline.
Used to verify that the gain over Base is not produced by an arbitrary
perturbation direction.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.losses.abo import ABOConfig, abo_loss
from dion.training.data import JsonlDataset, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.baselines.random_negation")


def random_eta(c: torch.Tensor) -> torch.Tensor:
    g = torch.randn_like(c)
    return g / g.norm(dim=-1, keepdim=True).clamp_min(1e-6)


def run(cfg_path: str) -> None:
    cfg = load_yaml(cfg_path)
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "random_negation"
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    model.enable_injection()

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=2,
        collate_fn=lambda rows: text_collate(rows, tok, cfg["train"]["seq_len"]),
    )

    params = [p for n, p in model.named_parameters() if "lora_" in n]
    if not params:
        params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])

    abo_cfg = ABOConfig(
        lambda_preserve=cfg["abo"]["lambda_preserve"],
        lambda_absorb=cfg["abo"]["lambda_absorb"],
        lambda_resolve=cfg["abo"]["lambda_resolve"],
        lambda_concrete=cfg["abo"]["lambda_concrete"],
        margin_T=cfg["abo"]["margin_T"],
        kappa_target=cfg["abo"]["kappa_target"],
    )

    step = 0
    max_steps = cfg["train"].get("random_neg_steps", cfg["train"].get("stage2_steps", 500))
    model.train()
    while step < max_steps:
        for batch in loader:
            batch = {k: v.to(next(model.parameters()).device) for k, v in batch.items()}
            input_ids, attn = batch["input_ids"], batch["attention_mask"]

            out_S = model(input_ids=input_ids, attention_mask=attn, labels=batch["labels"])
            logp_theta = torch.log_softmax(out_S.logits, dim=-1)
            concepts_S = model._aux.get("concepts", {})
            T_S = model.aggregate_tension()
            qs_S = {ell: torch.softmax(model.heads.cph.logits(c), -1) for ell, c in concepts_S.items()}

            model.disable_injection()
            with torch.no_grad():
                out_T = model(input_ids=input_ids, attention_mask=attn, labels=batch["labels"])
            logp_theta0 = torch.log_softmax(out_T.logits, dim=-1)
            model.enable_injection()

            with torch.no_grad():
                _ = model(input_ids=input_ids, attention_mask=attn)
            concepts_T = model._aux.get("concepts", {})
            qs_T = {ell: torch.softmax(model.heads.cph.logits(c), -1) for ell, c in concepts_T.items()}
            T_T = model.aggregate_tension()

            qs_A = {}
            for ell, c in concepts_T.items():
                eta = random_eta(c)
                c_A = c + cfg["din"]["rho_step"] * eta
                qs_A[ell] = torch.softmax(model.heads.cph.logits(c_A), -1)

            response_mask = (batch["attention_mask"] > 0).float()
            losses = []
            for ell in concepts_T:
                comp = abo_loss(
                    logp_theta=logp_theta, logp_theta0=logp_theta0,
                    response_mask=response_mask,
                    q_T=qs_T[ell], q_A=qs_A[ell], q_S=qs_S[ell],
                    tension_T=T_T if T_T is not None else torch.zeros(input_ids.size(0), device=input_ids.device),
                    tension_S=T_S if T_S is not None else torch.zeros(input_ids.size(0), device=input_ids.device),
                    K=cfg["cph"]["K"], cfg=abo_cfg,
                )
                losses.append(comp["loss"])
            loss = torch.stack(losses).mean()

            optim.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            optim.step()

            if step % cfg["train"].get("log_steps", 25) == 0:
                logger.info(f"[random-neg] step {step}/{max_steps} loss={loss.item():.4f}")
            step += 1
            if step >= max_steps:
                break

    torch.save(
        {"lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n}},
        out_dir / "state.pt",
    )
    logger.info(f"Saved Random-Negation state to {out_dir / 'state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    args = ap.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
