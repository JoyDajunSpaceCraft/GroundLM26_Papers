"""Plain SFT-LoRA baseline.

Trains a LoRA adapter on the OntoNeg-WN training set using formatted
(instruction, response) pairs. No TRA, no CPH, no Fisher: a directly
comparable adapter for the headline tables.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.training.data import JsonlDataset, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.baselines.sft_lora")


@dataclass
class SFTConfig:
    epochs: int = 1
    lr: float = 1.0e-4
    batch_size: int = 1
    grad_accum: int = 32
    seq_len: int = 2048


def format_row(row: dict) -> dict:
    target = row["T"]
    rel = row.get("missing_relation", "a property")
    cands = ", ".join(row.get("candidates", []))
    instruction = (
        f"For the concept '{target}', identify the inner negation -- i.e. a same-category "
        f"concept lacking the relation '{rel}'.\nCandidates: {cands}\nAnswer:"
    )
    response = row["A_star"]
    return {"instruction": instruction, "response": response}


def run(cfg_path: str, seed: int | None = None) -> None:
    cfg = load_yaml(cfg_path)
    if seed is not None:
        cfg["seed"] = seed
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "sft_lora"
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    if hasattr(model, "disable_injection"):
        model.disable_injection()

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=2,
        collate_fn=lambda rows: text_collate(
            rows, tok, cfg["train"]["seq_len"], include_gold_response=True,
        ),
    )

    params = [p for n, p in model.named_parameters() if "lora_" in n]
    if not params:
        params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"].get("sft_lr", cfg["train"]["lr"]),
                  weight_decay=cfg["train"]["weight_decay"])

    step = 0
    max_steps = cfg["train"].get("sft_steps", cfg["train"].get("stage2_steps", 500))
    accum = cfg["train"]["grad_accum"]
    model.train()
    optim.zero_grad()
    while step < max_steps:
        for batch in loader:
            batch = {k: v.to(next(model.parameters()).device) for k, v in batch.items()}
            input_ids, attn = batch["input_ids"], batch["attention_mask"]
            labels = batch.get("labels", input_ids.clone())

            out = model(input_ids=input_ids, attention_mask=attn, labels=labels)
            loss = out.loss / accum
            loss.backward()

            if (step + 1) % accum == 0:
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                optim.step()
                optim.zero_grad()

            if step % cfg["train"].get("log_steps", 25) == 0:
                logger.info(f"[sft-lora] step {step}/{max_steps} loss={loss.item()*accum:.4f}")
            step += 1
            if step >= max_steps:
                break

    torch.save(
        {"lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n}},
        out_dir / "state.pt",
    )
    logger.info(f"Saved SFT-LoRA state to {out_dir / 'state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()
    run(args.config, seed=args.seed)


if __name__ == "__main__":
    main()
