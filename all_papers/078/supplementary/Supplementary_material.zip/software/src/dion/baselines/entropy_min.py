"""Entropy-minimisation baseline.

Maximises model confidence by minimising per-token next-token entropy.
The loss is computed over generation / response positions only, never over
prompt tokens. Reward is negative mean entropy; this is distinct from
Intuitor/RLIF self-certainty training.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.training.data import JsonlDataset, onto_neg_prompt, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.baselines.entropy_min")


def entropy_min_loss(logits: torch.Tensor, response_mask: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    probs = torch.softmax(logits, dim=-1).clamp_min(eps)
    H = -(probs * probs.log()).sum(-1)
    denom = response_mask.sum(-1).clamp_min(1.0)
    return ((H * response_mask).sum(-1) / denom).mean()


def _generate_response(model, tok, prompt: str, max_new: int, device) -> str:
    enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to(device)
    with torch.no_grad():
        out = model.base.generate(
            **enc,
            max_new_tokens=max_new,
            do_sample=True,
            temperature=0.7,
            top_p=0.95,
            pad_token_id=tok.pad_token_id,
        )
    return tok.decode(out[0][enc["input_ids"].size(1):], skip_special_tokens=True).strip()


def run(cfg_path: str, seed: int | None = None) -> None:
    cfg = load_yaml(cfg_path)
    if seed is not None:
        cfg["seed"] = seed
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "entropy_min"
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    if hasattr(model, "disable_injection"):
        model.disable_injection()

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=2,
        collate_fn=lambda rows: rows,  # custom packing below
    )

    params = [p for n, p in model.named_parameters() if "lora_" in n]
    if not params:
        params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])

    step = 0
    max_steps = cfg["train"].get("entropy_min_steps", cfg["train"].get("stage2_steps", 500))
    seq_len = cfg["train"]["seq_len"]
    max_new = int(cfg["train"].get("entropy_min_max_new", 16))
    device = next(model.parameters()).device
    model.train()
    while step < max_steps:
        for rows in loader:
            prompts = []
            fulls = []
            prompt_lens = []
            for r in rows:
                p = onto_neg_prompt(r) if ("T" in r and "candidates" in r) else str(r)
                resp = _generate_response(model, tok, p, max_new, device)
                if not resp or not str(resp).strip():
                    raise RuntimeError(
                        "Entropy-Min refused empty model response; "
                        "fail-closed (no gold A_star fallback)"
                    )
                full = p + " " + resp
                prompts.append(p)
                fulls.append(full)

            enc_full = tok(
                fulls, padding=True, truncation=True, max_length=seq_len, return_tensors="pt",
            ).to(device)
            enc_prompt = tok(
                prompts, padding=True, truncation=True, max_length=seq_len, return_tensors="pt",
            )
            prompt_lens = enc_prompt["attention_mask"].sum(-1)

            out = model(input_ids=enc_full["input_ids"], attention_mask=enc_full["attention_mask"])
            logits = out.logits[:, :-1, :]
            attn = enc_full["attention_mask"][:, 1:].float()
            response_mask = torch.zeros_like(attn)
            for i, plen in enumerate(prompt_lens.tolist()):
                start = max(int(plen) - 1, 0)
                response_mask[i, start:] = attn[i, start:]
            # Fail closed: never fall back to full-prompt entropy.
            if float(response_mask.sum()) <= 0:
                raise RuntimeError("Entropy-Min response_mask is empty; refusing prompt-token loss")
            loss = entropy_min_loss(logits, response_mask)

            optim.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            optim.step()

            if step % cfg["train"].get("log_steps", 25) == 0:
                logger.info(f"[entropy-min] step {step}/{max_steps} loss={loss.item():.4f}")
            step += 1
            if step >= max_steps:
                break

    torch.save(
        {"lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n}},
        out_dir / "state.pt",
    )
    logger.info(f"Saved Entropy-Min state to {out_dir / 'state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()
    run(args.config, seed=args.seed)


if __name__ == "__main__":
    main()
