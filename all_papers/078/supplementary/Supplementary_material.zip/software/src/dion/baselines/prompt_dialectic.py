"""Prompt-level reasoning baseline.

Asks the base model to enact a four-step reasoning prompt (state, alternative,
synthesise, choose). Inference-time only -- no training is required. Used as
the prompt-only comparator in the headline tables.

Four prompt variants are supported to verify qualitative robustness of the
diagnostic finding across different wordings.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable

from dion.training.loader import load_dion_model
from dion.utils.io import load_jsonl, load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.baselines.prompt_dialectic")


PROMPT_VARIANTS = {
    "thesis_antithesis": """You will perform an internal critique on the following claim.

Claim: {claim}

Step 1: State the claim plainly.
Step 2: Identify one same-category alternative that lacks one property of the claim.
Step 3: Synthesise a more general concept that includes both.
Step 4: Final answer: which inner negation best fits among {candidates}?

Answer:""",
    "socratic": """Consider the concept '{target}'.

1. What category does it belong to?
2. What property ('{missing}') distinguishes it from its siblings?
3. Which sibling lacks that property?

Choose from: {candidates}
Answer:""",
    "contrastive": """Target concept: {target}
Missing relation: {missing}

Which of these candidates is a same-category concept that LACKS the relation '{missing}'?
Candidates: {candidates}

Respond with exactly one candidate label:""",
    "step_by_step": """We need to find the 'inner negation' of '{target}' with respect to '{missing}'.
An inner negation shares the same category but lacks one key property.

Think step by step, then pick from: {candidates}
Answer:""",
}

PROMPT_TEMPLATE = PROMPT_VARIANTS["thesis_antithesis"]


def prompt_predict(
    *,
    target: str,
    missing: str,
    candidates: list[str],
    generate_fn: Callable[[str], str],
    variant: str = "thesis_antithesis",
) -> str:
    template = PROMPT_VARIANTS.get(variant, PROMPT_TEMPLATE)
    text = generate_fn(template.format(
        claim=f"{target} (which {missing})",
        target=target,
        missing=missing,
        candidates=", ".join(candidates),
    ))
    text_low = text.lower()
    for c in candidates:
        if c.lower() in text_low:
            return c
    return ""


def run(cfg_path: str, variant: str = "thesis_antithesis") -> None:
    cfg = load_yaml(cfg_path)
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / f"prompt_dialectic_{variant}"
    out_dir.mkdir(parents=True, exist_ok=True)

    import torch
    model, tok = load_dion_model(cfg)
    if hasattr(model, "disable_injection"):
        model.disable_injection()
    device = next(model.parameters()).device
    model.eval()

    def generate_fn(prompt: str) -> str:
        enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to(device)
        with torch.no_grad():
            out = model.base.generate(
                **enc, max_new_tokens=64, do_sample=False, pad_token_id=tok.pad_token_id,
            )
        return tok.decode(out[0][enc["input_ids"].size(1):], skip_special_tokens=True)

    test_path = Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_test.jsonl"
    rows = list(load_jsonl(str(test_path)))
    results = []
    correct = 0
    for row in rows:
        pred = prompt_predict(
            target=row["T"],
            missing=row.get("missing_relation", ""),
            candidates=row["candidates"],
            generate_fn=generate_fn,
            variant=variant,
        )
        is_correct = pred == row["A_star"]
        correct += int(is_correct)
        results.append({"id": row["id"], "pred": pred, "gold": row["A_star"], "correct": is_correct})

    acc = correct / len(rows) if rows else 0.0
    logger.info(f"[prompt-dialectic/{variant}] INA={acc:.4f} ({correct}/{len(rows)})")

    out_file = out_dir / "predictions.json"
    out_file.write_text(json.dumps(results, indent=2, ensure_ascii=False))
    logger.info(f"Saved predictions to {out_file}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    ap.add_argument("--variant", default="thesis_antithesis",
                    choices=list(PROMPT_VARIANTS))
    args = ap.parse_args()
    run(args.config, args.variant)


if __name__ == "__main__":
    main()
