"""Baseline implementations for the DION-Bench protocol comparisons."""
