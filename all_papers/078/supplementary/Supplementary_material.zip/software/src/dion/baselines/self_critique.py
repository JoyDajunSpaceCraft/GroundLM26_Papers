"""Self-Critique baseline.

The model produces an initial response, generates a self-critique on that
response, then a revised response conditioned on the critique. The
(initial, revised) pair becomes a preference pair and is fed into a
question-conditioned DPO-style update with a frozen reference and
response-only log-probabilities.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.training.data import JsonlDataset, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.baselines.self_critique")


CRITIQUE_TEMPLATE = (
    "Critique the following response. Identify ONE concrete weakness "
    "in two short sentences.\n\nQuestion: {q}\nResponse: {r}\n\nCritique:"
)
REVISION_TEMPLATE = (
    "Improve the following response in light of the critique.\n\n"
    "Question: {q}\nOriginal response: {r}\nCritique: {c}\n\nImproved response:"
)


@dataclass
class SelfCritiqueConfig:
    beta_dpo: float = 0.1
    max_new_tokens: int = 64


def _response_logp(model, tok, questions: list[str], answers: list[str], seq_len: int, device) -> torch.Tensor:
    """Question-conditioned response-only sequence log-probability."""
    prompts = [f"Question: {q}\nAnswer:" for q in questions]
    full = [p + " " + a for p, a in zip(prompts, answers)]
    enc_full = tok(
        full, return_tensors="pt", padding=True, truncation=True, max_length=seq_len,
    ).to(device)
    enc_prompt = tok(
        prompts, return_tensors="pt", padding=True, truncation=True, max_length=seq_len,
    )
    prompt_lens = enc_prompt["attention_mask"].sum(-1).tolist()

    out = model(input_ids=enc_full["input_ids"], attention_mask=enc_full["attention_mask"])
    logits = out.logits[:, :-1, :]
    targets = enc_full["input_ids"][:, 1:]
    attn = enc_full["attention_mask"][:, 1:].float()
    logp = torch.log_softmax(logits, dim=-1)
    token_lp = torch.gather(logp, -1, targets.unsqueeze(-1)).squeeze(-1)

    scores = []
    for i, plen in enumerate(prompt_lens):
        # tokens after the prompt contribute; index shift by -1 for logits alignment
        start = max(int(plen) - 1, 0)
        scores.append((token_lp[i, start:] * attn[i, start:]).sum())
    return torch.stack(scores)


def _generate(model, tok, prompt: str, max_new: int, sample: bool, device) -> str:
    enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to(device)
    with torch.no_grad():
        out = model.base.generate(
            **enc, max_new_tokens=max_new, do_sample=sample,
            temperature=0.7 if sample else 1.0, top_p=0.95 if sample else 1.0,
            pad_token_id=tok.pad_token_id,
        )
    return tok.decode(out[0][enc["input_ids"].size(1):], skip_special_tokens=True)


def run(cfg_path: str, seed: int | None = None) -> None:
    cfg = load_yaml(cfg_path)
    if seed is not None:
        cfg["seed"] = seed
    set_seed(cfg.get("seed", 42))
    out_dir = Path(cfg["out_dir"]) / "self_critique"
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    if hasattr(model, "disable_injection"):
        model.disable_injection()
    # Frozen reference for DPO-style correction.
    ref_model = deepcopy(model)
    ref_model.eval()
    for p in ref_model.parameters():
        p.requires_grad_(False)

    sc_cfg = SelfCritiqueConfig(max_new_tokens=64)
    device = next(model.parameters()).device
    seq_len = cfg["train"]["seq_len"]

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])
    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=2,
        collate_fn=lambda rows: text_collate(rows, tok, seq_len),
    )

    params = [p for n, p in model.named_parameters() if "lora_" in n]
    if not params:
        params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])

    step = 0
    max_steps = cfg["train"].get("self_critique_steps", 500)
    while step < max_steps:
        for batch in loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            input_ids, attn = batch["input_ids"], batch["attention_mask"]
            B = input_ids.size(0)

            improved_texts: list[str] = []
            original_texts: list[str] = []
            questions: list[str] = []
            for i in range(B):
                q = tok.decode(input_ids[i], skip_special_tokens=True)
                r0 = _generate(model, tok, q, sc_cfg.max_new_tokens, sample=True, device=device)
                crit = _generate(
                    model, tok, CRITIQUE_TEMPLATE.format(q=q, r=r0),
                    max_new=64, sample=False, device=device,
                )
                rev = _generate(
                    model, tok, REVISION_TEMPLATE.format(q=q, r=r0, c=crit),
                    max_new=sc_cfg.max_new_tokens, sample=False, device=device,
                )
                questions.append(q)
                original_texts.append(r0)
                improved_texts.append(rev)

            logp_pos = _response_logp(model, tok, questions, improved_texts, seq_len, device)
            logp_neg = _response_logp(model, tok, questions, original_texts, seq_len, device)
            with torch.no_grad():
                ref_pos = _response_logp(ref_model, tok, questions, improved_texts, seq_len, device)
                ref_neg = _response_logp(ref_model, tok, questions, original_texts, seq_len, device)
            margin = (logp_pos - ref_pos) - (logp_neg - ref_neg)
            loss = -F.logsigmoid(sc_cfg.beta_dpo * margin).mean()

            optim.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            optim.step()

            if step % cfg["train"].get("log_steps", 25) == 0:
                logger.info(f"[self-critique] step {step}/{max_steps} loss={loss.item():.4f}")
            step += 1
            if step >= max_steps:
                break

    torch.save(
        {"lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n}},
        out_dir / "state.pt",
    )
    logger.info(f"Saved Self-Critique state to {out_dir/'state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()
    run(args.config, seed=args.seed)


if __name__ == "__main__":
    main()
