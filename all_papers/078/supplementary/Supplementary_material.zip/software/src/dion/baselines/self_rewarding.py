"""Task-specific self-judged DPO adaptation of Self-Rewarding LM.

Training prompts never contain gold answers. Pairwise updates use a frozen
reference model and response-only log-probabilities.
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.utils.data import DataLoader

from dion.training.data import JsonlDataset, onto_neg_prompt, text_collate
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.baselines.self_rewarding")


JUDGE_PROMPT_VARIANTS = {
    "strict": (
        "Rate the response on a 0-10 scale (10 = strictly correct and concise).\n"
        "Return only the number.\n\nQuestion: {q}\nResponse: {r}\nScore:"
    ),
    "permissive": (
        "On a 0-10 scale, rate how reasonable the response is.\n"
        "Return only the number.\n\nQuestion: {q}\nResponse: {r}\nScore:"
    ),
    "specificity_penalised": (
        "Rate the response on a 0-10 scale, but DO NOT prefer responses just "
        "because they contain more concrete details. Return only the number.\n\n"
        "Question: {q}\nResponse: {r}\nScore:"
    ),
}


@dataclass
class SelfRewardingConfig:
    judge_variant: str = "strict"
    num_candidates: int = 4
    beta_dpo: float = 0.1
    max_new_tokens: int = 64


def parse_score(text: str) -> float:
    m = re.search(r"(?<![A-Za-z])(\d+(?:\.\d+)?)", text)
    if not m:
        return 0.0
    try:
        return float(m.group(0))
    except ValueError:
        return 0.0


def self_judge_score(
    question: str,
    response: str,
    model_call: Callable[[str], str],
    variant: str = "strict",
) -> float:
    prompt = JUDGE_PROMPT_VARIANTS[variant].format(q=question, r=response)
    return parse_score(model_call(prompt))


def _response_logp(model, prompt_ids, prompt_attn, resp_ids, pad_id: int) -> torch.Tensor:
    """Log-probability of response tokens only under ``model``."""
    # Concatenate prompt + response
    full = torch.cat([prompt_ids, resp_ids], dim=-1)
    attn = torch.cat([
        prompt_attn,
        (resp_ids != pad_id).long(),
    ], dim=-1)
    out = model(input_ids=full, attention_mask=attn)
    logits = out.logits[:, :-1, :]
    targets = full[:, 1:]
    logp = torch.log_softmax(logits, dim=-1)
    tok_lp = torch.gather(logp, -1, targets.unsqueeze(-1)).squeeze(-1)
    # Mask: only positions corresponding to response (after prompt)
    plen = prompt_ids.size(1)
    resp_mask = torch.zeros_like(tok_lp)
    # targets index i corresponds to full[:, i+1]; response starts at plen
    if plen < full.size(1):
        resp_mask[:, plen - 1:] = (full[:, plen:] != pad_id).float()
        # align: tok_lp length is full_len-1; response tokens are indices [plen-1 ..]
    return (tok_lp * resp_mask).sum(-1)


def run(
    cfg_path: str,
    judge_variant: str = "strict",
    seed: int | None = None,
    shuffle_preferences: bool = False,
) -> None:
    cfg = load_yaml(cfg_path)
    set_seed(seed if seed is not None else cfg.get("seed", 42))
    tag = f"self_rewarding_{judge_variant}"
    if shuffle_preferences:
        tag = "shuffled_dpo"
    out_dir = Path(cfg["out_dir"]) / tag
    out_dir.mkdir(parents=True, exist_ok=True)

    model, tok = load_dion_model(cfg)
    if hasattr(model, "disable_injection"):
        model.disable_injection()
    # Frozen reference for DPO (LoRA snapshot at init; avoids full model deepcopy OOM)
    ref_lora = {
        n: p.detach().clone()
        for n, p in model.named_parameters() if "lora_" in n
    }

    sr_cfg = SelfRewardingConfig(judge_variant=judge_variant)

    ds = JsonlDataset([Path(cfg["bench"]["output_dir"]) / "onto_neg_wn_train.jsonl"])

    def _collate(rows):
        batch = text_collate(rows, tok, cfg["train"]["seq_len"], include_gold_response=False)
        batch["_prompt_strs"] = [onto_neg_prompt(r) for r in rows]
        return batch

    loader = DataLoader(
        ds, batch_size=cfg["train"]["per_device_batch"], shuffle=True, num_workers=0,
        collate_fn=_collate,
    )

    params = [p for n, p in model.named_parameters() if "lora_" in n]
    if not params:
        logger.warning("No LoRA parameters found; defaulting to all trainable.")
        params = [p for p in model.parameters() if p.requires_grad]
    optim = AdamW(params, lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])

    device = next(model.parameters()).device

    def model_call(prompt: str) -> str:
        enc = tok(prompt, return_tensors="pt", truncation=True, max_length=512).to(device)
        with torch.no_grad():
            out = model.base.generate(
                **enc, max_new_tokens=8, do_sample=False, pad_token_id=tok.pad_token_id,
            )
        return tok.decode(out[0][enc["input_ids"].size(1):], skip_special_tokens=True)

    step = 0
    max_steps = cfg["train"].get("self_rewarding_steps", cfg["train"].get("stage2_steps", 500))
    while step < max_steps:
        for batch in loader:
            prompts = batch.pop("_prompt_strs")
            input_ids = batch["input_ids"].to(device)
            attn = batch["attention_mask"].to(device)
            # Re-tokenize prompts without padding noise for generation
            enc = tok(
                prompts, padding=True, truncation=True,
                max_length=cfg["train"]["seq_len"], return_tensors="pt",
            )
            input_ids = enc["input_ids"].to(device)
            attn = enc["attention_mask"].to(device)
            with torch.no_grad():
                gens = model.base.generate(
                    input_ids=input_ids, attention_mask=attn,
                    do_sample=True, num_return_sequences=sr_cfg.num_candidates,
                    max_new_tokens=sr_cfg.max_new_tokens,
                    temperature=0.9, top_p=0.95, pad_token_id=tok.pad_token_id,
                )
            B = input_ids.shape[0]
            G = sr_cfg.num_candidates
            # gens includes prompt; slice response-only ids
            prompt_len = input_ids.size(1)
            gens = gens.view(B, G, -1)
            resp = gens[:, :, prompt_len:]

            scores = torch.zeros(B, G)
            for i in range(B):
                q = prompts[i]
                for g in range(G):
                    r = tok.decode(resp[i, g], skip_special_tokens=True)
                    scores[i, g] = self_judge_score(q, r, model_call, variant=sr_cfg.judge_variant)
            best = scores.argmax(-1)
            worst = scores.argmin(-1)
            if shuffle_preferences and G > 1:
                # Break judge ranking: random preferred/rejected pairs at same budget.
                best = torch.empty(B, dtype=torch.long)
                worst = torch.empty(B, dtype=torch.long)
                for i in range(B):
                    pair = torch.randperm(G)[:2]
                    best[i], worst[i] = int(pair[0]), int(pair[1])

            def _with_ref_lora(fn):
                saved = {}
                for n, p in model.named_parameters():
                    if n in ref_lora:
                        saved[n] = p.data
                        p.data = ref_lora[n].to(p.device, dtype=p.dtype)
                try:
                    return fn()
                finally:
                    for n, p in model.named_parameters():
                        if n in saved:
                            p.data = saved[n]

            losses = []
            for i in range(B):
                pos = resp[i, best[i]].unsqueeze(0)
                neg = resp[i, worst[i]].unsqueeze(0)
                pid = input_ids[i:i+1]
                pa = attn[i:i+1]
                lp_pos = _response_logp(model, pid, pa, pos, tok.pad_token_id)
                lp_neg = _response_logp(model, pid, pa, neg, tok.pad_token_id)
                with torch.no_grad():
                    ref_pos, ref_neg = _with_ref_lora(lambda: (
                        _response_logp(model, pid, pa, pos, tok.pad_token_id),
                        _response_logp(model, pid, pa, neg, tok.pad_token_id),
                    ))
                margin = (lp_pos - ref_pos) - (lp_neg - ref_neg)
                losses.append(-F.logsigmoid(sr_cfg.beta_dpo * margin))
            loss = torch.stack(losses).mean()

            optim.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            optim.step()

            if step % cfg["train"].get("log_steps", 25) == 0:
                label = "shuffled-dpo" if shuffle_preferences else f"self-rewarding/{judge_variant}"
                logger.info(f"[{label}] step {step}/{max_steps} loss={loss.item():.4f}")
            step += 1
            if step >= max_steps:
                break

    torch.save(
        {"lora": {n: p.detach().cpu() for n, p in model.named_parameters() if "lora_" in n}},
        out_dir / "state.pt",
    )
    logger.info(f"Saved Self-Rewarding state to {out_dir/'state.pt'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_main.yaml")
    ap.add_argument("--judge_variant", default="strict",
                    choices=list(JUDGE_PROMPT_VARIANTS))
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument(
        "--shuffle_preferences", action="store_true",
        help="Preference-shuffled DPO control: ignore judge ranking when forming pairs",
    )
    args = ap.parse_args()
    run(
        args.config, args.judge_variant, seed=args.seed,
        shuffle_preferences=args.shuffle_preferences,
    )


if __name__ == "__main__":
    main()
