"""Locate the benchmark and audit sheets in either layout.

In the development repository the locked splits live under ``data/bench/`` and
the human-audit sheets under ``audit/``. The anonymous release ships them as a
separate archive whose top level is ``data/``, so an unpacked release has the
sheets at ``data/audit/``. Every script resolves them through this module so the
same command works in both layouts.
"""

from __future__ import annotations

from pathlib import Path

_BENCH_CANDIDATES = ("data/bench", "bench")
_AUDIT_CANDIDATES = ("audit", "data/audit")


def _first_dir(root: Path, candidates: tuple[str, ...], what: str) -> Path:
    for name in candidates:
        path = root / name
        if path.is_dir():
            return path
    raise SystemExit(
        f"[paths] cannot find the {what} directory under {root}; expected one of "
        f"{', '.join(candidates)}")


def bench_dir(root: Path) -> Path:
    return _first_dir(root, _BENCH_CANDIDATES, "benchmark")


def audit_dir(root: Path) -> Path:
    return _first_dir(root, _AUDIT_CANDIDATES, "audit")
