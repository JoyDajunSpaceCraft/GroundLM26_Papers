"""Generation utilities used at inference time."""

from __future__ import annotations

import torch


@torch.no_grad()
def generate_text(model, tok, prompt: str, device, **kw) -> str:
    enc = tok(prompt, return_tensors="pt", truncation=True, max_length=2048).to(device)
    gen_kw = {
        "max_new_tokens": kw.get("max_new_tokens", 256),
        "do_sample": kw.get("do_sample", False),
        "pad_token_id": tok.pad_token_id or tok.eos_token_id,
    }
    if gen_kw["do_sample"]:
        gen_kw["temperature"] = kw.get("temperature", 0.7)
        gen_kw["top_p"] = kw.get("top_p", 0.9)
    out = (model.base.generate(**enc, **gen_kw)
           if hasattr(model, "base") else model.generate(**enc, **gen_kw))
    text = tok.decode(out[0][enc["input_ids"].size(1):], skip_special_tokens=True)
    return text
