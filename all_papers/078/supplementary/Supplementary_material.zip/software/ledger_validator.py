"""Result-ledger validator: recompute every reported number from raw artifacts.

The validator never trusts a precomputed field. For each ledger row derived from
per-item predictions it

1. loads the benchmark split and rebuilds the gold answer set from it -- gold is
   read from the benchmark and nowhere else, and a prediction file that carries
   any ``gold``-prefixed key is rejected outright,
2. re-parses each prediction from the shipped ``raw_output`` field using the
   released parser, after checking that the parser version recorded in the file
   matches the parser being run,
3. re-scores every item, re-derives the pooled mean, the across-run standard
   deviation and the two-way hierarchical bootstrap interval, and
4. compares against the ledger at ``--tol`` (1e-6 by default); interval endpoints
   are redrawn with an independent seed and therefore compared at ``--ci-tol``.

Any missing file, unparsable line, unknown metric, absent per-item field or
unreferenced prediction file is a failure, so an incomplete release cannot pass
by omission. Parse-rule and fallback counts are written to
``outputs/stats/parse_report.json``. Rows marked ``source=external_harness`` are
scored by their own harness and are checked for schema and provenance only; they
are reported separately rather than silently skipped.

Usage::

    python ledger_validator.py                      # strict, exits non-zero on drift
    python ledger_validator.py --bootstrap-reps 0   # skip interval recomputation
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from dion.evaluation.output_parser import (  # noqa: E402
    PARSER_VERSION,
    parse_abstraction,
    parse_candidate_choice,
    parse_mus,
    parse_repaired_kb,
)

ITEM_SOURCE = "per_item_predictions"
EXTERNAL_SOURCE = "external_harness"
TASK_OF_METRIC = {
    "INA": "onto_neg_wn", "OER": "onto_neg_wn", "AbsAcc": "concept_shift",
    "MUS-P": "logic_repair", "MUS-F1": "logic_repair",
    "MUS-R": "logic_repair", "Kprime-Exact": "logic_repair",
}
REQUIRED_FIELDS = {
    "onto_neg_wn": ("id", "seed", "raw_output", "cluster", "parser_version"),
    "concept_shift": ("id", "seed", "raw_output", "cluster", "parser_version"),
    "logic_repair": ("id", "seed", "raw_output", "cluster", "parser_version"),
}


class ValidationError(RuntimeError):
    pass


def load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        raise ValidationError(f"missing required file: {path}")
    rows = []
    for lineno, line in enumerate(path.open(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ValidationError(f"{path}:{lineno}: unparsable JSON ({exc})") from exc
    if not rows:
        raise ValidationError(f"empty artifact: {path}")
    return rows


def sample_sd(values: list[float]) -> float:
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    return math.sqrt(sum((v - mean) ** 2 for v in values) / (n - 1))


def set_prf(pred, gold) -> tuple[float, float, float]:
    p, g = {str(x) for x in (pred or [])}, {str(x) for x in (gold or [])}
    if not p and not g:
        return 1.0, 1.0, 1.0
    if not p or not g:
        return 0.0, 0.0, 0.0
    inter = len(p & g)
    prec, rec = inter / len(p), inter / len(g)
    f1 = 0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)
    return prec, rec, f1


class Gold:
    """Gold answers rebuilt from the benchmark splits, keyed by (task, split, id)."""

    def __init__(self, bench_dir: Path) -> None:
        self.bench_dir = bench_dir
        self._cache: dict[tuple[str, str], dict[str, dict]] = {}
        self.parse_rules: Counter[str] = Counter()

    def split(self, task: str, split: str) -> dict[str, dict]:
        key = (task, split)
        if key not in self._cache:
            rows = load_jsonl(self.bench_dir / f"{task}_{split}.jsonl")
            self._cache[key] = {r["id"]: r for r in rows}
        return self._cache[key]

    def score(self, item: dict) -> dict[str, float]:
        task, split = item["task"], item.get("split", "test")
        row = self.split(task, split).get(item["id"])
        if row is None:
            raise ValidationError(
                f"prediction for unknown item {item['id']!r} in {task}/{split}")
        for field in REQUIRED_FIELDS[task]:
            if field not in item:
                raise ValidationError(f"item {item['id']!r} missing field {field!r}")
        if item["parser_version"] != PARSER_VERSION:
            raise ValidationError(
                f"item {item['id']!r} was parsed by {item['parser_version']!r} but the "
                f"validator runs {PARSER_VERSION!r}")
        leaked = sorted(k for k in item if k.startswith("gold"))
        if leaked:
            raise ValidationError(
                f"item {item['id']!r} carries gold field(s) {leaked}; gold may come only "
                "from the benchmark file")
        if str(item["cluster"]) != str(row.get("S_id", row["id"])):
            raise ValidationError(
                f"item {item['id']!r} cluster does not match the benchmark row")

        raw = item["raw_output"]
        if task == "onto_neg_wn":
            parsed = parse_candidate_choice(raw, list(row["candidates"]))
            self.parse_rules[f"{task}:{parsed.rule}"] += 1
            pred = str(parsed.value)
            if not pred:
                raise ValidationError(
                    f"item {item['id']!r}: no candidate recoverable from raw_output")
            return {"INA": float(pred == row["A_star"]), "OER": float(pred == row["E"])}
        if task == "concept_shift":
            parsed = parse_abstraction(raw)
            self.parse_rules[f"{task}:{parsed.rule}"] += 1
            golds = {str(row["S"]).lower()} | {
                str(a).lower() for a in (row.get("S_alternatives") or [])}
            return {"AbsAcc": float(str(parsed.value).lower() in golds)}
        parsed = parse_mus(raw)
        self.parse_rules[f"{task}:{parsed.rule}"] += 1
        prec, rec, f1 = set_prf(parsed.value, row["MUS"])
        k_parsed = parse_repaired_kb(raw)
        self.parse_rules[f"{task}:kprime:{k_parsed.rule}"] += 1
        pred_k = {str(x) for x in k_parsed.value}
        gold_k = {str(x) for x in (row.get("K_prime") or [])}
        return {
            "MUS-P": prec, "MUS-R": rec, "MUS-F1": f1,
            "Kprime-Exact": float(bool(pred_k) and pred_k == gold_k),
        }


def recompute_config(path: Path, gold: Gold) -> dict[str, dict]:
    per_seed: dict[str, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))
    per_cluster: dict[str, dict[int, dict[str, list[float]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list)))
    for item in load_jsonl(path):
        if item["task"] not in REQUIRED_FIELDS:
            raise ValidationError(f"unknown task {item['task']!r} in {path}")
        for metric, value in gold.score(item).items():
            seed = int(item["seed"])
            per_seed[metric][seed].append(value)
            per_cluster[metric][seed][str(item["cluster"])].append(value)
    out: dict[str, dict] = {}
    for metric, seeds in per_seed.items():
        counts = {len(v) for v in seeds.values()}
        if len(counts) != 1:
            raise ValidationError(f"{path}: ragged item counts for {metric}: {counts}")
        seed_means = [sum(v) / len(v) for _s, v in sorted(seeds.items())]
        order = sorted(seeds)
        units = sorted({u for c in per_cluster[metric].values() for u in c})
        col = {u: j for j, u in enumerate(units)}
        sums = np.zeros((len(order), len(units)))
        sizes = np.zeros((len(order), len(units)))
        for si, seed in enumerate(order):
            for unit, values in per_cluster[metric][seed].items():
                sums[si, col[unit]] += sum(values)
                sizes[si, col[unit]] += len(values)
        if not sizes.all():
            raise ValidationError(
                f"{path}: {metric} does not cover every resampling unit in every run")
        out[metric] = {
            "mean": sum(seed_means) / len(seed_means),
            "sd": sample_sd(seed_means),
            "n": counts.pop(),
            "seeds": len(seeds),
            "sums": sums,
            "sizes": sizes,
        }
    return out


def stable_seed(*parts: str) -> int:
    """A bootstrap seed that does not depend on the interpreter's hash salt."""
    raw = hashlib.blake2b("::".join(parts).encode(), digest_size=8).digest()
    return int.from_bytes(raw, "big") % (1 << 30)


def bootstrap_ci(
    sums: np.ndarray, sizes: np.ndarray, reps: int, seed: int,
) -> tuple[float, float]:
    """Two-way interval for a crossed runs-by-units design.

    Every run scores the same items, so unit resampling is drawn once per
    replicate and applied to all runs; drawing it independently per run would let
    item noise average out over runs and understate the interval. Runs are then
    resampled on top whenever the row aggregates more than one run.
    """
    rng = np.random.default_rng(seed)
    n_runs, n_units = sums.shape
    picks = rng.integers(0, n_units, size=(reps, n_units))
    runs = (rng.integers(0, n_runs, size=(reps, n_runs)) if n_runs > 1 else None)
    draws = np.empty(reps)
    for rep in range(reps):
        take = picks[rep]
        per_run = sums[:, take].sum(axis=1) / sizes[:, take].sum(axis=1)
        draws[rep] = per_run[runs[rep]].mean() if runs is not None else per_run.mean()
    lo, hi = np.quantile(draws, [0.025, 0.975])
    return float(lo), float(hi)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ledger", default="result_ledger.csv")
    ap.add_argument("--predictions", default="outputs/predictions")
    ap.add_argument("--bench", default="data/bench")
    ap.add_argument("--tol", type=float, default=1e-6)
    ap.add_argument("--ci-tol", type=float, default=0.01,
                    help="Tolerance for the resampled interval endpoints: the "
                         "validator redraws them with its own seed, so the two "
                         "estimates differ by Monte-Carlo noise alone.")
    ap.add_argument("--bootstrap-reps", type=int, default=4000)
    ap.add_argument("--parse-report", default="outputs/stats/parse_report.json")
    ap.add_argument("--no-strict", action="store_true")
    args = ap.parse_args()

    ledger_path = Path(args.ledger)
    pred_dir = Path(args.predictions)
    gold = Gold(Path(args.bench))
    if not ledger_path.exists():
        print(f"[ledger] missing {ledger_path}")
        return 1
    if not pred_dir.is_dir():
        print(f"[ledger] missing prediction directory {pred_dir}")
        return 1

    with ledger_path.open() as f:
        rows = list(csv.DictReader(f))
    if not rows:
        print("[ledger] empty ledger")
        return 1
    required_cols = {"metric", "value", "split", "n", "seeds", "config", "headline",
                     "seed_sd", "ci95_low", "ci95_high", "source"}
    missing_cols = required_cols - set(rows[0])
    if missing_cols:
        print(f"[ledger] ledger schema missing columns: {sorted(missing_cols)}")
        return 1

    cache: dict[tuple[str, str], dict[str, dict]] = {}
    used_files: set[Path] = set()
    failures: list[str] = []
    checked = external = 0

    print(f"{'metric':<16}{'config':<24}{'split':<6}"
          f"{'ledger':>11}{'recomputed':>12}{'sd':>10}{'sd(rec)':>10}  status")
    print("-" * 100)
    for row in rows:
        metric, cfg, split = row["metric"], row["config"], row["split"]
        source = row["source"]
        if source == EXTERNAL_SOURCE:
            external += 1
            if not row["n"] or not row["value"]:
                failures.append(f"{metric}/{cfg}: external row lacks n or value")
            continue
        if source != ITEM_SOURCE:
            failures.append(f"{metric}/{cfg}: unknown source {source!r}")
            continue
        if metric not in TASK_OF_METRIC:
            failures.append(f"{metric}/{cfg}: metric not derivable from predictions")
            continue

        path = pred_dir / (f"{cfg}_items.jsonl" if split == "test"
                           else f"{cfg}_items_{split}.jsonl")
        key = (cfg, split)
        if key not in cache:
            try:
                cache[key] = recompute_config(path, gold)
            except ValidationError as exc:
                failures.append(str(exc))
                cache[key] = {}
        used_files.add(path)
        got = cache[key].get(metric)
        if got is None:
            print(f"{metric:<16}{cfg:<24}{split:<6}{'':>11}{'(missing)':>12}"
                  f"{'':>10}{'':>10}  MISSING")
            failures.append(f"{metric}/{cfg}/{split}: not recomputable from {path.name}")
            continue

        checked += 1
        problems = []
        val = float(row["value"])
        if abs(got["mean"] - val) > args.tol:
            problems.append(f"mean off by {abs(got['mean'] - val):.2e}")
        if row["seed_sd"]:
            if abs(got["sd"] - float(row["seed_sd"])) > args.tol:
                problems.append(f"sd off by {abs(got['sd'] - float(row['seed_sd'])):.2e}")
        elif got["seeds"] > 1:
            problems.append("multi-run row records no dispersion")
        if int(row["n"]) != got["n"]:
            problems.append(f"n {row['n']} != {got['n']}")
        if int(row["seeds"]) != got["seeds"]:
            problems.append(f"seeds {row['seeds']} != {got['seeds']}")
        if args.bootstrap_reps and row["ci95_low"]:
            lo, hi = bootstrap_ci(got["sums"], got["sizes"], args.bootstrap_reps,
                                  seed=stable_seed("validator", cfg, metric, split))
            for name, rec, claim in (("ci_low", lo, float(row["ci95_low"])),
                                     ("ci_high", hi, float(row["ci95_high"]))):
                if abs(rec - claim) > args.ci_tol:
                    problems.append(f"{name} {claim:.4f} vs {rec:.4f}")
            if not (float(row["ci95_low"]) <= got["mean"] <= float(row["ci95_high"])):
                problems.append("interval excludes the point estimate")

        status = "OK" if not problems else "MISMATCH"
        print(f"{metric:<16}{cfg:<24}{split:<6}{val:>11.6f}{got['mean']:>12.6f}"
              f"{row['seed_sd'] or '-':>10}{got['sd']:>10.6f}  {status}")
        if problems:
            failures.append(f"{metric}/{cfg}/{split}: " + "; ".join(problems))

    shipped = {p for p in pred_dir.glob("*_items*.jsonl")}
    orphans = sorted(p.name for p in shipped - used_files)
    if orphans:
        failures.append(f"prediction files not referenced by any ledger row: {orphans}")

    total_parsed = sum(gold.parse_rules.values())
    fallbacks = {k: v for k, v in gold.parse_rules.items() if ":fallback" in k}
    report = {
        "parser_version": PARSER_VERSION,
        "items_parsed": total_parsed,
        "rules": dict(sorted(gold.parse_rules.items())),
        "fallback_rules": dict(sorted(fallbacks.items())),
        "fallback_rate": (sum(fallbacks.values()) / total_parsed) if total_parsed else 0.0,
    }
    report_path = Path(args.parse_report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=1) + "\n")

    print("-" * 100)
    print(f"[ledger] {total_parsed} predictions re-parsed from raw_output with "
          f"{PARSER_VERSION}, fallback rate {report['fallback_rate']:.4%} "
          f"-> {report_path}")
    print(f"[ledger] {checked} item-derived rows recomputed, "
          f"{external} external-harness rows checked for provenance, "
          f"{len(failures)} problems")
    for f in failures:
        print(f"  - {f}")
    if failures:
        return 0 if args.no_strict else 1
    print("[ledger] all rows reproduce from shipped predictions.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
