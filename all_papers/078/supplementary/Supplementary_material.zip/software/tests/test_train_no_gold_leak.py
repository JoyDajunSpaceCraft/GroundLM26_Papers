"""Training prompts must not contain gold answers by default."""

from __future__ import annotations

from dion.training.data import onto_neg_prompt, text_collate


class _DummyTok:
    pad_token_id = 0

    def __call__(self, texts, padding=None, truncation=None, max_length=None,
                 return_tensors=None):
        import torch
        ids = []
        for t in texts:
            ids.append([1] * min(8, max(1, len(t) // 10)) + [0] * 2)
        maxlen = max(len(x) for x in ids)
        input_ids = torch.tensor([x + [0] * (maxlen - len(x)) for x in ids])
        attn = (input_ids != 0).long()
        return {"input_ids": input_ids, "attention_mask": attn}


def _row(gold: str = "kiwi") -> dict:
    """A row in the shipped OntoNeg-WN schema."""
    return {
        "T": "bird",
        "S": "animal",
        "A_star": gold,
        "candidates": ["dog", "wolf", "car", gold],
        "missing_relation": "HasA",
        "attribute_object_label": "feather",
        "attribute_phrase": "has feather",
        "attribute_negation_phrase": "does not have feather",
    }


def test_onto_neg_prompt_excludes_gold():
    prompt = onto_neg_prompt(_row())
    assert "Answer:" in prompt
    assert "has feather" in prompt
    # The candidate list may name the gold, but nothing may follow the cue.
    assert prompt.split("Answer:", 1)[1].strip() == ""


def test_collate_default_masks_all_labels():
    import torch

    batch = text_collate([_row("SECRET_GOLD")], _DummyTok(), seq_len=16,
                         include_gold_response=False)
    assert torch.all(batch["labels"] == -100)


def test_collate_supervises_only_the_response_span():
    import torch

    batch = text_collate([_row()], _DummyTok(), seq_len=16,
                         include_gold_response=True)
    labels = batch["labels"]
    assert torch.any(labels != -100), "SFT must supervise the response span"
    assert torch.any(labels == -100), "prompt tokens stay masked"
