"""CSD must never consult gold fields when building or ranking candidates."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _load_csd():
    spec = importlib.util.spec_from_file_location(
        "run_csd_intervention", ROOT / "scripts" / "run_csd_intervention.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def test_csd_rejects_gold_fields_on_parent():
    mod = _load_csd()
    item = {
        "id": "x", "task": "concept_shift", "split": "test", "seed": 42,
        "raw_output": "animal", "cluster": "c", "logprob": -1.0,
        "beam_candidates": ["cat", "animal"],
        "prompt_target": "Siamese", "prompt_context": "Manx Antonym",
        "S": "SHOULD_NOT_BE_READ",
    }
    with pytest.raises(ValueError, match="forbidden gold"):
        mod._beam_from_parent(item)


def test_csd_uses_parent_beam_only(tmp_path: Path):
    mod = _load_csd()
    parent = tmp_path / "parent.jsonl"
    out = tmp_path / "out.jsonl"
    rows = [
        {
            "config": "demo", "task": "concept_shift", "split": "test",
            "id": "cs1", "seed": 42, "checkpoint": "final",
            "raw_output": "siamese cat", "prediction": "siamese cat",
            "cluster": "c1", "parser_version": "dion-parser-1.1.0",
            "logprob": -1.2,
            "prompt_target": "Siamese",
            "prompt_context": "Manx Antonym",
            "beam_candidates": ["siamese cat", "Siamese", "Manx", "feline"],
        },
        {
            "config": "demo", "task": "logic_repair", "split": "test",
            "id": "lr1", "seed": 42, "checkpoint": "final",
            "raw_output": "MUS:\nA\nRepaired KB:\nB",
            "prediction_mus": ["A"], "prediction_k_prime": ["B"],
            "cluster": "lr1", "parser_version": "dion-parser-1.1.0",
            "logprob": -0.8,
        },
    ]
    parent.write_text("\n".join(json.dumps(r) for r in rows) + "\n")
    assert mod.main(["--parent", str(parent), "--out", str(out),
                     "--config-name", "demo_csd"]) == 0
    written = [json.loads(l) for l in out.read_text().splitlines() if l.strip()]
    assert len(written) == 2
    cs = written[0]
    assert cs["parse_rule"] == "csd_rerank"
    assert cs["logprob"] == -1.2  # copied from parent
    assert "csd_trace" in cs
    assert cs["csd_trace"]["candidates"] == [
        "siamese cat", "Siamese", "Manx", "feline"]
    assert "S" not in cs and "S_alternatives" not in cs
    assert written[1]["csd_trace"]["inherited"] is True


def test_csd_materialises_generator(tmp_path: Path, monkeypatch):
    """Regression: exhausting the jsonl generator must not yield 0 items."""
    mod = _load_csd()
    parent = tmp_path / "parent.jsonl"
    out = tmp_path / "out.jsonl"
    parent.write_text(json.dumps({
        "config": "demo", "task": "logic_repair", "split": "test",
        "id": "lr1", "seed": 1, "checkpoint": "final",
        "raw_output": "MUS:\nA\nRepaired KB:\nB",
        "prediction_mus": ["A"], "prediction_k_prime": ["B"],
        "cluster": "lr1", "parser_version": "dion-parser-1.1.0",
        "logprob": -0.5,
    }) + "\n")
    assert mod.main(["--parent", str(parent), "--out", str(out)]) == 0
    assert sum(1 for _ in out.open()) == 1
