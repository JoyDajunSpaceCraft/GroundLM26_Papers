"""Run-aware uncertainty, margin justification and multilevel mediation tests."""

from __future__ import annotations

import statistics

import numpy as np
import pytest

from dion.evaluation.mediation import fit_random_intercept_ols, multilevel_mediation
from dion.evaluation.stats import (
    audit_decision,
    equivalence_margin_justification,
    two_way_hierarchical_bootstrap,
    two_way_tost,
)

RUN_MEANS = [2.0, 2.4, 1.8, 2.2]


def _diff_by_run(run_means: list[float], n_items: int = 100, spread: float = 0.3) -> dict[str, list[float]]:
    """Items sit symmetrically around each run mean, so run means are exact."""
    half = n_items // 2
    return {
        f"run{i}": [mean - spread] * half + [mean + spread] * half
        for i, mean in enumerate(run_means)
    }


def _cluster_by_run(diff_by_run: dict[str, list[float]], cluster_size: int = 10) -> dict[str, list[str]]:
    return {
        run: [f"c{i // cluster_size}" for i in range(len(diffs))]
        for run, diffs in diff_by_run.items()
    }


def test_two_way_bootstrap_recovers_mean_and_seed_spread() -> None:
    res = two_way_hierarchical_bootstrap(_diff_by_run(RUN_MEANS), n_boot=400, seed=0)

    grand_mean = float(np.mean(RUN_MEANS))
    assert res["mean"] == pytest.approx(grand_mean)
    assert res["lo"] <= grand_mean <= res["hi"]
    assert res["n_runs"] == 4
    assert res["n_items"] == 400
    assert res["run_means"] == pytest.approx(sorted(RUN_MEANS))
    assert res["seed_sd"] == pytest.approx(statistics.stdev(RUN_MEANS))
    assert res["resampling"] == "run+item"


def test_two_way_bootstrap_is_deterministic_and_cluster_aware() -> None:
    diffs = _diff_by_run(RUN_MEANS)
    first = two_way_hierarchical_bootstrap(diffs, n_boot=200, seed=7)
    second = two_way_hierarchical_bootstrap(diffs, n_boot=200, seed=7)
    assert (first["lo"], first["hi"]) == (second["lo"], second["hi"])

    clustered = two_way_hierarchical_bootstrap(
        diffs, cluster_by_run=_cluster_by_run(diffs), n_boot=200, seed=7
    )
    assert clustered["resampling"] == "run+cluster"
    assert clustered["mean"] == pytest.approx(first["mean"])
    assert clustered["lo"] <= clustered["mean"] <= clustered["hi"]


def test_two_way_bootstrap_rejects_misaligned_clusters() -> None:
    diffs = _diff_by_run([0.0], n_items=10)
    with pytest.raises(ValueError):
        two_way_hierarchical_bootstrap(diffs, cluster_by_run={"run0": ["c0"] * 9}, n_boot=10)


def test_two_way_bootstrap_handles_empty_input() -> None:
    res = two_way_hierarchical_bootstrap({}, n_boot=50)
    assert res["n_runs"] == 0 and res["n_items"] == 0
    assert res["mean"] == 0.0 and res["lo"] == 0.0 and res["hi"] == 0.0
    assert res["seed_sd"] == 0.0
    assert res["run_means"] == []


def test_two_way_tost_equivalent_when_runs_agree_near_zero() -> None:
    diffs = _diff_by_run([0.0, 0.05, -0.04], n_items=60, spread=0.1)
    res = two_way_tost(diffs, margin=1.0, n_boot=400, seed=1)
    assert res["equivalent"] is True
    assert -1.0 < res["lo"] <= res["hi"] < 1.0
    assert res["margin"] == 1.0
    assert res["n_runs"] == 3
    assert res["resampling"] == "run+item"
    assert res["seed_sd"] == pytest.approx(statistics.stdev([0.0, 0.05, -0.04]))
    assert "pass" not in res


def test_two_way_tost_not_equivalent_beyond_margin() -> None:
    diffs = _diff_by_run([-2.1, -1.9, -2.0], n_items=60, spread=0.1)
    res = two_way_tost(diffs, margin=1.0, n_boot=400, seed=1)
    assert res["equivalent"] is False
    assert res["hi"] < -1.0


def _audit_inputs() -> tuple[dict[str, float], dict[str, dict[str, object]], dict[str, dict[str, float]]]:
    target = {"mean": 3.2, "lo": 1.4, "hi": 5.0}
    complementary = {
        "OntoNeg": {"mean": 0.1, "lo": -0.35, "hi": 0.55, "equivalent": True},
        "LogicRepair": {"mean": -0.2, "lo": -0.60, "hi": 0.20, "equivalent": True},
    }
    retention = {"MMLU": {"mean": -0.1, "lo": -0.5}, "PPL": {"mean": 0.2, "lo": -0.3}}
    return target, complementary, retention


def test_audit_decision_all_clauses_pass() -> None:
    res = audit_decision(*_audit_inputs())
    assert res["TargetSuperiorityPass"] is True
    assert res["ComplementaryEquivalencePass"] is True
    assert res["RetentionNIPass"] is True
    assert res["SafeGain"] is True
    assert res["LocalizedGain"] is True
    assert res["AuditPass"] is True
    assert res["failed_clauses"] == []


def test_audit_decision_safe_but_not_localized() -> None:
    target, complementary, retention = _audit_inputs()
    complementary["OntoNeg"] = {"mean": 0.6, "lo": -0.4, "hi": 1.6, "equivalent": False}
    res = audit_decision(target, complementary, retention)
    assert res["TargetSuperiorityPass"] is True
    assert res["ComplementaryEquivalencePass"] is False
    assert res["RetentionNIPass"] is True
    assert res["SafeGain"] is True
    assert res["LocalizedGain"] is False
    assert res["AuditPass"] is False
    assert res["failed_clauses"] == ["ComplementaryEquivalence[OntoNeg]"]


def test_audit_decision_retention_failure_blocks_everything() -> None:
    target, complementary, retention = _audit_inputs()
    retention["MMLU"] = {"mean": -1.8, "lo": -2.4, "hi": -1.2}
    res = audit_decision(target, complementary, retention)
    assert res["RetentionNIPass"] is False
    assert res["SafeGain"] is False
    assert res["LocalizedGain"] is False
    assert res["AuditPass"] is False
    assert res["failed_clauses"] == ["RetentionNI[MMLU]"]


def test_ppl_worsening_fails_retention_ni() -> None:
    """Lower-is-better PPL: +14% relative must fail a +5% upper NI bound."""
    target, complementary, _ = _audit_inputs()
    retention = {
        "WikiText-PPL": {
            "mean": 14.0,
            "lo": 13.4,
            "hi": 14.6,
            "margin": 5.0,
            "scale": "relative_percent",
        }
    }
    res = audit_decision(target, complementary, retention)
    assert res["RetentionNI"]["WikiText-PPL"]["pass"] is False
    assert "RetentionNI[WikiText-PPL]" in res["failed_clauses"]
    assert res["SafeGain"] is False


def test_oer_improvement_does_not_fail_complementary_ni() -> None:
    """Lower-is-better OER: a large improvement must not fail NI."""
    target = {"mean": 5.0, "lo": 2.0, "hi": 8.0}
    complementary = {
        "OER": {
            "mean": -8.5,
            "lo": -10.0,
            "hi": -7.0,
            "equivalent": False,
            "higher_is_better": False,
        },
        "AbsAcc": {
            "mean": -0.2,
            "lo": -0.6,
            "hi": 0.2,
            "equivalent": True,
        },
    }
    retention = {"MMLU": {"mean": -0.1, "lo": -0.5, "hi": 0.3}}
    res = audit_decision(target, complementary, retention)
    assert "ComplementaryNI[OER]" not in res["failed_clauses"]
    assert res["SafeGain"] is True  # NI passes; TOST may still fail
    assert res["LocalizedGain"] is False


def test_oer_worsening_fails_complementary_ni() -> None:
    target = {"mean": 5.0, "lo": 2.0, "hi": 8.0}
    complementary = {
        "OER": {
            "mean": 10.0,
            "lo": 8.0,
            "hi": 12.0,
            "equivalent": False,
        },
    }
    retention = {"MMLU": {"mean": -0.1, "lo": -0.5, "hi": 0.3}}
    res = audit_decision(target, complementary, retention)
    assert "ComplementaryNI[OER]" in res["failed_clauses"]
    assert res["SafeGain"] is False


def test_audit_decision_without_target_superiority() -> None:
    target, complementary, retention = _audit_inputs()
    target["lo"] = -0.2
    res = audit_decision(target, complementary, retention)
    assert res["TargetSuperiorityPass"] is False
    assert res["ComplementaryEquivalencePass"] is True
    assert res["SafeGain"] is False and res["AuditPass"] is False
    assert res["failed_clauses"] == ["TargetSuperiority"]


def test_equivalence_margin_justification_scales_with_runs() -> None:
    few = equivalence_margin_justification(run_sd=0.4, n_runs=3, margin=1.0)
    many = equivalence_margin_justification(run_sd=0.4, n_runs=12, margin=1.0)

    assert many["min_resolvable_effect"] < few["min_resolvable_effect"]
    assert many["run_standard_error"] == pytest.approx(0.4 / np.sqrt(12))
    # Without an observed interval the run standard error is the noise floor.
    assert many["implied_total_standard_error"] == many["run_standard_error"]
    assert many["n_runs"] == 12
    assert many["power"] == 0.8 and many["alpha"] == 0.05


def test_equivalence_margin_justification_reads_observed_half_width() -> None:
    """Cluster noise enters through the interval the design actually produced."""
    res = equivalence_margin_justification(
        run_sd=0.4, n_runs=7, margin=1.0, observed_half_width=0.8)
    assert res["implied_total_standard_error"] > res["run_standard_error"]
    assert res["implied_total_standard_error"] == pytest.approx(0.8 / 1.6448536270)
    assert res["min_resolvable_effect"] == pytest.approx(0.8 / 1.6448536270 * 2.4864749)
    assert res["margin_is_resolvable"] is False
    # Halving an unresolvable margin costs runs quadratically.
    assert res["runs_required_for_half_margin"] > 4 * res["n_runs"]


def test_equivalence_margin_justification_rejects_impossible_designs() -> None:
    with pytest.raises(ValueError):
        equivalence_margin_justification(run_sd=0.4, n_runs=0, margin=1.0)
    with pytest.raises(ValueError):
        equivalence_margin_justification(run_sd=-0.1, n_runs=3, margin=1.0)
    # A zero margin cannot be halved, and must not divide by zero.
    assert equivalence_margin_justification(
        run_sd=0.4, n_runs=3, margin=0.0)["runs_required_for_half_margin"] == 0


def _mediation_data(
    n_runs: int = 6,
    n_ckpt: int = 9,
    direct: float = 0.3,
    a_path: float = 0.6,
    b_path: float = 0.5,
    seed: int = 0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str], list[str]]:
    """Checkpoints nested in runs nested in families; half the effect via M."""
    rng = np.random.default_rng(seed)
    family_effects = {"self_reward": 0.0, "dpo": 0.3, "dion": -0.2}
    families = list(family_effects)
    treatment, mediator, outcome, runs, family_ids = [], [], [], [], []
    for run in range(n_runs):
        family = families[run % len(families)]
        run_intercept = rng.normal(0.0, 0.4)
        for _ in range(n_ckpt):
            t = float(rng.integers(0, 2))
            m = a_path * t + family_effects[family] + run_intercept + rng.normal(0.0, 0.05)
            treatment.append(t)
            mediator.append(m)
            outcome.append(direct * t + b_path * m + rng.normal(0.0, 0.05))
            runs.append(f"run{run}")
            family_ids.append(family)
    return (
        np.asarray(treatment),
        np.asarray(mediator),
        np.asarray(outcome),
        runs,
        family_ids,
    )


def test_multilevel_mediation_recovers_known_share() -> None:
    treatment, mediator, outcome, runs, families = _mediation_data()
    res = multilevel_mediation(
        treatment, mediator, outcome, runs, families, n_boot=200, seed=3
    )

    assert res.n_obs == 54
    assert res.n_runs == 6
    assert res.n_families == 3
    assert res.scale == "linear"
    assert res.interpretation == "associational"
    # Constructed total = 0.3 + 0.6 * 0.5 = 0.6, of which 0.3 flows via M.
    assert res.total_effect == pytest.approx(0.6, abs=0.05)
    assert res.indirect_effect == pytest.approx(res.total_effect - res.direct_effect)
    assert 0.2 <= res.proportion_associated <= 0.8
    assert res.ci_lo < res.ci_hi


def test_multilevel_mediation_validates_alignment() -> None:
    treatment, mediator, outcome, runs, families = _mediation_data(n_runs=2, n_ckpt=4)
    with pytest.raises(ValueError):
        multilevel_mediation(treatment, mediator, outcome[:-1], runs, families, n_boot=5)


def test_fit_random_intercept_ols_recovers_slopes() -> None:
    rng = np.random.default_rng(3)
    rows, targets, groups = [], [], []
    for group in range(8):
        run_intercept = rng.normal(0.0, 0.7)
        for _ in range(25):
            x1, x2 = float(rng.normal()), float(rng.normal())
            rows.append([1.0, x1, x2])
            targets.append(1.0 + 2.0 * x1 - 1.5 * x2 + run_intercept + rng.normal(0.0, 0.2))
            groups.append(f"run{group}")

    beta, intercepts, sigma_resid, sigma_group = fit_random_intercept_ols(
        np.asarray(targets), np.asarray(rows), groups
    )

    assert beta[1] == pytest.approx(2.0, abs=0.05)
    assert beta[2] == pytest.approx(-1.5, abs=0.05)
    assert len(intercepts) == 8
    assert sigma_resid == pytest.approx(0.2, abs=0.05)
    # Between-run spread is estimated from 8 groups, so only order of magnitude.
    assert 0.2 < sigma_group < 1.5
    assert statistics.mean(intercepts.values()) == pytest.approx(0.0, abs=0.5)
