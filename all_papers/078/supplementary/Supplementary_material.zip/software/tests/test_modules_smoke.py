"""Smoke tests -- run without GPU; verify shapes and the zero-init invariant."""

from __future__ import annotations

import math

import pytest
import torch

from dion.losses.abo import ABOConfig, abo_loss
from dion.losses.dipo import DIPOConfig, dipo_loss, internal_score, repetition_penalty
from dion.models.cph import ConceptPredicateHead, cph_loss, predicate_entropy  # noqa: F401
from dion.models.din import DINOperator
from dion.models.fisher import LowRankFisher
from dion.models.pool import AttentionPool
from dion.models.tension import boundary_energy, layer_tension  # noqa: F401
from dion.models.tra import TriadicResidualAdapter


@pytest.fixture(autouse=True)
def _deterministic() -> None:
    """Smoke tests draw random inputs; a fixed seed keeps runs reproducible."""
    torch.manual_seed(0)


def test_attention_pool_shapes() -> None:
    B, T, D = 2, 5, 64
    pool = AttentionPool(d_model=D, d_pool=32)
    h = torch.randn(B, T, D)
    mask = torch.ones(B, T, dtype=torch.long)
    c, a = pool(h, mask)
    assert c.shape == (B, D)
    assert a.shape == (B, T)
    assert torch.allclose(a.sum(-1), torch.ones(B), atol=1e-5)


def test_cph_loss_composition() -> None:
    """L_CPH = L_cons - lambda * H, so the diversity bonus may push it below zero."""
    K, lambda_div = 32, 0.05
    cph = ConceptPredicateHead(d_model=64, K=K)
    c1, c2 = torch.randn(8, 64), torch.randn(8, 64)
    q1, q2 = cph(c1), cph(c2)
    res = cph_loss(q1, q2, lambda_div=lambda_div)
    assert res["loss"].dim() == 0
    assert res["cons"] >= 0.0, "JS divergence is non-negative"
    assert 0.0 <= res["diversity_H"] <= math.log(K) + 1e-5
    assert torch.allclose(res["loss"],
                          res["cons"] - lambda_div * res["diversity_H"], atol=1e-6)
    assert res["loss"] >= -lambda_div * math.log(K) - 1e-5


def test_low_rank_fisher_psd() -> None:
    f = LowRankFisher(d=64, r=8, eps_curvature=0.1, seed=0)
    grads = torch.randn(4, 64)
    est = f(grads)
    assert est.F_tilde.shape == (8, 8)
    assert torch.allclose(est.F_tilde, est.F_tilde.transpose(-1, -2), atol=1e-5)
    eigvals = est.eigvals
    assert (eigvals >= -1e-5).all()
    assert est.fisher_proj.shape == (8, 64)


def test_din_eta_unit_norm() -> None:
    cph = ConceptPredicateHead(d_model=64, K=16)
    din = DINOperator(cph=cph, d_model=64, rank_r=8, beta_var=0.1)
    c = torch.randn(4, 64)
    grads = torch.randn(8, 64)
    eta, _ = din.compute_eta(c, grads)
    assert eta.shape == (4, 64)
    norms = eta.norm(dim=-1)
    assert torch.allclose(norms, torch.ones(4), atol=1e-3)


def test_tra_zero_init_identity() -> None:
    """Initialization Sanity Property: at init the TRA leaves hidden unchanged."""
    tra = TriadicResidualAdapter(d_model=32, rank_a=8, alpha=0.1)
    B, T, D = 2, 4, 32
    h = torch.randn(B, T, D)
    a = torch.softmax(torch.randn(B, T), -1)
    c = (a.unsqueeze(-1) * h).sum(1)
    eta = torch.randn(B, D)
    eta = eta / eta.norm(dim=-1, keepdim=True)
    out, s = tra(c=c, eta=eta, attention_weights=a, hidden=h)
    assert torch.allclose(out, h, atol=1e-6), "TRA must be identity at zero init"
    assert torch.allclose(s, torch.zeros_like(s), atol=1e-6)


def test_abo_loss_runs() -> None:
    B, T, V, K = 2, 5, 20, 16
    logp_theta = torch.randn(B, T, V, requires_grad=True)
    logp_theta0 = torch.randn(B, T, V)
    response_mask = torch.ones(B, T)
    q_T = torch.softmax(torch.randn(B, K), -1)
    q_A = torch.softmax(torch.randn(B, K), -1)
    q_S = torch.softmax(torch.randn(B, K), -1)
    res = abo_loss(
        logp_theta=logp_theta, logp_theta0=logp_theta0,
        response_mask=response_mask,
        q_T=q_T, q_A=q_A, q_S=q_S,
        tension_T=torch.tensor([0.5, 0.5]), tension_S=torch.tensor([0.4, 0.4]),
        K=K, cfg=ABOConfig(),
    )
    assert res["loss"].dim() == 0


def test_dipo_loss_runs() -> None:
    cfg = DIPOConfig()
    res = dipo_loss(
        logp_pos_theta=torch.tensor([1.0, 1.5], requires_grad=True),
        logp_pos_ref=torch.tensor([0.5, 1.0]),
        logp_neg_theta=torch.tensor([0.3, 0.8], requires_grad=True),
        logp_neg_ref=torch.tensor([0.2, 0.7]),
        cfg=cfg,
    )
    assert res["loss"].dim() == 0


def test_repetition_penalty_basic() -> None:
    p_low = repetition_penalty("the quick brown fox jumps over the lazy dog and runs")
    p_high = repetition_penalty("hello hello hello hello hello hello hello hello")
    assert p_high > p_low


def test_internal_score_signature() -> None:
    cfg = DIPOConfig()
    s = internal_score(
        tension_x=torch.tensor([1.0]), tension_xy=torch.tensor([0.5]),
        depth_delta=torch.tensor([0.1]), repetition=torch.tensor([0.0]),
        length=torch.tensor([100.0]), cfg=cfg,
    )
    assert s.shape == (1,)
    assert s.item() > 0


def test_stats_tost_and_bh() -> None:
    from dion.evaluation.stats import bh_correct, paired_bootstrap, tost
    diffs = [0.001, -0.0005, 0.002, -0.001, 0.0008] * 20
    lo, hi = paired_bootstrap(diffs, n_boot=200, seed=0)
    assert lo < hi
    res = tost(diffs, margin=0.01, n_boot=200, seed=0)
    assert res["pass"] is True
    flags = bh_correct([0.001, 0.04, 0.05, 0.5, 0.9], alpha=0.05)
    assert flags[0] is True and flags[3] is False
