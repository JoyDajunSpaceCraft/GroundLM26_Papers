"""Semantic validity tests for the DION-Bench constructors.

These check the invariants the paper relies on: negations are attested by
lexical evidence rather than inferred from a missing edge, the exception is the
only in-category candidate carrying that evidence, abstractions come with
certified IsA paths, and every LogicRepair item is solver-verified.
"""

from __future__ import annotations

import random

from dion.bench.concept_graph import ConceptGraph
from dion.bench.concept_shift import certified_lcs, is_clean_label, s_alternatives
from dion.bench.logic_repair import _synthesize_logic_rows, verify_mus
from dion.bench.onto_neg_wn import (
    CERTIFIED_TIERS,
    gloss_affirms,
    gloss_negation_cues,
    negation_evidence,
)


def _tiny_graph() -> ConceptGraph:
    """A four-sibling category where exactly one member denies the attribute.

    ``bird`` glosses the category default (``feather``), ``dog``/``wolf`` inherit
    it silently, ``kiwi`` denies it lexically (``featherless``), and ``car`` sits
    in a disjoint branch.
    """
    g = ConceptGraph()
    glosses = {
        "wn:entity.n.01": "",
        "wn:animal.n.01": "a living organism",
        "wn:bird.n.01": "a warm-blooded vertebrate covered with feathers",
        "wn:dog.n.01": "a domesticated carnivore kept as a pet",
        "wn:wolf.n.01": "a wild carnivore that hunts in packs",
        "wn:kiwi.n.01": "a flightless featherless bird of New Zealand",
        "wn:vehicle.n.01": "a conveyance that transports people",
        "wn:car.n.01": "a wheeled motor vehicle",
        "wn:feather.n.01": "feather",
    }
    labels = {
        "wn:entity.n.01": "entity", "wn:animal.n.01": "animal",
        "wn:bird.n.01": "bird", "wn:dog.n.01": "dog", "wn:wolf.n.01": "wolf",
        "wn:kiwi.n.01": "kiwi", "wn:vehicle.n.01": "vehicle",
        "wn:car.n.01": "car", "wn:feather.n.01": "feather",
    }
    for node, label in labels.items():
        g.g.add_node(node, source="wn", label=label, gloss=glosses[node])
    isa = [
        ("wn:animal.n.01", "wn:entity.n.01"),
        ("wn:vehicle.n.01", "wn:entity.n.01"),
        ("wn:bird.n.01", "wn:animal.n.01"),
        ("wn:dog.n.01", "wn:animal.n.01"),
        ("wn:wolf.n.01", "wn:animal.n.01"),
        ("wn:kiwi.n.01", "wn:animal.n.01"),
        ("wn:car.n.01", "wn:vehicle.n.01"),
    ]
    for child, parent in isa:
        g.g.add_edge(child, parent, rel="IsA", key="IsA", source="wn")
    g.g.add_edge("wn:bird.n.01", "wn:feather.n.01", rel="HasA", key="HasA",
                 source="wn")
    return g


def test_siblings_are_hyponyms_not_parent_out_edges():
    g = _tiny_graph()
    sibs = g.siblings("wn:dog.n.01")
    assert "wn:kiwi.n.01" in sibs
    assert "wn:animal.n.01" not in sibs


def test_negation_needs_lexical_evidence_not_edge_absence():
    g = _tiny_graph()
    # The exception denies the attribute in its own gloss.
    evidence = negation_evidence(g, "wn:kiwi.n.01", "HasA", "feather")
    assert evidence is not None
    assert evidence["tier"] in CERTIFIED_TIERS
    assert "featherless" in evidence["pattern"]
    assert "featherless" in evidence["quote"]
    # Silent inheritors have no attribute edge either, and that is not evidence.
    for silent in ("wn:dog.n.01", "wn:wolf.n.01"):
        assert negation_evidence(g, silent, "HasA", "feather") is None


def test_gloss_cues_are_symmetric_between_default_and_exception():
    g = _tiny_graph()
    affirmation = gloss_affirms(g.gloss("wn:bird.n.01"), "feather")
    assert affirmation and "feather" in affirmation
    # The same rule refuses to read a negated mention as an affirmation.
    assert gloss_affirms(g.gloss("wn:kiwi.n.01"), "feather") is None
    cues = gloss_negation_cues("a vast treeless plain in the arctic regions")
    assert ("HasA", "tree", "treeless") in cues


def test_explicit_negative_fact_outranks_gloss_evidence():
    g = _tiny_graph()
    g.g.add_edge("wn:dog.n.01", "wn:feather.n.01", rel="NotHasA", key="NotHasA",
                 source="cn")
    evidence = negation_evidence(g, "wn:dog.n.01", "HasA", "feather")
    assert evidence is not None
    assert evidence["tier"] == "explicit_negative_fact"
    assert evidence["assertion"] == "NotHasA(dog, feather)"


def test_certified_lcs_uses_isa_only_and_returns_both_paths():
    g = _tiny_graph()
    g.g.add_edge("wn:dog.n.01", "wn:car.n.01", rel="PartOf", key="PartOf",
                 source="wn")
    assert g.least_common_subsumer("wn:dog.n.01", "wn:kiwi.n.01") == "wn:animal.n.01"
    certificate = certified_lcs(g, "wn:dog.n.01", "wn:kiwi.n.01")
    assert certificate is not None
    subsumer, path_t, path_a = certificate
    assert subsumer == "wn:animal.n.01"
    assert path_t[0] == "wn:dog.n.01" and path_t[-1] == subsumer
    assert path_a[0] == "wn:kiwi.n.01" and path_a[-1] == subsumer

    def isa_step(child: str, parent: str) -> bool:
        return parent in g.hypernyms(child)

    # The PartOf edge must not shorten a path: every step stays an IsA step.
    across = certified_lcs(g, "wn:dog.n.01", "wn:car.n.01")
    assert across is not None
    _, from_dog, from_car = across
    assert from_dog == ["wn:dog.n.01", "wn:animal.n.01", "wn:entity.n.01"]
    assert from_car == ["wn:car.n.01", "wn:vehicle.n.01", "wn:entity.n.01"]
    for path in (path_t, path_a, from_dog, from_car):
        assert all(isa_step(a, b) for a, b in zip(path, path[1:]))


def test_s_alternatives_reject_mechanical_morphology():
    g = _tiny_graph()
    alts = s_alternatives(g, "wn:animal.n.01", "wn:dog.n.01", "wn:kiwi.n.01")
    assert "animal concept" not in alts
    assert "animals" not in alts
    assert all(is_clean_label(a) for a in alts)


def test_clean_label_filter_rejects_definitional_and_long_labels():
    assert is_clean_label("hoofed mammal")
    assert not is_clean_label("a kind of thing that is quite long indeed")


def test_logic_repair_mus_is_unsat_and_minimal():
    rng = random.Random(0)
    rows = _synthesize_logic_rows(8, rng, verify=True)
    assert rows
    for row in rows:
        assert len(row["MUS"]) in {4, 5, 6}
        certificate = row.get("certificate") or {}
        assert certificate.get("encoding") == "horn_implication_chain"
        assert certificate.get("unsat") and certificate.get("minimal")
        ok, _ = verify_mus(row["K"], row["a_star"], row["target_sentence"],
                           row["MUS"])
        assert ok
