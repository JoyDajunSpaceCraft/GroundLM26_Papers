"""Regression tests for the auditable evaluation pipeline."""

from __future__ import annotations

import json

import pytest


def test_abstraction_accuracy_accepts_every_audited_alternative() -> None:
    from dion.evaluation.main_metrics import abstraction_accuracy

    predictions = ["accepted third synonym", "miss"]
    accepted_sets = [
        ["reference", "first synonym", "accepted third synonym"],
        ["other reference"],
    ]

    assert abstraction_accuracy(predictions, accepted_sets) == 0.5


def test_logic_repair_parser_recovers_mus_and_repaired_kb() -> None:
    from dion.evaluation.output_parser import parse_mus, parse_repaired_kb

    raw = """MUS:
- Uma is a stone.
- All stones are alive.
Repaired KB:
- All stones are alive.
- Fay is dry.
"""

    assert parse_mus(raw).value == [
        "Uma is a stone.",
        "All stones are alive.",
    ]
    assert parse_repaired_kb(raw).value == [
        "All stones are alive.",
        "Fay is dry.",
    ]


def test_ledger_scores_mus_recall_and_kprime_from_raw_output(tmp_path) -> None:
    from dion.evaluation.output_parser import PARSER_VERSION
    from ledger_validator import Gold

    row = {
        "id": "logic-1",
        "MUS": ["A.", "B.", "C.", "D."],
        "K_prime": ["B.", "C."],
    }
    (tmp_path / "logic_repair_test.jsonl").write_text(json.dumps(row) + "\n")
    item = {
        "task": "logic_repair",
        "split": "test",
        "id": "logic-1",
        "seed": 42,
        "raw_output": "MUS:\n- A.\n- B.\nRepaired KB:\n- B.\n- C.",
        "cluster": "logic-1",
        "parser_version": PARSER_VERSION,
    }

    scores = Gold(tmp_path).score(item)

    assert scores["MUS-P"] == 1.0
    assert scores["MUS-R"] == 0.5
    assert scores["MUS-F1"] == pytest.approx(2 / 3)
    assert scores["Kprime-Exact"] == 1.0
