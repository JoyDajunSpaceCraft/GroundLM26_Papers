#!/usr/bin/env bash
# Cross-backbone diagnostic validation.
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"

MODELS_DIR="${MODELS_DIR:-models}"
BACKBONES=(
    "${MODELS_DIR}/Qwen3-8B-Base"
    "${MODELS_DIR}/Llama-3.1-8B"
    "${MODELS_DIR}/Qwen3-8B-Instruct"
)

for BB in "${BACKBONES[@]}"; do
    if [ ! -d "$BB" ]; then
        echo "[cross-backbone] Backbone not found: $BB  (skipping)"
        continue
    fi
    NAME=$(basename "$BB")
    echo "=== Tier A: inference-only on $NAME ==="
    python -m dion.evaluation.run_main_eval \
        --config configs/dion_main.yaml \
        --model_name_or_path "$BB" \
        --split test \
        --out "outputs/cross_backbone_${NAME}_eval.json"

    echo "=== Tier B: Self-Rewarding replication on $NAME ==="
    for SEED in 1 2 3; do
        # Write a transient config override so training also uses BB + seed.
        TMP_CFG=$(mktemp /tmp/dion_cross_XXXXXX.yaml)
        python - <<PY
import yaml
from pathlib import Path
cfg = yaml.safe_load(Path("configs/dion_main.yaml").read_text())
cfg.setdefault("model", {})
cfg["model"]["backbone"] = "$BB"
cfg["model"]["name_or_path"] = "$BB"
cfg["seed"] = $SEED
cfg["out_dir"] = f"outputs/cross_{NAME}_seed{SEED}"
Path("$TMP_CFG").write_text(yaml.safe_dump(cfg))
print("$TMP_CFG")
PY
        python -m dion.baselines.self_rewarding \
            --config "$TMP_CFG" \
            --judge_variant strict \
            --seed "$SEED"
        rm -f "$TMP_CFG"
    done

    echo "=== Tier B: TRA-only replication on $NAME ==="
    TMP_CFG=$(mktemp /tmp/dion_cross_XXXXXX.yaml)
    python - <<PY
import yaml
from pathlib import Path
cfg = yaml.safe_load(Path("configs/dion_tra_only.yaml").read_text())
cfg.setdefault("model", {})
cfg["model"]["backbone"] = "$BB"
cfg["model"]["name_or_path"] = "$BB"
Path("$TMP_CFG").write_text(yaml.safe_dump(cfg))
PY
    python -m dion.training.stage2_abo --config "$TMP_CFG"
    rm -f "$TMP_CFG"
done

echo "[cross-backbone] All done."
