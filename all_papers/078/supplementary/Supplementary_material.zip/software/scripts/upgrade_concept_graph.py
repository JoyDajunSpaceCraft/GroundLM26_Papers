#!/usr/bin/env python3
"""Add attested-negation edges, WordNet glosses and monosemous sense links.

Upgrades ``data/processed/concept_graph.gpkl`` in place instead of re-parsing the
500MB ConceptNet dump. Negative assertions come from
``data/processed/negative_facts.tsv`` (extracted from the same 5.7.0 dump).
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.bench.concept_graph import ConceptGraph, NEGATIVE_RELATIONS, cn_node  # noqa: E402

GRAPH = ROOT / "data/processed/concept_graph.gpkl"
NEG_TSV = ROOT / "data/processed/negative_facts.tsv"


def _cn_from_uri(uri: str) -> str:
    parts = uri.split("/")
    surface = parts[3].replace("_", " ") if len(parts) > 3 else uri
    suffix = "/".join(parts[4:]) if len(parts) > 4 else ""
    return cn_node(surface, suffix)


def main() -> int:
    t0 = time.time()
    print("[upgrade] loading graph ...", flush=True)
    graph = ConceptGraph.load(GRAPH)
    n0, e0 = graph.g.number_of_nodes(), graph.g.number_of_edges()
    print(f"[upgrade] nodes={n0} edges={e0} ({time.time() - t0:.1f}s)", flush=True)

    added_neg = 0
    if NEG_TSV.exists():
        with NEG_TSV.open() as f:
            for line in f:
                rel_uri, s, e = line.rstrip("\n").split("\t")
                rel = rel_uri.rsplit("/", 1)[-1]
                if rel not in NEGATIVE_RELATIONS:
                    continue
                src, tgt = _cn_from_uri(s), _cn_from_uri(e)
                graph.g.add_node(src, source="cn", label=src[3:].split("|")[0])
                graph.g.add_node(tgt, source="cn", label=tgt[3:].split("|")[0])
                graph.g.add_edge(src, tgt, rel=rel, source="cn", key=rel)
                added_neg += 1
    print(f"[upgrade] negative-fact edges added={added_neg} ({time.time() - t0:.1f}s)", flush=True)

    from nltk.corpus import wordnet as wn

    added_gloss = 0
    for syn in wn.all_synsets(pos=wn.NOUN):
        node = f"wn:{syn.name()}"
        if node in graph.g and not graph.g.nodes[node].get("gloss"):
            graph.g.nodes[node]["gloss"] = syn.definition().lower()
            added_gloss += 1
    print(f"[upgrade] glosses attached={added_gloss} ({time.time() - t0:.1f}s)", flush=True)

    linked = graph.link_monosemous_lemmas()
    print(f"[upgrade] monosemous sense links={linked} ({time.time() - t0:.1f}s)", flush=True)

    graph.save(GRAPH)
    print(f"[upgrade] saved nodes={graph.g.number_of_nodes()} "
          f"edges={graph.g.number_of_edges()} ({time.time() - t0:.1f}s)", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
