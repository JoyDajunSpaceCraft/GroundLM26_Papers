#!/usr/bin/env bash
# Resume SC/EM/SFT seeds 43/44 that failed due to missing --seed CLI.
# Waits for QUEUE_PID if set, then runs on GPU 0 with certified-only pool.
set -uo pipefail
cd "$(dirname "$0")/.."
export MODELS_DIR="${MODELS_DIR:-/export/models}"
export PYTHONPATH=src
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export HF_HOME="${HF_HOME:-/export/.hf_cache}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/export/.hf_cache/datasets}"

LOGDIR=outputs/gpu_backlog_logs
mkdir -p "$LOGDIR"
STAMP=$(date +%Y%m%d_%H%M%S)
exec > >(tee -a "$LOGDIR/missed_${STAMP}.log") 2>&1

if [[ -n "${QUEUE_PID:-}" ]]; then
  echo "[$(date -Is)] waiting for queue pid $QUEUE_PID"
  while kill -0 "$QUEUE_PID" 2>/dev/null; do sleep 60; done
  echo "[$(date -Is)] queue finished; starting missed SC/EM/SFT"
fi

TRAIN=data/bench/onto_neg_wn_train.jsonl
CERT=data/bench/onto_neg_wn_train_certified_only.jsonl
BAK=data/bench/onto_neg_wn_train.mixed.bak.jsonl
restore() { [[ -f "$BAK" ]] && mv -f "$BAK" "$TRAIN"; }
trap restore EXIT
[[ -f "$BAK" ]] || cp -f "$TRAIN" "$BAK"
cp -f "$CERT" "$TRAIN"

run_train() {
  local label="$1"; shift; local out="$1"; shift
  [[ -f "$out" ]] && { echo "SKIP $label"; return 0; }
  echo "[$(date -Is)] TRAIN $label"
  "$@" || echo "[$(date -Is)] FAIL $label"
}
run_eval() {
  local label="$1" cfg="$2" ckpt="$3" stem="$4"
  [[ -f "$ckpt" ]] || return 0
  [[ -f "${stem}_test.json" ]] && return 0
  echo "[$(date -Is)] EVAL $label"
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test \
    --save_items --out "${stem}_test.json" || echo "FAIL eval $label"
}

for seed in 43 44; do
  run_train "sc_s${seed}" "outputs/certified_only/self_critique_s${seed}/self_critique/state.pt" \
    python -m dion.baselines.self_critique --config "configs/certified_only/sc_s${seed}.yaml" --seed "$seed"
  run_eval "sc_s${seed}" "configs/certified_only/sc_s${seed}.yaml" \
    "outputs/certified_only/self_critique_s${seed}/self_critique/state.pt" \
    "outputs/certified_only/self_critique_s${seed}"
done
for seed in 43 44; do
  run_train "em_s${seed}" "outputs/certified_only/entropy_min_s${seed}/entropy_min/state.pt" \
    python -m dion.baselines.entropy_min --config "configs/certified_only/em_s${seed}.yaml" --seed "$seed"
  run_eval "em_s${seed}" "configs/certified_only/em_s${seed}.yaml" \
    "outputs/certified_only/entropy_min_s${seed}/entropy_min/state.pt" \
    "outputs/certified_only/entropy_min_s${seed}"
done
for seed in 43 44; do
  run_train "sft_s${seed}" "outputs/certified_only/sft_lora_s${seed}/sft_lora/state.pt" \
    python -m dion.baselines.sft_lora --config "configs/certified_only/sft_s${seed}.yaml" --seed "$seed"
  run_eval "sft_s${seed}" "configs/certified_only/sft_s${seed}.yaml" \
    "outputs/certified_only/sft_lora_s${seed}/sft_lora/state.pt" \
    "outputs/certified_only/sft_lora_s${seed}"
done

python3 scripts/summarize_certified_evals.py || true
echo "[$(date -Is)] missed SC/EM/SFT finished"
