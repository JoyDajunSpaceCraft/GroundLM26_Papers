#!/usr/bin/env python3
"""End-to-end Context-anchored Specificity-penalized Decoding (CSD).

Rebuilds CSD prediction files from a parent configuration's strict items:

  parent *_items.jsonl
    → read checkpoint beam candidates already stored on each parent record
    → score each candidate with a deterministic logprob proxy
    → rerank_candidates(...)  (gold-free: never opens S / S_alternatives)
    → write validator-schema *_csd_items.jsonl with a full ``csd_trace``

Candidate construction is **not** performed here from the benchmark gold.
Each parent record must already carry:

  * ``beam_candidates`` — strings the frozen checkpoint actually produced
    (greedy output plus any additional samples / MCQ options shown in the
    prompt); and
  * ``prompt_target`` / ``prompt_context`` — the prompt-visible cue used by
    the specificity penalty.

LogicRepair is not candidate selection: parent MUS/K' outputs are copied
unchanged. Coefficients come from ``configs/intervention_csd.yaml`` and are
never retuned here.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.evaluation.eval_time_intervention import (  # noqa: E402
    CSDConfig,
    rerank_candidates,
    specificity_penalty,
)
from dion.evaluation.output_parser import (  # noqa: E402
    PARSER_VERSION,
    parse_abstraction,
    parse_candidate_choice,
)
from dion.utils.io import load_jsonl, load_yaml  # noqa: E402

#: Fields that must never influence CSD candidate construction or ranking.
_FORBIDDEN_GOLD_KEYS = frozenset({
    "S", "S_alternatives", "A_star", "gold", "gold_mus", "K_prime", "MUS",
})


def _proxy_score(text: str, parent_logprob: float | None, rank: int) -> float:
    """Fallback stand-in when per-candidate logprobs are unavailable."""
    base = float(parent_logprob) if parent_logprob is not None else -1.0
    return base - 0.05 * rank - 0.01 * max(0, len(text.split()) - 2)


def _candidate_scores(item: dict, cands: list[str]) -> tuple[list[float], str]:
    """Prefer true per-candidate logprobs; else deterministic proxy scores."""
    raw = item.get("candidate_logprobs")
    if isinstance(raw, list) and len(raw) == len(cands):
        try:
            return [float(x) for x in raw], "candidate_logprob"
        except (TypeError, ValueError):
            pass
    parent_lp = item.get("logprob")
    return (
        [_proxy_score(c, parent_lp, i) for i, c in enumerate(cands)],
        "parent_logprob_proxy",
    )


def _beam_from_parent(item: dict) -> list[str]:
    """Checkpoint beam only — never synthesised from gold fields."""
    for key in _FORBIDDEN_GOLD_KEYS:
        if key in item:
            raise ValueError(
                f"parent record {item.get('id')!r} carries forbidden gold "
                f"field {key!r}; CSD refuses to run")
    raw = item.get("beam_candidates") or item.get("candidates")
    if not raw:
        raise ValueError(
            f"parent record {item.get('id')!r} has no beam_candidates; "
            f"CSD cannot invent a gold-free beam from the benchmark")
    out: list[str] = []
    for cand in raw:
        c = str(cand).strip()
        if c and c not in out:
            out.append(c)
    if not out:
        raise ValueError(f"empty beam for {item.get('id')!r}")
    return out


def apply_csd(
    parent_items: list[dict],
    cfg: CSDConfig,
    out_config: str,
) -> list[dict]:
    written: list[dict] = []
    for item in parent_items:
        task, split = item["task"], item.get("split", "test")
        raw = item["raw_output"]
        parent_lp = item.get("logprob")
        trace: dict = {
            "task": task,
            "parent_raw": raw,
            "parent_logprob": parent_lp,
            "source": "parent_beam_candidates",
        }

        if task == "logic_repair":
            record = {k: v for k, v in item.items()
                      if k not in {"beam_candidates", "prompt_target",
                                   "prompt_context", "prompt_options"}}
            record["config"] = out_config
            record["parse_rule"] = "inherited"
            record["csd_trace"] = {
                "inherited": True,
                "reason": "not_candidate_selection",
                "parent_logprob": parent_lp,
            }
            written.append(record)
            continue

        cands = _beam_from_parent(item)
        target = str(item.get("prompt_target") or "")
        context = str(item.get("prompt_context") or "")
        leaves = [str(x) for x in (item.get("prompt_leaves") or []) if x]
        if not target:
            raise ValueError(
                f"parent record {item.get('id')!r} missing prompt_target")

        if task == "concept_shift":
            greedy = str(parse_abstraction(raw).value)
        else:
            opts = list(item.get("prompt_options") or cands)
            greedy = str(parse_candidate_choice(raw, opts).value)
        if greedy not in cands:
            cands = [greedy] + cands

        scores, score_source = _candidate_scores(item, cands)
        chosen = rerank_candidates(
            cands, target, context, scores, cfg, greedy, leaf_surfaces=leaves)
        penalties = [
            specificity_penalty(c, target, context, cfg, leaf_surfaces=leaves)
            for c in cands
        ]
        trace.update({
            "candidates": cands,
            "base_scores": scores,
            "score_source": score_source,
            "penalties": penalties,
            "chosen": chosen,
            "greedy": greedy,
            "prompt_target": target,
            "prompt_context": context,
            "coefficients": {
                "novelty": cfg.novelty_coef,
                "length": cfg.length_coef,
                "leaf": cfg.leaf_coef,
            },
        })
        written.append({
            "config": out_config,
            "task": task,
            "split": split,
            "id": item["id"],
            "seed": item["seed"],
            "checkpoint": item.get("checkpoint", "final"),
            "raw_output": chosen,
            "prediction": chosen,
            "cluster": item["cluster"],
            "parser_version": PARSER_VERSION,
            "parse_rule": "csd_rerank",
            "logprob": parent_lp,
            "csd_trace": trace,
        })
    return written


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--parent", required=True,
                    help="Parent prediction file, e.g. "
                         "outputs/predictions/self_rewarding_strict_items.jsonl")
    ap.add_argument("--out", required=True, help="Output CSD prediction file")
    ap.add_argument("--config-name", default=None,
                    help="Config key written into each record "
                         "(default: parent stem + _csd)")
    ap.add_argument("--coeffs", default="configs/intervention_csd.yaml")
    args = ap.parse_args(argv)

    parent_path = Path(args.parent)
    # Materialise the generator — a prior bug exhausted it before apply_csd.
    items = list(load_jsonl(parent_path))
    if not items:
        raise SystemExit(f"[csd] parent file is empty: {parent_path}")

    yaml_cfg = load_yaml(args.coeffs) if Path(args.coeffs).exists() else {}
    coeffs = yaml_cfg.get("coefficients", yaml_cfg)
    csd = CSDConfig(
        novelty_coef=float(coeffs.get("novelty_coef", coeffs.get("novelty", 0.30))),
        length_coef=float(coeffs.get("length_coef", coeffs.get("length", 0.25))),
        leaf_coef=float(coeffs.get("leaf_coef", coeffs.get("leaf", 1.25))),
    )
    parent_stem = parent_path.stem.replace("_items", "").replace("_conf", "")
    out_config = args.config_name or f"{parent_stem}_csd"
    written = apply_csd(items, csd, out_config)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w") as f:
        for row in written:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"[csd] wrote {len(written)} items → {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
