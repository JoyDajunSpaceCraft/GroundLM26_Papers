#!/usr/bin/env bash
# Overnight certified-only OntoNeg retrain + eval on GPU 0.
# Swaps train file temporarily; always restores mixed pool on exit.
set -euo pipefail
cd "$(dirname "$0")/.."
export MODELS_DIR="${MODELS_DIR:-/export/models}"
export PYTHONPATH=src
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

LOGDIR=outputs/certified_only_logs
mkdir -p "$LOGDIR" configs/certified_only outputs/certified_only
STAMP=$(date +%Y%m%d_%H%M%S)
MAINLOG="$LOGDIR/run_${STAMP}.log"
exec > >(tee -a "$MAINLOG") 2>&1

echo "[$(date -Is)] starting certified-only overnight on GPU ${CUDA_VISIBLE_DEVICES}"

TRAIN=data/bench/onto_neg_wn_train.jsonl
CERT=data/bench/onto_neg_wn_train_certified_only.jsonl
BAK=data/bench/onto_neg_wn_train.mixed.bak.jsonl

restore() {
  if [[ -f "$BAK" ]]; then
    mv -f "$BAK" "$TRAIN"
    echo "[$(date -Is)] restored mixed train pool"
  fi
}
trap restore EXIT

if [[ ! -f "$BAK" ]]; then
  cp -f "$TRAIN" "$BAK"
fi
cp -f "$CERT" "$TRAIN"
echo "[$(date -Is)] train pool = certified-only ($(wc -l < "$TRAIN") rows)"

python3 - <<'PY'
import yaml
from pathlib import Path
from copy import deepcopy

def write_cfg(src, out_name, seed, out_dir):
    cfg = yaml.safe_load(Path(src).read_text())
    cfg = deepcopy(cfg)
    cfg["seed"] = seed
    cfg["out_dir"] = out_dir
    cfg["model"]["backbone"] = "${MODELS_DIR}/Qwen3-8B-Base"
    cfg["model"]["attn_implementation"] = "sdpa"
    path = Path("configs/certified_only") / out_name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(cfg, sort_keys=False))
    print(path)

# Priority queue: Self-Rewarding seeds, then SC/EM/SFT/LoRA+KL seed42
for seed in (42, 43, 44):
    write_cfg("configs/dion_sft_lora.yaml", f"sr_s{seed}.yaml", seed, f"outputs/certified_only/self_rewarding_s{seed}")
for name, mod in [("sc", "self_critique"), ("em", "entropy_min"), ("sft", "sft_lora")]:
    write_cfg("configs/dion_sft_lora.yaml", f"{name}_s42.yaml", 42, f"outputs/certified_only/{mod}_s42")
write_cfg("configs/dion_lora_kl.yaml", "lorakl_s42.yaml", 42, "outputs/certified_only/lora_kl_s42")
PY

run_train() {
  local label="$1"; shift
  local out="$1"; shift
  if [[ -f "$out" ]]; then
    echo "[$(date -Is)] SKIP train $label (exists $out)"
    return 0
  fi
  echo "[$(date -Is)] TRAIN $label"
  if ! "$@"; then
    echo "[$(date -Is)] FAIL train $label"
    return 1
  fi
  echo "[$(date -Is)] DONE train $label"
}

run_eval() {
  local label="$1" cfg="$2" ckpt="$3" stem="$4"
  if [[ ! -f "$ckpt" ]]; then
    echo "[$(date -Is)] SKIP eval $label (missing ckpt)"
    return 0
  fi
  if [[ -f "${stem}_test.json" ]]; then
    echo "[$(date -Is)] SKIP eval $label (exists)"
    return 0
  fi
  echo "[$(date -Is)] EVAL $label"
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test --save_items --out "${stem}_test.json" || {
    echo "[$(date -Is)] FAIL eval test $label"; return 1;
  }
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split conf --save_items --out "${stem}_conf.json" || {
    echo "[$(date -Is)] FAIL eval conf $label"; return 1;
  }
  echo "[$(date -Is)] DONE eval $label"
}

# --- Train + eval queue ---
for seed in 42 43 44; do
  cfg="configs/certified_only/sr_s${seed}.yaml"
  ckpt="outputs/certified_only/self_rewarding_s${seed}/self_rewarding_strict/state.pt"
  run_train "sr_s${seed}" "$ckpt" \
    python -m dion.baselines.self_rewarding --config "$cfg" --judge_variant strict --seed "$seed" || true
  run_eval "sr_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/self_rewarding_s${seed}"
done

cfg=configs/certified_only/sc_s42.yaml
ckpt=outputs/certified_only/self_critique_s42/self_critique/state.pt
run_train "sc_s42" "$ckpt" python -m dion.baselines.self_critique --config "$cfg" || true
run_eval "sc_s42" "$cfg" "$ckpt" "outputs/certified_only/self_critique_s42"

cfg=configs/certified_only/em_s42.yaml
ckpt=outputs/certified_only/entropy_min_s42/entropy_min/state.pt
run_train "em_s42" "$ckpt" python -m dion.baselines.entropy_min --config "$cfg" || true
run_eval "em_s42" "$cfg" "$ckpt" "outputs/certified_only/entropy_min_s42"

cfg=configs/certified_only/sft_s42.yaml
ckpt=outputs/certified_only/sft_lora_s42/sft_lora/state.pt
run_train "sft_s42" "$ckpt" python -m dion.baselines.sft_lora --config "$cfg" || true
run_eval "sft_s42" "$cfg" "$ckpt" "outputs/certified_only/sft_lora_s42"

cfg=configs/certified_only/lorakl_s42.yaml
ckpt=outputs/certified_only/lora_kl_s42/stage2_abo/abo_state.pt
run_train "lorakl_s42" "$ckpt" python -m dion.training.stage2_abo --config "$cfg" || true
run_eval "lorakl_s42" "$cfg" "$ckpt" "outputs/certified_only/lora_kl_s42"

# Summarize certified vs mixed headline numbers if evals exist
python3 - <<'PY'
import json
from pathlib import Path

def load(p):
    try:
        return json.loads(Path(p).read_text())
    except Exception:
        return None

rows = []
for name, path in [
    ("sr_cert_s42", "outputs/certified_only/self_rewarding_s42_test.json"),
    ("sc_cert_s42", "outputs/certified_only/self_critique_s42_test.json"),
    ("em_cert_s42", "outputs/certified_only/entropy_min_s42_test.json"),
    ("sft_cert_s42", "outputs/certified_only/sft_lora_s42_test.json"),
    ("lorakl_cert_s42", "outputs/certified_only/lora_kl_s42_test.json"),
    ("sr_mixed", "outputs/self_rewarding_strict_eval.json"),
    ("base", "outputs/base_eval.json"),
]:
    d = load(path)
    if not d:
        continue
    # tolerate nested metrics
    m = d.get("metrics", d)
    onto = m.get("onto_neg_wn", m.get("OntoNeg-WN", {}))
    cs = m.get("concept_shift", m.get("ConceptShift", {}))
    if isinstance(onto, dict):
        onto_acc = onto.get("accuracy", onto.get("ina", None))
    else:
        onto_acc = onto
    if isinstance(cs, dict):
        cs_acc = cs.get("accuracy", None)
    else:
        cs_acc = cs
    rows.append((name, onto_acc, cs_acc))

out = Path("outputs/certified_only/summary.md")
lines = ["# Certified-only overnight summary", ""]
lines.append("| run | OntoNeg | ConceptShift |")
lines.append("|---|---:|---:|")
for n, a, b in rows:
    lines.append(f"| {n} | {a} | {b} |")
out.write_text("\n".join(lines) + "\n")
print(out.read_text())
PY

echo "[$(date -Is)] overnight queue finished"
