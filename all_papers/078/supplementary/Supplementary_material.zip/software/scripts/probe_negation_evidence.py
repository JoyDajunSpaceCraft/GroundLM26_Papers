#!/usr/bin/env python3
"""Probe the attested-exception design space for OntoNeg-WN.

Design under test:

* WordNet supplies the IsA hierarchy and glosses; ConceptNet supplies attribute
  triples. The two are linked only through **monosemous** lemmas, so every
  linked node has a single WordNet noun sense (no sense conflation).
* A parent category ``P`` carries an attested attribute ``(r, o)``.
* Exactly one child ``A*`` carries positive evidence that the attribute does not
  hold: an explicit ConceptNet negative fact, a lexical negation in its WordNet
  gloss, or a contrastive value on the same relation.
* Sibling distractors carry no such evidence and inherit the default.

This removes the open-world "missing edge implies negation" inference.
"""

from __future__ import annotations

import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.bench.concept_graph import ConceptGraph, cn_node  # noqa: E402

REL_ATTRS = ("HasProperty", "CapableOf", "UsedFor", "HasA", "MadeOf", "AtLocation")
NEG_REL_MAP = {
    "/r/NotCapableOf": "CapableOf",
    "/r/NotHasProperty": "HasProperty",
    "/r/NotDesires": "Desires",
    "/r/NotUsedFor": "UsedFor",
}

_SCOPE_CUES = (
    "not ", "cannot", "can not", "unable to", "incapable of", "without ",
    "lacking ", "lacks ", "devoid of ", "never ", "no longer ", "fails to ",
    "does not ", "do not ", "having no ", "with no ", "rather than ",
)


def _cn_from_uri(uri: str) -> str:
    parts = uri.split("/")
    surface = parts[3].replace("_", " ") if len(parts) > 3 else uri
    suffix = "/".join(parts[4:]) if len(parts) > 4 else ""
    return cn_node(surface, suffix)


def load_negative_facts() -> dict[tuple[str, str], set[str]]:
    out: dict[tuple[str, str], set[str]] = defaultdict(set)
    path = ROOT / "data/processed/negative_facts.tsv"
    if not path.exists():
        return {}
    with path.open() as f:
        for line in f:
            rel, s, e = line.rstrip("\n").split("\t")
            base = NEG_REL_MAP.get(rel)
            if base:
                out[(_cn_from_uri(s), base)].add(_cn_from_uri(e))
    return dict(out)


def _stem(word: str) -> str:
    w = word.lower()
    for suf in ("ing", "es", "s"):
        if len(w) > 4 and w.endswith(suf):
            return w[: -len(suf)]
    return w


def gloss_negates(gloss: str, obj_label: str) -> str | None:
    if not gloss or not obj_label:
        return None
    head = obj_label.strip().split()[-1]
    stem = _stem(head)
    if len(stem) < 3:
        return None
    if re.search(rf"\b{re.escape(stem)}\w{{0,3}}less\b", gloss):
        return "X-less"
    if re.search(rf"\bnon-?{re.escape(stem)}\w{{0,4}}\b", gloss):
        return "non-X"
    for cue in _SCOPE_CUES:
        for m in re.finditer(re.escape(cue), gloss):
            if stem in gloss[m.end(): m.end() + 55]:
                return f"scope:{cue.strip()}"
    return None


def main() -> int:
    t0 = time.time()
    print("[probe] loading graph ...", flush=True)
    graph = ConceptGraph.load(ROOT / "data/processed/concept_graph.gpkl")
    print(f"[probe] nodes={graph.g.number_of_nodes()} edges={graph.g.number_of_edges()} "
          f"({time.time() - t0:.1f}s)", flush=True)

    from nltk.corpus import wordnet as wn

    glosses: dict[str, str] = {}
    mono: dict[str, str] = {}  # lemma surface -> wn node (monosemous nouns only)
    poly: set[str] = set()
    for syn in wn.all_synsets(pos=wn.NOUN):
        glosses[f"wn:{syn.name()}"] = syn.definition().lower()
    for lemma_name in wn.all_lemma_names(pos=wn.NOUN):
        syns = wn.synsets(lemma_name, pos=wn.NOUN)
        surface = lemma_name.replace("_", " ").lower()
        if len(syns) == 1:
            mono[surface] = f"wn:{syns[0].name()}"
        else:
            poly.add(surface)
    print(f"[probe] glosses={len(glosses)} monosemous={len(mono)} polysemous={len(poly)} "
          f"({time.time() - t0:.1f}s)", flush=True)

    negs = load_negative_facts()
    contrast: dict[str, set[str]] = defaultdict(set)
    for u, v, _k, d in graph.g.out_edges(keys=True, data=True):
        if d.get("rel") in ("Antonym", "DistinctFrom"):
            contrast[u].add(v)
            contrast[v].add(u)

    # Attribute triples on ConceptNet nodes, projected onto monosemous WordNet
    # senses. Suffixed ConceptNet URIs (cn:x|n) map to the same lemma.
    wn_attrs: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    wn_neg: dict[tuple[str, str], set[str]] = defaultdict(set)
    aligned_nodes = 0

    def surface_of(cn_id: str) -> str | None:
        if not cn_id.startswith("cn:"):
            return None
        body = cn_id[3:]
        surf, _, sfx = body.partition("|")
        if sfx and not sfx.startswith("n"):
            return None
        return surf

    for node in list(graph.g.nodes()):
        surf = surface_of(node)
        if surf is None or surf not in mono:
            continue
        wnode = mono[surf]
        if wnode not in graph.g:
            continue
        aligned_nodes += 1
        for _, tgt, _k, d in graph.g.out_edges(node, keys=True, data=True):
            rel = d.get("rel", "")
            if rel not in REL_ATTRS:
                continue
            tsurf = surface_of(tgt)
            obj_label = tsurf if tsurf else graph.label(tgt)
            if not obj_label or len(obj_label) < 3:
                continue
            wn_attrs[wnode][rel].add(obj_label)
        for (n, rel), objs in list(negs.items()):
            if n != node:
                continue
            for o in objs:
                lab = surface_of(o) or graph.label(o)
                wn_neg[(wnode, rel)].add(lab)

    print(f"[probe] aligned cn nodes={aligned_nodes} wn nodes with attrs={len(wn_attrs)} "
          f"({time.time() - t0:.1f}s)", flush=True)

    contrast_labels: dict[str, set[str]] = defaultdict(set)
    for u, vs in contrast.items():
        ul = surface_of(u) or graph.label(u)
        for v in vs:
            vl = surface_of(v) or graph.label(v)
            if ul and vl:
                contrast_labels[ul].add(vl)

    def negation_evidence(wnode: str, rel: str, obj_label: str):
        if obj_label in wn_neg.get((wnode, rel), ()):
            return ("explicit_negative_fact", f"Not{rel}(-,{obj_label})")
        pat = gloss_negates(glosses.get(wnode, ""), obj_label)
        if pat:
            return ("lexical_negation", pat)
        own = wn_attrs.get(wnode, {}).get(rel, set())
        hit = own & contrast_labels.get(obj_label, set())
        if hit:
            return ("attribute_contrast", f"{rel}(-,{sorted(hit)[0]})")
        return None

    # Parents = WordNet synsets with >=4 hyponyms.
    children: dict[str, list[str]] = defaultdict(list)
    for u, v, _k, d in graph.g.out_edges(keys=True, data=True):
        if d.get("rel") == "IsA" and u.startswith("wn:") and v.startswith("wn:"):
            children[v].append(u)
    parents = [p for p, kids in children.items() if len(kids) >= 4]
    print(f"[probe] wn parents with >=4 kids: {len(parents)}", flush=True)

    tally = Counter()
    rows = 0
    fams: set[str] = set()
    rel_tally = Counter()
    examples = []
    for pi, parent in enumerate(parents):
        kids = list(children[parent])
        # Default attribute source: parent's own attrs, or the majority of kids.
        cand_attrs: dict[str, set[str]] = defaultdict(set)
        for rel, objs in wn_attrs.get(parent, {}).items():
            cand_attrs[rel].update(objs)
        kid_counts: dict[tuple[str, str], int] = Counter()
        for kid in kids:
            for rel, objs in wn_attrs.get(kid, {}).items():
                for o in objs:
                    kid_counts[(rel, o)] += 1
        for (rel, o), c in kid_counts.items():
            if c >= 2:
                cand_attrs[rel].add(o)
        if not cand_attrs:
            continue
        for rel, objs in cand_attrs.items():
            for obj_label in objs:
                exceptions = []
                normals = []
                for kid in kids:
                    ev = negation_evidence(kid, rel, obj_label)
                    if ev:
                        exceptions.append((kid, ev))
                    else:
                        normals.append(kid)
                if len(exceptions) == 1 and len(normals) >= 3:
                    rows += 1
                    fams.add(parent)
                    tally[exceptions[0][1][0]] += 1
                    rel_tally[rel] += 1
                    if len(examples) < 12:
                        examples.append((
                            graph.label(parent), rel, obj_label,
                            graph.label(exceptions[0][0]), exceptions[0][1],
                            [graph.label(x) for x in normals[:3]],
                        ))
        if pi % 5000 == 0 and pi:
            print(f"[probe] parents={pi} rows={rows} fams={len(fams)} {dict(tally)} "
                  f"({time.time() - t0:.1f}s)", flush=True)

    print(f"[probe] DONE rows={rows} families={len(fams)} evidence={dict(tally)} "
          f"rels={dict(rel_tally)} ({time.time() - t0:.1f}s)", flush=True)
    print("[probe] examples:")
    for ex in examples:
        print("   ", ex)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
