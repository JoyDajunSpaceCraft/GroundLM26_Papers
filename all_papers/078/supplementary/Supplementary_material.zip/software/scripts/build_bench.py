#!/usr/bin/env python3
"""Build the locked DION-Bench splits and validate their semantic invariants.

Splits per task: ``train`` / ``dev`` / ``test``, plus a ``conf`` confirmatory
holdout for the two tasks the evaluation-time intervention touches. Evaluation
splits are concept-family-disjoint from training and, for OntoNeg-WN, contain
certified negation evidence only.
"""

from __future__ import annotations

import json
import random
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.bench.concept_graph import ConceptGraph
from dion.bench.concept_shift import build_concept_shift, is_clean_label
from dion.bench.logic_repair import _synthesize_logic_rows, verify_mus
from dion.bench.onto_neg_wn import (
    CERTIFIED_TIERS,
    assert_row as assert_onto_row,
    build_onto_neg_wn,
)
from dion.utils.io import save_jsonl
from dion.utils.logging_utils import get_logger

logger = get_logger("build_bench")

#: (train, dev, test, conf)
#: OntoNeg-WN evaluation splits are capped by the supply of certified negation
#: evidence, so its training pool is whatever certified + heuristic rows remain
#: after the family-disjoint holdouts are carved out.
SIZES = {
    "onto_neg_wn": (1597, 100, 500, 200),
    "concept_shift": (4000, 500, 1000, 500),
    "logic_repair": (4000, 500, 1000, 0),
}
EXPECTED_TOTAL = sum(sum(v) for v in SIZES.values())

#: Splits whose rows are used for reported numbers.
EVAL_SPLITS = ("test", "dev", "conf")


def _load_graph() -> ConceptGraph:
    cache = ROOT / "data/processed/concept_graph.gpkl"
    if not cache.exists():
        raise SystemExit(
            f"missing {cache}; run scripts/03_build_bench.sh to construct the graph"
        )
    logger.info(f"Loading cached graph {cache}")
    return ConceptGraph.load(cache)


def _logic_sig(r: dict) -> str:
    return json.dumps({"K": r["K"], "MUS": r["MUS"], "a_star": r["a_star"]}, sort_keys=True)


def _rows(out: Path, name: str) -> list[dict]:
    path = out / f"{name}.jsonl"
    return [json.loads(line) for line in path.open()] if path.exists() else []


# ----------------------------------------------------------------- validation
def _validate_onto(out: Path, graph: ConceptGraph) -> None:
    train = _rows(out, "onto_neg_wn_train")
    for split in EVAL_SPLITS:
        rows = _rows(out, f"onto_neg_wn_{split}")
        if not rows:
            raise SystemExit(f"OntoNeg {split} split missing")
        tiers = Counter(r["provenance"]["evidence_tier"] for r in rows)
        uncertified = sum(n for t, n in tiers.items() if t not in CERTIFIED_TIERS)
        if uncertified:
            raise SystemExit(f"OntoNeg {split}: {uncertified} uncertified rows ({dict(tiers)})")
        e_counts = Counter(r["E"] for r in rows)
        top_e, top_n = e_counts.most_common(1)[0]
        if top_n / len(rows) > 0.05:
            raise SystemExit(f"OntoNeg {split} external collapse: {top_e!r}={top_n}/{len(rows)}")
        if len(e_counts) < 50:
            raise SystemExit(f"OntoNeg {split} external diversity too low: {len(e_counts)}")
        if len(Counter(r["missing_relation"] for r in rows)) < 2:
            raise SystemExit(f"OntoNeg {split} relation diversity too low")
        for r in rows:
            if r["A_star"] not in r["candidates"]:
                raise SystemExit(f"OntoNeg gold missing from candidates: {r['id']}")
            if not is_clean_label(r["attribute_object_label"]):
                raise SystemExit(f"OntoNeg unclean attribute: {r['id']} {r['attribute_object_label']!r}")
            assert_onto_row(graph, r)
        logger.info(f"OntoNeg/{split} OK: n={len(rows)} tiers={dict(tiers)} externals={len(e_counts)}")

    train_fams = {r["S_id"] for r in train}
    for split in EVAL_SPLITS:
        fams = {r["S_id"] for r in _rows(out, f"onto_neg_wn_{split}")}
        if train_fams & fams:
            raise SystemExit(f"OntoNeg train/{split} family overlap: {len(train_fams & fams)}")
    test_fams = {r["S_id"] for r in _rows(out, "onto_neg_wn_test")}
    conf_fams = {r["S_id"] for r in _rows(out, "onto_neg_wn_conf")}
    if test_fams & conf_fams:
        raise SystemExit(f"OntoNeg test/conf family overlap: {len(test_fams & conf_fams)}")
    logger.info("OntoNeg family disjointness OK")


def _validate_cs(out: Path) -> None:
    train = _rows(out, "concept_shift_train")
    for split in EVAL_SPLITS:
        rows = _rows(out, f"concept_shift_{split}")
        if not rows:
            raise SystemExit(f"ConceptShift {split} split missing")
        for r in rows:
            prov = r["provenance"]
            if not prov.get("ancestor_path_T") or not prov.get("ancestor_path_A"):
                raise SystemExit(f"ConceptShift missing ancestor certificate: {r['id']}")
            if not prov.get("sense_resolved"):
                raise SystemExit(f"ConceptShift row not sense-resolved: {r['id']}")
            for key in ("T_id", "A_id", "S_id"):
                if not str(r[key]).startswith("wn:"):
                    raise SystemExit(f"ConceptShift non-synset node {key} in {r['id']}")
            if prov["ancestor_path_T"][-1] != r["S_id"] or prov["ancestor_path_A"][-1] != r["S_id"]:
                raise SystemExit(f"ConceptShift ancestor path does not end at S: {r['id']}")
            if not is_clean_label(r["S"]):
                raise SystemExit(f"ConceptShift unclean gold: {r['id']} {r['S']!r}")
            for alt in r["S_alternatives"]:
                if not is_clean_label(alt):
                    raise SystemExit(f"ConceptShift unclean alternative: {r['id']} {alt!r}")
        rels = Counter(r["relation"] for r in rows)
        sources = Counter(r["provenance"]["edge_source"] for r in rows)
        if len(rels) < 2:
            raise SystemExit(f"ConceptShift {split} relation mix degenerate: {rels}")
        logger.info(f"ConceptShift/{split} OK: n={len(rows)} rels={dict(rels)} sources={dict(sources)}")

    train_fams = {r["S_id"] for r in train}
    for split in EVAL_SPLITS:
        fams = {r["S_id"] for r in _rows(out, f"concept_shift_{split}")}
        if train_fams & fams:
            raise SystemExit(f"ConceptShift train/{split} family overlap: {len(train_fams & fams)}")
    logger.info("ConceptShift family disjointness OK")


def _validate_lr(out: Path) -> None:
    train = _rows(out, "logic_repair_train")
    test = _rows(out, "logic_repair_test")
    train_sigs = {_logic_sig(r) for r in train}
    leak = sum(1 for r in test if _logic_sig(r) in train_sigs)
    if leak:
        raise SystemExit(f"LogicRepair train/test leak: {leak}")
    sources = Counter(r["source"] for r in test)
    styles = Counter((r.get("provenance") or {}).get("surface_style") for r in test)
    mus_sizes = Counter(len(r["MUS"]) for r in test)
    encodings = Counter((r.get("certificate") or {}).get("encoding") for r in test)
    if set(sources) != {"synthetic"}:
        raise SystemExit(f"LogicRepair source must be synthetic only: {sources}")
    if styles.get("folio", 0) < 100 or styles.get("proofwriter", 0) < 100:
        raise SystemExit(f"LogicRepair surface-style mix too weak: {styles}")
    if any(sz not in {4, 5, 6} for sz in mus_sizes):
        raise SystemExit(f"LogicRepair MUS sizes out of range: {mus_sizes}")
    if encodings.get("horn_implication_chain", 0) != len(test):
        raise SystemExit(f"LogicRepair encoding mismatch: {encodings}")
    bad = sum(
        0 if verify_mus(r["K"], r["a_star"], r["target_sentence"], r["MUS"])[0] else 1
        for r in test
    )
    if bad:
        raise SystemExit(f"LogicRepair certificate failures: {bad}")
    logger.info(
        f"LogicRepair OK: leak=0 sources={dict(sources)} styles={dict(styles)} "
        f"mus={dict(mus_sizes)}"
    )


def main() -> None:
    out = ROOT / "data/bench"
    out.mkdir(parents=True, exist_ok=True)
    graph = _load_graph()
    _ = graph.hyponyms(next(iter(graph.g.nodes())))  # warm the child index

    tr, dv, te, cf = SIZES["onto_neg_wn"]
    build_onto_neg_wn(
        graph=graph, out_path=str(out),
        train_size=tr, dev_size=dv, test_size=te, conf_size=cf, seed=42,
    )

    tr, dv, te, cf = SIZES["concept_shift"]
    build_concept_shift(
        out_path=str(out), graph=graph,
        train_size=tr, dev_size=dv, test_size=te, conf_size=cf, seed=42,
    )

    tr, dv, te, _cf = SIZES["logic_repair"]
    need = tr + dv + te
    rng = random.Random(42)
    logger.info(f"Synthesizing {need * 2} LogicRepair rows ...")
    lr = _synthesize_logic_rows(need * 2, rng, verify=True)
    seen: set[str] = set()
    uniq: list[dict] = []
    for r in lr:
        sig = _logic_sig(r)
        if sig in seen:
            continue
        seen.add(sig)
        uniq.append(r)
    if len(uniq) < need:
        raise SystemExit(f"LogicRepair underfilled: {len(uniq)} < {need}")
    rng.shuffle(uniq)
    holdout, train_pool = uniq[: dv + te], uniq[dv + te:]
    splits = {
        "train": train_pool[:tr],
        "dev": holdout[:dv],
        "test": holdout[dv: dv + te],
    }
    for name, items in splits.items():
        for i, r in enumerate(items):
            r["id"] = f"logic_repair_{name}_{i:06d}"
        logger.info(f"logic_repair/{name}: {save_jsonl(out / f'logic_repair_{name}.jsonl', items)}")

    total = sum(1 for p in sorted(out.glob("*.jsonl")) for _ in p.open())
    logger.info(f"Total locked rows: {total}")
    if total != EXPECTED_TOTAL:
        raise SystemExit(f"Expected {EXPECTED_TOTAL} rows, got {total}")

    _validate_onto(out, graph)
    _validate_cs(out)
    _validate_lr(out)
    print("[bench] OK", total)


if __name__ == "__main__":
    main()
