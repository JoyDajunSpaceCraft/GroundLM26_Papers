#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"

CKPT="${1:-outputs/checkpoints/stage2/state.pt}"
OUT="${2:-outputs/eval/main_test.json}"
SPLIT="${3:-test}"

if [[ ! -f "$CKPT" ]]; then
  echo "Missing checkpoint: $CKPT" >&2
  echo "Train Stage-2 first, or pass an explicit checkpoint path as \$1." >&2
  exit 1
fi

python -m dion.evaluation.run_main_eval \
  --config configs/dion_main.yaml \
  --split "$SPLIT" \
  --ckpt "$CKPT" \
  --out "$OUT" \
  --save_items
