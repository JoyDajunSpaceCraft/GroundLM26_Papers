#!/usr/bin/env python3
"""CPU audit: count LogicRepair test items with a second minimal UNSAT subset.

Scoring in the paper is against the shipped MUS/K'. This script does not change
scores; it records whether another deletion-minimal unsatisfiable subset exists
under the same Horn encoding. Results are written under outputs/stats/.
"""
from __future__ import annotations

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.bench.logic_repair import _encode_horn_theory, _sat_unsat  # noqa: E402


def _is_minimal_unsat(sentences: list[str]) -> bool:
    if not _sat_unsat(_encode_horn_theory(sentences)):
        return False
    for i in range(len(sentences)):
        subset = sentences[:i] + sentences[i + 1 :]
        if _sat_unsat(_encode_horn_theory(subset)):
            return False
    return True


def alternate_mus_count(row: dict, *, max_extra_size: int = 6) -> int:
    """Return number of minimal UNSAT subsets of K∪{a*} other than shipped MUS."""
    K = list(row["K"])
    a_star = row["a_star"]
    shipped = frozenset(row["MUS"])
    universe = list(dict.fromkeys([*K, a_star]))
    found = 0
    # Bound search: shipped MUS sizes are 4--6; scan same band.
    for size in range(4, min(max_extra_size, len(universe)) + 1):
        for combo in combinations(universe, size):
            cand = frozenset(combo)
            if cand == shipped:
                continue
            if a_star not in cand:
                continue
            ordered = list(combo)
            if _is_minimal_unsat(ordered):
                found += 1
                if found >= 1:
                    return found
    return found


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="test")
    ap.add_argument("--limit", type=int, default=0, help="0 = all items")
    ap.add_argument(
        "--out",
        default=str(ROOT / "outputs/stats/logic_repair_mus_uniqueness.json"),
    )
    args = ap.parse_args()

    path = ROOT / "data/bench" / f"logic_repair_{args.split}.jsonl"
    rows = [json.loads(line) for line in path.open()]
    if args.limit:
        rows = rows[: args.limit]

    nonunique = []
    for i, row in enumerate(rows):
        n_alt = alternate_mus_count(row)
        if n_alt:
            nonunique.append({"id": row["id"], "alternate_minimal_subsets_ge": n_alt})
        if (i + 1) % 50 == 0:
            print(f"[mus-audit] {i+1}/{len(rows)} scanned; nonunique={len(nonunique)}")

    report = {
        "split": args.split,
        "n_scanned": len(rows),
        "n_with_alternate_minimal_subset": len(nonunique),
        "rate": (len(nonunique) / len(rows)) if rows else 0.0,
        "scoring_note": "Paper scores against shipped gold; uniqueness not claimed.",
        "examples": nonunique[:20],
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
