#!/usr/bin/env python3
"""Mine WordNet glosses for dictionary-attested attribute exceptions.

For every noun synset whose gloss explicitly denies an attribute (``flightless``,
``without seeds``, ``unable to fly``, ...), we recover the denied attribute and
check that the synset has a hypernym with at least three co-hyponyms whose
glosses do not deny the same attribute. Those configurations give an inner
negation whose gold answer is certified by a dictionary definition rather than
by a missing knowledge-graph edge.
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict


LESS_RE = re.compile(r"\b([a-z]{3,})less\b")
WITHOUT_RE = re.compile(
    r"\b(?:without|lacking|lacks|devoid of|having no|with no|not having|free of|free from)\s+"
    r"((?:a |an |the )?[a-z][a-z\- ]{2,30})"
)
UNABLE_RE = re.compile(
    r"\b(?:unable to|incapable of|cannot|can not|not able to|does not|do not|not capable of|never)\s+"
    r"([a-z][a-z\- ]{2,30})"
)
NON_RE = re.compile(r"\bnon-?([a-z]{4,})\b")

STOP_TAIL = {
    "a", "an", "the", "of", "or", "and", "in", "on", "to", "for", "with", "by",
    "any", "its", "their", "other", "such", "some", "that", "which", "who",
}


def clean_phrase(p: str) -> str:
    p = p.strip().strip(",;:.")
    p = re.sub(r"^(a|an|the)\s+", "", p)
    toks = [t for t in p.split() if t]
    while toks and toks[-1] in STOP_TAIL:
        toks.pop()
    return " ".join(toks[:3])


def main() -> int:
    from nltk.corpus import wordnet as wn

    gloss = {}
    for syn in wn.all_synsets(pos=wn.NOUN):
        gloss[syn.name()] = syn.definition().lower()
    print(f"[gloss] noun synsets={len(gloss)}")

    hits: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    pat_tally = Counter()
    for name, g in gloss.items():
        for m in LESS_RE.finditer(g):
            stem = m.group(1)
            if len(stem) < 3:
                continue
            hits[name].append(("X-less", stem, m.group(0)))
            pat_tally["X-less"] += 1
        for m in WITHOUT_RE.finditer(g):
            ph = clean_phrase(m.group(1))
            if ph:
                hits[name].append(("without-X", ph, m.group(0)))
                pat_tally["without-X"] += 1
        for m in UNABLE_RE.finditer(g):
            ph = clean_phrase(m.group(1))
            if ph:
                hits[name].append(("unable-X", ph, m.group(0)))
                pat_tally["unable-X"] += 1
        for m in NON_RE.finditer(g):
            hits[name].append(("non-X", m.group(1), m.group(0)))
            pat_tally["non-X"] += 1

    print(f"[gloss] synsets with a negation cue={len(hits)} patterns={dict(pat_tally)}")

    # Require: a hypernym with >=2 co-hyponyms whose glosses do not carry the same
    # denial, so the exception is unique among the emitted candidates.
    viable = 0
    fam = set()
    ev_tally = Counter()
    per_astar = Counter()
    examples = []
    for name, evs in hits.items():
        syn = wn.synset(name)
        for hyper in syn.hypernyms():
            sibs = [s for s in hyper.hyponyms() if s.name() != name]
            if len(sibs) < 2:
                continue
            seen_attr = set()
            for kind, attr, surface in evs:
                stem = attr.split()[-1]
                stem = stem[:-1] if stem.endswith("s") and len(stem) > 4 else stem
                if len(stem) < 3 or stem in seen_attr:
                    continue
                clean_sibs = []
                for s in sibs:
                    sg = gloss.get(s.name(), "")
                    if re.search(rf"\b{re.escape(stem)}\w{{0,3}}less\b", sg):
                        continue
                    if re.search(
                        rf"\b(?:without|lacking|lacks|unable to|cannot|non-?)\s*\w{{0,6}}"
                        rf"{re.escape(stem)}", sg
                    ):
                        continue
                    clean_sibs.append(s)
                if len(clean_sibs) >= 2:
                    seen_attr.add(stem)
                    viable += 1
                    fam.add(hyper.name())
                    ev_tally[kind] += 1
                    per_astar[name] += 1
                    if len(examples) < 15:
                        examples.append((
                            hyper.name(), name, kind, attr, surface,
                            [s.name() for s in clean_sibs[:2]],
                        ))
    print(f"[gloss] viable rows={viable} families={len(fam)} evidence={dict(ev_tally)}")
    print(f"[gloss] distinct A*={len(per_astar)} max rows per A*={max(per_astar.values()) if per_astar else 0}")
    for e in examples:
        print("   ", e)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
