#!/usr/bin/env bash
# Watchdog for run_gpu_backlog_queue.sh — detect FAIL / stall / death and log alerts.
set -uo pipefail
cd "$(dirname "$0")/.."
LOGDIR=outputs/gpu_backlog_logs
ALERT="$LOGDIR/watchdog_alerts.log"
STATE="$LOGDIR/watchdog_state.env"
mkdir -p "$LOGDIR"
QUEUE_PID="${QUEUE_PID:-509964}"
POLL_SEC="${POLL_SEC:-90}"
STALL_MIN="${STALL_MIN:-70}"  # eval can be silent ~45–55 min

log() { echo "[$(date -Is)] $*" | tee -a "$ALERT"; }

LAST_MARK=""
LAST_CHANGE_TS=$(date +%s)
LAST_FAIL_COUNT=0
LAST_GPU_MEM=""

while true; do
  LOG=$(ls -t "$LOGDIR"/queue_*.log 2>/dev/null | head -1 || true)
  if [[ -z "$LOG" ]]; then
    log "WARN no queue log yet"
    sleep "$POLL_SEC"
    continue
  fi

  alive=0
  if kill -0 "$QUEUE_PID" 2>/dev/null; then alive=1; fi
  # Descendants (bash → python), not just direct children
  child=$(pgrep -P "$QUEUE_PID" -a 2>/dev/null | head -5 || true)
  py=$(pgrep -af "dion\.(baselines|training|evaluation)|run_retention_eval|run_csd_intervention" 2>/dev/null | grep -v pgrep | head -3 || true)
  gpu=$(nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader 2>/dev/null | head -1)
  gpu_mem=$(echo "$gpu" | awk -F', ' '{print $2}')

  # progress mark: last TRAIN/EVAL/DONE/step/Phase line
  mark=$(rg -n "TRAIN |EVAL |DONE |FAIL |Phase |step [0-9]+/|RETENTION |finished" "$LOG" 2>/dev/null | tail -1 || true)
  fail_n=$(rg -c "^\[.*\] FAIL |error: unrecognized|Traceback \(most recent call last\)" "$LOG" 2>/dev/null || echo 0)
  # normalize fail_n
  fail_n=${fail_n//$'\n'/}
  fail_n=${fail_n:-0}

  now=$(date +%s)
  # Log line change OR active python worker OR GPU memory churn → not stalled
  if [[ "$mark" != "$LAST_MARK" ]] || [[ -n "$py" && "$gpu_mem" != "$LAST_GPU_MEM" ]]; then
    LAST_MARK="$mark"
    LAST_CHANGE_TS=$now
  fi
  # If a python worker is alive and GPU mem > 2GB, treat as alive progress even if quiet
  mem_mib=$(echo "$gpu_mem" | tr -dc '0-9')
  if [[ -n "$py" && -n "$mem_mib" && "$mem_mib" -gt 2000 ]]; then
    LAST_CHANGE_TS=$now
  fi
  LAST_GPU_MEM="$gpu_mem"
  idle_min=$(( (now - LAST_CHANGE_TS) / 60 ))

  # new failures since last poll
  if [[ "$fail_n" =~ ^[0-9]+$ ]] && (( fail_n > LAST_FAIL_COUNT )); then
    log "ALERT new FAIL count $LAST_FAIL_COUNT -> $fail_n | last: $mark"
    rg -n "FAIL |error: unrecognized|Traceback|Error" "$LOG" | tail -20 >> "$ALERT"
    LAST_FAIL_COUNT=$fail_n
  fi

  if (( alive == 0 )); then
    # queue ended — check if finished cleanly
    if rg -q "GPU backlog queue finished" "$LOG"; then
      log "OK queue finished cleanly | $mark"
      echo "FINISHED $(date -Is)" > "$STATE"
      exit 0
    else
      log "ALERT queue pid $QUEUE_PID dead without finish marker | $mark | gpu=$gpu"
      echo "DEAD $(date -Is)" > "$STATE"
      exit 2
    fi
  fi

  if (( idle_min >= STALL_MIN )); then
    log "ALERT stall ${idle_min}min no progress | alive=$alive | gpu=$gpu | $mark | child=$child"
  else
    # heartbeat every poll to a separate status file (not alert spam)
    printf '%s\n' "ts=$(date -Is)" "alive=$alive" "idle_min=$idle_min" "fail_n=$fail_n" "gpu=$gpu" "mark=$mark" "child=$child" > "$LOGDIR/watchdog_status.txt"
  fi

  sleep "$POLL_SEC"
done
