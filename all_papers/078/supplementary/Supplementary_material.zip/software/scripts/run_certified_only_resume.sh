#!/usr/bin/env bash
# Resume after sr_s42 train succeeded; eval failed due to injection hook.
set -uo pipefail
cd "$(dirname "$0")/.."
export MODELS_DIR="${MODELS_DIR:-/export/models}"
export PYTHONPATH=src
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

LOGDIR=outputs/certified_only_logs
mkdir -p "$LOGDIR"
STAMP=$(date +%Y%m%d_%H%M%S)
exec > >(tee -a "$LOGDIR/resume_${STAMP}.log") 2>&1

TRAIN=data/bench/onto_neg_wn_train.jsonl
CERT=data/bench/onto_neg_wn_train_certified_only.jsonl
BAK=data/bench/onto_neg_wn_train.mixed.bak.jsonl

restore() {
  if [[ -f "$BAK" ]]; then
    mv -f "$BAK" "$TRAIN"
    echo "[$(date -Is)] restored mixed train pool"
  fi
}
trap restore EXIT

if [[ ! -f "$BAK" ]]; then
  cp -f "$TRAIN" "$BAK"
fi
cp -f "$CERT" "$TRAIN"
echo "[$(date -Is)] resume certified-only queue ($(wc -l < "$TRAIN") rows)"

run_train() {
  local label="$1"; shift
  local out="$1"; shift
  if [[ -f "$out" ]]; then
    echo "[$(date -Is)] SKIP train $label (exists $out)"
    return 0
  fi
  echo "[$(date -Is)] TRAIN $label"
  "$@" || { echo "[$(date -Is)] FAIL train $label"; return 1; }
  echo "[$(date -Is)] DONE train $label"
}

run_eval() {
  local label="$1" cfg="$2" ckpt="$3" stem="$4"
  if [[ ! -f "$ckpt" ]]; then
    echo "[$(date -Is)] SKIP eval $label (missing ckpt)"; return 0
  fi
  if [[ -f "${stem}_test.json" ]]; then
    echo "[$(date -Is)] SKIP eval $label (exists)"; return 0
  fi
  echo "[$(date -Is)] EVAL $label"
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test --save_items --out "${stem}_test.json" || return 1
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split conf --save_items --out "${stem}_conf.json" || return 1
  echo "[$(date -Is)] DONE eval $label"
}

# Eval existing sr_s42 first
run_eval "sr_s42" configs/certified_only/sr_s42.yaml \
  outputs/certified_only/self_rewarding_s42/self_rewarding_strict/state.pt \
  outputs/certified_only/self_rewarding_s42 || true

for seed in 43 44; do
  cfg="configs/certified_only/sr_s${seed}.yaml"
  ckpt="outputs/certified_only/self_rewarding_s${seed}/self_rewarding_strict/state.pt"
  run_train "sr_s${seed}" "$ckpt" \
    python -m dion.baselines.self_rewarding --config "$cfg" --judge_variant strict --seed "$seed" || true
  run_eval "sr_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/self_rewarding_s${seed}" || true
done

cfg=configs/certified_only/sc_s42.yaml
ckpt=outputs/certified_only/self_critique_s42/self_critique/state.pt
run_train "sc_s42" "$ckpt" python -m dion.baselines.self_critique --config "$cfg" || true
run_eval "sc_s42" "$cfg" "$ckpt" "outputs/certified_only/self_critique_s42" || true

cfg=configs/certified_only/em_s42.yaml
ckpt=outputs/certified_only/entropy_min_s42/entropy_min/state.pt
run_train "em_s42" "$ckpt" python -m dion.baselines.entropy_min --config "$cfg" || true
run_eval "em_s42" "$cfg" "$ckpt" "outputs/certified_only/entropy_min_s42" || true

cfg=configs/certified_only/sft_s42.yaml
ckpt=outputs/certified_only/sft_lora_s42/sft_lora/state.pt
run_train "sft_s42" "$ckpt" python -m dion.baselines.sft_lora --config "$cfg" || true
run_eval "sft_s42" "$cfg" "$ckpt" "outputs/certified_only/sft_lora_s42" || true

cfg=configs/certified_only/lorakl_s42.yaml
ckpt=outputs/certified_only/lora_kl_s42/stage2_abo/abo_state.pt
run_train "lorakl_s42" "$ckpt" python -m dion.training.stage2_abo --config "$cfg" || true
run_eval "lorakl_s42" "$cfg" "$ckpt" "outputs/certified_only/lora_kl_s42" || true

python3 scripts/summarize_certified_evals.py || true
echo "[$(date -Is)] resume queue finished"
