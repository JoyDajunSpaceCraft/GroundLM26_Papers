#!/usr/bin/env python3
"""Summarize certified-only eval JSONs into LaTeX + markdown with multi-seed stats."""
from __future__ import annotations

import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "certified_only"
PAPER_TAB = ROOT / "paper" / "tables" / "certified_only.tex"
NUMBERS = ROOT / "paper" / "tables" / "numbers_certified.tex"

METHODS = [
    ("Self-Rewarding", "self_rewarding"),
    ("Self-Critique", "self_critique"),
    ("Entropy-Min", "entropy_min"),
    ("SFT-LoRA", "sft_lora"),
    ("Shuffled-DPO", "shuffled_dpo"),
    ("LoRA+KL", "lora_kl"),
]


def metrics(path: Path):
    d = json.loads(path.read_text())
    ina = float(d["INA"])
    absacc = float(d["AbsAcc"])
    oer = float(d.get("OER", 0.0))
    if ina <= 1:
        ina *= 100
        absacc *= 100
        oer *= 100
    return ina, absacc, oer


def mean_sd(xs):
    if len(xs) == 1:
        return xs[0], 0.0
    return statistics.mean(xs), statistics.stdev(xs)


def collect(stem_prefix: str):
    rows = []
    for seed in (42, 43, 44):
        p = OUT / f"{stem_prefix}_s{seed}_test.json"
        if not p.exists():
            continue
        ina, absacc, oer = metrics(p)
        rows.append((seed, ina, absacc, oer))
    return rows


def main():
    md = ["# Certified-only summary", "", "| run | INA | AbsAcc | pool |", "|---|---:|---:|---|"]
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\small",
        r"\setlength{\tabcolsep}{3.5pt}",
        r"\begin{tabular}{lcc}",
        r"\toprule",
        r"\textbf{Run (certified-only train)} & \textbf{OntoNeg INA} & \textbf{ConceptShift AbsAcc} \\",
        r"\midrule",
        r"Base (reference) & $26.40$ & $59.50$ \\",
        r"Self-Rewarding mixed ledger & $31.67$ & $22.00$ \\",
        r"\midrule",
    ]
    macros = []
    for name, pref in METHODS:
        rows = collect(pref)
        if not rows:
            continue
        for seed, ina, absacc, _ in rows:
            md.append(f"| {name} s{seed} | {ina:.2f} | {absacc:.2f} | certified-only |")
        inas = [r[1] for r in rows]
        abss = [r[2] for r in rows]
        m_ina, s_ina = mean_sd(inas)
        m_abs, s_abs = mean_sd(abss)
        if len(rows) >= 2:
            lines.append(
                rf"{name} (${len(rows)}$ seeds) & ${m_ina:.2f}_{{\pm {s_ina:.2f}}}$ & ${m_abs:.2f}_{{\pm {s_abs:.2f}}}$ \\"
            )
            lines.append(
                rf"{{\scriptsize $\Delta$ vs Base}} & {{\scriptsize ${m_ina-26.40:+.2f}$}} & {{\scriptsize ${m_abs-59.50:+.2f}$}} \\"
            )
        else:
            seed, ina, absacc, _ = rows[0]
            lines.append(rf"{name} s{seed} & ${ina:.2f}$ & ${absacc:.2f}$ \\")
        slug = "".join(w.capitalize() for w in pref.split("_"))
        macros += [
            f"\\newcommand{{\\cert{slug}Ina}}{{{m_ina:.2f}}}",
            f"\\newcommand{{\\cert{slug}InaSd}}{{{s_ina:.2f}}}",
            f"\\newcommand{{\\cert{slug}Abs}}{{{m_abs:.2f}}}",
            f"\\newcommand{{\\cert{slug}AbsSd}}{{{s_abs:.2f}}}",
            f"\\newcommand{{\\cert{slug}Seeds}}{{{len(rows)}}}",
        ]

    lines += [
        r"\bottomrule",
        r"\end{tabular}",
        r"\caption{Certified-only OntoNeg training ($284$ rows; no \texttt{kg\_edge\_absence}). "
        r"Means$\pm$s.d.\ over completed seeds; all methods show OntoNeg gain with ConceptShift collapse. "
        r"Main Table~\ref{tab:main} remains the mixed-pool multi-method ledger.}",
        r"\label{tab:certified-only}",
        r"\end{table}",
        "",
    ]
    PAPER_TAB.write_text("\n".join(lines))
    (OUT / "summary.md").write_text("\n".join(md) + "\n")
    # Keep legacy SR macro names used by Round-21 body text.
    sr = collect("self_rewarding")
    if sr:
        m_ina, s_ina = mean_sd([r[1] for r in sr])
        m_abs, s_abs = mean_sd([r[2] for r in sr])
        macros = [
            f"\\newcommand{{\\certSrIna}}{{{m_ina:.2f}}}",
            f"\\newcommand{{\\certSrInaSd}}{{{s_ina:.2f}}}",
            f"\\newcommand{{\\certSrAbs}}{{{m_abs:.2f}}}",
            f"\\newcommand{{\\certSrAbsSd}}{{{s_abs:.2f}}}",
            f"\\newcommand{{\\certSrGain}}{{{m_ina-26.40:+.2f}}}",
            f"\\newcommand{{\\certSrCollapse}}{{{m_abs-59.50:+.2f}}}",
            f"\\newcommand{{\\certSrSeeds}}{{{len(sr)}}}",
            "",
        ] + macros
    NUMBERS.write_text("\n".join(macros) + "\n")
    print(NUMBERS.read_text())
    print((OUT / "summary.md").read_text())


if __name__ == "__main__":
    main()
