#!/usr/bin/env bash
# Frontier LLM zero-shot and few-shot evaluation on OntoNeg-WN (V4).
#
# Requires DION_JUDGE_BASE and DION_JUDGE_KEY environment variables
# for API access to the frontier models.
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"
python -m dion.evaluation.frontier_eval --split test --n 500
