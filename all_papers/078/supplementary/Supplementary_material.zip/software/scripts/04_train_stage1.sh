#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"
export TOKENIZERS_PARALLELISM=false
python -u -m dion.training.stage1_cph --config configs/dion_main.yaml
