#!/usr/bin/env bash
# Resume after main queue died at shuf_s44 (mid-file edit syntax error).
# Runs: LoRA+KL ×3 → mixed SR + CSD → retention. Optionally waits for WAIT_PID.
set -uo pipefail
cd "$(dirname "$0")/.."
export MODELS_DIR="${MODELS_DIR:-/export/models}"
export PYTHONPATH=src
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export HF_HOME="${HF_HOME:-/export/.hf_cache}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/export/.hf_cache/datasets}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_DATASETS_OFFLINE="${HF_DATASETS_OFFLINE:-1}"
export HF_HUB_OFFLINE="${HF_HUB_OFFLINE:-1}"

LOGDIR=outputs/gpu_backlog_logs
mkdir -p "$LOGDIR" outputs/certified_only outputs/mixed_pool outputs/predictions/csd_true_lp outputs/retention
STAMP=$(date +%Y%m%d_%H%M%S)
exec > >(tee -a "$LOGDIR/resume_tail_${STAMP}.log") 2>&1

if [[ -n "${WAIT_PID:-}" ]]; then
  echo "[$(date -Is)] waiting for pid $WAIT_PID before resume tail"
  while kill -0 "$WAIT_PID" 2>/dev/null; do sleep 60; done
  echo "[$(date -Is)] wait done"
fi

echo "[$(date -Is)] === resume tail: LoRA+KL / mixed SR / retention ==="

TRAIN=data/bench/onto_neg_wn_train.jsonl
CERT=data/bench/onto_neg_wn_train_certified_only.jsonl
BAK=data/bench/onto_neg_wn_train.mixed.bak.jsonl
restore_train() { [[ -f "$BAK" ]] && mv -f "$BAK" "$TRAIN" && echo "[$(date -Is)] restored mixed train"; }
trap restore_train EXIT

run_train() {
  local label="$1"; shift; local out="$1"; shift
  [[ -f "$out" ]] && { echo "[$(date -Is)] SKIP train $label"; return 0; }
  echo "[$(date -Is)] TRAIN $label"
  "$@" || { echo "[$(date -Is)] FAIL train $label"; return 1; }
  echo "[$(date -Is)] DONE train $label"
}
run_eval_test() {
  local label="$1" cfg="$2" ckpt="$3" stem="$4"
  [[ -f "$ckpt" ]] || { echo "SKIP eval $label"; return 0; }
  [[ -f "${stem}_test.json" ]] && { echo "SKIP eval $label"; return 0; }
  echo "[$(date -Is)] EVAL $label"
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test \
    --save_items --out "${stem}_test.json" || echo "[$(date -Is)] FAIL eval $label"
}

# Ensure certified pool for LoRA+KL
[[ -f "$BAK" ]] || cp -f "$TRAIN" "$BAK"
cp -f "$CERT" "$TRAIN"
echo "[$(date -Is)] train pool = certified-only ($(wc -l < "$TRAIN") rows)"

for seed in 42 43 44; do
  cfg="configs/certified_only/lorakl_s${seed}.yaml"
  # ensure gc off
  python3 - <<PY
import yaml
from pathlib import Path
p=Path("$cfg")
c=yaml.safe_load(p.read_text())
c.setdefault("train",{})["gradient_checkpointing"]=False
c["model"]["attn_implementation"]="sdpa"
p.write_text(yaml.safe_dump(c, sort_keys=False))
PY
  ckpt="outputs/certified_only/lora_kl_s${seed}/stage2_abo/abo_state.pt"
  run_train "lorakl_s${seed}" "$ckpt" python -m dion.training.stage2_abo --config "$cfg" || true
  run_eval_test "lorakl_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/lora_kl_s${seed}"
done

restore_train
trap - EXIT
restore_train || true

echo "[$(date -Is)] === Phase C: mixed-pool SR s42 + true-logprob CSD ==="
cfg=configs/certified_only/mixed_sr_s42.yaml
ckpt=outputs/mixed_pool/self_rewarding_s42/self_rewarding_strict/state.pt
run_train "mixed_sr_s42" "$ckpt" \
  python -m dion.baselines.self_rewarding --config "$cfg" --judge_variant strict --seed 42 || true
PARENT_MIX=outputs/predictions/csd_true_lp/self_rewarding_strict_mixed_s42_test.json
PM=outputs/predictions/csd_true_lp/self_rewarding_strict_mixed_s42_test.items.jsonl
if [[ -f "$ckpt" && ! -f "$PM" ]]; then
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test \
    --save_items --save_csd_parent --out "$PARENT_MIX" || true
fi
if [[ -f "$PM" ]]; then
  python scripts/run_csd_intervention.py --parent "$PM" \
    --out outputs/predictions/csd_true_lp/self_rewarding_csd_mixed_true_lp_items.jsonl || true
fi

python3 scripts/summarize_certified_evals.py || true

echo "[$(date -Is)] === Phase D: per-seed external retention ==="
for seed in 42 43 44; do
  out="outputs/retention/base_s${seed}.json"
  if [[ ! -f "$out" ]]; then
    echo "[$(date -Is)] RETENTION base s${seed}"
    python scripts/run_retention_eval.py --config configs/dion_sft_lora.yaml \
      --label base --seed "$seed" --out "$out" || echo "FAIL retention base s${seed}"
  fi
done
for seed in 42 43 44; do
  out="outputs/retention/self_rewarding_strict_s${seed}.json"
  ckpt="outputs/certified_only/self_rewarding_s${seed}/self_rewarding_strict/state.pt"
  if [[ -f "$ckpt" && ! -f "$out" ]]; then
    echo "[$(date -Is)] RETENTION SR s${seed}"
    python scripts/run_retention_eval.py --config "configs/certified_only/sr_s${seed}.yaml" \
      --ckpt "$ckpt" --label self_rewarding_strict --seed "$seed" --out "$out" || echo "FAIL retention SR"
  fi
done
if [[ -f outputs/certified_only/self_critique_s42/self_critique/state.pt \
   && ! -f outputs/retention/self_critique_s42.json ]]; then
  python scripts/run_retention_eval.py --config configs/certified_only/sc_s42.yaml \
    --ckpt outputs/certified_only/self_critique_s42/self_critique/state.pt \
    --label self_critique --seed 42 --out outputs/retention/self_critique_s42.json || true
fi

python3 - <<'PY'
import json, statistics
from pathlib import Path
from collections import defaultdict
root = Path("outputs/retention")
by = defaultdict(lambda: defaultdict(list))
for p in sorted(root.glob("*.json")):
    if p.name.startswith("summary"): continue
    d = json.loads(p.read_text())
    for task, v in d.get("tasks", {}).items():
        by[d["label"]][task].append(float(v["score"]))
rows = {}
for lab, tasks in by.items():
    rows[lab] = {}
    for task, xs in tasks.items():
        rows[lab][task] = {
            "mean": statistics.mean(xs),
            "sd": statistics.stdev(xs) if len(xs) > 1 else 0.0,
            "n_seeds": len(xs),
            "seeds": xs,
        }
(root / "summary_seed_sd.json").write_text(json.dumps(rows, indent=2))
print("wrote summary_seed_sd.json", {k: list(v) for k,v in rows.items()})
PY

echo "[$(date -Is)] resume tail finished"
