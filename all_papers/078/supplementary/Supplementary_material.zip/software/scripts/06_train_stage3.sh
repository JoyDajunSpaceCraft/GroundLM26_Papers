#!/usr/bin/env bash
# Stage 3 (DIPO) is included as a negative ablation; the headline configs set
# train.stage3_steps=0 so this stage is a no-op by default. Set a positive
# stage3_steps in the chosen config to reproduce the negative ablation.
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"
export TOKENIZERS_PARALLELISM=false
python -u -m dion.training.stage3_dipo --config configs/dion_main.yaml
