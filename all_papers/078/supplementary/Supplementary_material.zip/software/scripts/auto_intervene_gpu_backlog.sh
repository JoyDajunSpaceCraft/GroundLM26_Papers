#!/usr/bin/env bash
# Overnight auto-intervene: watch queue log for NEW failures and act.
set -uo pipefail
cd "$(dirname "$0")/.."
LOGDIR=outputs/gpu_backlog_logs
ALERT="$LOGDIR/auto_intervene.log"
QUEUE_PID="${QUEUE_PID:-509964}"
LAST_LINE=0
mkdir -p "$LOGDIR"

log() { echo "[$(date -Is)] $*" | tee -a "$ALERT"; }

log "auto-intervene started queue_pid=$QUEUE_PID"

while true; do
  LOG=$(ls -t "$LOGDIR"/queue_*.log 2>/dev/null | head -1 || true)
  if [[ -z "$LOG" ]]; then sleep 60; continue; fi

  if ! kill -0 "$QUEUE_PID" 2>/dev/null; then
    if rg -q "GPU backlog queue finished" "$LOG"; then
      log "OK main queue finished"
    else
      log "ALERT main queue died without finish marker"
    fi
    # Ensure missed SC/EM/SFT runs
    if ! pgrep -f run_gpu_backlog_missed_sc_em_sft >/dev/null; then
      log "launching missed SC/EM/SFT resume"
      nohup bash scripts/run_gpu_backlog_missed_sc_em_sft.sh >> "$LOGDIR/missed_auto.log" 2>&1 &
    fi
    exit 0
  fi

  # Scan new lines only
  total=$(wc -l < "$LOG")
  if (( total > LAST_LINE )); then
    new=$(sed -n "$((LAST_LINE+1)),${total}p" "$LOG")
    LAST_LINE=$total
    if echo "$new" | rg -q "FAIL train lorakl|grad_fn|inplace operation"; then
      log "ALERT LoRA+KL failure detected — stage2 should already be patched; dumping tail"
      echo "$new" | rg -n "FAIL|Traceback|Error|lorakl" | tee -a "$ALERT" | tail -40
    fi
    if echo "$new" | rg -q "unrecognized arguments: --seed"; then
      log "ALERT seed CLI failure — baselines patched; missed script will cover"
    fi
    if echo "$new" | rg -q "Network is unreachable|Connection reset|huggingface.co"; then
      log "ALERT HF network issue during job — retention script uses offline cache"
    fi
    if echo "$new" | rg -q "DONE eval shuf_s44|TRAIN lorakl_s42"; then
      log "INFO entering LoRA+KL phase — high-risk, watching closely"
    fi
    if echo "$new" | rg -q "DONE train lorakl_s42"; then
      log "OK lorakl_s42 train succeeded"
    fi
    if echo "$new" | rg -q "Phase D: per-seed external retention"; then
      log "INFO retention phase — verifying HF offline env in child"
    fi
    if echo "$new" | rg -q "GPU backlog queue finished"; then
      log "OK finish marker seen"
    fi
  fi

  # Refresh STATUS.md
  mark=$(rg -n "TRAIN |EVAL |DONE |FAIL |Phase |step [0-9]+/" "$LOG" 2>/dev/null | tail -1 || true)
  py=$(pgrep -af "dion\.(baselines|training|evaluation)|run_retention" 2>/dev/null | grep -v pgrep | head -1 || true)
  gpu=$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader 2>/dev/null | head -1)
  cat > "$LOGDIR/STATUS.md" <<EOF
# GPU backlog status (auto)
Updated: $(date -Is)

- queue_pid: $QUEUE_PID (alive=$(kill -0 $QUEUE_PID 2>/dev/null && echo yes || echo no))
- gpu0: $gpu
- mark: $mark
- worker: $py
EOF

  sleep 90
done
