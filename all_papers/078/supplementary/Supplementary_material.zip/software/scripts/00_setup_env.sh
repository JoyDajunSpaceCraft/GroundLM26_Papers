#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"

echo "[setup] installing pip dependencies ..."
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
pip install -e .

python - <<'PY'
import nltk
from nltk.corpus import wordnet as wn

for name in ("wordnet", "omw-1.4"):
    nltk.download(name, quiet=True)
# Fail closed: WordNet must be importable after download.
assert wn.synsets("dog"), "NLTK WordNet corpus missing after download"
print("[setup] NLTK WordNet OK:", len(list(wn.all_synsets())) , "synsets")
PY
echo "[setup] done."
