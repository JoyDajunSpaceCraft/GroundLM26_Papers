#!/usr/bin/env bash
# Round-21 GPU backlog on CUDA device 0 (device 1 often holds a long-lived vLLM).
# Order: true-logprob CSD parents → certified multi-seed expand → mixed SR CSD
# → external retention per-seed (Base + SR + SC).
set -uo pipefail
cd "$(dirname "$0")/.."
export MODELS_DIR="${MODELS_DIR:-/export/models}"
export PYTHONPATH=src
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
# Retention / HF datasets: shared server cache; prefer offline to avoid Hub IPv6 hangs.
export HF_HOME="${HF_HOME:-/export/.hf_cache}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/export/.hf_cache/datasets}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
if [[ "${HF_FORCE_ONLINE:-0}" != "1" ]]; then
  export HF_DATASETS_OFFLINE="${HF_DATASETS_OFFLINE:-1}"
  export HF_HUB_OFFLINE="${HF_HUB_OFFLINE:-1}"
fi

LOGDIR=outputs/gpu_backlog_logs
mkdir -p "$LOGDIR" configs/certified_only outputs/certified_only \
  outputs/predictions/csd_true_lp outputs/mixed_pool outputs/retention
STAMP=$(date +%Y%m%d_%H%M%S)
MAINLOG="$LOGDIR/queue_${STAMP}.log"
exec > >(tee -a "$MAINLOG") 2>&1

echo "[$(date -Is)] GPU backlog queue CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

TRAIN=data/bench/onto_neg_wn_train.jsonl
CERT=data/bench/onto_neg_wn_train_certified_only.jsonl
BAK=data/bench/onto_neg_wn_train.mixed.bak.jsonl

restore_train() {
  if [[ -f "$BAK" ]]; then
    mv -f "$BAK" "$TRAIN"
    echo "[$(date -Is)] restored mixed train pool"
  fi
}
trap restore_train EXIT

swap_cert() {
  if [[ ! -f "$BAK" ]]; then
    cp -f "$TRAIN" "$BAK"
  fi
  cp -f "$CERT" "$TRAIN"
  echo "[$(date -Is)] train pool = certified-only ($(wc -l < "$TRAIN") rows)"
}

python3 - <<'PY'
import yaml
from pathlib import Path
from copy import deepcopy

def write_cfg(src, out_name, seed, out_dir, **train_extra):
    cfg = yaml.safe_load(Path(src).read_text())
    cfg = deepcopy(cfg)
    cfg["seed"] = seed
    cfg["out_dir"] = out_dir
    cfg["model"]["backbone"] = "${MODELS_DIR}/Qwen3-8B-Base"
    cfg["model"]["attn_implementation"] = "sdpa"
    for k, v in train_extra.items():
        cfg.setdefault("train", {})[k] = v
    if "lora_kl" in out_dir or "lorakl" in out_name:
        cfg.setdefault("train", {})["gradient_checkpointing"] = False
    path = Path("configs/certified_only") / out_name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(cfg, sort_keys=False))
    print("wrote", path)

for seed in (42, 43, 44):
    write_cfg("configs/dion_sft_lora.yaml", f"sr_s{seed}.yaml", seed, f"outputs/certified_only/self_rewarding_s{seed}")
    write_cfg("configs/dion_sft_lora.yaml", f"sc_s{seed}.yaml", seed, f"outputs/certified_only/self_critique_s{seed}")
    write_cfg("configs/dion_sft_lora.yaml", f"em_s{seed}.yaml", seed, f"outputs/certified_only/entropy_min_s{seed}")
    write_cfg("configs/dion_sft_lora.yaml", f"sft_s{seed}.yaml", seed, f"outputs/certified_only/sft_lora_s{seed}")
    write_cfg("configs/dion_sft_lora.yaml", f"shuf_s{seed}.yaml", seed, f"outputs/certified_only/shuffled_dpo_s{seed}")
    write_cfg("configs/dion_lora_kl.yaml", f"lorakl_s{seed}.yaml", seed, f"outputs/certified_only/lora_kl_s{seed}",
              gradient_checkpointing=False)
write_cfg("configs/dion_sft_lora.yaml", "mixed_sr_s42.yaml", 42, "outputs/mixed_pool/self_rewarding_s42")
PY

run_train() {
  local label="$1"; shift
  local out="$1"; shift
  if [[ -f "$out" ]]; then
    echo "[$(date -Is)] SKIP train $label (exists $out)"
    return 0
  fi
  echo "[$(date -Is)] TRAIN $label"
  if ! "$@"; then
    echo "[$(date -Is)] FAIL train $label"
    return 1
  fi
  echo "[$(date -Is)] DONE train $label"
}

run_eval_test() {
  local label="$1" cfg="$2" ckpt="$3" stem="$4"
  if [[ ! -f "$ckpt" ]]; then
    echo "[$(date -Is)] SKIP eval $label (missing ckpt)"
    return 0
  fi
  if [[ -f "${stem}_test.json" ]]; then
    echo "[$(date -Is)] SKIP eval $label (exists)"
    return 0
  fi
  echo "[$(date -Is)] EVAL test $label"
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test \
    --save_items --out "${stem}_test.json" || {
    echo "[$(date -Is)] FAIL eval $label"; return 1;
  }
  echo "[$(date -Is)] DONE eval $label"
}

# ---------- Phase A: true-logprob CSD parents (existing certified SR s42) ----------
echo "[$(date -Is)] === Phase A: CSD true-logprob parents (certified SR s42) ==="
CFG=configs/certified_only/sr_s42.yaml
CKPT=outputs/certified_only/self_rewarding_s42/self_rewarding_strict/state.pt
PARENT_OUT=outputs/predictions/csd_true_lp/self_rewarding_strict_cert_s42_test.json
PARENT_ITEMS=outputs/predictions/csd_true_lp/self_rewarding_strict_cert_s42_test.items.jsonl
if [[ -f "$CKPT" && ! -f "$PARENT_ITEMS" ]]; then
  python -m dion.evaluation.run_main_eval --config "$CFG" --ckpt "$CKPT" --split test \
    --save_items --save_csd_parent --out "$PARENT_OUT" \
    || echo "[$(date -Is)] FAIL CSD parent cert SR"
fi
CSD_OUT=outputs/predictions/csd_true_lp/self_rewarding_csd_true_lp_items.jsonl
if [[ -f "$PARENT_ITEMS" ]]; then
  python3 - <<PY
import json
from pathlib import Path
from collections import Counter
p=Path("$PARENT_ITEMS")
n=has=0; src=Counter()
for line in p.open():
    r=json.loads(line); n+=1
    if r.get("candidate_logprobs"): has+=1
    src[r.get("score_source","none")]+=1
print(f"[csd-parent] n={n} with_candidate_logprobs={has} sources={dict(src)}")
PY
  if [[ ! -f "$CSD_OUT" ]]; then
    python scripts/run_csd_intervention.py --parent "$PARENT_ITEMS" --out "$CSD_OUT" \
      || echo "[$(date -Is)] FAIL CSD intervention"
  fi
  python3 - <<'PY'
import json
from pathlib import Path
from collections import Counter
truep=Path("outputs/predictions/csd_true_lp/self_rewarding_csd_true_lp_items.jsonl")
src=Counter(); n=0
if truep.exists():
    for line in truep.open():
        r=json.loads(line); n+=1
        tr=r.get("csd_trace") or {}
        src[tr.get("score_source") or r.get("score_source") or "unknown"]+=1
summary={"n": n, "score_source": dict(src)}
Path("outputs/predictions/csd_true_lp/summary.json").write_text(json.dumps(summary, indent=2))
print("[csd-true]", summary)
PY
fi

# ---------- Phase B: certified-only multi-seed expansion ----------
echo "[$(date -Is)] === Phase B: certified-only multi-seed ==="
swap_cert

for seed in 43 44; do
  cfg="configs/certified_only/sc_s${seed}.yaml"
  ckpt="outputs/certified_only/self_critique_s${seed}/self_critique/state.pt"
  run_train "sc_s${seed}" "$ckpt" python -m dion.baselines.self_critique --config "$cfg" --seed "$seed" || true
  run_eval_test "sc_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/self_critique_s${seed}"
done

for seed in 43 44; do
  cfg="configs/certified_only/em_s${seed}.yaml"
  ckpt="outputs/certified_only/entropy_min_s${seed}/entropy_min/state.pt"
  run_train "em_s${seed}" "$ckpt" python -m dion.baselines.entropy_min --config "$cfg" --seed "$seed" || true
  run_eval_test "em_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/entropy_min_s${seed}"
done

for seed in 43 44; do
  cfg="configs/certified_only/sft_s${seed}.yaml"
  ckpt="outputs/certified_only/sft_lora_s${seed}/sft_lora/state.pt"
  run_train "sft_s${seed}" "$ckpt" python -m dion.baselines.sft_lora --config "$cfg" --seed "$seed" || true
  run_eval_test "sft_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/sft_lora_s${seed}"
done

for seed in 42 43 44; do
  cfg="configs/certified_only/shuf_s${seed}.yaml"
  ckpt="outputs/certified_only/shuffled_dpo_s${seed}/shuffled_dpo/state.pt"
  run_train "shuf_s${seed}" "$ckpt" \
    python -m dion.baselines.self_rewarding --config "$cfg" --judge_variant strict --seed "$seed" --shuffle_preferences || true
  run_eval_test "shuf_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/shuffled_dpo_s${seed}"
done

for seed in 42 43 44; do
  cfg="configs/certified_only/lorakl_s${seed}.yaml"
  ckpt="outputs/certified_only/lora_kl_s${seed}/stage2_abo/abo_state.pt"
  run_train "lorakl_s${seed}" "$ckpt" python -m dion.training.stage2_abo --config "$cfg" || true
  run_eval_test "lorakl_s${seed}" "$cfg" "$ckpt" "outputs/certified_only/lora_kl_s${seed}"
done

restore_train
trap - EXIT
restore_train || true

# ---------- Phase C: mixed-pool SR for paper-primary CSD ----------
echo "[$(date -Is)] === Phase C: mixed-pool SR s42 + true-logprob CSD ==="
cfg=configs/certified_only/mixed_sr_s42.yaml
ckpt=outputs/mixed_pool/self_rewarding_s42/self_rewarding_strict/state.pt
run_train "mixed_sr_s42" "$ckpt" \
  python -m dion.baselines.self_rewarding --config "$cfg" --judge_variant strict --seed 42 || true
PARENT_MIX=outputs/predictions/csd_true_lp/self_rewarding_strict_mixed_s42_test.json
PM=outputs/predictions/csd_true_lp/self_rewarding_strict_mixed_s42_test.items.jsonl
if [[ -f "$ckpt" && ! -f "$PM" ]]; then
  python -m dion.evaluation.run_main_eval --config "$cfg" --ckpt "$ckpt" --split test \
    --save_items --save_csd_parent --out "$PARENT_MIX" || true
fi
if [[ -f "$PM" ]]; then
  python scripts/run_csd_intervention.py --parent "$PM" \
    --out outputs/predictions/csd_true_lp/self_rewarding_csd_mixed_true_lp_items.jsonl || true
fi

python3 scripts/summarize_certified_evals.py || true

# ---------- Phase D: real per-seed RetentionNI (external suite) ----------
echo "[$(date -Is)] === Phase D: per-seed external retention ==="
# Priority: Base (no ckpt) × 3 seeds, then certified SR × 3, then SC s42.
for seed in 42 43 44; do
  out="outputs/retention/base_s${seed}.json"
  if [[ ! -f "$out" ]]; then
    echo "[$(date -Is)] RETENTION base s${seed}"
    python scripts/run_retention_eval.py --config configs/dion_sft_lora.yaml \
      --label base --seed "$seed" --out "$out" || echo "[$(date -Is)] FAIL retention base s${seed}"
  else
    echo "[$(date -Is)] SKIP retention base s${seed}"
  fi
done
for seed in 42 43 44; do
  out="outputs/retention/self_rewarding_strict_s${seed}.json"
  ckpt="outputs/certified_only/self_rewarding_s${seed}/self_rewarding_strict/state.pt"
  if [[ -f "$ckpt" && ! -f "$out" ]]; then
    echo "[$(date -Is)] RETENTION SR s${seed}"
    python scripts/run_retention_eval.py --config "configs/certified_only/sr_s${seed}.yaml" \
      --ckpt "$ckpt" --label self_rewarding_strict --seed "$seed" --out "$out" \
      || echo "[$(date -Is)] FAIL retention SR s${seed}"
  else
    echo "[$(date -Is)] SKIP retention SR s${seed}"
  fi
done
if [[ -f outputs/certified_only/self_critique_s42/self_critique/state.pt \
   && ! -f outputs/retention/self_critique_s42.json ]]; then
  echo "[$(date -Is)] RETENTION SC s42"
  python scripts/run_retention_eval.py --config configs/certified_only/sc_s42.yaml \
    --ckpt outputs/certified_only/self_critique_s42/self_critique/state.pt \
    --label self_critique --seed 42 --out outputs/retention/self_critique_s42.json \
    || echo "[$(date -Is)] FAIL retention SC s42"
fi

python3 - <<'PY'
"""Aggregate retention seed means/SDs for later ledger merge."""
import json, statistics
from pathlib import Path
from collections import defaultdict
root = Path("outputs/retention")
by = defaultdict(lambda: defaultdict(list))
for p in sorted(root.glob("*.json")):
    if p.name.startswith("summary"): continue
    d = json.loads(p.read_text())
    lab = d["label"]
    for task, v in d.get("tasks", {}).items():
        by[lab][task].append(float(v["score"]))
rows = {}
for lab, tasks in by.items():
    rows[lab] = {}
    for task, xs in tasks.items():
        if len(xs) == 1:
            rows[lab][task] = {"mean": xs[0], "sd": 0.0, "n_seeds": 1, "seeds": xs}
        else:
            rows[lab][task] = {
                "mean": statistics.mean(xs),
                "sd": statistics.stdev(xs),
                "n_seeds": len(xs),
                "seeds": xs,
            }
out = root / "summary_seed_sd.json"
out.write_text(json.dumps(rows, indent=2))
print("wrote", out)
for lab, tasks in rows.items():
    print(lab, {k: (round(v["mean"],4), round(v["sd"],4), v["n_seeds"]) for k,v in tasks.items()})
PY

echo "[$(date -Is)] GPU backlog queue finished — log $MAINLOG"
