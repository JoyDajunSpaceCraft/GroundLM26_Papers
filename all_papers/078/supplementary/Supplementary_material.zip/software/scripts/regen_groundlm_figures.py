#!/usr/bin/env python3
"""Regenerate GroundLM-style diagnostic figures with a unified palette."""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

# Gold-standard palette
GREEN = "#2E7D32"
RED = "#C62828"
BLUE = "#1565C0"
AMBER = "#F9A825"
INK = "#212121"
GRID = "#E0E0E0"
LIGHT = "#FAFAFA"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.edgecolor": INK,
    "axes.labelcolor": INK,
    "text.color": INK,
    "xtick.color": INK,
    "ytick.color": INK,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.dpi": 300,
    "pdf.fonttype": 42,
})


def save(fig, name: str):
    for base in (OUT, FIG):
        fig.savefig(base / f"{name}.png", bbox_inches="tight", facecolor="white")
        fig.savefig(base / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    print("wrote", name)
    plt.close(fig)


def fig_protocol_decision():
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    ax.set_title("Conjunctive protocol decision flow", fontweight="bold", loc="left")

    boxes = [
        (0.4, 4.2, 2.2, 1.2, "Target gain\nsuperiority?", BLUE),
        (3.5, 4.2, 2.4, 1.2, "Complementary\nnon-inferiority?", AMBER),
        (6.8, 4.2, 2.4, 1.2, "Retention NI\n(+ drift report)", GREEN),
        (3.5, 1.6, 2.4, 1.2, "Complementary\nTOST equivalence?", AMBER),
        (6.8, 1.6, 2.4, 1.2, "LocalizedGain\n(AuditPass)", GREEN),
        (0.4, 1.6, 2.2, 1.2, "Reject /\nreference-only", RED),
    ]
    for x, y, w, h, text, color in boxes:
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.15",
                                    facecolor=color, edgecolor=INK, alpha=0.18, linewidth=1.2))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=9, fontweight="medium")

    def arr(x1, y1, x2, y2, label=""):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="->", color=INK, lw=1.4))
        if label:
            ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.25, label, ha="center", fontsize=8, color=INK)

    arr(2.6, 4.8, 3.5, 4.8, "yes")
    arr(5.9, 4.8, 6.8, 4.8, "yes")
    arr(8.0, 4.2, 8.0, 2.8, "")
    arr(6.8, 2.2, 5.9, 2.2, "")
    ax.text(7.4, 3.5, "SafeGain\npath", ha="center", fontsize=8, color=GREEN, fontweight="bold")
    arr(1.5, 4.2, 1.5, 2.8, "no")
    ax.text(0.5, 0.4, "Report all five axes even when the conjunctive decision rejects.", fontsize=8, style="italic")
    save(fig, "figure_protocol_flow")


def fig_sign_reversal():
    methods = ["Base", "EntMin", "SelfCrit", "SelfRew", "CSD", "LoRA+KL"]
    onto = [0.0, 1.07, 2.87, 5.27, 4.13, 0.0]
    cs = [0.0, -7.10, -14.17, -37.50, -12.93, 0.12]
    x = np.arange(len(methods))
    w = 0.38
    fig, ax = plt.subplots(figsize=(7.2, 3.4))
    ax.bar(x - w / 2, onto, w, color=GREEN, label="OntoNeg ΔINA (pp)", edgecolor=INK, linewidth=0.6)
    ax.bar(x + w / 2, cs, w, color=RED, label="ConceptShift ΔAbsAcc (pp)", edgecolor=INK, linewidth=0.6)
    ax.axhline(0, color=INK, lw=0.8)
    ax.axhspan(-1, 1, color=BLUE, alpha=0.08, label="±1pp TOST band")
    ax.set_xticks(x)
    ax.set_xticklabels(methods, rotation=0, ha="center", fontsize=8)
    ax.set_ylabel("Δ vs Base (pp)")
    ax.set_title("Sign-reversing local regression under self-judged DPO", fontweight="bold", loc="left")
    ax.grid(axis="y", color=GRID, lw=0.8)
    ax.legend(frameon=False, fontsize=8, loc="lower left")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    save(fig, "figure_sign_reversal")


def fig_train_label_mix():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.2))
    # left pie-like bars
    ax = axes[0]
    labels = ["certified denial\n(dictionary/explicit)", "kg_edge_absence\nheuristic"]
    vals = [284, 1313]
    colors = [BLUE, RED]
    bars = ax.bar(labels, vals, color=colors, edgecolor=INK, linewidth=0.8)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 20, str(v), ha="center", fontsize=9, fontweight="bold")
    ax.set_ylim(0, 1600)
    ax.set_ylabel("# OntoNeg-WN train rows")
    ax.set_title("Training evidence mix (mixed pool)", fontweight="bold", loc="left")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    ax = axes[1]
    ax.axis("off")
    ax.set_title("Evaluation vs training policy", fontweight="bold", loc="left")
    text = (
        "Evaluation splits: certified only\n"
        "(attested denial + affirmation).\n\n"
        "Main ledger checkpoints: mixed train\n"
        f"({sum(vals)} rows).\n\n"
        "Sensitivity: certified-only retrain\n"
        f"({vals[0]} rows; no missing-edge labels).\n\n"
        "Until sensitivity replaces the ledger,\n"
        "specificity bias is one consistent\n"
        "explanation among confounders."
    )
    ax.text(0.02, 0.95, text, va="top", ha="left", fontsize=9,
            bbox=dict(boxstyle="round,pad=0.4", facecolor=LIGHT, edgecolor=GRID))
    fig.suptitle("Attested evaluation ≠ mixed training evidence", fontweight="bold", y=1.02)
    fig.tight_layout()
    save(fig, "figure_train_label_mix")


def fig_specificity_case():
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.set_title("Error mode: specificity bias on ConceptShift", fontweight="bold", loc="left")

    panels = [
        (0.3, 1.2, 3.0, 4.0, "Gold abstraction", "sparrow + penguin\n→ bird", BLUE,
         "Least common subsumer\nfrom attested IsA paths"),
        (3.5, 1.2, 3.0, 4.0, "Self-judge preference", "prefers more-specific\ncandidates", RED,
         "Over-specific answers\nwin pairwise ranking"),
        (6.7, 1.2, 3.0, 4.0, "CSD mitigation", "rerank by context +\nspecificity penalty", GREEN,
         "Dev-tuned; holdout\nkeeps most of the fix"),
    ]
    for x, y, w, h, title, body, color, note in panels:
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.12",
                                    facecolor=color, edgecolor=INK, alpha=0.14, linewidth=1.2))
        ax.text(x + w / 2, y + h - 0.45, title, ha="center", fontsize=10, fontweight="bold", color=color)
        ax.text(x + w / 2, y + h / 2 + 0.2, body, ha="center", va="center", fontsize=10)
        ax.text(x + w / 2, y + 0.45, note, ha="center", va="center", fontsize=8, style="italic")
    save(fig, "figure_specificity_case")


def fig_human_frontier():
    """Base / GPT-4.1 0-shot / Human from tables/human_solver.tex."""
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    cats = ["OntoNeg-WN\n(INA)", "ConceptShift\n(AbsAcc)", "LogicRepair\n(F1)"]
    base = [26.4, 59.5, 44.98]
    frontier = [48.3, 71.4, 58.2]  # GPT-4.1 0-shot
    human = [82.7, 85.3, 76.4]
    x = np.arange(len(cats))
    w = 0.25
    ax.bar(x - w, base, w, color=BLUE, label="Qwen3-8B-Base", edgecolor=INK, lw=0.6)
    ax.bar(x, frontier, w, color=AMBER, label="GPT-4.1 0-shot", edgecolor=INK, lw=0.6)
    ax.bar(x + w, human, w, color=GREEN, label="Human (majority)", edgecolor=INK, lw=0.6)
    ax.axhline(25, color=RED, ls="--", lw=1.0, label="OntoNeg chance (25%)")
    ax.set_xticks(x)
    ax.set_xticklabels(cats)
    ax.set_ylabel("Score (%)")
    ax.set_ylim(0, 100)
    ax.set_title("Solvable probes: Base near OntoNeg chance is not an unsolvable suite", fontweight="bold", loc="left")
    ax.grid(axis="y", color=GRID)
    ax.legend(frameon=False, fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    save(fig, "figure_human_frontier")


if __name__ == "__main__":
    fig_protocol_decision()
    fig_sign_reversal()
    fig_train_label_mix()
    fig_specificity_case()
    fig_human_frontier()
    print("done")
