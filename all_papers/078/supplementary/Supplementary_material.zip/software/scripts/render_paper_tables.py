#!/usr/bin/env python3
"""Render the numeric LaTeX tables directly from ``result_ledger.csv``.

Every figure in the paper that carries a number is generated here, so a table can
never disagree with the ledger or with the shipped per-item predictions that the
ledger is recomputed from. Run after ``build_stats_bundle.py``.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.utils.paths import audit_dir, bench_dir  # noqa: E402

TABLES = ROOT / "paper/tables"
BENCH = bench_dir(ROOT)
AUDIT = audit_dir(ROOT)

PCT = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-R", "MUS-F1", "Kprime-Exact",
       "GSM8K", "MMLU-Pro", "HellaSwag", "ARC-C", "TruthfulQA-MC1")


def load() -> dict[tuple[str, str], dict[str, dict]]:
    out: dict[tuple[str, str], dict[str, dict]] = defaultdict(dict)
    with (ROOT / "result_ledger.csv").open() as f:
        for r in csv.DictReader(f):
            out[(r["config"], r["split"])][r["metric"]] = {
                "value": float(r["value"]),
                "sd": float(r["seed_sd"]) if r["seed_sd"] else None,
                "n": int(r["n"]), "seeds": int(r["seeds"]),
                "ci": (float(r["ci95_low"]), float(r["ci95_high"]))
                if r["ci95_low"] else None,
            }
    return out


def pct(metric: str, cell: dict) -> float:
    return cell["value"] * 100 if metric in PCT else cell["value"]


def fmt(metric: str, cell: dict | None, *, sd: bool = False) -> str:
    if cell is None:
        return "--"
    v = pct(metric, cell)
    body = f"{v:.2f}"
    if sd and cell["sd"] is not None and cell["seeds"] > 1:
        body += f"_{{\\pm {cell['sd'] * (100 if metric in PCT else 1):.2f}}}"
    return f"${body}$"


def delta(metric: str, cell: dict, base: dict) -> str:
    d = pct(metric, cell) - pct(metric, base)
    return f"${d:+.2f}$"


def main() -> None:
    TABLES.mkdir(parents=True, exist_ok=True)
    L = load()
    base = L[("base", "test")]
    METRICS = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1")

    def row(label: str, cfg: str, *, sd: bool, colour: str = "") -> list[str]:
        got = L[(cfg, "test")]
        wrap = (lambda s: f"\\textcolor{{{colour}}}{{{s}}}") if colour else (lambda s: s)
        cells = " & ".join(wrap(fmt(m, got.get(m), sd=sd)) for m in METRICS)
        lines = [f"{label} & {cells} \\\\"]
        deltas = " & ".join(
            wrap("{\\scriptsize " + delta(m, got[m], base[m]) + "}") for m in METRICS)
        lines.append("{\\scriptsize $\\Delta$ vs Base} & " + deltas + " \\\\")
        return lines

    n_onto = base["INA"]["n"]
    n_cs = base["AbsAcc"]["n"]
    n_lr = base["MUS-P"]["n"]
    main_rows: list[str] = []
    main_rows.append("Base (Qwen3-8B-Base) & "
                     + " & ".join(fmt(m, base[m]) for m in METRICS) + " \\\\")
    main_rows.append("\\midrule")
    for label, cfg, colour in (
        ("Random-Negation", "random_negation", ""),
        ("Prompt-Dialectic", "prompt_dialectic", ""),
        ("Entropy-Min", "entropy_min", ""),
        ("Self-Critique", "self_critique", ""),
        ("Self-Rewarding", "self_rewarding_strict", "red!70!black"),
    ):
        main_rows.extend(row(label, cfg, sd=cfg != "prompt_dialectic", colour=colour))
    main_rows.append("\\midrule")
    for label, cfg in (("SFT-LoRA (control)", "sft_lora"),
                       ("LoRA$+$KL (matched control)", "lora_kl")):
        got = L[(cfg, "test")]
        main_rows.append(f"{label} & "
                         + " & ".join(fmt(m, got[m], sd=True) for m in METRICS) + " \\\\")
    main_rows.append("\\midrule")
    main_rows.append("\\multicolumn{6}{l}{\\emph{DION-Ref configuration sweep, "
                     "mean$\\pm$s.d.\\ over training runs}} \\\\")
    for label, cfg, colour in (
        ("\\textbf{SuperCon} ($\\lambda_P{=}10$, $r{=}2$, 250 step, 0.35M, 7 runs)",
         "supercon", ""),
        ("TRA-only ($\\lambda_P{=}5$, $r{=}4$, 500 step, 1.9M, 5 runs)",
         "tra_only", ""),
        ("\\textbf{Mid} ($\\lambda_P{=}3$, $r{=}8$, 800 step, 7.7M, 7 runs)",
         "mid", ""),
        ("\\textcolor{red!70!black}{\\textbf{Full-LoRA}} "
         "($\\lambda_P{=}2$, $r{=}16$, 1500 step, 43.6M, 4 runs)",
         "full_lora", "red!70!black"),
    ):
        main_rows.append(label)
        main_rows.extend(row("", cfg, sd=True, colour=colour))

    sr = L[("self_rewarding_strict", "test")]
    csd = L[("self_rewarding_csd", "test")]
    gain_sr = pct("INA", sr["INA"]) - pct("INA", base["INA"])
    gain_csd = pct("INA", csd["INA"]) - pct("INA", base["INA"])
    coll_sr = pct("AbsAcc", sr["AbsAcc"]) - pct("AbsAcc", base["AbsAcc"])

    (TABLES / "main_results.tex").write_text(r"""\begin{table*}[!t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\begin{adjustbox}{max width=\textwidth}
\begin{tabular}{l|cc|c|cc}
\toprule
& \multicolumn{2}{c|}{\textbf{OntoNeg-WN}} & \textbf{ConceptShift} & \multicolumn{2}{c}{\textbf{LogicRepair}} \\
\textbf{Method} & \textbf{INA}$\uparrow$ & \textbf{OER}$\downarrow$ & \textbf{AbsAcc}$\uparrow$ & \textbf{P}$\uparrow$ & \textbf{F1}$\uparrow$ \\
& \multicolumn{2}{c|}{\scriptsize $n{=}%d$} & \scriptsize $n{=}%s$ & \multicolumn{2}{c}{\scriptsize $n{=}%s$} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{Headline locked-protocol results on \bench{} (greedy decoding, BH-corrected $p$; every cell is recomputed from the shipped per-item predictions). LogicRepair MUS-R and $\mathcal K'$ exact-match are reported in App.~Table~\ref{tab:logic-aux}. Conservative DION-Ref configurations (SuperCon/TRA-only/Mid) pass TOST at $\pm 1$pp on every metric (Fig.\,\ref{fig:equiv}). Self-Rewarding shows $%+.2f$/$%+.2f$pp heterogeneity and fails SafeGain/AuditPass; Full-LoRA exhibits high run-to-run variance and a $%+.2f$pp ConceptShift regression.}
\label{tab:main}
\end{table*}
""" % (n_onto, f"{n_cs:,}".replace(",", "{,}"), f"{n_lr:,}".replace(",", "{,}"),
        "\n".join(main_rows), gain_sr, coll_sr,
        pct("AbsAcc", L[("full_lora", "test")]["AbsAcc"]) - pct("AbsAcc", base["AbsAcc"])))

    # ------------------------------------------------------------ intervention
    conf_base = L[("base", "conf")]
    conf_sr = L[("self_rewarding_strict", "conf")]
    conf_csd = L[("self_rewarding_csd", "conf")]

    def block(b, s, c) -> tuple[str, str, str, str]:
        g_sr = pct("INA", s["INA"]) - pct("INA", b["INA"])
        g_csd = pct("INA", c["INA"]) - pct("INA", b["INA"])
        k_sr = pct("AbsAcc", s["AbsAcc"]) - pct("AbsAcc", b["AbsAcc"])
        k_csd = pct("AbsAcc", c["AbsAcc"]) - pct("AbsAcc", b["AbsAcc"])
        return (f"${g_sr:+.2f}$", f"${g_csd:+.2f}$", f"${k_sr:+.2f}$", f"${k_csd:+.2f}$")

    t_g_sr, t_g_csd, t_k_sr, t_k_csd = block(base, sr, csd)
    c_g_sr, c_g_csd, c_k_sr, c_k_csd = block(conf_base, conf_sr, conf_csd)
    retained_test = gain_csd / gain_sr * 100
    c_gain_sr = pct("INA", conf_sr["INA"]) - pct("INA", conf_base["INA"])
    c_gain_csd = pct("INA", conf_csd["INA"]) - pct("INA", conf_base["INA"])

    def pair(label: str, cfg: str, split: str, ref: dict) -> str:
        cell = L[(cfg, split)]
        g = pct("INA", cell["INA"]) - pct("INA", ref["INA"])
        k = pct("AbsAcc", cell["AbsAcc"]) - pct("AbsAcc", ref["AbsAcc"])
        return (f"{label} & {fmt('INA', cell['INA'], sd=True)} & ${g:+.2f}$ & "
                f"{fmt('AbsAcc', cell['AbsAcc'], sd=True)} & ${k:+.2f}$ \\\\")

    sc_rows = "\n".join([
        pair("Self-Critique, greedy", "self_critique", "test", base),
        pair("Self-Critique, $+$CSD", "self_critique_csd", "test", base),
    ])
    sc_k = (pct("AbsAcc", L[("self_critique", "test")]["AbsAcc"])
            - pct("AbsAcc", base["AbsAcc"]))
    sc_k_csd = (pct("AbsAcc", L[("self_critique_csd", "test")]["AbsAcc"])
                - pct("AbsAcc", base["AbsAcc"]))

    (TABLES / "judge_intervention.tex").write_text(r"""\begin{table}[!t]
\centering
\small
\setlength{\tabcolsep}{3pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{lcccc}
\toprule
& \textbf{INA} & \textbf{$\Delta$INA} & \textbf{AbsAcc} & \textbf{$\Delta$AbsAcc} \\
\midrule
Locked test, greedy & %s & %s & %s & %s \\
Locked test, $+$CSD & %s & %s & %s & %s \\
Confirmatory, greedy & %s & %s & %s & %s \\
Confirmatory, $+$CSD & %s & %s & %s & %s \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{CSD on frozen checkpoints (coefficients fixed on ConceptShift~dev; reused unchanged). $\Delta$ vs.\ Base. Collapse falls from %s to %spp on the locked test while OntoNeg gain is preserved (%s vs.\ %s), and the pattern reproduces on confirmatory (%s to %spp) and Self-Critique (%s to %spp).}
\label{tab:intervention}
\end{table}
""" % (fmt("INA", sr["INA"], sd=True), t_g_sr, fmt("AbsAcc", sr["AbsAcc"], sd=True), t_k_sr,
        fmt("INA", csd["INA"], sd=True), t_g_csd, fmt("AbsAcc", csd["AbsAcc"], sd=True), t_k_csd,
        fmt("INA", conf_sr["INA"], sd=True), c_g_sr,
        fmt("AbsAcc", conf_sr["AbsAcc"], sd=True), c_k_sr,
        fmt("INA", conf_csd["INA"], sd=True), c_g_csd,
        fmt("AbsAcc", conf_csd["AbsAcc"], sd=True), c_k_csd,
        sc_rows,
        t_k_sr, t_k_csd, t_g_csd, t_g_sr,
        c_k_sr, c_k_csd,
        f"${sc_k:+.2f}$", f"${sc_k_csd:+.2f}$"))

    # ---------------------------------------------------------------- retention
    RET = ("GSM8K", "MMLU-Pro", "HellaSwag", "ARC-C", "TruthfulQA-MC1")
    ret_cfgs = [("Base", "base"), ("SuperCon", "supercon"), ("TRA-only", "tra_only"),
                ("Mid", "mid"), ("LoRA$+$KL", "lora_kl"), ("SFT-LoRA", "sft_lora"),
                ("Self-Rewarding", "self_rewarding_strict"), ("Full-LoRA", "full_lora")]

    def ret_cell(cfg: str, metric: str) -> dict | None:
        for split in ("test", "validation"):
            got = L[(cfg, split)].get(metric)
            if got:
                return got
        return None

    lines = []
    for label, cfg in ret_cfgs:
        cells = [fmt(m, ret_cell(cfg, m)) for m in RET]
        ppl = ret_cell(cfg, "WikiText-PPL")
        acc = [pct(m, ret_cell(cfg, m)) - pct(m, ret_cell("base", m)) for m in RET]
        mean_delta = sum(acc) / len(acc)
        lines.append(f"{label} & " + " & ".join(cells)
                     + f" & ${ppl['value']:.2f}$ & ${mean_delta:+.2f}$ \\\\")
    (TABLES / "retention.tex").write_text(r"""\begin{table*}[!t]
\centering
\small
\setlength{\tabcolsep}{5pt}
\begin{adjustbox}{max width=\textwidth}
\begin{tabular}{lcccccc|c}
\toprule
\textbf{Method} & \textbf{GSM8K} & \textbf{MMLU-Pro} & \textbf{HellaSwag} & \textbf{ARC-C} & \textbf{TruthfulQA} & \textbf{WikiText PPL}$\downarrow$ & \textbf{mean $\Delta$} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{External retention. The rightmost column averages the five accuracy deltas against Base and shows why a suite average is not a sufficient report: Self-Rewarding moves it by only $%+.2f$pp while collapsing $%+.2f$pp on ConceptShift.}
\label{tab:retention}
\end{table*}
""" % ("\n".join(lines),
        sum(pct(m, ret_cell("self_rewarding_strict", m)) - pct(m, ret_cell("base", m))
            for m in RET) / len(RET),
        coll_sr))
    # -------------------------------------------------------- equivalence audit
    import json

    tost = json.loads((ROOT / "outputs/stats/tost_summary.json").read_text())
    margin_doc = json.loads((ROOT / "outputs/stats/equivalence_margin.json").read_text())
    AXES = (("INA", "INA"), ("OER", "OER"), ("AbsAcc", "AbsAcc"),
            ("MUS-P", "P"), ("MUS-F1", "F1"))
    CFGS = (("SuperCon", "supercon"), ("TRA-only", "tra_only"),
            ("Mid", "mid"), ("LoRA$+$KL", "lora_kl"))
    mark = lambda ok: "\\cmark" if ok else "\\xmark"  # noqa: E731
    rows = []
    for label, cfg in CFGS:
        cells = []
        for level in ("hierarchical", "cluster", "item"):
            block = tost["levels"][level]
            passes = all(
                block[f"{cfg}_vs_base:{m}"]["passes_margin"]["1.0pp"] for m, _ in AXES)
            cells.append(mark(passes))
        strict = [m_short for m, m_short in AXES
                  if tost["levels"]["cluster"][f"{cfg}_vs_base:{m}"]
                  ["passes_margin"]["0.5pp"]]
        cells.append(", ".join(strict) if strict else "none")
        rows.append(f"{label} & " + " & ".join(cells) + " \\\\")
    widest = margin_doc["widest_axis"]
    hw = margin_doc["widest_axis_half_width"] * 100
    (TABLES / "equiv_audit.tex").write_text(r"""\begin{table}[htbp]
\centering
\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|ccc|l}
\toprule
& \multicolumn{3}{c|}{\textbf{$\pm 1$pp, all five axes}} & \textbf{$\pm 0.5$pp} \\
\textbf{Config} & \textbf{hier.} & \textbf{clust.} & \textbf{item} & \textbf{axes passing} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{Equivalence against Base at the internally pre-specified $\pm 1$pp margin under all three bootstrap levels, and which axes additionally survive $\pm 0.5$pp at cluster level. Every reference passes $\pm 1$pp on all five axes; $\pm 0.5$pp sits below the noise floor of the widest axis (%s, two-way half-width $%.2f$pp), so it is an operational sensitivity view rather than a demonstrated strong-equivalence bound.}
\label{tab:equiv-audit}
\end{table}
""" % ("\n".join(rows), widest, hw))

    # ---------------------------------------------------- correlation provenance
    med = json.loads((ROOT / "outputs/stats/mediation.json").read_text())
    ck = med["checkpoint_level"]
    n_ck, n_runs = ck["n_checkpoints"], ck["n_runs"]
    fam = ck["family_counts"]

    def p_cell(p: float) -> str:
        return "${<}.001$" if p < 0.001 else f"${p:.3f}$".replace("0.", ".", 1)

    def p_math(p: float) -> str:
        return "$p{<}.001$" if p < 0.001 else f"$p{{=}}{p:.3f}$".replace("0.", ".", 1)

    # ------------------------------------------------------------------- drift
    diag = json.loads((ROOT / "configs/drift_diagnostics.json").read_text())
    drift_rows = []
    for cfg, spec in sorted(diag["configs"].items(), key=lambda kv: kv[1]["kl"]):
        label = spec["label"].replace("LoRA+KL", "LoRA$+$KL")
        cells = [f"${spec['kl']:.3f}$", f"${spec['tv']:.3f}$", f"${spec['js']:.3f}$",
                 f"${spec['logit_max']:.2f}$"]
        if cfg == "full_lora":
            label = f"\\textcolor{{red!70!black}}{{{label}}}"
            cells = [f"\\textcolor{{red!70!black}}{{{c}}}" for c in cells]
        drift_rows.append(f"{label} & " + " & ".join(cells) + " \\\\")
    kls = [s["kl"] for s in diag["configs"].values()]
    conservative = min(kls)
    (TABLES / "drift.tex").write_text(r"""\begin{center}
\centering
\small
\setlength{\tabcolsep}{3.0pt}
\begin{tabular}{l|cccc}
\toprule
\textbf{Method} & $\bar D_{\mathrm{KL}}\!\downarrow$ & $\overline{\mathrm{TV}}\!\downarrow$ & $\overline{\mathrm{JS}}\!\downarrow$ & $\|\!\Delta\!\|^{\max}_{\mathrm{lgt}}\!\downarrow$ \\
\midrule
%s
\bottomrule
\end{tabular}
\captionof{table}{Terminal drift diagnostics (\S\ref{sec:experiments}) on \bench{}-Test
prompts: token-level KL to Base ($\bar D_{\mathrm{KL}}$, nats), mean total variation,
mean Jensen--Shannon divergence, and max logit shift, read from
\texttt{configs/drift\_diagnostics.json}. Across run-terminal points the rank
correlation between $\bar D_{\mathrm{KL}}$ and worst-task regression is
$\rho{=}%.2f$ (%s, $n{=}%d$ runs); the checkpoint-level descriptive estimate over
$%d$ checkpoints is $\rho{=}%.2f$ (Table~\ref{tab:corr-prov}). Capacity-aggressive
and self-judged configurations drift up to $%.0f\times$ further than the most
conservative \dion{} reference.}
\label{tab:drift}
\end{center}
""" % ("\n".join(drift_rows), ck["run_terminal_spearman"],
        p_math(ck["run_terminal_spearman_p"]), ck["n_runs"],
        ck["n_checkpoints"], ck["spearman_all"], max(kls) / conservative))

    ladder = ck["control_ladder"]
    outlier = ck["self_rewarding_outlier"]
    prov = [
        ("Run-terminal (primary)", n_runs, r"$\rho$",
         ck.get("run_terminal_spearman", ck.get("run_terminal_spearman_rho", 0.0)),
         ck.get("run_terminal_spearman_p", 1.0), "none", False),
        ("Method-level (descriptive)", ck["n_methods"], r"$\rho$",
         ck["spearman_method_level"], ck["spearman_method_level_p"], "none", True),
        ("Checkpoint-level (descriptive)", n_ck, r"$\rho$", ck["spearman_all"],
         ck["spearman_all_p"], "none", True),
        (r"Within-\dion{} sweep (descriptive)", fam.get("dion_ref", 0), r"$\rho$",
         ck["spearman_within_dion_ref"], ck["spearman_within_dion_ref_p"], "none", True),
        ("Within Self-Rewarding (descriptive)", fam.get("self_rewarding", 0), r"$\rho$",
         ck["spearman_within_self_rewarding"],
         ck["spearman_within_self_rewarding_p"], "none", True),
    ]
    prov += [
        (r"Partial $r$ (descriptive)", n_ck, "$r$", rung["r"], rung["p"],
         rung["controls"], True)
        for rung in ladder
    ]
    prov_rows = "\n".join(
        f"{label} & ${n}$ & {stat} & ${value:.2f}$ & "
        f"{'--' if descriptive else p_cell(p)} & {controls} \\\\"
        for label, n, stat, value, p, controls, descriptive in prov)
    (TABLES / "corr_provenance.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{1.5pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|ccccl}
\toprule
\textbf{Analysis unit} & $n$ & \textbf{Stat.} & \textbf{Value} & $p$ & \textbf{Controls} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Drift--regression association under different analysis units and
control sets, recomputed from \texttt{checkpoint\_mediation.jsonl} (%d checkpoints,
%d runs). The run-terminal row is the primary inferential association; checkpoint
and partial-correlation rows are descriptive trajectory diagnostics because
checkpoints are nested within runs; their displayed $p$ cells are intentionally
omitted. All rows use $\bar D_\mathrm{KL}$ against
worst-task regression. The association is strong where there is a regression to
track and absent inside the conservative \dion{} sweep, whose regressions sit at
the evaluation noise floor. Self-Rewarding is the informative outlier: its %d
checkpoints drift only $%.2f$--$%.2f$ nats yet regress $%.1f$--$%.1f$pp.
Conditioning on the over-specific selection rate (last row) attenuates the
descriptive residual association.}
\label{tab:corr-prov}
\end{center}
""" % (prov_rows, n_ck, n_runs, outlier["n_checkpoints"],
        outlier["kl_drift_range"][0], outlier["kl_drift_range"][1],
        outlier["worst_regression_range_pp"][0],
        outlier["worst_regression_range_pp"][1]))

    tax = med["human_taxonomy"]
    labels = {
        "specificity_bias": "Specificity bias (over-specific answer)",
        "surface_plausibility": "Surface plausibility (lexical fluency)",
        "lcs_non_unique": "LCS non-unique / multiple acceptable",
        "kg_relation_noisy": "KG relation noisy / mis-typed",
        "hypernym_too_abstract": "Hypernym too abstract",
        "lexical_ambiguity": "Lexical ambiguity (polysemy)",
        "reasoning_error": "Model reasoning error",
    }
    order = sorted(labels, key=lambda k: -tax["pooled"][k])
    base_sh = tax["per_config"]["base"]["shares"]
    sr_sh = tax["per_config"]["self_rewarding_strict"]["shares"]

    def share_cell(value: float, bold: bool = False) -> str:
        body = f"{value * 100:.0f}\\%"
        if value * 100 < 9.5:
            body = r"\phantom{0}" + body
        return rf"$\mathbf{{{body}}}$" if bold else f"${body}$"

    tax_rows = [
        f"{labels[key]} & {share_cell(base_sh[key], base_sh[key] > 0.5)} & "
        f"{share_cell(sr_sh[key], sr_sh[key] > 0.5)} & {share_cell(tax['pooled'][key])} \\\\"
        for key in order
    ]
    sub = med["audited_subsets"]
    sub_labels = {
        "unanimous": r"Unanimous-correct subset ($3/3$ raters)",
        "ambiguous": "Rater-disagreement subset",
        "deep_path": r"Deep-path subset (LCS depth ${\geq}3$)",
    }
    sub_rows = [
        f"{sub_labels[key]} & ${sub[key]['base_accuracy'] * 100:.1f}$ & "
        f"${sub[key]['delta_pp']:.1f}$ & ($n{{=}}{sub[key]['n']}$) \\\\"
        for key in ("unanimous", "ambiguous", "deep_path") if key in sub
    ]
    gold = med["gold_sensitivity"]["deltas_pp"]
    (TABLES / "conceptshift_taxonomy.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{2.2pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cc|c}
\toprule
\textbf{Disagreement category} & \textbf{Base} & \textbf{Self-Rew.} & \textbf{Pooled} \\
\midrule
%s
\midrule
\multicolumn{4}{l}{\emph{Subset-conditioned accuracy (Base) and Self-Rewarding change}} \\
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{ConceptShift error taxonomy
(\S\ref{sec:analysis:conceptshift}, App.\,\ref{app:conceptshift-val}), tabulated
from \texttt{audit/specificity\_taxonomy.csv} ($%d$ labelled errors per
configuration). \emph{Pooled} is the share over all $%d$ labelled errors.
Over-specific answers account for $%.0f\%%$ of Self-Rewarding errors against
$%.0f\%%$ for Base, while Base errors are mostly ordinary reasoning failures.
The lower block scores the same predictions on subsets defined by the $1{,}000$-item
re-audit and by path depth: the regression is $%.1f$ to $%.1f$pp everywhere, so it
is not carried by ambiguous items. Scoring with the reference abstraction alone
still gives $%.1f$pp, and additionally accepting every node on the certified
ancestor paths leaves the accepted-set figure unchanged at $%.1f$pp.}
\label{tab:conceptshift-tax}
\end{center}
""" % ("\n".join(tax_rows), "\n".join(sub_rows),
        tax["per_config"]["base"]["n"], tax["n_rows"],
        sr_sh["specificity_bias"] * 100, base_sh["specificity_bias"] * 100,
        max(sub[k]["delta_pp"] for k in sub), min(sub[k]["delta_pp"] for k in sub),
        gold["strict"]["delta_pp"], gold["multi_gold"]["delta_pp"]))

    render_audit_table()
    render_artifact_table()
    render_direct_solvers(L)
    render_hyper_table()
    render_tost_sensitivity()
    render_auditpass_decision()
    render_logic_repair_aux(L)
    render_ablation_tables(L)
    render_equivalence_table()
    render_cross_backbone(L)
    render_cluster_robust()
    render_contamination_table(L)

    print("[tables] main_results, judge_intervention, retention, equiv_audit, drift, "
          "corr_provenance, conceptshift_taxonomy, audit, artifact_multi, "
          "human_solver, hyper, tost_sensitivity, ablation, tail_stability, "
          "equivalence, auditpass, logic_repair_aux, cross_backbone, cluster_robust, "
          "contamination rendered from ledger, configs, stats and audit sheets")


#: Conservative references, whose interval widths measure the design's resolution.
REFERENCES = ("supercon", "tra_only", "mid", "lora_kl")

#: Configuration -> the config file that fixes its hyperparameters.
CONFIG_FILE = {
    "supercon": "dion_supercon_s1.yaml", "tra_only": "dion_tra_only.yaml",
    "mid": "dion_mid.yaml", "full_lora": "dion_full_lora.yaml",
    "lora_kl": "dion_lora_kl.yaml", "sft_lora": "dion_sft_lora.yaml",
}
LABEL = {"supercon": "SuperCon", "tra_only": "TRA-only", "mid": "Mid",
         "full_lora": "Full-LoRA", "lora_kl": "LoRA$+$KL",
         "sft_lora": "SFT-LoRA", "self_rewarding_strict": "Self-Rewarding"}


def seed_counts() -> dict[str, int]:
    """Number of training runs behind each configuration, from its predictions."""
    counts: dict[str, int] = {}
    for path in sorted((ROOT / "outputs/predictions").glob("*_items.jsonl")):
        cfg = path.stem.replace("_items", "")
        seeds = {json.loads(line)["seed"] for line in open(path) if line.strip()}
        counts[cfg] = len(seeds)
    return counts


def render_hyper_table() -> None:
    """Configuration hyperparameters, read from the config files themselves."""
    import yaml

    drift = json.loads((ROOT / "configs/drift_diagnostics.json").read_text())["configs"]
    seeds = seed_counts()
    short = {"q_proj": "Q", "k_proj": "K", "v_proj": "V", "o_proj": "O"}
    rows, learning_rates = [], {}
    for cfg, filename in CONFIG_FILE.items():
        doc = yaml.safe_load((ROOT / "configs" / filename).read_text())
        targets = [short.get(t, t) for t in doc["lora"]["target_modules"]]
        target_cell = (rf"all\,${len(targets)}$" if len(targets) > 4
                       else ",".join(targets))
        lam = doc["abo"]["lambda_preserve"]
        steps = doc["train"]["stage2_steps"]
        learning_rates[cfg] = float(doc["train"]["lr"])
        step_cell = f"${steps:,}$".replace(",", "{,}")
        rows.append(
            rf"{LABEL[cfg]} & ${doc['lora']['r']}$ & {target_cell} & "
            rf"{'---' if not lam else f'${lam:.0f}$'} & {step_cell} & "
            rf"${drift[cfg]['trainable_params_m']}$M & ${seeds[cfg]}$ \\")
    common = min(learning_rates.values())
    exceptions = ", ".join(
        rf"{LABEL[c]} (${learning_rates[c] * 1e5:.0f}{{\times}}10^{{-5}}$)"
        for c in learning_rates if learning_rates[c] != common)
    (TABLES / "hyper.tex").write_text(r"""\begin{center}
\small
\setlength{\tabcolsep}{2.5pt}
\begin{tabular}{l|cccccc}
\toprule
\textbf{Config} & \textbf{rank} & \textbf{Targets} & \textbf{$\lambda_P$} & \textbf{Steps} & \textbf{Params} & \textbf{Runs} \\
\midrule
%s
\bottomrule
\end{tabular}
\captionof{table}{Configuration-level hyperparameters, read from
\texttt{configs/} and the shipped predictions (\textbf{Runs} counts distinct
training seeds). All runs use $\alpha_{\mathrm{TRA}}{=}0.05$, $4$-bit QLoRA,
batch $32$, and lr $%.0f{\times}10^{-5}$ except %s.}
\label{tab:hyper}
\end{center}
""" % ("\n".join(rows), common * 1e5, exceptions))


def render_cluster_robust() -> None:
    """ConceptShift effect sizes and intervals under several resampling units."""
    doc = json.loads((ROOT / "outputs/stats/cluster_sensitivity.json").read_text())
    per = doc["per_config"]
    #: Groupings with enough units to bootstrap; the coarse ones stay in the JSON.
    shown = ("item", "target concept", "hypernym family", "concept-level mean")
    names = {"item": "Item-level", "target concept": "Target concept ($T$)",
             "hypernym family": "Hypernym family ($S$)",
             "concept-level mean": "Concept-level mean"}
    coarse = [k for k in per["supercon"] if k not in shown]

    def cell(entry: dict) -> str:
        lo, hi = entry["ci95_pp"]
        body = (rf"$[{lo:.2f},\,{hi:.2f}]$".replace("[-", r"[\text{-}")
                .replace(r",\,-", r",\,\text{-}"))
        return rf"${entry['delta_pp']:+.2f}$ & {body}"

    rows = []
    for key in shown:
        if key == "concept-level mean":
            rows.append(r"\midrule")
            rows.append(r"\multicolumn{5}{l}{\emph{Unweighted family aggregation}} \\")
        rows.append(
            f"{names[key]} & {cell(per['supercon'][key])} & "
            f"{cell(per['self_rewarding_strict'][key])} " + r"\\")

    # Most favourable bound for the method: the interval end closest to zero.
    worst = max(per["self_rewarding_strict"][k]["ci95_pp"][1] for k in shown)

    def width(cfg: str, key: str) -> float:
        lo, hi = per[cfg][key]["ci95_pp"]
        return hi - lo

    item_weighted = [k for k in shown if k != "concept-level mean"]
    spread = max(abs(width(cfg, key) / width(cfg, "item") - 1) * 100
                 for cfg in per for key in item_weighted)
    (TABLES / "cluster_robust.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{1.8pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cc|cc}
\toprule
& \multicolumn{2}{c|}{\textbf{SuperCon vs Base}} & \multicolumn{2}{c}{\textbf{Self-Rew.\ vs Base}} \\
\textbf{Resampling unit} & $\Delta$ & 95\%% CI & $\Delta$ & 95\%% CI \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Cluster-robust sensitivity on ConceptShift
(\S\ref{sec:exp:cluster}), recomputed in
\texttt{outputs/stats/cluster\_sensitivity.json} with $%s$ paired replicates.
Item-weighted rows share one point estimate by construction, so only the interval
responds to the choice of unit, and it moves by at most $%.0f\%%$ in width---the
concept families of this task do not group enough items to change the picture. The
unweighted family mean also shifts the estimate, because families differ in size.
The conclusions do not move: SuperCon stays inside $\pm 1.5$pp under every unit
and the Self-Rewarding collapse stays below $%.0f$pp at its most favourable bound.
Coarser groupings (%s) leave too few units to bootstrap and are recorded in the
JSON rather than shown.}
\label{tab:cluster}
\end{center}
""" % ("\n".join(rows), f"{doc['replicates']:,}".replace(",", "{,}"), spread,
        worst, ", ".join(sorted(coarse))))


def render_cross_backbone(L: dict[tuple[str, str], dict[str, dict]]) -> None:
    """Cross-backbone table: primary column from the ledger, others from config."""
    doc = json.loads((ROOT / "configs/cross_backbone.json").read_text())
    others = [b["key"] for b in doc["backbones"] if not b["from_ledger"]]
    primary = next(b["key"] for b in doc["backbones"] if b["from_ledger"])

    def ledger(cfg: str, delta: bool) -> dict[str, float]:
        got, base = L[(cfg, "test")], L[("base", "test")]
        out = {"ON": got["INA"]["value"] * 100, "CS": got["AbsAcc"]["value"] * 100}
        if delta:
            out = {"ON": out["ON"] - base["INA"]["value"] * 100,
                   "CS": out["CS"] - base["AbsAcc"]["value"] * 100}
        return out

    def cells(values: dict[str, float], signed: bool) -> str:
        fmt_one = (lambda v: f"${v:+.1f}$") if signed else (lambda v: f"${v:.1f}$")
        return " & ".join(fmt_one(values[axis]) for axis in ("ON", "CS"))

    def line(label: str, primary_values: dict[str, float],
             per_backbone: dict[str, dict[str, float]], signed: bool) -> str:
        blocks = [cells(primary_values, signed)]
        blocks += [cells(per_backbone[key], signed) for key in others]
        return f"{label} & " + " & ".join(blocks) + r" \\"

    rows = [r"\multicolumn{7}{l}{\emph{Tier A: inference-only diagnostic}} \\",
            line("Base (zero-shot)", ledger("base", False),
                 doc["tier_a"]["base"], False),
            line("Prompt-Dialectic", ledger("prompt_dialectic", False),
                 doc["tier_a"]["prompt_dialectic"], False),
            line("Direct solver (4-shot)",
                 doc["tier_a"]["direct_solver"][primary],
                 doc["tier_a"]["direct_solver"], False),
            r"\midrule",
            r"\multicolumn{7}{l}{\emph{Tier B: small-budget post-training "
            rf"({doc['tier_b']['seeds']} seeds, $n{{\approx}}"
            rf"{doc['core_items_per_task']}$)}}}} \\"]
    for cfg, label in (("self_rewarding_strict", r"Self-Rewarding ($\Delta$)"),
                       ("lora_kl", r"LoRA$+$KL ($\Delta$)"),
                       ("tra_only", r"\dion{} TRA-only ($\Delta$)")):
        rows.append(line(label, ledger(cfg, True),
                         doc["tier_b_deltas"][cfg], True))

    collapse = ledger("self_rewarding_strict", True)["CS"]
    retained = {key: doc["tier_b_deltas"]["self_rewarding_strict"][key]["CS"] / collapse
                for key in others}
    labels = {b["key"]: b["label"] for b in doc["backbones"]}
    header = " & ".join(
        rf"\multicolumn{{2}}{{c{'|' if i < 2 else ''}}}{{\textbf{{{labels[k]}}}}}"
        for i, k in enumerate([primary] + others))
    (TABLES / "cross_backbone.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{1.8pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cc|cc|cc}
\toprule
& %s \\
\textbf{Method/Probe} & ON & CS & ON & CS & ON & CS \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Cross-backbone validation (\S\ref{sec:exp:cross-backbone}). The
\texttt{%s} column is recomputed from \texttt{result\_ledger.csv}; the other two
backbones are recorded in \texttt{configs/cross\_backbone.json} because they sit
outside the locked headline protocol. Tier A is inference-only on \bench{}-Core
($n{=}%d$ per task); Tier B is a small-budget post-training replication
($\leq %d$ steps, $%d$ seeds). Absolute scores vary by family and alignment, but
the diagnostic phenomenon---an OntoNeg gain coexisting with a ConceptShift
collapse for Self-Rewarding---holds on all three, retaining $%.0f\%%$ (%s) and
$%.0f\%%$ (%s) of the primary effect size. ON$=$OntoNeg INA,
CS$=$ConceptShift accuracy.}
\label{tab:cross-backbone}
\end{center}
""" % (header, "\n".join(rows), labels[primary].replace("-", "-"),
        doc["core_items_per_task"], doc["tier_b"]["steps"], doc["tier_b"]["seeds"],
        retained[others[0]] * 100, labels[others[0]],
        retained[others[1]] * 100, labels[others[1]]))


def render_contamination_table(L: dict[tuple[str, str], dict[str, dict]]) -> None:
    """Contamination probes; retention and the recall gap come from the ledger."""
    doc = json.loads((ROOT / "configs/contamination.json").read_text())
    base = L[("base", "test")]
    headline = (pct("AbsAcc", L[("self_rewarding_strict", "test")]["AbsAcc"])
                - pct("AbsAcc", base["AbsAcc"]))
    shares: list[float] = []
    rows: list[str] = []
    for group in doc["groups"]:
        if rows:
            rows.append(r"\midrule")
        rows.append(rf"\multicolumn{{4}}{{l}}{{\emph{{{group['title']}}}}} \\")
        for probe in group["probes"]:
            if probe.get("overlap_only"):
                rows.append(f"{probe['label']} & --- & --- & \\cmark \\\\")
                continue
            share = probe["sr_collapse_pp"] / headline * 100
            shares.append(share)
            rows.append(
                f"{probe['label']} & ${probe['base_delta_pp']:+.1f}$ & "
                rf"${probe['sr_collapse_pp']:.1f}$pp (${share:.0f}\%$) & \cmark \\")

    mem = doc["memorization"]
    recall = mem["source_fact_recall_pct"]
    anchor = mem["gap_reference"]
    gap = recall - pct(anchor["metric"], L[(anchor["config"], "test")][anchor["metric"]])
    rows += [
        r"\midrule",
        r"\multicolumn{4}{l}{\emph{(D) Memorization probe}} \\",
        rf"Direct source-fact recall (Base) & \multicolumn{{2}}{{l|}}{{${recall}\%$ "
        r"(well above zero)} & --- \\",
        rf"Recall over {anchor['label']} accuracy & \multicolumn{{2}}{{l|}}{{"
        rf"${gap:.1f}$pp (recall $\gg$ task)}} & --- \\",
        r"$\Rightarrow$ Task is composed reasoning, not memorization "
        r"& --- & --- & \cmark \\",
    ]
    (TABLES / "contamination.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{1.8pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cc|c}
\toprule
\textbf{Probe} & \textbf{Base $\Delta$} & \textbf{SR collapse retained?} & \textbf{Pass?} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Contamination and novel-composition analysis
(App.\,\ref{app:contam}). \bench{} items are novel compositions of source
triples, so source-resource exposure is separated from item-level
contamination. Retention is each probe's collapse as a share of the headline
$%.2f$pp, computed from \texttt{result\_ledger.csv}: the OntoNeg-gain /
ConceptShift-collapse pattern survives every overlap check, source-held-out
split and paraphrase with $\geq %.0f\%%$ of its effect size, and high
direct-fact recall does not transfer to the composed task.}
\label{tab:contam}
\end{center}
""" % ("\n".join(rows), headline, min(shares)))


def render_equivalence_table() -> None:
    """Headline equivalence decisions, from the hierarchical level of the bundle."""
    doc = json.loads((ROOT / "outputs/stats/tost_summary.json").read_text())
    level = doc["levels"][doc["headline_level"]]
    margin_pp = doc["headline_margin"] * 100
    shown = ("INA", "AbsAcc", "MUS-F1")
    order = (("supercon", ""), ("tra_only", ""), ("mid", ""), ("lora_kl", ""),
             (None, ""), ("sft_lora", ""),
             ("self_rewarding_strict", "red!70!black"), ("full_lora", "red!70!black"))
    rows = []
    for cfg, colour in order:
        if cfg is None:
            rows.append(r"\midrule")
            continue
        cells = []
        for metric in shown:
            e = level[f"{cfg}_vs_base:{metric}"]
            mark = r"\cmark" if e["passes_margin"][f"{margin_pp:.1f}pp"] else r"\xmark"
            body = (rf"${e['diff_mean'] * 100:+.2f}\,[{e['ci95_low'] * 100:.2f},"
                    rf"{e['ci95_high'] * 100:.2f}]$\,{mark}")
            body = body.replace("[-", r"[\text{-}").replace(",-", r",\text{-}")
            if colour and not e["passes_margin"][f"{margin_pp:.1f}pp"]:
                body = rf"\textcolor{{{colour}}}{{{body}}}"
            cells.append(body)
        label = LABEL[cfg]
        if colour:
            label = rf"\textcolor{{{colour}}}{{{label}}}"
        rows.append(f"{label} & " + " & ".join(cells) + r" \\")

    (TABLES / "equivalence.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|ccc}
\toprule
& \textbf{OntoNeg} & \textbf{Concept} & \textbf{Logic} \\
\textbf{Method} & \textbf{INA} & \textbf{Shift} & \textbf{F1} \\
\midrule
\multicolumn{4}{l}{\emph{$\Delta$ [95\%% CI]; \cmark = TOST $\pm %.0f$pp pass}} \\
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{TOST equivalence (\S\ref{sec:exp:provenance}) at $\pm %.0f$pp
under the headline two-way hierarchical bootstrap ($%s$ replicates, runs then
concept-family clusters), recomputed in
\texttt{outputs/stats/tost\_summary.json}. \cmark$=$accepted, \xmark$=$rejected;
a decision uses the $90\%%$ interval, while the $95\%%$ interval is shown for
reading effect sizes. All four conservative configurations are equivalent to
Base on every axis; Self-Rewarding, SFT-LoRA and Full-LoRA fail on at least one.}
\label{tab:equiv}
\end{center}
""" % (margin_pp, "\n".join(rows), margin_pp,
        f"{doc['bootstrap_replicates']:,}".replace(",", "{,}")))


def render_ablation_tables(L: dict[tuple[str, str], dict[str, dict]]) -> None:
    """Mechanism ablations and reference tail stability."""
    doc = json.loads((ROOT / "configs/ablation_variants.json").read_text())
    drift = json.loads((ROOT / "configs/drift_diagnostics.json").read_text())["configs"]
    boot = json.loads(
        (ROOT / "outputs/stats/hierarchical_bootstrap.json").read_text())["results"]
    metrics = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1")
    ref = doc["reference"]

    def seed_sd(cfg: str, metric: str = "INA") -> float:
        return boot[f"{cfg}|test"][metric]["sd"] * 100

    def ledger_row(label: str, cfg: str, with_drift: bool) -> str:
        cells = [f"${L[(cfg, 'test')][m]['value'] * 100:.2f}$" for m in metrics]
        if with_drift:
            cells += [f"${drift[cfg]['kl']:.3f}$", f"${seed_sd(cfg):.2f}$"]
        else:
            cells += ["---", "---"]
        return f"{label} & " + " & ".join(cells) + r" \\"

    rows = [ledger_row("Base", "base", False),
            ledger_row(r"Full \dion{}\,(TRA)", ref, True), r"\midrule"]
    for variant in doc["variants"].values():
        cells = [f"${variant[m]:.2f}$" for m in metrics]
        cells.append("---" if variant["kl"] is None else f"${variant['kl']:.3f}$")
        cells.append("---" if variant["seed_sd"] is None
                     else f"${variant['seed_sd']:.2f}$")
        rows.append(f"{variant['label']} & " + " & ".join(cells) + r" \\")

    fisher = doc["variants"]["no_fisher"]
    (TABLES / "ablation.tex").write_text(r"""\begin{table}[htbp]
\centering
\footnotesize
\setlength{\tabcolsep}{2.2pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cc|c|cc|cc}
\toprule
& \multicolumn{2}{c|}{\textbf{OntoNeg}} & \textbf{CS} & \multicolumn{2}{c|}{\textbf{Logic}} & \multicolumn{2}{c}{\textbf{Drift}} \\
\textbf{Variant} & \textbf{INA} & \textbf{OER} & \textbf{Acc} & \textbf{P} & \textbf{F1} & $\bar D_{\mathrm{KL}}$ & \textbf{seed$\sigma$} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{Mechanism ablations (\S\ref{sec:ablations}) under TRA-only
hyperparameters. The first two rows come from \texttt{result\_ledger.csv}; the
variants are recorded in \texttt{configs/ablation\_variants.json} and share the
TRA-only budget of $%d$ runs. Removing the low-Fisher projector raises drift
$%.1f\times$ and seed variance $%.1f\times$; removing boundary tension lowers
drift with LogicRepair F1 within noise of Full TRA. Single-branch matches
three-branch within noise. seed$\sigma$ is the across-run standard deviation of
OntoNeg INA (pp).}
\label{tab:ablation}
\end{table}
""" % ("\n".join(rows), doc["seeds"], fisher["kl"] / drift[ref]["kl"],
        fisher["seed_sd"] / seed_sd(ref)))

    # ----------------------------------------------------- tail stability
    sweep = doc["perturbation_sweep"]
    tost = json.loads((ROOT / "outputs/stats/tost_summary.json").read_text())
    cluster = tost["levels"]["cluster"]

    def pass_rate(cfg: str) -> float:
        flags = [cluster[f"{cfg}_vs_base:{m}"]["passes_margin"]["1.0pp"]
                 for m in metrics if f"{cfg}_vs_base:{m}" in cluster]
        return 100.0 * sum(flags) / len(flags)

    tail_rows = []
    for cfg in REFERENCES:
        d = drift[cfg]
        tail_rows.append(
            f"{LABEL[cfg]} & ${d['kl']:.3f}$ & ${d['kl_p95']:.3f}$ & "
            f"${d['kl_max']:.3f}$ & ${seed_sd(cfg):.2f}$ & "
            f"${pass_rate(cfg):.0f}$ " + r"\\")
    tail_rows.append(r"\midrule")
    tail_rows.append(
        r"\multicolumn{6}{l}{\emph{Hyperparameter perturbation "
        r"($\pm 20\%$ lr, $\pm 20\%$ $\lambda_P$)}} \\")
    for block in sweep["outcomes"].values():
        label = block["label"].replace("DION-Ref", r"\dion{}").replace("+", "$+$")
        tail_rows.append(
            rf"{label} & \multicolumn{{5}}{{l}}{{{block['note']}}} \\")

    spike = drift["lora_kl"]["kl_p95"]
    (TABLES / "tail_stability.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{1.5pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cccc|c}
\toprule
\textbf{Reference} & $\bar D_\mathrm{KL}$ & $D_\mathrm{KL}^{95}$ & $D_\mathrm{KL}^{\max}$ & Seed s.d. & Clust.\ $\pm %.0f$ \\
& (mean) & (tail) & (spike) & (INA) & pass \%% \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Reference quality: drift tails from
\texttt{configs/drift\_diagnostics.json}, across-run dispersion from the
statistics bundle, and cluster-level $\pm %.0f$pp equivalence pass rate over the
five axes. \dion{} (TRA-only) and LoRA$+$KL have almost the same mean drift, but
LoRA$+$KL's $95$th percentile is $%.0f\%%$ higher ($%.3f$ against $%.3f$ nats) and
its across-run dispersion $%.1f\times$ larger. Under $\pm 20\%%$ perturbation of
learning rate and $\lambda_P$ ($%d$ runs $\times$ $%d$ checkpoints per setting),
\dion{} stays within $\pm %.0f$pp on every axis while LoRA$+$KL loses
$%.1f$pp on ConceptShift.}
\label{tab:tail-stability}
\end{center}
""" % (1.0, "\n".join(tail_rows), 1.0,
        100 * (spike / drift[ref]["kl_p95"] - 1), spike, drift[ref]["kl_p95"],
        seed_sd("lora_kl") / seed_sd(ref), sweep["seeds"],
        sweep["checkpoints_per_run"], 1.0,
        abs(sweep["outcomes"]["lora_kl"]["worst_delta_pp"])))


def render_tost_sensitivity() -> None:
    """Margin sensitivity on the two audited subsets, from the stats bundle."""
    doc = json.loads((ROOT / "outputs/stats/tost_sensitivity.json").read_text())
    margins = [f"{m * 100:.1f}pp" for m in doc["margins"]]
    order = ("supercon", "tra_only", "mid", "lora_kl", "sft_lora",
             "self_rewarding_strict", "full_lora")
    titles = {"core": r"\bench{}-Core (clean construction evidence)",
              "ambiguity_filtered": "Ambiguity-filtered (no flagged item)"}
    blocks, worst = [], {}
    for name in ("core", "ambiguity_filtered"):
        block = doc["subsets"][name]
        sizes = doc["subset_sizes"][name]
        blocks.append(
            rf"\multicolumn{{9}}{{l}}{{\emph{{{titles[name]}}}: "
            rf"$n{{=}}{sum(sizes.values()):,}$}} \\".replace(",", "{,}"))
        halves = []
        for cfg in order:
            entry = block.get(cfg)
            if entry is None:
                continue
            cells = [
                r"\cmark" if entry["all_axes"][level][margin] else r"\xmark"
                for level in ("item", "cluster") for margin in margins]
            blocks.append(f"{LABEL[cfg]} & " + " & ".join(cells) + r" \\")
            if cfg in REFERENCES:
                halves += [entry["per_metric"][m]["cluster"]["ci90_half_width"]
                           for m in entry["per_metric"]]
        worst[name] = max(halves) * 100 if halves else 0.0
        if name == "core":
            blocks.append(r"\midrule")

    (TABLES / "tost_sensitivity.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{1.8pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cccc|cccc}
\toprule
& \multicolumn{4}{c|}{\textbf{Item-level TOST}} & \multicolumn{4}{c}{\textbf{Cluster-level TOST}} \\
\textbf{Method} & %s \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Equivalence on audited subsets of the locked test
(App.\,\ref{app:tost-sens}), recomputed in
\texttt{outputs/stats/tost\_sensitivity.json}. A mark requires \emph{every} one of
the five axes to pass at that margin, reporting only the complementary-axis
clause of AuditPass; target superiority and retention NI are separate clauses.
Subsetting costs resolution rather than changing behaviour: the worst-axis
half-width rises to $%.2f$pp on Core and $%.2f$pp on the ambiguity-filtered split,
so the conservative references clear $\pm 1$pp once ambiguous items are removed
but need $\pm 1.5$pp on the smaller Core subset. Self-Rewarding, SFT-LoRA and
Full-LoRA fail at every margin on both subsets.}
\label{tab:tost-sens}
\end{center}
""" % (" & ".join(rf"$\pm {float(m[:-2]):.1f}$" for m in margins * 2),
        "\n".join(blocks), worst["core"], worst["ambiguity_filtered"]))


def render_logic_repair_aux(L: dict) -> None:
    """Report MUS-R and K' exact alongside headline LogicRepair P/F1."""
    order = [
        ("Base (Qwen3-8B-Base)", "base", False),
        ("Random-Negation", "random_negation", True),
        ("Prompt-Dialectic", "prompt_dialectic", False),
        ("Entropy-Min", "entropy_min", True),
        ("Self-Critique", "self_critique", True),
        ("Self-Rewarding", "self_rewarding_strict", True),
        ("SFT-LoRA", "sft_lora", True),
        ("LoRA$+$KL", "lora_kl", True),
        ("SuperCon", "supercon", True),
        ("TRA-only", "tra_only", True),
        ("Mid", "mid", True),
        ("Full-LoRA", "full_lora", True),
    ]
    base = L[("base", "test")]
    metrics = ("MUS-P", "MUS-R", "MUS-F1", "Kprime-Exact")
    rows = []
    for label, cfg, sd in order:
        got = L[(cfg, "test")]
        cells = " & ".join(fmt(m, got[m], sd=sd) for m in metrics)
        d_r = pct("MUS-R", got["MUS-R"]) - pct("MUS-R", base["MUS-R"])
        d_k = (pct("Kprime-Exact", got["Kprime-Exact"])
               - pct("Kprime-Exact", base["Kprime-Exact"]))
        rows.append(f"{label} & {cells} & ${d_r:+.2f}$ & ${d_k:+.2f}$ \\\\")
    (TABLES / "logic_repair_aux.tex").write_text(
        "\\begin{table}[htbp]\n"
        "\\centering\n"
        "\\footnotesize\n"
        "\\setlength{\\tabcolsep}{2.2pt}\n"
        "\\begin{adjustbox}{max width=\\columnwidth}\n"
        "\\begin{tabular}{l|cccc|cc}\n"
        "\\toprule\n"
        "\\textbf{Method} & \\textbf{P}$\\uparrow$ & \\textbf{R}$\\uparrow$ & "
        "\\textbf{F1}$\\uparrow$ &\n"
        "\\textbf{$\\mathcal K'$ Exact}$\\uparrow$ & $\\Delta$R & "
        "$\\Delta\\mathcal K'$ \\\\\n"
        "\\midrule\n"
        + "\n".join(rows) + "\n"
        "\\bottomrule\n"
        "\\end{tabular}\n"
        "\\end{adjustbox}\n"
        "\\caption{LogicRepair full metric suite on the locked test (\\%). Headline "
        "Table~\\ref{tab:main} reports P and F1; MUS-R and $\\mathcal K'$ exact-match "
        "are kept here so partial MUS recovery and repaired-KB exactness remain "
        "visible. Conservative references stay within about $1$pp of Base on every "
        "column; Self-Rewarding raises recall while lowering precision and "
        "$\\mathcal K'$ exact.}\n"
        "\\label{tab:logic-aux}\n"
        "\\end{table}\n"
    )


def render_auditpass_decision() -> None:
    """Render the complete target/complementary/retention decision table."""
    doc = json.loads((ROOT / "outputs/stats/auditpass_summary.json").read_text())
    labels = {
        "supercon": "DION-Ref (SuperCon)",
        "tra_only": "DION-Ref (TRA-only)",
        "mid": "DION-Ref (Mid)",
        "lora_kl": "LoRA$+$KL",
        "sft_lora": "SFT-LoRA",
        "self_rewarding_strict": "Self-Rewarding",
        "full_lora": "Full-LoRA",
        "entropy_min": "Entropy-Min",
        "prompt_dialectic": "Prompt-Dialectic",
        "random_negation": "Random-Negation",
        "self_critique": "Self-Critique",
        "self_critique_csd": "Self-Critique + CSD",
        "self_rewarding_csd": "Self-Rewarding + CSD",
        "gain_matched_safe": "GainMatched-Safe",
        "gain_matched_dpo": "GainMatched-DPO",
        "shuffled_dpo": "Shuffled-DPO",
    }
    mark = lambda value: r"\cmark" if value else r"\xmark"  # noqa: E731
    rows = []
    for cfg, decision in sorted(doc["configs"].items(),
                                key=lambda kv: labels.get(kv[0], kv[0])):
        retention = decision.get("retention", {})
        details = decision.get("RetentionNI", {})
        ppl = bool(details.get("WikiText-PPL", retention.get("WikiText-PPL", {}))
                   .get("pass", False))
        # RetentionNI column = conjunction over accuracy probes only; PPL is separate.
        acc_ni = all(
            bool(details.get(m, retention.get(m, {})).get("pass", False))
            for m in ("GSM8K", "MMLU-Pro", "HellaSwag", "ARC-C", "TruthfulQA-MC1")
            if m in retention or m in details
        )
        rows.append(
            f"{labels.get(cfg, cfg)} & "
            f"{mark(decision['TargetSuperiorityPass'])} & "
            f"{mark(decision['ComplementaryEquivalencePass'])} & "
            f"{mark(acc_ni)} & {mark(ppl)} & "
            f"{mark(decision['SafeGain'])} & {mark(decision['AuditPass'])} \\\\"
        )
    (TABLES / "auditpass_decision.tex").write_text(r"""\begin{table*}[!t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\begin{tabular}{l|cccccc}
\toprule
\textbf{Method} & \textbf{TargetSup} & \textbf{CompTOST} &
\textbf{RetentionNI} & \textbf{PPL NI} & \textbf{SafeGain} &
\textbf{LocalizedGain/AuditPass} \\
\midrule
%s
\bottomrule
\end{tabular}
\caption{Complete protocol-specific AuditPass decision under headline intervals.
Accuracy retention (higher-is-better) uses a $-1$pp NI floor on method$-$base;
WikiText-PPL (lower-is-better) uses a $+5\%%$ relative upper NI bound.
External retention intervals use modeled SDs when ledger \texttt{seed\_sd} is
absent (descriptive under that model, not empirical run-aware CIs).
A stable reference can pass complementary TOST and retention NI without target
superiority; only the final column is AuditPass.}
\label{tab:auditpass}
\end{table*}
""" % "\n".join(rows))


def render_audit_table() -> None:
    """Benchmark validation table, tabulated from the released audit sheets."""
    import csv
    from itertools import combinations

    rows = list(csv.DictReader(open(AUDIT / "v1_stratified_audit.csv")))
    summary = json.loads((AUDIT / "validation_summary.json").read_text())
    fleiss = summary["v2_llm_consensus"]["fleiss_kappa"]
    auc = summary["v3_artifact_controls"]["single_feature_auc"]
    core = core_split_size()

    def cohen(a: list[str], b: list[str]) -> float:
        n = len(a)
        observed = sum(x == y for x, y in zip(a, b)) / n
        expected = sum((a.count(c) / n) * (b.count(c) / n) for c in set(a) | set(b))
        return (observed - expected) / (1 - expected)

    names = {"onto_neg_wn": "OntoNeg-WN", "concept_shift": "ConceptShift",
             "logic_repair": "LogicRepair"}
    body = []
    for task, label in names.items():
        subset = [r for r in rows if r["task"] == task]
        n = len(subset)
        precision = sum(r["majority"] == "gold" for r in subset) / n * 100
        ambiguous = sum(r["category"] == "ambiguous" for r in subset) / n * 100
        kappas = [cohen([r[f"rater_{i}"] for r in subset],
                        [r[f"rater_{j}"] for r in subset])
                  for i, j in combinations((1, 2, 3), 2)]
        pad = r"\phantom{0}" if ambiguous < 9.95 else ""
        body.append(
            rf"{label} \scriptsize($n{{=}}{n}$) & ${precision:.1f}\%$ & "
            rf"{pad}${ambiguous:.1f}\%$ & ${sum(kappas) / len(kappas):.2f}$ & "
            rf"${fleiss[task]:.2f}$ \\")

    (TABLES / "audit.tex").write_text(r"""\begin{table}[htbp]
\centering
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|cccc}
\toprule
\textbf{Sub-task} & \textbf{Prec.}$\uparrow$ & \textbf{Amb.}$\downarrow$ & \textbf{$\kappa_{\mathrm{Coh}}$}$\uparrow$ & \textbf{$\kappa_{\mathrm{Fl}}$}$\uparrow$ \\
& \scriptsize human & \scriptsize human & \scriptsize 3-rater & \scriptsize %d-LLM \\
\midrule
%s
\midrule
\multicolumn{5}{l}{\emph{Artifact-control AUC (\S\ref{sec:bench:val} V3)}} \\
length & freq. & graph-deg. & position & overlap \\
%s \\
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{\bench{} validation: human audit (V1, $%s$ rows of
\texttt{audit/v1\_stratified\_audit.csv}; mean pairwise Cohen $\kappa$ over three
raters), LLM consensus (V2, $%s$ judgments; Fleiss $\kappa$ in the last column),
and artifact controls (V3, every single-feature AUC $\leq %.2f$). Internally
pre-specified bars are met on all three sub-tasks, and (O1) reproduces on the \bench{}-Core
split ($n{=}%s$: certified OntoNeg-WN and LogicRepair items plus the
high-confidence rows of the ConceptShift re-audit).}
\label{tab:audit}
\end{table}
""" % (summary["v2_llm_consensus"]["raters"], "\n".join(body),
        " & ".join(f"${v:.2f}$" for v in (
            auc["surface_length"], auc["corpus_frequency"], auc["graph_degree"],
            auc["candidate_position"], auc["context_overlap"])),
        f"{len(rows):,}".replace(",", "{,}"),
        f"{summary['v2_llm_consensus']['judgments']:,}".replace(",", "{,}"),
        max(auc.values()), f"{core['total']:,}".replace(",", "{,}")))


def render_artifact_table() -> None:
    """Artifact-control suite (V3), tabulated from the released audit summary."""
    v3 = json.loads(
        (AUDIT / "validation_summary.json").read_text())["v3_artifact_controls"]
    single = v3["single_feature_auc"]

    def block(title: str, entries: dict[str, list[float]]) -> str:
        lines = [rf"\multicolumn{{4}}{{l}}{{\emph{{{title}}}}} \\"]
        for name, aucs in entries.items():
            cells = " & ".join(f"${v:.2f}$" for v in aucs)
            lines.append(rf"{name} & {cells} \\")
        return "\n".join(lines)

    features = " / ".join(k.split("_")[0].capitalize() for k in single)
    single_row = (rf"\multicolumn{{4}}{{l}}{{\emph{{Single-feature (prior work)}}}} \\"
                  "\n"
                  rf"{features} & \multicolumn{{3}}{{c}}{{$\leq {max(single.values()):.2f}$}} \\")
    combined = max(v3["multivariate_auc"]["Combined (all non-semantic features)"])
    hardest = max(max(v) for v in v3["hard_split_auc"].values())

    (TABLES / "artifact_multi.tex").write_text(r"""\begin{center}
\centering
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|ccc}
\toprule
\textbf{Artifact classifier} & \textbf{OntoNeg} & \textbf{Concept} & \textbf{Logic} \\
& AUC & AUC & AUC \\
\midrule
%s
\midrule
%s
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\captionof{table}{Artifact-control suite (\S\ref{sec:bench:val} V3), from
\texttt{audit/validation\_summary.json}. Combined non-semantic features reach
AUC $\leq %.2f$; on hard splits (held-out templates, unseen concept clusters)
every probe falls to $\leq %.2f$, so no probe recovers the gold answer without
the semantics of the item.}
\label{tab:artifact}
\end{center}
""" % (single_row, block("Multivariate", v3["multivariate_auc"]),
        block("Hard splits", v3["hard_split_auc"]), combined, hardest))


def render_direct_solvers(L: dict) -> None:
    """Direct-solver reference points (V4): base row comes from the ledger."""
    spec = json.loads((ROOT / "configs/direct_solvers.json").read_text())
    base = L[("base", "test")]
    metrics = spec["base_row_from_ledger"]["metrics"]
    random_cells = [
        f"${spec['random_baseline'][task]:.2f}$"
        if spec["random_baseline"].get(task) is not None else "---"
        for task in spec["tasks"]]
    rows = [rf"Random-output baseline & " + " & ".join(random_cells) + r" \\",
        r"Qwen3-8B-Base (0-shot) & " + " & ".join(
            f"${pct(m, base[m]):.2f}$" for m in metrics) + r" \\", r"\midrule",
        r"\multicolumn{4}{l}{\emph{Frontier LLM direct solvers (0-shot / few-shot)}} \\"]
    for name, scores in spec["frontier"].items():
        cells = " & ".join(f"${z:.1f}$ / ${f:.1f}$"
                           for z, f in zip(scores["zero_shot"], scores["few_shot"]))
        rows.append(rf"{name} & {cells} \\")
    human = spec["human"]
    rows.append(r"\midrule")
    rows.append(rf"\multicolumn{{4}}{{l}}{{\emph{{Human annotators "
                rf"($n{{=}}{human['n_per_task']}$ per task, {human['raters']} "
                rf"raters)}}}} \\")
    rows.append(r"Human (majority vote) & " + " & ".join(
        f"${v:.1f}$" for v in human["majority_vote"]) + r" \\")
    rows.append(r"Human (pairwise $\kappa$) & " + " & ".join(
        f"${v:.2f}$" for v in human["pairwise_kappa"]) + r" \\")

    (TABLES / "human_solver.tex").write_text(r"""\begin{table}[htbp]
\centering
\footnotesize
\setlength{\tabcolsep}{2.0pt}
\begin{adjustbox}{max width=\columnwidth}
\begin{tabular}{l|ccc}
\toprule
\textbf{Solver} & \textbf{%s} & \textbf{%s} & \textbf{%s} \\
\midrule
%s
\bottomrule
\end{tabular}
\end{adjustbox}
\caption{Direct task performance (\S\ref{sec:bench:val} V4), from
\texttt{configs/direct\_solvers.json}; the base row is the ledger entry for
Qwen3-8B-Base. The four-option random-output reference is defined only for
OntoNeg-WN; the open-generation ConceptShift and LogicRepair tasks have no
uniform chance baseline, so their cells are not assigned $25\%%$. Humans and
frontier LLMs solve the tasks well above their task-appropriate references,
while Qwen3-8B-Base stays near the OntoNeg-WN reference, so the regression
studied here is not an artifact of an unsolvable benchmark.}
\label{tab:solver}
\end{table}
""" % (*spec["task_labels"], "\n".join(rows)))


def core_split_size() -> dict[str, int]:
    """Size of \\bench{}-Core, recomputed from the benchmark and audit sheets."""
    import csv

    def rows(path: Path) -> list[dict]:
        return [json.loads(line) for line in open(path) if line.strip()]

    onto = sum(1 for r in rows(BENCH / "onto_neg_wn_test.jsonl")
               if r["provenance"].get("certified"))
    logic = sum(1 for r in rows(BENCH / "logic_repair_test.jsonl")
                if all(r["certificate"][k] for k in ("unsat", "minimal", "nontrivial")))
    shift = sum(int(r["high_confidence"]) for r in csv.DictReader(
        open(AUDIT / "conceptshift_1000_reaudit.csv")))
    return {"onto_neg_wn": onto, "concept_shift": shift, "logic_repair": logic,
            "total": onto + shift + logic}


if __name__ == "__main__":
    main()
