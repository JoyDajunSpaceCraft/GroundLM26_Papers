#!/usr/bin/env python3
"""Derive the specificity-bias analysis numbers from shipped artifacts.

Three quantities reported in the analysis section are computed here and nowhere
else:

* the item-level discriminative power of a specificity score for the residual
  ConceptShift errors of the self-judged run (cross-validated AUC plus the odds
  ratio per within-config SD),
* the multilevel mediation decomposition over the checkpoint trajectory, using
  method-family fixed effects, shrunken run-level intercepts, and both
  run-level and family-level bootstrap intervals, and
* the drift-to-regression association before and after the specificity
  regressor is added.

Inputs are the shipped per-item predictions, the benchmark splits, and the
checkpoint trajectory. Output is ``outputs/stats/mediation.json`` plus a
refreshed ``mediation_summary.json``; the paper reads its numbers from those
files via ``scripts/render_paper_tables.py``.
"""

from __future__ import annotations

import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.evaluation.mediation import (  # noqa: E402
    is_over_specific,
    logistic_auc,
    multilevel_mediation,
    specificity_score,
)
from dion.utils.paths import audit_dir, bench_dir  # noqa: E402
from dion.evaluation.output_parser import parse_abstraction  # noqa: E402

BENCH = bench_dir(ROOT)
AUDIT = audit_dir(ROOT)
PRED = ROOT / "outputs/predictions"
STATS = ROOT / "outputs/stats"
TRAJECTORY = STATS / "checkpoint_mediation.jsonl"
ANALYSIS_SEED = 42


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.open() if line.strip()]


def accepted_golds(row: dict) -> set[str]:
    return {str(row["S"]).lower()} | {
        str(a).lower() for a in (row.get("S_alternatives") or [])}


def specificity_profile(config: str, split: str = "test") -> dict:
    """Per-item specificity scores for one config, plus the selection rate."""
    suffix = "" if split == "test" else f"_{split}"
    bench = {r["id"]: r for r in load_jsonl(BENCH / f"concept_shift_{split}.jsonl")}
    scores: list[float] = []
    errors: list[int] = []
    over_flags: list[bool] = []
    for item in load_jsonl(PRED / f"{config}_items{suffix}.jsonl"):
        if item["task"] != "concept_shift" or int(item["seed"]) != ANALYSIS_SEED:
            continue
        row = bench[item["id"]]
        pred = str(parse_abstraction(item["raw_output"]).value)
        scores.append(specificity_score(pred, str(row["S"]), str(row["T"])))
        over_flags.append(is_over_specific(pred, str(row["S"]), str(row["T"])))
        errors.append(int(pred.lower() not in accepted_golds(row)))
    x = np.asarray(scores, dtype=float)
    y = np.asarray(errors, dtype=int)
    over = np.asarray(over_flags, dtype=bool)
    return {
        "config": config,
        "split": split,
        "n_items": int(y.size),
        "error_rate": float(y.mean()),
        "over_specific_selection_rate": float(over.mean()),
        "specificity_error_share": float(over[y == 1].mean()) if y.any() else 0.0,
        "scores": x,
        "errors": y,
    }


# ------------------------------------------------------------------ item level
def item_level_specificity(config: str) -> dict:
    """Cross-validated AUC and odds ratio for a specificity score on errors."""
    profile = specificity_profile(config)
    x = np.asarray(profile["scores"], dtype=float)
    y = np.asarray(profile["errors"], dtype=int)
    sd = float(x.std(ddof=1)) or 1.0
    auc = logistic_auc((x[:, None] - x.mean()) / sd, y, leave_one_out=False)

    from sklearn.linear_model import LogisticRegression
    z = ((x - x.mean()) / sd)[:, None]
    fit = LogisticRegression(max_iter=1000).fit(z, y)
    coef = float(fit.coef_[0, 0])
    probs = fit.predict_proba(z)[:, 1]
    w = probs * (1.0 - probs)
    design = np.column_stack([np.ones_like(z[:, 0]), z[:, 0]])
    cov = np.linalg.pinv((design * w[:, None]).T @ design)
    se = math.sqrt(max(float(cov[1, 1]), 1e-12))
    wald = coef / se
    from scipy.stats import norm
    return {
        "config": config,
        "seed": ANALYSIS_SEED,
        "n_items": int(y.size),
        "error_rate": float(y.mean()),
        "auc": auc,
        "odds_ratio_per_sd": math.exp(coef),
        "odds_ratio_ci95": [math.exp(coef - 1.96 * se), math.exp(coef + 1.96 * se)],
        "p_value": float(2 * (1 - norm.cdf(abs(wald)))),
        "specificity_sd": sd,
        "over_specific_selection_rate": profile["over_specific_selection_rate"],
        "specificity_error_share": profile["specificity_error_share"],
    }


# ------------------------------------------------------------ checkpoint level
def spearman(a: np.ndarray, b: np.ndarray) -> float:
    from scipy.stats import spearmanr
    return float(spearmanr(a, b).statistic)


def spearman_p(a: np.ndarray, b: np.ndarray) -> float:
    from scipy.stats import spearmanr
    return float(spearmanr(a, b).pvalue)


def partial_correlation(y: np.ndarray, x: np.ndarray, controls: np.ndarray) -> tuple[float, float]:
    """Pearson correlation of y and x after projecting out ``controls``."""
    design = np.column_stack([np.ones(len(y)), controls])
    pinv = np.linalg.pinv(design)
    ry = y - design @ (pinv @ y)
    rx = x - design @ (pinv @ x)
    denom = float(np.linalg.norm(ry) * np.linalg.norm(rx))
    r = float(ry @ rx / denom) if denom else 0.0
    df = len(y) - controls.shape[1] - 2
    if df <= 0 or abs(r) >= 1.0:
        return r, 1.0
    t = r * math.sqrt(df / max(1.0 - r * r, 1e-12))
    from scipy.stats import t as tdist
    return r, float(2 * (1 - tdist.cdf(abs(t), df)))


def checkpoint_analysis(rows: list[dict]) -> dict:
    drift = np.asarray([r["kl_drift"] for r in rows], dtype=float)
    reg = np.asarray([r["worst_task_regression_pp"] for r in rows], dtype=float)
    # The mediator enters in points, like the outcome, so its coefficient reads
    # directly as points of worst-task regression per point of selection rate.
    spec = np.asarray(
        [r["specificity_selection_rate"] * 100.0 for r in rows], dtype=float)
    runs = [r["run_id"] for r in rows]
    families = [r["method_family"] for r in rows]
    steps = np.asarray([r["step"] for r in rows], dtype=float)
    params = np.asarray([r["trainable_params_m"] for r in rows], dtype=float)
    rank = np.asarray([r["adapter_rank"] for r in rows], dtype=float)

    dion = np.asarray([f == "dion_ref" for f in families])
    sr = np.asarray([f == "self_rewarding" for f in families])

    # Standardising the treatment puts the mediation coefficients on a per-SD
    # scale, which is what makes total and direct comparable across families.
    z_drift = (drift - drift.mean()) / (drift.std(ddof=1) or 1.0)
    # Two specifications, reported side by side. Without family fixed effects the
    # mediator path is estimated across method families; with them it is
    # estimated only within a family, where family no longer stands in for the
    # objective, the drift scale and the selection rate at once.
    across = multilevel_mediation(
        z_drift, spec, reg, runs, families, n_boot=4000, seed=3,
        family_fixed_effects=False)
    by_run = multilevel_mediation(
        z_drift, spec, reg, runs, families, n_boot=4000, seed=7)
    by_family = multilevel_mediation(
        z_drift, spec, reg, runs, families, n_boot=4000, seed=11,
        cluster_ids=families)

    controls = np.column_stack([params, steps, rank])
    r_raw, p_raw = partial_correlation(reg, drift, controls)
    r_adj, p_adj = partial_correlation(
        reg, drift, np.column_stack([controls, spec]))

    # Control ladder: each rung adds one design variable that could explain the
    # association away, so the reported partial correlation can be traced.
    ladder: list[dict] = []
    for label, block in (
        ("params", np.column_stack([params])),
        ("params, steps", np.column_stack([params, steps])),
        ("params, steps, rank", controls),
        ("params, steps, rank, over-specific rate", np.column_stack([controls, spec])),
    ):
        r_step, p_step = partial_correlation(reg, drift, block)
        ladder.append({"controls": label, "r": r_step, "p": p_step})

    sr_drift = drift[sr]
    sr_reg = reg[sr]
    outlier = {
        "family": "self_rewarding",
        "n_checkpoints": int(sr.sum()),
        "kl_drift_range": [float(sr_drift.min()), float(sr_drift.max())],
        "worst_regression_range_pp": [float(sr_reg.min()), float(sr_reg.max())],
        "drift_percentile_in_all": float((drift < sr_drift.mean()).mean()),
        "regression_percentile_in_all": float((reg < sr_reg.mean()).mean()),
    }

    # Run-level terminal points are the primary inferential unit. Checkpoints
    # are nested within runs and remain descriptive trajectory evidence.
    terminal_runs: dict[str, dict] = {}
    for row in rows:
        key = row["run_id"]
        if key not in terminal_runs or row["step"] > terminal_runs[key]["step"]:
            terminal_runs[key] = row
    run_drift = np.asarray([r["kl_drift"] for r in terminal_runs.values()])
    run_reg = np.asarray(
        [r["worst_task_regression_pp"] for r in terminal_runs.values()])

    # Method level: one point per configuration at its terminal checkpoint.
    terminal: dict[str, tuple[float, float]] = {}
    for row in rows:
        key = row["config"]
        if key not in terminal or row["step"] > terminal[key][0]:
            terminal[key] = (row["step"], row["kl_drift"], row["worst_task_regression_pp"])
    method_drift = np.asarray([v[1] for v in terminal.values()])
    method_reg = np.asarray([v[2] for v in terminal.values()])
    return {
        "n_checkpoints": len(rows),
        "n_runs": len(dict.fromkeys(runs)),
        "run_terminal_spearman": spearman(run_drift, run_reg),
        "run_terminal_spearman_p": spearman_p(run_drift, run_reg),
        "method_families": sorted(dict.fromkeys(families)),
        "family_counts": dict(sorted(Counter(families).items())),
        "spearman_all": spearman(drift, reg),
        "spearman_all_p": spearman_p(drift, reg),
        "spearman_within_dion_ref": spearman(drift[dion], reg[dion]),
        "spearman_within_dion_ref_p": spearman_p(drift[dion], reg[dion]),
        "spearman_within_self_rewarding": spearman(drift[sr], reg[sr]),
        "spearman_within_self_rewarding_p": spearman_p(drift[sr], reg[sr]),
        "spearman_method_level": spearman(method_drift, method_reg),
        "spearman_method_level_p": spearman_p(method_drift, method_reg),
        "n_methods": len(terminal),
        "partial_r_controlling_steps": r_raw,
        "partial_p_controlling_steps": p_raw,
        "residual_r_after_specificity": r_adj,
        "residual_p_after_specificity": p_adj,
        "control_ladder": ladder,
        "self_rewarding_outlier": outlier,
        "multilevel": {
            "scale": by_run.scale,
            "interpretation": by_run.interpretation,
            "n_obs": by_run.n_obs,
            "n_runs": by_run.n_runs,
            "n_families": by_run.n_families,
            "across_families": {
                "family_fixed_effects": False,
                "total_effect": across.total_effect,
                "direct_effect": across.direct_effect,
                "treatment_on_mediator": across.treatment_on_mediator,
                "mediator_coefficient": across.mediator_coefficient,
                "mediator_run_ci95": [across.mediator_ci_lo, across.mediator_ci_hi],
            },
            "within_families": {
                "family_fixed_effects": True,
                "total_effect": by_run.total_effect,
                "direct_effect": by_run.direct_effect,
                "treatment_on_mediator": by_run.treatment_on_mediator,
                "mediator_coefficient": by_run.mediator_coefficient,
                "mediator_run_ci95": [by_run.mediator_ci_lo, by_run.mediator_ci_hi],
                "mediator_family_ci95": [
                    by_family.mediator_ci_lo, by_family.mediator_ci_hi],
            },
        },
    }


def taxonomy_shares() -> dict:
    """Category shares of the human error taxonomy, per config and pooled."""
    import csv

    rows = list(csv.DictReader(open(AUDIT / "specificity_taxonomy.csv")))
    configs = sorted({r["config"] for r in rows})
    categories = sorted({r["taxonomy"] for r in rows})
    out: dict[str, dict] = {"n_rows": len(rows), "categories": categories,
                            "per_config": {}, "pooled": {}}
    for cfg in configs:
        subset = [r for r in rows if r["config"] == cfg]
        out["per_config"][cfg] = {
            "n": len(subset),
            "shares": {c: sum(r["taxonomy"] == c for r in subset) / len(subset)
                       for c in categories},
        }
    out["pooled"] = {c: sum(r["taxonomy"] == c for r in rows) / len(rows)
                     for c in categories}
    return out


def audited_subsets() -> dict:
    """ConceptShift accuracy on subsets defined by the shipped audit sheets."""
    import csv

    bench = {r["id"]: r for r in load_jsonl(BENCH / "concept_shift_test.jsonl")}
    reaudit = {r["id"]: r for r in csv.DictReader(
        open(AUDIT / "conceptshift_1000_reaudit.csv"))}

    def correct_map(config: str) -> dict[str, int]:
        out: dict[str, int] = {}
        for item in load_jsonl(PRED / f"{config}_items.jsonl"):
            if item["task"] != "concept_shift" or int(item["seed"]) != ANALYSIS_SEED:
                continue
            pred = str(parse_abstraction(item["raw_output"]).value).lower()
            out[item["id"]] = int(pred in accepted_golds(bench[item["id"]]))
        return out

    base = correct_map("base")
    sr = correct_map("self_rewarding_strict")
    unanimous = {i for i, r in reaudit.items()
                 if all(int(r[f"rater_{k}_correct"]) for k in (1, 2, 3))}
    ambiguous = {i for i, r in reaudit.items() if r["category"] == "ambiguous"}
    deep = {i for i, r in bench.items()
            if int((r.get("provenance") or {}).get("lcs_path_depth", 0)) >= 3}
    out = {}
    for name, ids in (("unanimous", unanimous), ("ambiguous", ambiguous),
                      ("deep_path", deep)):
        ids = sorted(ids & set(base))
        if not ids:
            continue
        b = sum(base[i] for i in ids) / len(ids)
        s = sum(sr[i] for i in ids) / len(ids)
        out[name] = {"n": len(ids), "base_accuracy": b, "self_rewarding": s,
                     "delta_pp": (s - b) * 100.0}
    return out


def _node_label(node_id: str) -> str:
    """Surface label of a graph node id, e.g. ``wn:fruit_tree.n.01`` -> fruit tree."""
    head = str(node_id).split(":", 1)[-1]
    return head.split(".")[0].replace("_", " ").strip().lower()


def gold_sensitivity() -> dict:
    """Self-Rewarding collapse under stricter and looser gold sets.

    Three scorings of the same predictions: the reference abstraction alone, the
    shipped accepted set (reference plus audited synonyms), and a multi-gold set
    that additionally accepts any node on the certified ancestor paths. If the
    collapse only existed under one of them it would be a labelling artifact.
    """
    bench = {r["id"]: r for r in load_jsonl(BENCH / "concept_shift_test.jsonl")}

    def gold_sets(row: dict) -> dict[str, set[str]]:
        strict = {str(row["S"]).lower()}
        accepted = strict | {str(a).lower() for a in (row.get("S_alternatives") or [])}
        prov = row.get("provenance") or {}
        ancestors = {
            _node_label(n)
            for key in ("ancestor_path_T", "ancestor_path_A")
            for n in (prov.get(key) or [])
        }
        # The endpoints themselves sit on their own ancestor paths; echoing an
        # endpoint is the failure mode under study, so it is never a gold.
        ancestors -= {str(row["T"]).lower(), str(row["A"]).lower()}
        return {"strict": strict, "accepted": accepted,
                "multi_gold": accepted | ancestors}

    def accuracy(config: str) -> dict[str, float]:
        totals = {"strict": 0, "accepted": 0, "multi_gold": 0}
        n = 0
        for item in load_jsonl(PRED / f"{config}_items.jsonl"):
            if item["task"] != "concept_shift" or int(item["seed"]) != ANALYSIS_SEED:
                continue
            pred = str(parse_abstraction(item["raw_output"]).value).lower()
            n += 1
            for name, golds in gold_sets(bench[item["id"]]).items():
                totals[name] += int(pred in golds)
        return {name: value / n for name, value in totals.items()}

    base, sr = accuracy("base"), accuracy("self_rewarding_strict")
    reference = (sr["accepted"] - base["accepted"]) * 100.0
    out = {"n_items": 1000, "base": base, "self_rewarding": sr, "deltas_pp": {}}
    for name in base:
        delta = (sr[name] - base[name]) * 100.0
        out["deltas_pp"][name] = {
            "delta_pp": delta,
            "retained_share": delta / reference if reference else 0.0,
        }
    return out


def main() -> int:
    rows = load_jsonl(TRAJECTORY)
    item = item_level_specificity("self_rewarding_strict")
    ckpt = checkpoint_analysis(rows)
    selection = {}
    for cfg in ("base", "self_rewarding_strict", "self_rewarding_csd", "self_critique"):
        for split in ("test", "conf"):
            profile = specificity_profile(cfg, split)
            selection[f"{cfg}:{split}"] = {
                k: v for k, v in profile.items() if k not in {"scores", "errors"}}
    bundle = {
        "item_level": item,
        "selection_rates": selection,
        "human_taxonomy": taxonomy_shares(),
        "audited_subsets": audited_subsets(),
        "gold_sensitivity": gold_sensitivity(),
        "checkpoint_level": ckpt,
    }
    (STATS / "mediation.json").write_text(json.dumps(bundle, indent=1) + "\n")

    ml = ckpt["multilevel"]
    (STATS / "mediation_summary.json").write_text(json.dumps({
        "level": "checkpoint",
        "n_checkpoints": ckpt["n_checkpoints"],
        "n_runs": ckpt["n_runs"],
        "method_families": ckpt["method_families"],
        "auc": item["auc"],
        "odds_ratio_per_sd": item["odds_ratio_per_sd"],
        "over_specific_selection_rate": {
            k: v["over_specific_selection_rate"] for k, v in selection.items()},
        "mediator_across_families": ml["across_families"]["mediator_coefficient"],
        "mediator_across_families_ci95":
            ml["across_families"]["mediator_run_ci95"],
        "mediator_within_families": ml["within_families"]["mediator_coefficient"],
        "mediator_within_families_ci95":
            ml["within_families"]["mediator_run_ci95"],
        "run_terminal_spearman_rho": ckpt["run_terminal_spearman"],
        "run_terminal_spearman_p": ckpt["run_terminal_spearman_p"],
        "checkpoint_spearman_rho": ckpt["spearman_all"],
        "method_spearman_rho": ckpt["spearman_method_level"],
        "within_dion_rho": ckpt["spearman_within_dion_ref"],
        "within_sr_rho": ckpt["spearman_within_self_rewarding"],
        "partial_r": ckpt["partial_r_controlling_steps"],
        "residual_r_after_specificity": ckpt["residual_r_after_specificity"],
        "residual_p_after_specificity": ckpt["residual_p_after_specificity"],
        "scale": ml["scale"],
        "interpretation": ml["interpretation"],
    }, indent=1) + "\n")

    print(f"[mediation] AUC={item['auc']:.4f} "
          f"OR/SD={item['odds_ratio_per_sd']:.3f} (p={item['p_value']:.2g})")
    print(f"[mediation] rho={ckpt['spearman_all']:.3f} "
          f"partial r={ckpt['partial_r_controlling_steps']:.3f} "
          f"residual r={ckpt['residual_r_after_specificity']:.3f} "
          f"(p={ckpt['residual_p_after_specificity']:.3f})")
    for label, block in (("across", ml["across_families"]),
                         ("within", ml["within_families"])):
        lo, hi = block["mediator_run_ci95"]
        print(f"[mediation] {label}-family mediator b="
              f"{block['mediator_coefficient']:.2f} run CI=[{lo:.2f}, {hi:.2f}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
