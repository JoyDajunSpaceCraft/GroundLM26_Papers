#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"
mkdir -p data/raw

CN_PATH="data/raw/conceptnet-assertions-5.7.0.csv.gz"
if [ ! -s "$CN_PATH" ]; then
  echo "[data] downloading ConceptNet 5.7 ..."
  curl -L --retry 3 -o "$CN_PATH" \
      https://s3.amazonaws.com/conceptnet/downloads/2019/edges/conceptnet-assertions-5.7.0.csv.gz
fi

echo "[data] HF datasets warm-up (FOLIO / ProofWriter + retention suite) ..."
python - <<'PY'
from datasets import load_dataset
for name, sub, split in [
    ("tasksource/folio", None, "train"),
    ("tasksource/proofwriter", None, "train[:20000]"),
    ("TIGER-Lab/MMLU-Pro", None, "test"),
    ("gsm8k", "main", "test"),
    ("hellaswag", None, "validation"),
    ("ai2_arc", "ARC-Challenge", "test"),
    ("truthful_qa", "multiple_choice", "validation"),
    ("Salesforce/wikitext", "wikitext-2-raw-v1", "test"),
]:
    print(f"[data] caching {name}/{sub}/{split}")
    if sub:
        load_dataset(name, sub, split=split)
    else:
        load_dataset(name, split=split)
PY

echo "[data] done."
