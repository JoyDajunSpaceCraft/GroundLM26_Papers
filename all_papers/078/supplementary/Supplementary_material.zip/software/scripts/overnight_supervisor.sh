#!/usr/bin/env bash
# Overnight supervisor: keep GPU backlog pipelines alive until all targets exist.
# READ-ONLY w.r.t. training scripts (does not edit them). Restarts dead pipelines.
set -uo pipefail
cd "$(dirname "$0")/.."
LOGDIR=outputs/gpu_backlog_logs
mkdir -p "$LOGDIR"
ALERT="$LOGDIR/overnight_supervisor.log"
STATUS="$LOGDIR/STATUS.md"
POLL=90
STALL_MIN=45

log() { echo "[$(date -Is)] $*" | tee -a "$ALERT"; }

export MODELS_DIR="${MODELS_DIR:-/export/models}"
export PYTHONPATH=src
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export HF_HOME="${HF_HOME:-/export/.hf_cache}"
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-/export/.hf_cache/datasets}"
export HF_DATASETS_OFFLINE="${HF_DATASETS_OFFLINE:-1}"
export HF_HUB_OFFLINE="${HF_HUB_OFFLINE:-1}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"

targets_done() {
  # Minimal done criteria for the night
  local need=(
    outputs/certified_only/shuffled_dpo_s42_test.json
    outputs/certified_only/shuffled_dpo_s43_test.json
    outputs/certified_only/shuffled_dpo_s44_test.json
    outputs/certified_only/self_critique_s43_test.json
    outputs/certified_only/self_critique_s44_test.json
    outputs/certified_only/entropy_min_s43_test.json
    outputs/certified_only/entropy_min_s44_test.json
    outputs/certified_only/sft_lora_s43_test.json
    outputs/certified_only/sft_lora_s44_test.json
    outputs/certified_only/lora_kl_s42_test.json
    outputs/predictions/csd_true_lp/summary.json
    outputs/retention/summary_seed_sd.json
  )
  local missing=0
  for f in "${need[@]}"; do
    [[ -f "$f" ]] || missing=1
  done
  # also accept lorakl only s42 if s43/s44 still going — require at least s42
  [[ -f outputs/certified_only/lora_kl_s42_test.json ]] || missing=1
  return $missing
}

count_missing() {
  local n=0
  for f in \
    outputs/certified_only/self_critique_s43_test.json \
    outputs/certified_only/self_critique_s44_test.json \
    outputs/certified_only/entropy_min_s43_test.json \
    outputs/certified_only/entropy_min_s44_test.json \
    outputs/certified_only/sft_lora_s43_test.json \
    outputs/certified_only/sft_lora_s44_test.json \
    outputs/certified_only/lora_kl_s42_test.json \
    outputs/certified_only/lora_kl_s43_test.json \
    outputs/certified_only/lora_kl_s44_test.json \
    outputs/mixed_pool/self_rewarding_s42/self_rewarding_strict/state.pt \
    outputs/retention/summary_seed_sd.json
  do
    [[ -f "$f" ]] || n=$((n+1))
  done
  echo "$n"
}

ensure_missed() {
  if pgrep -f "run_gpu_backlog_missed_sc_em_sft.sh" >/dev/null; then
    return 0
  fi
  # Only needed if any SC/EM/SFT s43/44 missing
  local need_missed=0
  for f in \
    outputs/certified_only/self_critique_s43/self_critique/state.pt \
    outputs/certified_only/self_critique_s44/self_critique/state.pt \
    outputs/certified_only/entropy_min_s43/entropy_min/state.pt \
    outputs/certified_only/entropy_min_s44/entropy_min/state.pt \
    outputs/certified_only/sft_lora_s43/sft_lora/state.pt \
    outputs/certified_only/sft_lora_s44/sft_lora/state.pt \
    outputs/certified_only/self_critique_s43_test.json \
    outputs/certified_only/self_critique_s44_test.json \
    outputs/certified_only/entropy_min_s43_test.json \
    outputs/certified_only/entropy_min_s44_test.json \
    outputs/certified_only/sft_lora_s43_test.json \
    outputs/certified_only/sft_lora_s44_test.json
  do
    [[ -f "$f" ]] || need_missed=1
  done
  if (( need_missed == 0 )); then
    return 0
  fi
  # Don't start missed if resume_tail is actively training lorakl/mixed (GPU exclusive)
  if pgrep -af "stage2_abo|run_retention_eval|mixed_pool|self_rewarding.*mixed" | grep -v pgrep >/dev/null; then
    log "INFO skip restart missed — resume worker holds GPU"
    return 0
  fi
  log "ALERT restarting missed SC/EM/SFT"
  nohup bash scripts/run_gpu_backlog_missed_sc_em_sft.sh >> "$LOGDIR/missed_supervisor_relaunch.log" 2>&1 &
  echo $! > "$LOGDIR/missed.pid"
}

ensure_resume() {
  if pgrep -f "run_gpu_backlog_resume_tail.sh" >/dev/null; then
    return 0
  fi
  local need=0
  for f in \
    outputs/certified_only/lora_kl_s42/stage2_abo/abo_state.pt \
    outputs/certified_only/lora_kl_s42_test.json \
    outputs/mixed_pool/self_rewarding_s42/self_rewarding_strict/state.pt \
    outputs/retention/summary_seed_sd.json
  do
    [[ -f "$f" ]] || need=1
  done
  if (( need == 0 )); then
    return 0
  fi
  # If missed still running, chain wait
  local wait_pid=""
  if pgrep -f "run_gpu_backlog_missed_sc_em_sft.sh" >/dev/null; then
    wait_pid=$(pgrep -f "run_gpu_backlog_missed_sc_em_sft.sh" | head -1)
  fi
  log "ALERT restarting resume_tail WAIT_PID=${wait_pid:-none}"
  if [[ -n "$wait_pid" ]]; then
    WAIT_PID="$wait_pid" nohup bash scripts/run_gpu_backlog_resume_tail.sh >> "$LOGDIR/resume_supervisor_relaunch.log" 2>&1 &
  else
    nohup bash scripts/run_gpu_backlog_resume_tail.sh >> "$LOGDIR/resume_supervisor_relaunch.log" 2>&1 &
  fi
  echo $! > "$LOGDIR/resume.pid"
}

LAST_MARK=""
LAST_TS=$(date +%s)

log "overnight supervisor started pid=$$"

while true; do
  miss=$(count_missing)
  gpu=$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader 2>/dev/null | head -1)
  py=$(pgrep -af "dion\.(baselines|training|evaluation)|run_retention_eval|stage2_abo" 2>/dev/null | grep -v pgrep | head -1 || true)
  missed_alive=$(pgrep -f "run_gpu_backlog_missed_sc_em_sft.sh" >/dev/null && echo yes || echo no)
  resume_alive=$(pgrep -f "run_gpu_backlog_resume_tail.sh" >/dev/null && echo yes || echo no)

  # progress mark from newest logs
  mark=$( (
      rg -n "TRAIN |EVAL |DONE |FAIL |step [0-9]+/|Phase |RETENTION |waiting for|resume tail|finished" \
        "$LOGDIR"/missed_*.log "$LOGDIR"/resume_tail_*.log "$LOGDIR"/resume_supervisor_relaunch.log \
        "$LOGDIR"/missed_supervisor_relaunch.log 2>/dev/null || true
    ) | tail -1 )

  now=$(date +%s)
  if [[ "$mark" != "$LAST_MARK" ]]; then
    LAST_MARK="$mark"
    LAST_TS=$now
  fi
  # active GPU python => not stalled
  mem=$(echo "$gpu" | awk -F', ' '{print $1}' | tr -dc '0-9')
  if [[ -n "$py" && -n "$mem" && "$mem" -gt 2000 ]]; then
    LAST_TS=$now
  fi
  idle=$(( (now - LAST_TS) / 60 ))

  # Fail signatures in recent logs
  if rg -q "FAIL train|Traceback \(most recent call last\)|grad_fn|inplace operation|unrecognized arguments" \
      "$LOGDIR"/missed_20260805_175228.log "$LOGDIR"/resume_tail_*.log \
      "$LOGDIR"/missed_supervisor_relaunch.log "$LOGDIR"/resume_supervisor_relaunch.log 2>/dev/null; then
    # only alert if NEW lines in last 3 minutes — cheap check via mtime
    :
  fi

  cat > "$STATUS" <<EOF
# GPU backlog status (overnight supervisor)
Updated: $(date -Is)

- missing_targets: $miss
- missed pipeline: $missed_alive
- resume pipeline: $resume_alive
- idle_min: $idle
- gpu0: $gpu
- mark: $mark
- worker: $py

## Completed so far
- CSD true-lp parent
- Shuffled-DPO s42/43/44

## Pipeline
SC/EM/SFT s43-44 → LoRA+KL ×3 → mixed SR+CSD → Retention
EOF

  ensure_missed
  # Only ensure resume if missed not needed OR already waiting/running
  ensure_resume

  if (( idle >= STALL_MIN )); then
    log "ALERT stall ${idle}min mark=$mark gpu=$gpu py=$py"
    # If no python worker but targets remain, force relaunch
    if [[ -z "$py" ]]; then
      log "ALERT no GPU worker — forcing pipeline ensure"
      # kill empty waiters? leave ensure_* to relaunch
      pkill -f "run_gpu_backlog_missed_sc_em_sft.sh" 2>/dev/null || true
      pkill -f "run_gpu_backlog_resume_tail.sh" 2>/dev/null || true
      sleep 5
      ensure_missed
      ensure_resume
      LAST_TS=$(date +%s)
    fi
  fi

  if (( miss == 0 )); then
    log "OK all night targets present — supervisor exiting"
    python3 scripts/summarize_certified_evals.py >> "$ALERT" 2>&1 || true
    echo "FINISHED $(date -Is)" > "$LOGDIR/OVERNIGHT_DONE"
    exit 0
  fi

  sleep "$POLL"
done
