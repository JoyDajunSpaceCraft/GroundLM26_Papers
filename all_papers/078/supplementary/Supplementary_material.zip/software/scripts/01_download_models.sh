#!/usr/bin/env bash
set -euo pipefail
export HF_HUB_ENABLE_HF_TRANSFER=1
: "${HF_ENDPOINT:=https://huggingface.co}"
export HF_ENDPOINT

DEST="${1:-${MODELS_DIR:-./models}}"
mkdir -p "$DEST"

echo "[models] downloading Qwen3-8B-Base into $DEST/Qwen3-8B-Base ..."
huggingface-cli download Qwen/Qwen3-8B-Base \
    --local-dir "$DEST/Qwen3-8B-Base" \
    --local-dir-use-symlinks False \
    --resume-download

if [ "${DOWNLOAD_CROSS_BACKBONE:-0}" = "1" ]; then
  echo "[models] downloading Qwen3-8B-Instruct (cross-backbone) ..."
  if [ ! -d "$DEST/Qwen3-8B-Instruct" ]; then
    huggingface-cli download Qwen/Qwen3-8B-Instruct \
        --local-dir "$DEST/Qwen3-8B-Instruct" \
        --local-dir-use-symlinks False \
        --resume-download
  fi
  echo "[models] downloading Llama-3.1-8B (cross-backbone) ..."
  if [ ! -d "$DEST/Llama-3.1-8B" ]; then
    huggingface-cli download meta-llama/Llama-3.1-8B \
        --local-dir "$DEST/Llama-3.1-8B" \
        --local-dir-use-symlinks False \
        --resume-download
  fi
fi

echo "[models] done. Hub layout:"
ls "$DEST"
