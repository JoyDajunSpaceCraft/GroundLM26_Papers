#!/usr/bin/env python3
"""Compose complete two-row Figure 1 (all five stages; no split/summary cards).

Source: figures/figure1_wide_source.png
Output: figures/figure1.png, paper/figures/figure1.png
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "figures" / "figure1_wide_source.png"
TARGET_PRINT_H = 6.70
TARGET_W = 3600


def ink_bbox(im: Image.Image, thr: int = 249, pad: int = 6) -> Image.Image:
    a = np.asarray(im)
    mask = (a[:, :, 0] < thr) | (a[:, :, 1] < thr) | (a[:, :, 2] < thr)
    rows = np.where(mask.any(axis=1))[0]
    cols = np.where(mask.any(axis=0))[0]
    return im.crop(
        (
            max(0, int(cols[0]) - pad),
            max(0, int(rows[0]) - pad),
            min(im.width, int(cols[-1]) + 1 + pad),
            min(im.height, int(rows[-1]) + 1 + pad),
        )
    )


def trim_internal_only(
    im: Image.Image, max_gap: int = 14, thr: int = 249, edge_protect: int = 40
) -> Image.Image:
    a = np.asarray(im)
    ink = ((a[:, :, 0] < thr) | (a[:, :, 1] < thr) | (a[:, :, 2] < thr)).mean(axis=1)
    white = ink < 0.01
    keep = np.ones(len(white), dtype=bool)
    i, n = 0, len(white)
    while i < n:
        if not white[i]:
            i += 1
            continue
        j = i
        while j < n and white[j]:
            j += 1
        if i >= edge_protect and j <= n - edge_protect and (j - i) > max_gap:
            drop_start = i + max_gap // 2
            drop_end = j - max_gap // 2
            if drop_end > drop_start:
                keep[drop_start:drop_end] = False
        i = j
    return Image.fromarray(a[keep]) if not keep.all() else im


def sc(im: Image.Image, scale: float) -> Image.Image:
    out = im.resize(
        (max(1, int(im.width * scale)), max(1, int(im.height * scale))),
        Image.Resampling.LANCZOS,
    )
    return out.filter(ImageFilter.UnsharpMask(radius=1.2, percent=140, threshold=2))


def compose(src: Image.Image) -> Image.Image:
    x0, x_mid, x1 = 24, 1010, 1640
    y0, y1 = 38, 690
    fy0, fy1 = 728, 848
    row1 = trim_internal_only(ink_bbox(src.crop((x0, y0, x_mid, y1))))
    row2 = trim_internal_only(ink_bbox(src.crop((x_mid, y0, x1, y1))))
    footer = ink_bbox(src.crop((16, fy0, 1654, fy1)), pad=4)
    s = TARGET_W / row1.width
    gap, pad = 6, 10
    r1, r2 = sc(row1, s), sc(row2, s)
    ft = footer.resize(
        (r1.width, max(1, int(footer.height * r1.width / footer.width))),
        Image.Resampling.LANCZOS,
    )
    ft = ft.filter(ImageFilter.UnsharpMask(radius=1.2, percent=140, threshold=2))
    W = r1.width + 2 * pad
    H = pad + r1.height + gap + r2.height + gap + ft.height + pad
    bg = Image.new("RGB", (W, H), (248, 250, 252))
    bg.paste(r1, (pad, pad))
    bg.paste(r2, (pad + (r1.width - r2.width) // 2, pad + r1.height + gap))
    bg.paste(ft, (pad, pad + r1.height + gap + r2.height + gap))
    print_w = 6.3
    natural_h = print_w * bg.height / bg.width
    if natural_h > TARGET_PRINT_H:
        new_h = int(bg.width * TARGET_PRINT_H / print_w)
        bg = bg.resize((bg.width, new_h), Image.Resampling.LANCZOS)
        bg = bg.filter(ImageFilter.UnsharpMask(radius=1.3, percent=150, threshold=2))
    return bg


def main() -> None:
    if not SRC.is_file():
        raise SystemExit(f"missing wide source: {SRC}")
    out = compose(Image.open(SRC).convert("RGB"))
    for dest in (ROOT / "figures" / "figure1.png", ROOT / "paper" / "figures" / "figure1.png"):
        dest.parent.mkdir(parents=True, exist_ok=True)
        out.save(dest, optimize=True)
        print(
            f"wrote {dest} {out.size} print_h@6.3in={6.3 * out.height / out.width:.2f}"
        )


if __name__ == "__main__":
    main()
