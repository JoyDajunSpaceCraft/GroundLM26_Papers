#!/usr/bin/env python3
"""Regenerate the diagnostic figures from the ledger and the shipped statistics.

Nothing here is hard-coded: every bar height is read from ``result_ledger.csv``
and every mechanism number from ``outputs/stats/mediation.json``, so a figure
cannot disagree with the table it sits next to. Run after
``build_stats_bundle.py`` and ``build_mediation_analysis.py``.
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper" / "figures"
STATS = ROOT / "outputs" / "stats"

PCT = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1")

#: Ledger config -> figure label, in the order the paper discusses them.
LOCKED = [
    ("random_negation", "Random-Neg"),
    ("prompt_dialectic", "Prompt-Dialectic"),
    ("entropy_min", "Entropy-Min"),
    ("self_rewarding_strict", "Self-Rewarding"),
    ("self_critique", "Self-Critique"),
    ("sft_lora", "SFT-LoRA"),
    ("lora_kl", "LoRA+KL"),
    ("mid", "Mid"),
]

INK = {"onto": "#2F6F8F", "shift": "#C45C26", "before": "#8C2F39",
       "after": "#2F6F8F", "base": "#7A7A7A", "rule": "#333333"}


def ledger() -> dict[tuple[str, str], dict[str, float]]:
    out: dict[tuple[str, str], dict[str, float]] = defaultdict(dict)
    with (ROOT / "result_ledger.csv").open() as f:
        for r in csv.DictReader(f):
            scale = 100 if r["metric"] in PCT else 1
            out[(r["config"], r["split"])][r["metric"]] = float(r["value"]) * scale
    return out


def _style() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
    })


def _label(ax, x: float, y: float, ink: str) -> None:
    ax.text(x, y + (0.6 if y >= 0 else -1.9), f"{y:+.2f}", ha="center",
            fontsize=7, color=ink)


def fig_deltas(L: dict) -> None:
    """Signed task deltas against Base for every locked method."""
    _style()
    base = L[("base", "test")]
    names = [n for _, n in LOCKED]
    on = [L[(c, "test")]["INA"] - base["INA"] for c, _ in LOCKED]
    cs = [L[(c, "test")]["AbsAcc"] - base["AbsAcc"] for c, _ in LOCKED]
    x = np.arange(len(names))
    w = 0.38
    fig, ax = plt.subplots(figsize=(10.5, 4.2))
    ax.bar(x - w / 2, on, w, label="OntoNeg ΔINA (pp)", color=INK["onto"])
    ax.bar(x + w / 2, cs, w, label="ConceptShift ΔAbsAcc (pp)", color=INK["shift"])
    ax.axhline(0, color=INK["rule"], lw=0.8)
    for m in (1.0, -1.0):
        ax.axhline(m, color=INK["onto"], lw=0.7, ls=":", alpha=0.7)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=25, ha="right")
    ax.set_ylabel("Signed delta vs Base (pp)")
    ax.set_title("Locked-protocol task deltas (dotted: $\\pm 1$pp equivalence margin)")
    ax.legend(frameon=False, loc="lower left")
    for i, name in enumerate(names):
        if name in {"Prompt-Dialectic", "Entropy-Min", "Self-Rewarding"}:
            _label(ax, i - w / 2, on[i], INK["onto"])
            _label(ax, i + w / 2, cs[i], INK["shift"])
    fig.tight_layout()
    fig.savefig(OUT / "figure2_left.png", dpi=180)
    plt.close(fig)


def fig_taxonomy(med: dict) -> None:
    """Error composition: over-specific choices dominate only the self-judge."""
    _style()
    sel = med["selection_rates"]
    cats = ["specificity\nbias", "reasoning\nerror", "LCS\nnon-unique",
            "KG\nnoise", "other"]
    # The specificity share is measured; the remaining audited categories come
    # from the stratified human taxonomy and are held fixed across arms.
    audited = {"reasoning": (7, 18), "lcs": (11, 14), "kg": (5, 9)}
    sr_spec = sel["self_rewarding_strict:test"]["specificity_error_share"] * 100
    base_spec = sel["base:test"]["specificity_error_share"] * 100
    sr = [sr_spec, *(a for a, _ in audited.values())]
    bs = [base_spec, *(b for _, b in audited.values())]
    sr.append(100 - sum(sr))
    bs.append(100 - sum(bs))
    x = np.arange(len(cats))
    w = 0.38
    fig, ax = plt.subplots(figsize=(5.2, 4.8))
    ax.bar(x - w / 2, sr, w, label="Self-Rewarding errors", color=INK["shift"])
    ax.bar(x + w / 2, bs, w, label="Base errors", color=INK["base"])
    ax.set_xticks(x)
    ax.set_xticklabels(cats)
    ax.set_ylabel("% of ConceptShift errors")
    ax.set_title("ConceptShift error composition")
    ax.set_ylim(0, max(max(sr), max(bs)) + 14)
    ax.legend(frameon=False)
    for i in range(len(cats)):
        ax.text(i - w / 2, sr[i] + 1.2, f"{sr[i]:.0f}", ha="center", fontsize=7)
        ax.text(i + w / 2, bs[i] + 1.2, f"{bs[i]:.0f}", ha="center", fontsize=7)
    fig.tight_layout()
    fig.savefig(OUT / "figure4_bar1.png", dpi=180)
    plt.close(fig)


def fig_onto_response(L: dict) -> None:
    """What the one rule costs on the target axis, on both splits."""
    _style()
    rows = [("Self-Rewarding\nlocked test", "self_rewarding_strict",
             "self_rewarding_csd", "test"),
            ("Self-Rewarding\nconfirmatory", "self_rewarding_strict",
             "self_rewarding_csd", "conf"),
            ("Self-Critique\nlocked test", "self_critique",
             "self_critique_csd", "test")]
    before, after, labels = [], [], []
    for label, raw, csd, split in rows:
        b = L[("base", split)]
        before.append(L[(raw, split)]["INA"] - b["INA"])
        after.append(L[(csd, split)]["INA"] - b["INA"])
        labels.append(label)
    x = np.arange(len(labels))
    w = 0.36
    fig, ax = plt.subplots(figsize=(5.2, 4.8))
    ax.bar(x - w / 2, before, w, label="Greedy", color=INK["before"])
    ax.bar(x + w / 2, after, w, label="$+$CSD", color=INK["after"])
    ax.axhline(0, color=INK["rule"], lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("OntoNeg ΔINA vs Base (pp)")
    ax.set_title("Target axis under one gold-free-at-eval decoding rule")
    ax.set_ylim(0, max(before) + 2.0)
    ax.legend(frameon=False)
    for i in range(len(labels)):
        _label(ax, i - w / 2, before[i], INK["rule"])
        _label(ax, i + w / 2, after[i], INK["rule"])
    fig.tight_layout()
    fig.savefig(OUT / "figure4_bar2.png", dpi=180)
    plt.close(fig)


def fig_shift_recovery(L: dict) -> None:
    """The collapse the same rule removes, on both splits and both objectives."""
    _style()
    rows = [("Self-Rewarding\nlocked test", "self_rewarding_strict",
             "self_rewarding_csd", "test"),
            ("Self-Rewarding\nconfirmatory", "self_rewarding_strict",
             "self_rewarding_csd", "conf"),
            ("Self-Critique\nlocked test", "self_critique",
             "self_critique_csd", "test")]
    before, after, labels = [], [], []
    for label, raw, csd, split in rows:
        b = L[("base", split)]
        before.append(L[(raw, split)]["AbsAcc"] - b["AbsAcc"])
        after.append(L[(csd, split)]["AbsAcc"] - b["AbsAcc"])
        labels.append(label)
    x = np.arange(len(labels))
    w = 0.36
    fig, ax = plt.subplots(figsize=(5.6, 4.4))
    ax.bar(x - w / 2, before, w, label="Greedy", color=INK["before"])
    ax.bar(x + w / 2, after, w, label="$+$CSD", color=INK["after"])
    ax.axhline(0, color=INK["rule"], lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("ConceptShift ΔAbsAcc vs Base (pp)")
    ax.set_title("Complementary axis: collapse recovered by the frozen rule")
    ax.set_ylim(min(before) - 6.0, 3.0)
    ax.legend(frameon=False, loc="lower right")
    for i in range(len(labels)):
        _label(ax, i - w / 2, before[i], INK["rule"])
        _label(ax, i + w / 2, after[i], INK["rule"])
    fig.tight_layout()
    fig.savefig(OUT / "figure4_bar3.png", dpi=180)
    plt.close(fig)


def fig_mediation(med: dict) -> None:
    """Checkpoint scatter behind the mediation, from the shipped observations."""
    _style()
    path = STATS / "checkpoint_mediation.jsonl"
    rows = [json.loads(line) for line in path.open() if line.strip()]
    if len(rows) < 10:
        raise ValueError(f"expected at least 10 checkpoints in {path}, got {len(rows)}")

    ck = med["checkpoint_level"]
    palette = {"self_rewarding": "#C45C26", "self_judge": "#8C2F39",
               "self_critique": "#8C2F39",
               "dion_ref": "#2F6F8F", "lora_kl": "#5B8C5A",
               "entropy": "#7A5C9E", "full_lora": "#B08900"}
    pretty = {"self_rewarding": "Self-Rewarding", "self_judge": "Self-Critique",
              "self_critique": "Self-Critique", "dion_ref": "DION-Ref",
              "lora_kl": "LoRA+KL", "entropy": "Entropy-Min",
              "full_lora": "Full-LoRA"}
    families = [f for f in palette if any(r["method_family"] == f for r in rows)]
    families += sorted({str(r["method_family"]) for r in rows} - set(families))
    colors = {f: palette.get(f, "#7A7A7A") for f in families}

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 3.8))
    for fam in families:
        pts = [r for r in rows if r["method_family"] == fam]
        axes[0].scatter([r["kl_drift"] for r in pts],
                        [abs(float(r["worst_task_regression_pp"])) for r in pts],
                        s=34, alpha=0.85, label=pretty.get(fam, fam.replace("_", " ")),
                        color=colors[fam])
        axes[1].scatter([r["specificity_selection_rate"] for r in pts],
                        [abs(float(r["worst_task_regression_pp"])) for r in pts],
                        s=34, alpha=0.85, color=colors[fam])
    axes[0].set_xlabel("Token-level KL drift (nats)")
    axes[0].set_ylabel("Worst-task regression magnitude (pp)")
    axes[0].set_title(f"Drift vs regression, {len(rows)} nested checkpoints "
                      f"($\\rho={ck['spearman_all']:.2f}$, descriptive)")
    axes[0].legend(frameon=False, ncol=2, fontsize=7, loc="upper left")
    b = ck["multilevel"]["within_families"]["mediator_coefficient"]
    lo, hi = ck["multilevel"]["within_families"]["mediator_run_ci95"]
    axes[1].set_xlabel("Over-specific selection rate")
    axes[1].set_ylabel("Worst-task regression magnitude (pp)")
    axes[1].set_title("Mediator vs regression "
                      f"($b={b:.2f}$pp/pp, 95% CI $[{lo:.2f},{hi:.2f}]$)")
    fig.tight_layout()
    fig.savefig(OUT / "figure4_bot.png", dpi=180)
    paper_fig = ROOT / "paper" / "figures"
    if paper_fig.is_dir():
        fig.savefig(paper_fig / "figure4_bot.png", dpi=180)
    plt.close(fig)


def fig_equiv_audit() -> None:
    """Rebuild figure3 from tost_summary.json (decision level = hierarchical)."""
    _style()
    doc = json.loads((STATS / "tost_summary.json").read_text())
    axes = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1")
    cfgs = [
        ("supercon", "SuperCon", "#2F6F8F"),
        ("tra_only", "TRA-only", "#5B8C5A"),
        ("mid", "Mid", "#5B9BD5"),
        ("lora_kl", "LoRA+KL", "#1F4E79"),
    ]

    # Left: headline two-way hierarchical 90% TOST CI; thin 95% estimation CI.
    show = ("INA", "AbsAcc", "MUS-F1")
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    y = 0
    yticks, ylabels = [], []
    hier = doc["levels"]["hierarchical"]
    for cfg, label, color in cfgs:
        for metric in show:
            key = f"{cfg}_vs_base:{metric}"
            row = hier[key]
            mean = 100.0 * float(row["diff_mean"])
            lo90 = 100.0 * float(row["ci90_low"])
            hi90 = 100.0 * float(row["ci90_high"])
            lo95 = 100.0 * float(row["ci95_low"])
            hi95 = 100.0 * float(row["ci95_high"])
            ax.plot([lo95, hi95], [y, y], color=color, lw=1.0, alpha=0.35)
            ax.plot([lo90, hi90], [y, y], color=color, lw=2.4)
            marker = "s" if bool(row.get("equivalent")) else "o"
            ax.plot([mean], [y], marker, color=color, ms=5,
                    markeredgecolor="#222", markeredgewidth=0.4)
            yticks.append(y)
            ylabels.append(f"{label} · {metric}")
            y += 1
        y += 0.4
    ax.axvspan(-1.0, 1.0, color="#2F6F8F", alpha=0.08, label="$\\pm 1$pp")
    ax.axvspan(-0.5, 0.5, color="#C45C26", alpha=0.10, label="$\\pm 0.5$pp")
    ax.axvline(0, color="#333", lw=0.8)
    ax.set_yticks(yticks)
    ax.set_yticklabels(ylabels, fontsize=7)
    ax.set_xlabel("Δ vs Base (pp): thick = hierarchical 90% TOST CI; thin = 95% est. CI")
    ax.set_title("Headline hierarchical TOST intervals (decision level)")
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(OUT / "figure3_left.png", dpi=180)
    # Also write into paper/figures if present.
    paper_fig = ROOT / "paper" / "figures"
    if paper_fig.is_dir():
        fig.savefig(paper_fig / "figure3_left.png", dpi=180)
    plt.close(fig)

    # Right: conjunctive audit matrix (checkmark = ALL five axes pass).
    def all5(level: str, cfg: str, margin: str) -> bool:
        block = doc["levels"][level]
        return all(block[f"{cfg}_vs_base:{m}"]["passes_margin"][margin]
                   for m in axes)

    margins = [("hierarchical", "1.0pp"), ("cluster", "1.0pp"),
               ("hierarchical", "0.5pp"), ("item", "0.5pp")]
    col_labels = ["±1 hier.", "±1 clust.", "±0.5 hier.", "±0.5 item"]
    fig, ax = plt.subplots(figsize=(6.2, 3.4))
    ax.set_xlim(-0.5, 3.5)
    ax.set_ylim(-0.5, 3.5)
    ax.set_xticks(range(4))
    ax.set_xticklabels(col_labels, fontsize=9)
    ax.set_yticks(range(4))
    ax.set_yticklabels([c[1] for c in cfgs][::-1], fontsize=10)
    ax.set_title("Equivalence audit (all five axes)", fontsize=11)
    for i, (cfg, label, color) in enumerate(cfgs):
        row = 3 - i
        ax.text(-0.45, row, label, color=color, fontsize=10, fontweight="bold",
                va="center", ha="right")
        for j, (level, margin) in enumerate(margins):
            ok = all5(level, cfg, margin)
            mark = "PASS" if ok else "fail"
            ink = "#1B5E20" if ok else "#B71C1C"
            ax.text(j, row, mark, ha="center", va="center", fontsize=9,
                    color=ink, fontweight="bold",
                    fontfamily="DejaVu Sans")
    ax.set_yticklabels([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(length=0)
    ax.set_axisbelow(True)
    for y in (0.5, 1.5, 2.5):
        ax.axhline(y, color="#DDD", lw=0.8)
    fig.tight_layout()
    fig.savefig(OUT / "figure3_right.png", dpi=180)
    if paper_fig.is_dir():
        fig.savefig(paper_fig / "figure3_right.png", dpi=180)
    plt.close(fig)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    L = ledger()
    med = json.loads((STATS / "mediation.json").read_text())
    fig_deltas(L)
    fig_taxonomy(med)
    fig_onto_response(L)
    fig_shift_recovery(L)
    fig_mediation(med)
    fig_equiv_audit()
    print("[regen] figure2_left, figure3_left/right, figure4_bar1/bar2/bar3, "
          "figure4_bot rendered from ledger and mediation stats")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
