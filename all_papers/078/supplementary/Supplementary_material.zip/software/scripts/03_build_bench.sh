#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")"/.. && pwd)"
cd "$HERE"
python -m dion.bench.builder_main --config configs/dion_main.yaml --task all
