#!/usr/bin/env python3
"""Per-seed external retention suite (GSM8K / MMLU-Pro / HellaSwag / ARC-C /
TruthfulQA-MC1 / WikiText-PPL) for RetentionNI seed_sd backfill.

Writes JSON under outputs/retention/<label>_s<seed>.json with per-task scores.
Does not invent ledger numbers; callers merge empirical seed_sd separately.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from dion.evaluation.general_retention import (
    eval_arc_c,
    eval_gsm8k,
    eval_hellaswag,
    eval_mmlu_pro,
    eval_truthfulqa,
    eval_wikitext_ppl,
)
from dion.training.loader import load_dion_model
from dion.utils.io import load_yaml
from dion.utils.logging_utils import get_logger
from dion.utils.seed import set_seed

logger = get_logger("dion.eval.retention")


def _configure_hf_cache() -> None:
    """Point at the shared /export cache; stay offline unless explicitly overridden."""
    import os

    os.environ.setdefault("HF_HOME", "/export/.hf_cache")
    os.environ.setdefault("HF_DATASETS_CACHE", "/export/.hf_cache/datasets")
    if os.environ.get("HF_FORCE_ONLINE", "0") != "1":
        os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
        os.environ.setdefault("HF_HUB_OFFLINE", "1")


def _load_ckpt(model, ckpt: str | None) -> None:
    if not ckpt or not Path(ckpt).exists():
        return
    sd = torch.load(ckpt, map_location="cpu")
    if "tras" in sd:
        model.heads.tras.load_state_dict(sd["tras"], strict=False)
    for n, p in model.named_parameters():
        if n in sd.get("lora", {}):
            with torch.no_grad():
                p.copy_(sd["lora"][n].to(p.device).to(p.dtype))
    logger.info(f"Loaded checkpoint {ckpt}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/dion_sft_lora.yaml")
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--label", required=True, help="e.g. base / self_rewarding_strict")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=None)
    ap.add_argument("--n_gsm8k", type=int, default=500)
    ap.add_argument("--n_mmlu", type=int, default=1000)
    ap.add_argument("--n_hellaswag", type=int, default=1000)
    ap.add_argument("--n_arc", type=int, default=1000)
    ap.add_argument("--n_wikitext", type=int, default=500)
    ap.add_argument("--max_new_tokens", type=int, default=32)
    args = ap.parse_args()

    _configure_hf_cache()
    set_seed(args.seed)
    cfg = load_yaml(args.config)
    # Retention is generation-only; keep GC off for speed/stability.
    cfg.setdefault("train", {})["gradient_checkpointing"] = False
    model, tok = load_dion_model(cfg)
    _load_ckpt(model, args.ckpt)
    model.disable_injection()
    model.eval()
    device = next(model.parameters()).device
    base = model.base if hasattr(model, "base") else model

    @torch.no_grad()
    def model_call(prompt: str) -> str:
        enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to(device)
        out = base.generate(
            **enc,
            max_new_tokens=args.max_new_tokens,
            do_sample=False,
            pad_token_id=tok.pad_token_id,
        )
        return tok.decode(out[0][enc["input_ids"].size(1):], skip_special_tokens=True)

    @torch.no_grad()
    def score_fn(text: str) -> float:
        enc = tok(text, return_tensors="pt", truncation=True, max_length=512).to(device)
        labels = enc["input_ids"].clone()
        out = base(**enc, labels=labels)
        # mean NLL in nats
        return float(out.loss.item())

    results = {}
    for name, fn in [
        ("GSM8K", lambda: eval_gsm8k(model_call, n_examples=args.n_gsm8k)),
        ("MMLU-Pro", lambda: eval_mmlu_pro(model_call, n_examples=args.n_mmlu, seed=args.seed)),
        ("HellaSwag", lambda: eval_hellaswag(model_call, n_examples=args.n_hellaswag)),
        ("ARC-C", lambda: eval_arc_c(model_call, n_examples=args.n_arc)),
        ("TruthfulQA-MC1", lambda: eval_truthfulqa(model_call)),
        ("WikiText-PPL", lambda: eval_wikitext_ppl(score_fn, n_examples=args.n_wikitext, seed=args.seed)),
    ]:
        logger.info(f"[{args.label} s{args.seed}] starting {name}")
        r = fn()
        results[name] = {"n": r.n, "score": r.score}
        logger.info(f"[{args.label} s{args.seed}] {name}={r.score:.4f} (n={r.n})")

    out = {
        "label": args.label,
        "seed": args.seed,
        "config": args.config,
        "ckpt": args.ckpt,
        "tasks": results,
    }
    out_path = Path(args.out or f"outputs/retention/{args.label}_s{args.seed}.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
