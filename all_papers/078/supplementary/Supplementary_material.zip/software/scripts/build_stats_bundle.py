#!/usr/bin/env python3
"""Recompute the statistics bundle from the shipped per-item predictions.

This is the only producer of the files under ``outputs/stats/`` that carry an
interval or a test decision, so a number in the paper can be traced to one
recomputation over one set of artifacts:

* ``hierarchical_bootstrap.json`` -- per configuration, split and metric: the
  pooled mean, the across-run standard deviation and the two-way interval that
  resamples training runs and then concept-family clusters within each run.
* ``tost_summary.json`` -- paired equivalence tests of every configuration
  against Base at four margins under three resampling levels. Clusters are drawn
  once per replicate and shared by both arms, so the test is paired at the level
  of the family that generated the items.
* ``equivalence_margin.json`` -- what the design can resolve: the across-run SD,
  the observed two-way half-width, the minimum effect resolvable at 80% power,
  and the number of runs that halving the margin would take.
* ``protocol_hash.txt`` -- content hash of ``protocol.md``.

Gold labels are read only from ``data/bench``; predictions are re-parsed from
their shipped ``raw_output`` field with the released parser. Nothing here reads
a precomputed score, so running it after ``verify-ledger`` is a second,
independent path to the same numbers.

Usage::

    PYTHONPATH=src python scripts/build_stats_bundle.py
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.utils.paths import audit_dir, bench_dir  # noqa: E402
from dion.evaluation.output_parser import (  # noqa: E402
    PARSER_VERSION,
    parse_abstraction,
    parse_candidate_choice,
    parse_mus,
    parse_repaired_kb,
)
from dion.evaluation.stats import audit_decision, equivalence_margin_justification  # noqa: E402

BENCH = bench_dir(ROOT)
AUDIT = audit_dir(ROOT)
PRED = ROOT / "outputs/predictions"
STATS = ROOT / "outputs/stats"

# Complementary TOST / AuditPass still conjoin the five headline axes.
# MUS-R and Kprime-Exact are reported alongside LogicRepair but are not part of
# the conjunctive equivalence decision (exact repair is sparse by construction).
METRICS = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1")
REPORT_METRICS = METRICS + ("MUS-R", "Kprime-Exact")
TASK_OF_METRIC = {
    "INA": "onto_neg_wn", "OER": "onto_neg_wn", "AbsAcc": "concept_shift",
    "MUS-P": "logic_repair", "MUS-F1": "logic_repair",
    "MUS-R": "logic_repair", "Kprime-Exact": "logic_repair",
}
CLUSTER_UNIT = {"onto_neg_wn": "S_id", "concept_shift": "S_id",
                "logic_repair": "item"}
MARGINS = (0.005, 0.01, 0.015, 0.02)
HEADLINE_MARGIN = 0.01
HEADLINE_LEVEL = "hierarchical"
LEVELS = ("hierarchical", "cluster", "item")
ALPHA = 0.05
# External harness rows are currently aggregate observations.  When they do not
# carry run dispersion, use documented *modeled* SDs (not empirical run SDs)
# and propagate uncertainty over the reported seed counts.  Decisions that use
# these intervals must be labelled modeled_uncertainty, never run_aware.
EXTERNAL_MODELED_SD = {
    "accuracy": 0.002,
    "ppl": 0.02,
}
RETENTION_ACCURACY = (
    "GSM8K", "MMLU-Pro", "HellaSwag", "ARC-C", "TruthfulQA-MC1",
)
RETENTION_PPL = "WikiText-PPL"
#: Two one-sided 5% tests at 80% power.
POWER = 0.8
REFERENCES = ("supercon", "tra_only", "mid", "lora_kl")
#: Configurations shown in the margin-sensitivity view, in table order.
SENSITIVITY_CONFIGS = ("supercon", "tra_only", "mid", "lora_kl", "sft_lora",
                       "self_rewarding_strict", "full_lora",
                       "gain_matched_safe", "gain_matched_dpo", "shuffled_dpo")


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.open() if line.strip()]


@dataclass
class Aggregate:
    """Per-metric scores of one configuration, grouped by run and by unit."""

    metric: str
    seeds: list[int]
    keys: list[str]
    sums: np.ndarray      # (n_runs, n_keys)
    counts: np.ndarray    # (n_runs, n_keys)
    item_keys: list[str]
    item_sums: np.ndarray
    item_counts: np.ndarray

    @property
    def n_items(self) -> int:
        return int(self.counts[0].sum())

    @property
    def run_means(self) -> np.ndarray:
        totals = self.sums.sum(axis=1)
        sizes = self.counts.sum(axis=1)
        return totals / sizes

    @property
    def mean(self) -> float:
        return float(self.run_means.mean())

    @property
    def sd(self) -> float:
        return (float(self.run_means.std(ddof=1))
                if len(self.seeds) > 1 else 0.0)

    def grouped(self, level: str) -> tuple[np.ndarray, np.ndarray, list[str]]:
        if level == "item":
            return self.item_sums, self.item_counts, self.item_keys
        return self.sums, self.counts, self.keys


class Bench:
    """Gold answers rebuilt from the benchmark splits."""

    def __init__(self) -> None:
        self._cache: dict[tuple[str, str], dict[str, dict]] = {}

    def rows(self, task: str, split: str) -> dict[str, dict]:
        key = (task, split)
        if key not in self._cache:
            self._cache[key] = {
                r["id"]: r for r in load_jsonl(BENCH / f"{task}_{split}.jsonl")}
        return self._cache[key]

    def score(self, item: dict) -> dict[str, float]:
        task, split = item["task"], item.get("split", "test")
        row = self.rows(task, split)[item["id"]]
        if item.get("parser_version") != PARSER_VERSION:
            raise SystemExit(
                f"[stats] item {item['id']} carries parser "
                f"{item.get('parser_version')!r}, this build runs {PARSER_VERSION!r}")
        raw = item["raw_output"]
        if task == "onto_neg_wn":
            pred = str(parse_candidate_choice(raw, list(row["candidates"])).value)
            return {"INA": float(pred == str(row["A_star"])),
                    "OER": float(pred == str(row["E"]))}
        if task == "concept_shift":
            pred = str(parse_abstraction(raw).value).lower()
            golds = {str(row["S"]).lower()} | {
                str(a).lower() for a in (row.get("S_alternatives") or [])}
            return {"AbsAcc": float(pred in golds)}
        pred_set = {str(x) for x in parse_mus(raw).value}
        gold_set = {str(x) for x in row["MUS"]}
        if not pred_set or not gold_set:
            prec = rec = f1 = float(not pred_set and not gold_set)
        else:
            inter = len(pred_set & gold_set)
            prec, rec = inter / len(pred_set), inter / len(gold_set)
            f1 = 0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)
        pred_k = {str(x) for x in parse_repaired_kb(raw).value}
        gold_k = {str(x) for x in (row.get("K_prime") or [])}
        return {
            "MUS-P": prec, "MUS-R": rec, "MUS-F1": f1,
            "Kprime-Exact": float(bool(pred_k) and pred_k == gold_k),
        }


def aggregate(
    items: list[dict], bench: Bench, keep: dict[str, set[str]] | None = None,
) -> dict[str, Aggregate]:
    """Group re-scored items by run and by resampling unit.

    ``keep`` optionally restricts each task to a set of item ids, which is how the
    subset sensitivity views are built without a second scoring path.
    """
    per: dict[str, dict[int, dict[str, list[float]]]] = {}
    clusters: dict[str, dict[str, str]] = {}
    for item in items:
        if keep is not None and item["id"] not in keep.get(item["task"], set()):
            continue
        scores = bench.score(item)
        seed = int(item["seed"])
        cluster = str(item["cluster"])
        for metric, value in scores.items():
            per.setdefault(metric, {}).setdefault(seed, {}).setdefault(
                item["id"], []).append(value)
            clusters.setdefault(metric, {})[item["id"]] = cluster

    out: dict[str, Aggregate] = {}
    for metric, by_seed in per.items():
        seeds = sorted(by_seed)
        item_ids = sorted(by_seed[seeds[0]])
        cluster_of = clusters[metric]
        cluster_keys = sorted({cluster_of[i] for i in item_ids})
        col = {k: j for j, k in enumerate(cluster_keys)}
        sums = np.zeros((len(seeds), len(cluster_keys)))
        counts = np.zeros((len(seeds), len(cluster_keys)))
        item_sums = np.zeros((len(seeds), len(item_ids)))
        item_counts = np.zeros((len(seeds), len(item_ids)))
        for si, seed in enumerate(seeds):
            for ii, item_id in enumerate(item_ids):
                values = by_seed[seed][item_id]
                total = float(sum(values))
                item_sums[si, ii] = total
                item_counts[si, ii] = len(values)
                j = col[cluster_of[item_id]]
                sums[si, j] += total
                counts[si, j] += len(values)
        out[metric] = Aggregate(metric, seeds, cluster_keys, sums, counts,
                                item_ids, item_sums, item_counts)
    return out


def _weights(n_keys: int, reps: int, rng: np.random.Generator) -> np.ndarray:
    """Multinomial resampling weights, one row per replicate.

    Drawing ``n_keys`` units with replacement is equivalent to drawing the vector
    of how often each unit appears, which turns a bootstrap replicate into one
    matrix product.
    """
    return rng.multinomial(
        n_keys, np.full(n_keys, 1.0 / n_keys), size=reps).astype(np.float64)


def _run_means(sums: np.ndarray, counts: np.ndarray, w: np.ndarray) -> np.ndarray:
    num = w @ sums.T
    den = w @ counts.T
    return np.divide(num, den, out=np.zeros_like(num), where=den > 0)


def _resample_runs(
    per_run: np.ndarray, rng: np.random.Generator, resample: bool,
) -> np.ndarray:
    if not resample:
        return per_run.mean(axis=1)
    reps, n_runs = per_run.shape
    idx = rng.integers(0, n_runs, size=(reps, n_runs))
    return per_run[np.arange(reps)[:, None], idx].mean(axis=1)


def two_way_interval(
    agg: Aggregate, reps: int, seed: int, alpha: float = ALPHA,
) -> tuple[float, float]:
    """Interval that resamples runs, then clusters within each drawn run."""
    rng = np.random.default_rng(seed)
    w = _weights(len(agg.keys), reps, rng)
    per_run = _run_means(agg.sums, agg.counts, w)
    draws = _resample_runs(per_run, rng, resample=len(agg.seeds) > 1)
    lo, hi = np.quantile(draws, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


def paired_tost(
    a: Aggregate, b: Aggregate, level: str, reps: int, seed: int,
    alpha: float = ALPHA,
) -> dict:
    """Paired equivalence test of ``a`` against ``b`` at one resampling level."""
    sums_a, counts_a, keys_a = a.grouped(level)
    sums_b, counts_b, keys_b = b.grouped(level)
    if keys_a != keys_b:
        shared = sorted(set(keys_a) & set(keys_b))
        ia = [keys_a.index(k) for k in shared]
        ib = [keys_b.index(k) for k in shared]
        sums_a, counts_a = sums_a[:, ia], counts_a[:, ia]
        sums_b, counts_b = sums_b[:, ib], counts_b[:, ib]
    rng = np.random.default_rng(seed)
    w = _weights(sums_a.shape[1], reps, rng)
    per_run_a = _run_means(sums_a, counts_a, w)
    per_run_b = _run_means(sums_b, counts_b, w)
    resample_runs = level == "hierarchical"
    draws_a = _resample_runs(per_run_a, rng, resample_runs and len(a.seeds) > 1)
    draws_b = _resample_runs(per_run_b, rng, resample_runs and len(b.seeds) > 1)
    diffs = draws_a - draws_b
    lo90, hi90 = np.quantile(diffs, [alpha, 1 - alpha])
    lo95, hi95 = np.quantile(diffs, [alpha / 2, 1 - alpha / 2])
    half = float((hi90 - lo90) / 2.0)
    return {
        "diff_mean": a.mean - b.mean,
        "diff_bootstrap_mean": float(diffs.mean()),
        "ci90_low": float(lo90), "ci90_high": float(hi90),
        "ci95_low": float(lo95), "ci95_high": float(hi95),
        "ci90_half_width": half,
        "margin": HEADLINE_MARGIN,
        "equivalent": bool(lo90 > -HEADLINE_MARGIN and hi90 < HEADLINE_MARGIN),
        "passes_margin": {
            f"{m * 100:.1f}pp": bool(lo90 > -m and hi90 < m) for m in MARGINS},
        "n_units": int(sums_a.shape[1]),
    }


#: Cluster definitions for the ConceptShift robustness view: label -> how to read
#: the grouping key off a benchmark row.
CS_GROUPINGS = {
    "item": lambda r: r["id"],
    "target concept": lambda r: str(r["T_id"]),
    "hypernym family": lambda r: str(r["S_id"]),
    "relation type": lambda r: str(r["relation"]),
    "edge source": lambda r: str(r["provenance"]["edge_source"]),
}


def cluster_sensitivity(
    bench: Bench, reps: int, alpha: float = ALPHA,
) -> dict:
    """ConceptShift effect sizes under several cluster definitions.

    One paired bootstrap per grouping, plus an unweighted concept-level estimator
    that averages families instead of items, so a reader can see how much of the
    interval width comes from the choice of resampling unit.
    """
    rows = bench.rows("concept_shift", "test")

    def per_item(cfg: str) -> dict[str, float]:
        totals: dict[str, list[float]] = {}
        for item in load_jsonl(PRED / f"{cfg}_items.jsonl"):
            if item["task"] != "concept_shift":
                continue
            totals.setdefault(item["id"], []).append(bench.score(item)["AbsAcc"])
        return {k: float(np.mean(v)) for k, v in totals.items()}

    scores = {cfg: per_item(cfg) for cfg in
              ("base", "supercon", "self_rewarding_strict")}
    ids = sorted(scores["base"])
    out: dict[str, dict] = {}
    for cfg in ("supercon", "self_rewarding_strict"):
        diff = np.array([scores[cfg][i] - scores["base"][i] for i in ids])
        block: dict[str, dict] = {}
        for label, key in CS_GROUPINGS.items():
            groups: dict[str, list[int]] = {}
            for pos, item_id in enumerate(ids):
                groups.setdefault(key(rows[item_id]), []).append(pos)
            keys = sorted(groups)
            sums = np.array([diff[groups[k]].sum() for k in keys])
            counts = np.array([float(len(groups[k])) for k in keys], dtype=float)
            rng = np.random.default_rng(stable_seed("cluster", cfg, label))
            w = _weights(len(keys), reps, rng)
            draws = (w @ sums) / (w @ counts)
            lo, hi = np.quantile(draws, [alpha / 2, 1 - alpha / 2])
            block[label] = {"delta_pp": float(diff.mean() * 100),
                            "ci95_pp": [float(lo * 100), float(hi * 100)],
                            "n_units": len(keys)}
        # Unweighted family mean: every concept family counts once.
        families: dict[str, list[int]] = {}
        for pos, item_id in enumerate(ids):
            families.setdefault(str(rows[item_id]["S_id"]), []).append(pos)
        keys = sorted(families)
        means = np.array([diff[families[k]].mean() for k in keys])
        rng = np.random.default_rng(stable_seed("cluster-mean", cfg))
        w = _weights(len(keys), reps, rng)
        draws = (w @ means) / len(keys)
        lo, hi = np.quantile(draws, [alpha / 2, 1 - alpha / 2])
        block["concept-level mean"] = {
            "delta_pp": float(means.mean() * 100),
            "ci95_pp": [float(lo * 100), float(hi * 100)],
            "n_units": len(keys)}
        out[cfg] = block
    return {
        "note": ("Paired ConceptShift effect sizes under different resampling "
                 "units. The point estimate is identical for every item-weighted "
                 "row by construction; only the interval changes."),
        "metric": "AbsAcc", "replicates": reps, "per_config": out,
    }


def subset_ids(bench: Bench) -> dict[str, dict[str, set[str]]]:
    """Item-id whitelists for the two subset sensitivity views.

    ``core`` keeps locked-test items with clean construction evidence: certified
    OntoNeg-WN items, high-confidence rows of the ConceptShift re-audit, and
    certificate-verified LogicRepair items. ``ambiguity_filtered`` instead drops
    every item an annotator flagged as ambiguous, on whichever audit covers it.
    """
    import csv

    onto = bench.rows("onto_neg_wn", "test")
    shift = bench.rows("concept_shift", "test")
    logic = bench.rows("logic_repair", "test")
    reaudit = {r["id"]: r for r in csv.DictReader(
        open(AUDIT / "conceptshift_1000_reaudit.csv"))}
    v1_ambiguous = {r["id"] for r in csv.DictReader(
        open(AUDIT / "v1_stratified_audit.csv")) if r["category"] != "correct"}

    certified = {i for i, r in onto.items() if r["provenance"].get("certified")}
    verified = {i for i, r in logic.items()
                if all(r["certificate"][k]
                       for k in ("unsat", "minimal", "nontrivial"))}
    core = {
        "onto_neg_wn": certified,
        "concept_shift": {i for i in shift
                          if int(reaudit.get(i, {"high_confidence": 0})
                                 ["high_confidence"])},
        "logic_repair": verified,
    }
    filtered = {
        "onto_neg_wn": {i for i in onto if i not in v1_ambiguous},
        "concept_shift": {i for i in shift
                          if reaudit.get(i, {}).get("category") == "correct"},
        "logic_repair": {i for i in logic if i not in v1_ambiguous},
    }
    return {"core": core, "ambiguity_filtered": filtered}


def min_resolvable_effect(
    sd: float, n_runs: int, observed_half_width: float, margin: float,
) -> dict:
    """What the design can resolve, from the interval it actually produces.

    Delegates to the released statistics library so the margin justification in
    the paper and the function a reader can call are one implementation.
    """
    doc = equivalence_margin_justification(
        run_sd=sd, n_runs=max(1, n_runs), margin=margin,
        observed_half_width=observed_half_width, power=POWER, alpha=ALPHA)
    return {k: v for k, v in doc.items() if k not in ("power", "alpha")}


def external_retention(
    configs: tuple[str, ...],
) -> tuple[dict[str, dict[str, dict]], dict[str, str]]:
    """Build retention estimates from aggregate external harness rows.

    Accuracy is reported in percentage points (higher is better). WikiText-PPL
    is reported as relative percent change ``(method−base)/base×100`` (lower
    PPL is better; positive values are worsenings). Missing seed SDs use the
    documented modeled SD; such intervals are *not* empirical run-aware CIs.
    """
    rows = list(csv.DictReader((ROOT / "result_ledger.csv").open()))
    by_key = {(r["config"], r["metric"]): r for r in rows
              if r["source"] == "external_harness"}
    out: dict[str, dict[str, dict]] = {}
    modeled: dict[str, str] = {}
    z = 1.96
    for cfg in configs:
        out[cfg] = {}
        for metric in RETENTION_ACCURACY + (RETENTION_PPL,):
            current, base = by_key.get((cfg, metric)), by_key.get(("base", metric))
            if current is None or base is None:
                out[cfg][metric] = {
                    "available": False,
                    "reason": "missing external_harness ledger row",
                }
                continue
            is_ppl = metric == RETENTION_PPL
            scale = "ppl" if is_ppl else "accuracy"
            used_modeled = not current["seed_sd"] or not base["seed_sd"]
            sd_a = (float(current["seed_sd"]) if current["seed_sd"]
                    else EXTERNAL_MODELED_SD[scale])
            sd_b = (float(base["seed_sd"]) if base["seed_sd"]
                    else EXTERNAL_MODELED_SD[scale])
            n_a, n_b = max(1, int(current["seeds"])), max(1, int(base["seeds"]))
            mean_a, mean_b = float(current["value"]), float(base["value"])
            delta = mean_a - mean_b
            half_raw = z * math.sqrt(sd_a**2 / n_a + sd_b**2 / n_b)
            if is_ppl:
                mean = delta / mean_b * 100.0
                half = half_raw / mean_b * 100.0
                margin = 5.0
                unit = "relative_percent"
            else:
                mean = delta * 100.0
                half = half_raw * 100.0
                margin = 1.0
                unit = "percentage_points"
            if used_modeled:
                modeled[metric] = (
                    f"modeled SD={EXTERNAL_MODELED_SD[scale]} "
                    f"({scale}, raw ledger units; not empirical run SD)"
                )
            out[cfg][metric] = {
                "mean": mean,
                "lo": mean - half,
                "hi": mean + half,
                "margin": margin,
                "scale": unit,
                "higher_is_better": not is_ppl,
                "n_runs": min(n_a, n_b),
                "seed_sd": {"config": sd_a, "base": sd_b},
                "run_aware": not used_modeled,
                "modeled_uncertainty": used_modeled,
            }
    return out, modeled


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replicates", type=int, default=4000)
    ap.add_argument("--interval-replicates", type=int, default=4000)
    args = ap.parse_args(argv)

    STATS.mkdir(parents=True, exist_ok=True)
    bench = Bench()
    files = sorted(PRED.glob("*_items*.jsonl"))
    if not files:
        raise SystemExit(f"[stats] no prediction files under {PRED}")

    subsets = subset_ids(bench)
    aggregates: dict[tuple[str, str], dict[str, Aggregate]] = {}
    subset_aggregates: dict[str, dict[str, dict[str, Aggregate]]] = {
        name: {} for name in subsets}
    for path in files:
        stem = path.stem.replace("_items", "|")
        cfg, _, suffix = stem.partition("|")
        split = suffix.lstrip("_") or "test"
        items = load_jsonl(path)
        aggregates[(cfg, split)] = aggregate(items, bench)
        if split == "test" and (cfg == "base" or cfg in SENSITIVITY_CONFIGS):
            for name, keep in subsets.items():
                subset_aggregates[name][cfg] = aggregate(items, bench, keep=keep)
        print(f"[stats] {cfg}/{split}: "
              f"{', '.join(sorted(aggregates[(cfg, split)]))}", flush=True)

    # ------------------------------------------------- interval estimates
    results: dict[str, dict[str, dict]] = {}
    for (cfg, split), by_metric in sorted(aggregates.items()):
        block: dict[str, dict] = {}
        for metric in REPORT_METRICS:
            agg = by_metric.get(metric)
            if agg is None:
                continue
            lo, hi = two_way_interval(
                agg, args.interval_replicates,
                seed=stable_seed(cfg, split, metric))
            block[metric] = {
                "mean": agg.mean, "sd": agg.sd, "ci95": [lo, hi],
                "seeds": len(agg.seeds), "n": agg.n_items,
                "n_clusters": len(agg.keys),
                "run_means": [float(v) for v in agg.run_means],
            }
        results[f"{cfg}|{split}"] = block
    (STATS / "hierarchical_bootstrap.json").write_text(json.dumps({
        "procedure": ("resample training runs with replacement, then item "
                      "clusters within each drawn run"),
        "replicates": args.interval_replicates,
        "alpha": ALPHA,
        "cluster_unit": CLUSTER_UNIT,
        "parser_version": PARSER_VERSION,
        "results": results,
    }, indent=1, sort_keys=True) + "\n")

    # ------------------------------------------------------------ TOST
    base = aggregates[("base", "test")]
    levels: dict[str, dict[str, dict]] = {}
    for level in LEVELS:
        block: dict[str, dict] = {}
        for (cfg, split), by_metric in sorted(aggregates.items()):
            if split != "test" or cfg == "base":
                continue
            for metric in METRICS:
                agg, ref = by_metric.get(metric), base.get(metric)
                if agg is None or ref is None:
                    continue
                block[f"{cfg}_vs_base:{metric}"] = paired_tost(
                    agg, ref, level, args.replicates,
                    seed=stable_seed("tost", level, cfg, metric))
        levels[level] = block
        print(f"[stats] {level}: {len(block)} paired tests", flush=True)

    (STATS / "tost_summary.json").write_text(json.dumps({
        "headline_margin": HEADLINE_MARGIN,
        "headline_level": HEADLINE_LEVEL,
        "procedure": {
            "hierarchical": "resample training runs, then item clusters within run",
            "cluster": "resample item clusters, runs held fixed",
            "item": "resample items independently, runs held fixed",
        },
        "note": ("Headline equivalence decisions use the hierarchical level. The "
                 "cluster and item levels are narrower sensitivity views and are "
                 "the basis for any stricter-margin statement."),
        "bootstrap_replicates": args.replicates,
        "alpha": ALPHA,
        "margins": list(MARGINS),
        "cluster_unit": CLUSTER_UNIT,
        "levels": levels,
    }, indent=1, sort_keys=True) + "\n")

    # ------------------------------------------------------------- AuditPass
    # The target probe is INA.  Complementary axes use the headline hierarchical
    # TOST interval, while external retention is estimated independently from
    # the harness ledger and uses accuracy-pp / PPL-relative NI margins.
    headline_configs = tuple(
        cfg for cfg in SENSITIVITY_CONFIGS if (cfg, "test") in aggregates
    )
    retention_by_config, retention_note = external_retention(headline_configs)
    audit_rows: dict[str, dict] = {}
    for cfg in headline_configs:
        target_raw = levels[HEADLINE_LEVEL].get(f"{cfg}_vs_base:INA")
        if target_raw is None:
            continue
        target = {
            "mean": target_raw["diff_mean"] * 100.0,
            "lo": target_raw["ci95_low"] * 100.0,
            "hi": target_raw["ci95_high"] * 100.0,
        }
        complementary = {}
        for metric in METRICS:
            if metric == "INA":
                continue
            raw = levels[HEADLINE_LEVEL].get(f"{cfg}_vs_base:{metric}")
            if raw is None:
                continue
            complementary[metric] = {
                "mean": raw["diff_mean"] * 100.0,
                "lo": raw["ci90_low"] * 100.0,
                "hi": raw["ci90_high"] * 100.0,
                "equivalent": raw["equivalent"],
            }
        decision = audit_decision(
            target, complementary, retention_by_config.get(cfg, {}),
            margin_pp=100.0 * HEADLINE_MARGIN, alpha=ALPHA,
        )
        decision["config"] = cfg
        decision["target_metric"] = "INA"
        decision["complementary_metrics"] = sorted(complementary)
        # Prefer the per-probe pass flags from audit_decision; keep raw
        # interval fields for auditability.
        merged = {}
        for name, raw in retention_by_config.get(cfg, {}).items():
            detail = dict(raw)
            detail.update(decision.get("RetentionNI", {}).get(name, {}))
            merged[name] = detail
        decision["retention"] = merged
        audit_rows[cfg] = decision
    (STATS / "auditpass_summary.json").write_text(json.dumps({
        "rule": (
            "AuditPass = protocol-specific LocalizedGain under decision "
            "intervals: target superiority on INA + complementary DION-Bench "
            "TOST equivalence + external retention NI. Accuracy retention "
            "(higher-is-better) uses a -1pp NI floor on method−base; "
            "WikiText-PPL (lower-is-better) uses a +5% relative upper NI bound "
            "on method−base. OER complementary NI likewise uses an upper bound."
        ),
        "headline_level": HEADLINE_LEVEL,
        "alpha": ALPHA,
        "retention_uncertainty": (
            "External harness rows are aggregate observations. Missing seed_sd "
            "uses documented modeled SDs (EXTERNAL_MODELED_SD) and propagates "
            "uncertainty over the reported seed counts. These intervals are "
            "modeled_uncertainty, not empirical run-aware CIs; RetentionNI "
            "clauses that depend on them are descriptive under that model."
        ),
        "modeled_sd": retention_note,
        "configs": audit_rows,
    }, indent=1, sort_keys=True) + "\n")
    print("[stats] auditpass summary written", flush=True)

    # ---------------------------------------------------- margin justification
    power = {}
    for metric in METRICS:
        agg = aggregates[("supercon", "test")].get(metric)
        if agg is None:
            continue
        half = levels[HEADLINE_LEVEL][f"supercon_vs_base:{metric}"]["ci90_half_width"]
        power[metric] = min_resolvable_effect(
            agg.sd, len(agg.seeds), half, HEADLINE_MARGIN)
    widest = max(power, key=lambda m: power[m]["observed_ci90_half_width"])
    (STATS / "equivalence_margin.json").write_text(json.dumps({
        "margin": HEADLINE_MARGIN,
        "reference_config": "supercon",
        "rationale": (
            "The ±1pp band is an operational, pre-specified tolerance "
            "(protocol.md), not a domain-derived indifference region. For each "
            "metric we report the across-run standard deviation, the observed "
            "two-way hierarchical interval half-width ((hi−lo)/2), the minimum "
            "resolvable effect at 80% power for two one-sided 5% tests, and how "
            "many training runs halving the margin would require. Axes whose "
            "MDE exceeds ±1pp still use the operational band; their passes "
            "certify protocol equivalence, not noise-floor superiority."),
        "widest_axis": widest,
        "widest_axis_half_width": power[widest]["observed_ci90_half_width"],
        "per_metric": power,
    }, indent=1, sort_keys=True) + "\n")

    # ------------------------------------------------ interval width provenance
    ratios = {"cluster_over_item": [], "hierarchical_over_item": []}
    for cfg in REFERENCES:
        for metric in METRICS:
            key = f"{cfg}_vs_base:{metric}"
            item = levels["item"][key]["ci90_half_width"]
            if item <= 0:
                continue
            ratios["cluster_over_item"].append(
                levels["cluster"][key]["ci90_half_width"] / item)
            ratios["hierarchical_over_item"].append(
                levels["hierarchical"][key]["ci90_half_width"] / item)
    (STATS / "interval_widths.json").write_text(json.dumps({
        "note": ("Ratio of the 90% interval half-width at each resampling level to "
                 "the item level, over the four reference configurations and five "
                 "metrics. Cluster resampling only widens a task whose concept "
                 "families group many items; resampling training runs widens every "
                 "axis, which is why headline decisions use the two-way level."),
        "per_task_cluster_over_item": {
            task: [
                levels["cluster"][f"{cfg}_vs_base:{m}"]["ci90_half_width"]
                / levels["item"][f"{cfg}_vs_base:{m}"]["ci90_half_width"]
                for cfg in REFERENCES for m in METRICS
                if TASK_OF_METRIC[m] == task
                and levels["item"][f"{cfg}_vs_base:{m}"]["ci90_half_width"] > 0
            ]
            for task in sorted(set(TASK_OF_METRIC.values()))
        },
        "summary": {
            name: {"min": min(values), "max": max(values),
                   "median": float(np.median(values))}
            for name, values in ratios.items() if values
        },
    }, indent=1, sort_keys=True) + "\n")

    # ------------------------------------------------- subset margin sensitivity
    sensitivity: dict[str, dict] = {}
    for name, by_cfg in subset_aggregates.items():
        ref = by_cfg.get("base")
        if ref is None:
            continue
        block: dict[str, dict] = {}
        for cfg in SENSITIVITY_CONFIGS:
            by_metric = by_cfg.get(cfg)
            if by_metric is None:
                continue
            per_metric: dict[str, dict] = {}
            for metric in METRICS:
                agg, base_agg = by_metric.get(metric), ref.get(metric)
                if agg is None or base_agg is None:
                    continue
                per_metric[metric] = {
                    level: paired_tost(
                        agg, base_agg, level, args.replicates,
                        seed=stable_seed("sens", name, level, cfg, metric))
                    for level in ("cluster", "item")
                }
            block[cfg] = {
                "n_items": {m: by_metric[m].n_items for m in per_metric},
                "per_metric": per_metric,
                # This is only the complementary-axis equivalence clause;
                # target superiority and external retention are evaluated in
                # auditpass_summary.json.
                "all_axes": {
                    level: {
                        margin: all(per_metric[m][level]["passes_margin"][margin]
                                    for m in per_metric)
                        for margin in (f"{m * 100:.1f}pp" for m in MARGINS)
                    } for level in ("cluster", "item")
                },
            }
        sensitivity[name] = block
        print(f"[stats] {name}: {len(block)} configurations", flush=True)

    (STATS / "tost_sensitivity.json").write_text(json.dumps({
        "note": ("Equivalence decisions repeated on two audited subsets of the "
                 "locked test at four margins. 'all_axes' is the conjunction over "
                 "the five DION-Bench metrics and reports only the complementary-"
                 "axis clause of AuditPass; target superiority and retention NI "
                 "are evaluated separately."),
        "subset_definitions": {
            "core": ("certified OntoNeg-WN items, high-confidence ConceptShift "
                     "re-audit rows, certificate-verified LogicRepair items"),
            "ambiguity_filtered": (
                "items no annotator flagged as ambiguous, on whichever audit "
                "covers them"),
        },
        "subset_sizes": {
            name: {task: len(ids) for task, ids in keep.items()}
            for name, keep in subsets.items()},
        "margins": list(MARGINS),
        "bootstrap_replicates": args.replicates,
        "subsets": sensitivity,
    }, indent=1, sort_keys=True) + "\n")

    (STATS / "cluster_sensitivity.json").write_text(json.dumps(
        cluster_sensitivity(bench, args.replicates), indent=1, sort_keys=True) + "\n")
    print("[stats] cluster sensitivity written", flush=True)

    digest = hashlib.sha256((ROOT / "protocol.md").read_bytes()).hexdigest()
    (STATS / "protocol_hash.txt").write_text(digest + "\n")
    print(f"[stats] protocol.md sha256 {digest[:16]}...")
    print(f"[stats] widest axis {widest} "
          f"(half-width {power[widest]['observed_ci90_half_width'] * 100:.2f}pp)")
    return 0


def stable_seed(*parts: str) -> int:
    """A replicate seed that does not depend on the interpreter's hash salt."""
    raw = hashlib.blake2b("::".join(parts).encode(), digest_size=8).digest()
    return int.from_bytes(raw, "big") % (1 << 31)


if __name__ == "__main__":
    raise SystemExit(main())
