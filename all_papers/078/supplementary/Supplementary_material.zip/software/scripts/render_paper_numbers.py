#!/usr/bin/env python3
"""Emit ``paper/tables/numbers.tex``: every statistic the prose quotes.

The body text used to spell out correlations, AUCs and collapse magnitudes by
hand, so re-fitting a model silently desynchronised the prose from the shipped
JSON. Each macro here is computed from ``result_ledger.csv`` or from a file under
``outputs/stats/``, and the prose only refers to macros. Run after
``build_stats_bundle.py`` and ``build_mediation_analysis.py``.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dion.utils.paths import audit_dir, bench_dir  # noqa: E402

STATS = ROOT / "outputs/stats"
OUT = ROOT / "paper/tables/numbers.tex"
BENCH = bench_dir(ROOT)
AUDIT = audit_dir(ROOT)

PCT = ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1", "GSM8K", "MMLU-Pro",
       "HellaSwag", "ARC-C", "TruthfulQA-MC1")


def ledger() -> dict[tuple[str, str], dict[str, float]]:
    out: dict[tuple[str, str], dict[str, float]] = defaultdict(dict)
    with (ROOT / "result_ledger.csv").open() as f:
        for r in csv.DictReader(f):
            scale = 100 if r["metric"] in PCT else 1
            out[(r["config"], r["split"])][r["metric"]] = float(r["value"]) * scale
    return out


def _ranks(xs: list[float]) -> list[float]:
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    out = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        avg = (i + j) / 2 + 1
        for k in range(i, j + 1):
            out[order[k]] = avg
        i = j + 1
    return out


def _spearman(a: list[float], b: list[float]) -> float:
    ra, rb = _ranks(a), _ranks(b)
    ma, mb = sum(ra) / len(ra), sum(rb) / len(rb)
    num = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
    da = sum((x - ma) ** 2 for x in ra) ** 0.5
    db = sum((y - mb) ** 2 for y in rb) ** 0.5
    return num / (da * db) if da and db else 0.0


def num(value: float, digits: int = 2) -> str:
    """Format without a signed zero, which reads as a typo in running text."""
    text = f"{value:.{digits}f}"
    return text[1:] if text.startswith("-0.") and float(text) == 0.0 else text


def p_str(p: float) -> str:
    """ACL style: never print a p-value as zero."""
    if p < 0.001:
        return "p{<}.001"
    if p < 0.01:
        return f"p{{=}}{p:.3f}".replace("0.", ".")
    return f"p{{=}}{p:.2f}".replace("0.", ".")


def audit_macros() -> dict[str, str]:
    """Agreement and precision statistics recomputed from the released audit sheets."""
    from itertools import combinations

    def cohen(a: list[str], b: list[str]) -> float:
        n = len(a)
        observed = sum(x == y for x, y in zip(a, b)) / n
        expected = sum((a.count(c) / n) * (b.count(c) / n) for c in set(a) | set(b))
        return (observed - expected) / (1 - expected)

    def mean_kappa(rows: list[dict], field: str) -> float:
        pairs = [cohen([r[field % i] for r in rows], [r[field % j] for r in rows])
                 for i, j in combinations((1, 2, 3), 2)]
        return sum(pairs) / len(pairs)

    v1 = list(csv.DictReader(open(AUDIT / "v1_stratified_audit.csv")))
    tasks = sorted({r["task"] for r in v1})
    precision, ambiguity, kappas = [], [], []
    for task in tasks:
        subset = [r for r in v1 if r["task"] == task]
        precision.append(sum(r["majority"] == "gold" for r in subset) / len(subset))
        ambiguity.append(sum(r["category"] == "ambiguous" for r in subset) / len(subset))
        kappas.append(mean_kappa(subset, "rater_%d"))

    re_rows = list(csv.DictReader(open(AUDIT / "conceptshift_1000_reaudit.csv")))
    n = len(re_rows)
    return {
        "auditRows": f"{len(v1):,}".replace(",", "{,}"),
        "auditPrecMin": f"{min(precision) * 100:.1f}",
        "auditAmbMax": f"{max(ambiguity) * 100:.1f}",
        "auditKappaLo": f"{min(kappas):.2f}",
        "auditKappaHi": f"{max(kappas):.2f}",
        "reauditN": f"{n:,}".replace(",", "{,}"),
        "reauditKappa": f"{mean_kappa(re_rows, 'rater_%d_correct'):.2f}",
        "reauditMajority": f"{sum(int(r['majority_correct']) for r in re_rows) / n * 100:.1f}",
        "reauditHighConf": f"{sum(int(r['high_confidence']) for r in re_rows) / n * 100:.0f}",
        "reauditHighConfN": str(sum(int(r["high_confidence"]) for r in re_rows)),
        "reauditAmb": f"{sum(r['category'] == 'ambiguous' for r in re_rows) / n * 100:.1f}",
    }


def cluster_macros() -> dict[str, str]:
    """How much the ConceptShift interval responds to the resampling unit."""
    doc = json.loads((ROOT / "outputs/stats/cluster_sensitivity.json").read_text())
    per = doc["per_config"]
    units = ("item", "target concept", "hypernym family")

    def width(cfg: str, key: str) -> float:
        lo, hi = per[cfg][key]["ci95_pp"]
        return hi - lo

    spread = max(abs(width(cfg, key) / width(cfg, "item") - 1) * 100
                 for cfg in per for key in units)
    bound = max(per["self_rewarding_strict"][k]["ci95_pp"][1]
                for k in list(units) + ["concept-level mean"])
    return {
        "clustUnits": str(len(units) + 1),
        "clustSpread": f"{spread:.0f}",
        "srClustBound": num(bound, 1),
        "srClustMean": num(per["self_rewarding_strict"]["concept-level mean"]
                           ["delta_pp"], 1),
    }


def contamination_macros(L: dict) -> dict[str, str]:
    """Effect-size retention of the contamination probes, against the ledger."""
    doc = json.loads((ROOT / "configs/contamination.json").read_text())
    headline = (L[("self_rewarding_strict", "test")]["AbsAcc"]
                - L[("base", "test")]["AbsAcc"])
    shares = [probe["sr_collapse_pp"] / headline * 100
              for group in doc["groups"] for probe in group["probes"]
              if not probe.get("overlap_only")]
    mem = doc["memorization"]
    anchor = mem["gap_reference"]
    return {
        "contamProbes": str(len(shares)),
        "contamRetainMin": f"{min(shares):.0f}",
        "contamRetainMax": f"{max(shares):.0f}",
        "contamOverlap": f"{doc['minhash_overlap_max_pct']:.0f}",
        "contamExact": str(doc["exact_triple_matches"]),
        "contamParaphraseN": str(doc["paraphrase_n"]),
        "memRecall": f"{mem['source_fact_recall_pct']:.1f}",
        "memGap": f"{mem['source_fact_recall_pct'] - L[(anchor['config'], 'test')][anchor['metric']]:.1f}",
        "memAnchor": anchor["label"],
    }


def reference_quality_macros() -> dict[str, str]:
    """Drift-tail, dispersion and ablation contrasts behind the reference claims."""
    drift = json.loads(
        (ROOT / "configs/drift_diagnostics.json").read_text())["configs"]
    ablation = json.loads((ROOT / "configs/ablation_variants.json").read_text())
    boot = json.loads(
        (ROOT / "outputs/stats/hierarchical_bootstrap.json").read_text())["results"]
    tost = json.loads(
        (ROOT / "outputs/stats/tost_summary.json").read_text())["levels"]["cluster"]
    ref = ablation["reference"]
    fisher = ablation["variants"]["no_fisher"]
    sweep = ablation["perturbation_sweep"]

    def sd(cfg: str) -> float:
        return boot[f"{cfg}|test"]["INA"]["sd"] * 100

    def pass_rate(cfg: str) -> float:
        flags = [tost[f"{cfg}_vs_base:{m}"]["passes_margin"]["1.0pp"]
                 for m in ("INA", "OER", "AbsAcc", "MUS-P", "MUS-F1")]
        return 100.0 * sum(flags) / len(flags)

    return {
        "refTailLower": f"{100 * (1 - drift[ref]['kl_p95'] / drift['lora_kl']['kl_p95']):.0f}",
        "refTail": f"{drift[ref]['kl_p95']:.3f}",
        "klTail": f"{drift['lora_kl']['kl_p95']:.3f}",
        "refSd": f"{sd(ref):.2f}",
        "klSd": f"{sd('lora_kl'):.2f}",
        "fisherSdRatio": f"{fisher['seed_sd'] / sd(ref):.1f}",
        "fisherDriftRatio": f"{fisher['kl'] / drift[ref]['kl']:.1f}",
        "refPassRate": f"{pass_rate(ref):.0f}",
        "klPassRate": f"{pass_rate('lora_kl'):.0f}",
        "pertRuns": str(sweep["seeds"]),
        "pertCkpts": str(sweep["checkpoints_per_run"]),
        "pertRefWorst": num(abs(sweep["outcomes"][ref]["worst_delta_pp"]), 1),
        "pertKLWorst": num(abs(sweep["outcomes"]["lora_kl"]["worst_delta_pp"]), 1),
        "ablBoundaryFone": f"{ablation['variants']['no_boundary']['MUS-F1']:.2f}",
        "ablRefFone": f"{boot[f'{ref}|test']['MUS-F1']['mean'] * 100:.2f}",
    }


def main() -> int:
    L = ledger()
    med = json.loads((STATS / "mediation.json").read_text())
    margin = json.loads((STATS / "equivalence_margin.json").read_text())
    api = json.loads((STATS / "api_call_ledger.json").read_text())
    ck = med["checkpoint_level"]
    item = med["item_level"]
    sel = med["selection_rates"]

    base = L[("base", "test")]
    sr = L[("self_rewarding_strict", "test")]
    csd = L[("self_rewarding_csd", "test")]
    full = L[("full_lora", "test")]

    m: dict[str, str] = {}

    # -- checkpoint-level drift/regression association ----------------------
    m["ckptN"] = str(ck["n_checkpoints"])
    m["ckptRuns"] = str(ck["n_runs"])
    m["rhoRun"] = num(ck["run_terminal_spearman"])
    # Configuration-level association only; do not surface a confirmatory p-value.
    m["rhoRunP"] = "descriptive"
    m["rhoAll"] = num(ck["spearman_all"])
    m["rhoMethod"] = num(ck["spearman_method_level"])
    m["rhoDionRef"] = num(ck["spearman_within_dion_ref"])
    m["rhoDionRefP"] = p_str(ck["spearman_within_dion_ref_p"])
    m["rhoSelfRew"] = num(ck["spearman_within_self_rewarding"])
    m["partialR"] = num(ck["partial_r_controlling_steps"])
    m["partialP"] = p_str(ck["partial_p_controlling_steps"])
    m["residR"] = f"{ck['residual_r_after_specificity']:.2f}"
    m["residP"] = p_str(ck["residual_p_after_specificity"])

    ml = ck["multilevel"]
    m["medFamilies"] = str(ml["n_families"])
    for key, tag in (("across_families", "Across"), ("within_families", "Within")):
        block = ml[key]
        lo, hi = block["mediator_run_ci95"]
        m[f"med{tag}B"] = f"{block['mediator_coefficient']:.2f}"
        m[f"med{tag}Lo"] = f"{lo:.2f}"
        m[f"med{tag}Hi"] = f"{hi:.2f}"
        m[f"med{tag}Total"] = f"{block['total_effect']:.3f}"
        m[f"med{tag}Direct"] = f"{block['direct_effect']:.3f}"

    # -- item-level specificity model --------------------------------------
    m["specAUC"] = f"{item['auc']:.2f}"
    m["specOR"] = f"{item['odds_ratio_per_sd']:.2f}"
    m["specORlo"] = f"{item['odds_ratio_ci95'][0]:.2f}"
    m["specORhi"] = f"{item['odds_ratio_ci95'][1]:.2f}"
    m["specORp"] = p_str(item["p_value"])
    m["specTaxN"] = str(item["n_items"])

    def share(key: str) -> str:
        return f"{sel[key]['specificity_error_share'] * 100:.0f}"

    def rate(key: str) -> str:
        return f"{sel[key]['over_specific_selection_rate'] * 100:.0f}"

    m["specShareSR"] = share("self_rewarding_strict:test")
    m["specShareBase"] = share("base:test")
    m["specShareCSD"] = share("self_rewarding_csd:test")
    m["selRateSR"] = rate("self_rewarding_strict:test")
    m["selRateBase"] = rate("base:test")
    m["selRateCSD"] = rate("self_rewarding_csd:test")
    m["selRateSRconf"] = rate("self_rewarding_strict:conf")
    m["selRateCSDconf"] = rate("self_rewarding_csd:conf")

    # -- human error taxonomy and gold-set sensitivity ----------------------
    tax = med["human_taxonomy"]
    m["taxN"] = str(tax["n_rows"])
    m["taxPerConfig"] = str(tax["per_config"]["base"]["n"])
    m["taxShareSR"] = (
        f"{tax['per_config']['self_rewarding_strict']['shares']['specificity_bias'] * 100:.0f}")
    m["taxShareBase"] = (
        f"{tax['per_config']['base']['shares']['specificity_bias'] * 100:.0f}")
    m["taxReasonBase"] = (
        f"{tax['per_config']['base']['shares']['reasoning_error'] * 100:.0f}")
    subs = med["audited_subsets"]
    m["subUnanN"] = str(subs["unanimous"]["n"])
    m["subUnanDelta"] = num(subs["unanimous"]["delta_pp"], 1)
    m["subAmbigN"] = str(subs["ambiguous"]["n"])
    m["subAmbigDelta"] = num(subs["ambiguous"]["delta_pp"], 1)
    m["subDeepN"] = str(subs["deep_path"]["n"])
    m["subDeepDelta"] = num(subs["deep_path"]["delta_pp"], 1)
    m["taxReasonSR"] = (
        f"{tax['per_config']['self_rewarding_strict']['shares']['reasoning_error'] * 100:.0f}")
    m.update(audit_macros())
    m.update(reference_quality_macros())
    m.update(cluster_macros())
    gold = med["gold_sensitivity"]["deltas_pp"]
    m["goldStrict"] = num(gold["strict"]["delta_pp"], 1)
    m["goldAccepted"] = num(gold["accepted"]["delta_pp"], 1)
    m["goldMulti"] = num(gold["multi_gold"]["delta_pp"], 1)
    m["goldStrictShare"] = f"{gold['strict']['retained_share'] * 100:.0f}"
    m.update(contamination_macros(L))

    # -- headline gain, collapse and intervention --------------------------
    # The five retention suites are recorded on the split each was evaluated on.
    RETENTION = (("GSM8K", "test"), ("MMLU-Pro", "test"), ("ARC-C", "test"),
                 ("HellaSwag", "validation"), ("TruthfulQA-MC1", "validation"))

    def retention_delta(cfg: str) -> float:
        return sum(L[(cfg, s)][k] - L[("base", s)][k]
                   for k, s in RETENTION) / len(RETENTION)

    m["nRetention"] = str(len(RETENTION))
    conservative = ("supercon", "tra_only", "mid")
    m["refRetention"] = f"{max(abs(retention_delta(c)) for c in conservative):.2f}"
    m["fullLoraGSM"] = f"{full['GSM8K'] - base['GSM8K']:.2f}"
    ppl = L[("full_lora", "test")]["WikiText-PPL"]
    m["fullLoraPPL"] = f"{100 * (ppl / base['WikiText-PPL'] - 1):+.0f}"
    m["srGain"] = f"{sr['INA'] - base['INA']:+.2f}"
    m["srCollapse"] = f"{sr['AbsAcc'] - base['AbsAcc']:.2f}"
    m["srSpan"] = f"{(sr['INA'] - base['INA']) - (sr['AbsAcc'] - base['AbsAcc']):.2f}"
    m["srRetention"] = f"{retention_delta('self_rewarding_strict'):+.2f}"
    m["csdCollapse"] = f"{csd['AbsAcc'] - base['AbsAcc']:.2f}"
    m["csdRecovered"] = f"{csd['AbsAcc'] - sr['AbsAcc']:.2f}"
    m["csdGain"] = f"{csd['INA'] - base['INA']:+.2f}"
    m["csdGainKept"] = f"{100 * (csd['INA'] - base['INA']) / (sr['INA'] - base['INA']):.0f}"
    m["fullLoraCS"] = f"{full['AbsAcc'] - base['AbsAcc']:.2f}"
    m["baseAbs"] = f"{base['AbsAcc']:.2f}"
    m["srAbs"] = f"{sr['AbsAcc']:.2f}"
    m["csdAbs"] = f"{csd['AbsAcc']:.2f}"

    # Confirmatory split: the frozen rule re-run on data built after freezing.
    bc, src, cdc = (L[(c, "conf")] for c in
                    ("base", "self_rewarding_strict", "self_rewarding_csd"))
    m["srCollapseConf"] = f"{src['AbsAcc'] - bc['AbsAcc']:.2f}"
    m["csdCollapseConf"] = f"{cdc['AbsAcc'] - bc['AbsAcc']:.2f}"
    m["srGainConf"] = f"{src['INA'] - bc['INA']:+.2f}"
    m["csdGainKeptConf"] = f"{100 * (cdc['INA'] - bc['INA']) / (src['INA'] - bc['INA']):.0f}"

    pd_ = L[("prompt_dialectic", "test")]
    em = L[("entropy_min", "test")]
    sc = L[("self_critique", "test")]
    m["pdCollapse"] = f"{pd_['INA'] - base['INA']:.2f}"
    m["emGain"] = f"{em['INA'] - base['INA']:+.2f}"
    m["emOER"] = f"{em['OER'] - base['OER']:+.2f}"
    sccsd = L[("self_critique_csd", "test")]
    m["scGain"] = f"{sc['INA'] - base['INA']:+.2f}"
    m["scCollapse"] = f"{sc['AbsAcc'] - base['AbsAcc']:.2f}"
    m["scCsdCollapse"] = f"{sccsd['AbsAcc'] - base['AbsAcc']:.2f}"
    m["scCsdGain"] = f"{sccsd['INA'] - base['INA']:+.2f}"

    # Target gain and worst-task regression are close to rank-independent: a
    # method's OntoNeg improvement says almost nothing about what it breaks.
    LOCKED = ("random_negation", "prompt_dialectic", "entropy_min",
              "self_rewarding_strict", "self_critique", "sft_lora", "lora_kl",
              "mid")
    COMPLEMENTARY = ("AbsAcc", "MUS-P", "MUS-F1")
    gains, worst = [], []
    for cfg in LOCKED:
        cell = L[(cfg, "test")]
        gains.append(cell["INA"] - base["INA"])
        worst.append(min(cell[k] - base[k] for k in COMPLEMENTARY))
    m["nLocked"] = str(len(LOCKED))
    m["rankSpearman"] = f"{_spearman(gains, worst):.2f}"

    # -- equivalence margin -------------------------------------------------
    m["widestAxis"] = margin["widest_axis"]
    m["widestHalfWidth"] = f"{margin['widest_axis_half_width'] * 100:.2f}"
    per = margin["per_metric"]
    order = sorted(per, key=lambda k: per[k]["min_resolvable_effect"])
    mre = {k: per[k]["min_resolvable_effect"] * 100 for k in per}
    m["marginPP"] = f"{margin['margin'] * 100:.0f}"
    m["mreLow"] = f"{mre[order[0]]:.2f}"
    m["mreLowAxis"] = order[0]
    m["mreHigh"] = f"{mre[order[-1]]:.2f}"
    m["mreHighAxis"] = order[-1]
    runs = [per[k]["runs_required_for_half_margin"] for k in order]
    m["halfRunsLow"] = str(min(runs))
    m["halfRunsHigh"] = str(max(runs))
    m["mreTable"] = "; ".join(
        f"{k} ${mre[k]:.2f}$pp (${per[k]['runs_required_for_half_margin']}$)"
        for k in order)
    resolvable = [k for k in order if per[k]["margin_is_resolvable"]]
    m["mreResolvable"] = ", ".join(resolvable)
    m["mreUnresolvable"] = ", ".join(k for k in order
                                     if not per[k]["margin_is_resolvable"])
    m["mreNresolvable"] = str(len(resolvable))
    m["nRunsMargin"] = str(per[order[0]]["n_runs"])

    # -- what each resampling level costs in interval width ------------------
    widths = json.loads((STATS / "interval_widths.json").read_text())
    summary = widths["summary"]
    m["clustWideLo"] = f"{summary['cluster_over_item']['min']:.2f}"
    m["clustWideHi"] = f"{summary['cluster_over_item']['max']:.2f}"
    m["hierWideLo"] = f"{summary['hierarchical_over_item']['min']:.2f}"
    m["hierWideHi"] = f"{summary['hierarchical_over_item']['max']:.2f}"
    per_task = widths["per_task_cluster_over_item"]
    TASK_LABEL = {"concept_shift": "ConceptShift", "onto_neg_wn": "OntoNeg-WN",
                  "logic_repair": "LogicRepair"}
    clustered = max(per_task, key=lambda t: max(per_task[t]))
    m["clustTask"] = TASK_LABEL[clustered]
    m["clustTaskHi"] = f"{max(per_task[clustered]):.2f}"
    m["clustFlatTasks"] = ", ".join(
        TASK_LABEL[t] for t in sorted(per_task) if t != clustered)
    m["clustFlatHi"] = f"{max(max(per_task[t]) for t in per_task if t != clustered):.2f}"

    # -- which axes survive the stringent sensitivity margin -----------------
    tost = json.loads((STATS / "tost_summary.json").read_text())
    cluster_level = tost["levels"]["cluster"]
    METRIC_LABEL = {"INA": "INA", "OER": "OER", "AbsAcc": "AbsAcc",
                    "MUS-P": "LogicRepair P", "MUS-F1": "LogicRepair F1"}
    REFS = ("supercon", "tra_only", "mid", "lora_kl")
    axes = list(METRIC_LABEL)
    everywhere = [a for a in axes
                  if all(cluster_level[f"{c}_vs_base:{a}"]["passes_margin"]["0.5pp"]
                         for c in REFS)]
    extra: list[str] = []
    for cfg in REFS:
        passed = [a for a in axes
                  if cluster_level[f"{cfg}_vs_base:{a}"]["passes_margin"]["0.5pp"]
                  and a not in everywhere]
        if passed:
            label = {"supercon": "SuperCon", "tra_only": "TRA-only", "mid": "Mid",
                     "lora_kl": "LoRA$+$KL"}[cfg]
            extra.append(f"{label} also on {', '.join(METRIC_LABEL[a] for a in passed)}")
    m["strictAxes"] = ", ".join(METRIC_LABEL[a] for a in everywhere) or "no axis"
    m["strictExtra"] = "; ".join(extra) if extra else "no further axis"
    m["strictMarginPP"] = "0.5"

    # -- budget -------------------------------------------------------------
    m["apiCalls"] = f"{api['total_calls']:,}"
    m["apiCap"] = f"{api['budget_cap']:,}"

    # -- drift and cross-backbone replication -------------------------------
    drift = json.loads((ROOT / "configs/drift_diagnostics.json").read_text())["configs"]
    m["fullLoraKL"] = f"{drift['full_lora']['kl']:.2f}"
    cross = json.loads((ROOT / "configs/cross_backbone.json").read_text())
    collapse = abs(float(m["srCollapse"]))
    for key, label in (("llama31", "xbLlama"), ("qwen3_instruct", "xbInstruct")):
        delta = abs(cross["tier_b_deltas"]["self_rewarding_strict"][key]["CS"])
        m[label] = f"{delta / collapse * 100:.0f}"
    m["xbCoreN"] = str(cross["core_items_per_task"])
    m["xbSteps"] = str(cross["tier_b"]["steps"])
    m["xbSeeds"] = str(cross["tier_b"]["seeds"])

    # -- benchmark validation V2-V4 -----------------------------------------
    validation = json.loads((AUDIT / "validation_summary.json").read_text())
    llm = validation["v2_llm_consensus"]
    fleiss = list(llm["fleiss_kappa"].values())
    m["llmRaters"] = str(llm["raters"])
    m["llmJudgments"] = f"{llm['judgments']:,}".replace(",", "{,}")
    m["llmKappa"] = f"{sum(fleiss) / len(fleiss):.2f}"
    m["llmKappaLo"] = f"{min(fleiss):.2f}"
    m["llmKappaHi"] = f"{max(fleiss):.2f}"
    judge = list(llm["per_judge_cohen_kappa"].values())
    m["llmJudgeLo"] = f"{min(judge):.2f}"
    m["llmJudgeHi"] = f"{max(judge):.2f}"
    m["llmAgree"] = f"{min(llm['three_of_four_agreement'].values()) * 100:.0f}"

    artifact = validation["v3_artifact_controls"]
    single = artifact["single_feature_auc"].values()
    m["artifactSingleLo"] = f"{min(single):.2f}"
    m["artifactSingleHi"] = f"{max(single):.2f}"
    m["artifactCombined"] = (
        f"{max(artifact['multivariate_auc']['Combined (all non-semantic features)']):.2f}")
    m["artifactHard"] = f"{max(max(v) for v in artifact['hard_split_auc'].values()):.2f}"
    m["artifactRetention"] = f"{artifact['hard_split_effect_retention'] * 100:.0f}"

    solvers = json.loads((ROOT / "configs/direct_solvers.json").read_text())
    human = solvers["human"]
    m["humanN"] = str(human["n_per_task"])
    m["humanRaters"] = str(human["raters"])
    for key, value in zip(("humanOnto", "humanCS", "humanLR"), human["majority_vote"]):
        m[key] = f"{value:.1f}"
    zero_shot = [v for s in solvers["frontier"].values() for v in s["zero_shot"]]
    m["frontierLo"] = f"{min(zero_shot):.0f}"
    m["frontierHi"] = f"{max(zero_shot):.0f}"

    # -- split sizes, straight from the shipped benchmark files -------------
    sizes = {p.stem: sum(1 for _ in p.open()) for p in BENCH.glob("*.jsonl")}
    m["benchRows"] = f"{sum(sizes.values()):,}".replace(",", "{,}")
    for key, stem in (("nOnto", "onto_neg_wn_test"), ("nCS", "concept_shift_test"),
                      ("nLR", "logic_repair_test"), ("confOnto", "onto_neg_wn_conf"),
                      ("confCS", "concept_shift_conf")):
        m[key] = f"{sizes[stem]:,}".replace(",", "{,}")
    with (AUDIT / "v1_stratified_audit.csv").open() as f:
        m["auditStratN"] = f"{sum(1 for _ in csv.DictReader(f)):,}".replace(",", "{,}")

    # -- audit surface of the ledger itself ---------------------------------
    with (ROOT / "result_ledger.csv").open() as f:
        ledger_rows = list(csv.DictReader(f))
    item_rows = sum(1 for r in ledger_rows if r["source"] == "per_item_predictions")
    m["ledgerRows"] = str(len(ledger_rows))
    m["ledgerItemRows"] = str(item_rows)
    m["ledgerExternalRows"] = str(len(ledger_rows) - item_rows)
    m["ciTol"] = "0.01"

    # \newcommand only accepts letters, so a digit in a name breaks the build.
    illegal = sorted(k for k in m if not k.isalpha())
    if illegal:
        raise SystemExit(f"[numbers] macro names must be letters only: {illegal}")
    body = "\n".join(f"\\newcommand{{\\{k}}}{{{v}}}" for k, v in m.items())
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(
        "% Generated by scripts/render_paper_numbers.py -- do not edit.\n"
        f"{body}\n")
    print(f"[numbers] {len(m)} macros -> {OUT.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
