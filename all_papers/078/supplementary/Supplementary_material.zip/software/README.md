# DION-Bench Software Release

Camera-ready software release accompanying

> *When Targeted Grounded Gains Hide Complementary Abstraction Regression:
> DION-Bench and a Conjunctive Evaluation Protocol.*

Zida Yang\*, Guquan You\*, Jiexin Zheng\*, and Yijie Peng\*\*
(\* equal contribution; \*\* corresponding author)

- Zida Yang and Jiexin Zheng: Guanghua School of Management, Peking University
- Guquan You: Institute of Emergency Safety Innovation, Guangzhou University; Guangdong Guangda Mingxin Technology Co., Ltd.
- Yijie Peng: Department of AI for Management, School of Management and Engineering and School of Computer Science, Nanjing University; Wuhan Institute for Artificial Intelligence, Peking University; Xiangjiang Laboratory

Contact: `pengyijie@nju.edu.cn`

This archive contains the DION-Ref reference adapter, the training stages,
the DION-Bench constructors (OntoNeg-WN, ConceptShift, LogicRepair), the
evaluation harness and versioned output parser, the statistics library, and
the fail-closed result-ledger validator. The benchmark splits and the
human-audit CSVs ship separately in the data archive (`data.tgz` /
`data.zip`); place them under `data/` before running anything that scores.

## Quickstart

```bash
tar xzf software.tgz -C dion_software/
cd dion_software
bash scripts/00_setup_env.sh        # pip install + nltk corpora
export MODELS_DIR=./models
bash scripts/01_download_models.sh  # Qwen3-8B-Base; DOWNLOAD_CROSS_BACKBONE=1 adds the other backbones
bash scripts/02_download_data.sh    # ConceptNet dump, surface-style references, retention suites
make bench                          # optional: regenerate the DION-Bench splits
bash scripts/04_train_stage1.sh     # Stage 1: CPH
bash scripts/05_train_stage2.sh     # Stage 2: TRA + ABO
# scripts/06_train_stage3.sh        # Stage 3 (DIPO): negative ablation, off by default
make eval                           # main evaluation -> outputs/predictions/
# Optional: rebuild CSD items from a parent prediction file
make csd PARENT=outputs/predictions/self_rewarding_strict_items.jsonl \
         OUT=outputs/predictions/self_rewarding_csd_items.jsonl
```

## Auditing the released numbers without a GPU

Every *item-derived* primary number is recomputed from the per-item predictions
under `outputs/predictions/`, which ship with this archive. Aggregate-matched
robustness records (cross-backbone, direct solvers, LLM judgments, contamination,
drift) ship under `outputs/robustness/` and are labelled
`source=aggregate_matched_per_item`. The intended chain is:

```text
checkpoint → exact prompt → raw_output → parser → (optional CSD) → ledger → tables
```

```bash
make verify-ledger   # fail-closed recomputation of every result_ledger.csv row
make stats           # intervals, TOST, AuditPass (incl. retention/PPL NI)
make analysis        # checkpoint mediation + item-level specificity model
make tables numbers  # regenerate every paper table and in-text number
make smoke           # CPU-only module tests, no GPU required
```

`make verify-ledger` reads gold *only* from `data/bench/`, rejects any
prediction file that carries a `gold`-prefixed field or a parser version
other than the released one, re-parses each prediction from its released
`raw_output` with `src/dion/evaluation/output_parser.py`, re-scores every
item (INA/OER, AbsAcc against the full accepted set, MUS-P/MUS-R/MUS-F1 and
Kprime-Exact), and compares pooled means, per-run dispersion, item counts and
run counts against `result_ledger.csv` at `1e-6`. Interval endpoints are redrawn
with an independent seed and compared at `--ci-tol` (0.01 by default), since
two independent resamplings agree only up to Monte-Carlo noise. Rows scored
by external harnesses carry no per-item file and are checked for provenance
instead of being skipped. Parse-rule and fallback counts land in
`outputs/stats/parse_report.json`.

`make csd` runs `scripts/run_csd_intervention.py`, which rebuilds CSD
predictions from a parent file. Each parent record must already carry the
checkpoint `beam_candidates` plus prompt-visible `prompt_target` /
`prompt_context` / `prompt_leaves` fields. Produce those fields from a
checkpoint via the standard evaluator:

```bash
PYTHONPATH=src python -m dion.evaluation.run_main_eval \
  --config configs/<cfg>.yaml --save_items --save_csd_parent \
  --out outputs/<cfg>_eval.json
```

The script never opens benchmark gold fields (`S`, `S_alternatives`, …). It
re-ranks the stored beam with the fixed coefficients in
`configs/intervention_csd.yaml`. When `candidate_logprobs` are present it uses
them; otherwise it falls back to a documented parent-logprob proxy and records
`score_source` in `csd_trace`. LogicRepair is not candidate selection and is
inherited unchanged.

## Method names in the paper, keys in this archive

Every row of the primary table corresponds to one configuration key, which is
also the `config` column of `result_ledger.csv`, the stem of
`outputs/predictions/<key>_items.jsonl` (test set) and
`outputs/predictions/<key>_items_conf.jsonl` (holdout split), and the
prefix of `outputs/<key>_eval.json`.

| Paper row | Configuration key |
| --- | --- |
| Base (Qwen3-8B-Base) | `base` |
| Random-Negation | `random_negation` |
| Prompt-Dialectic | `prompt_dialectic` |
| Entropy-Min | `entropy_min` |
| Self-Critique | `self_critique` |
| Self-Critique, +CSD | `self_critique_csd` |
| Self-Rewarding | `self_rewarding_strict` |
| Self-Rewarding, +CSD | `self_rewarding_csd` |
| SFT-LoRA (control) | `sft_lora` |
| LoRA+KL (matched control) | `lora_kl` |
| DION-Ref SuperCon | `supercon` |
| DION-Ref TRA-only | `tra_only` |
| DION-Ref Mid | `mid` |
| DION-Ref Full-LoRA | `full_lora` |
| GainMatched-Safe (positive control) | `gain_matched_safe` |
| GainMatched-DPO | `gain_matched_dpo` |
| Shuffled-DPO | `shuffled_dpo` |

## Backbone and configurations

* Primary backbone: `Qwen/Qwen3-8B-Base` (Apache-2.0).
* Cross-backbone study: `Qwen/Qwen3-8B-Instruct`, `meta-llama/Llama-3.1-8B`
  (set `DOWNLOAD_CROSS_BACKBONE=1` before running script `01`).
* Training-run budgets, as recorded in `result_ledger.csv`: SuperCon 7,
  Mid 7, TRA-only 5, LoRA+KL 5, Full-LoRA 4, SFT-LoRA 3, and 3 for each
  reward-free baseline. `configs/` holds one YAML per run; the appendix
  hyperparameter table lists rank, target module, lambda_P, steps and
  trainable parameters per configuration, and is rendered from
  `configs/drift_diagnostics.json` plus those YAMLs.

## Reproducibility

* Paired bootstrap, cluster bootstrap, two-way hierarchical bootstrap, TOST
  equivalence, non-inferiority tests, AuditPass decisioning and Benjamini–Hochberg
  correction live in `src/dion/evaluation/stats.py`; the release-level bundle
  that applies them to the released predictions is `scripts/build_stats_bundle.py`
  (writes `tost_summary.json`, `auditpass_summary.json`, etc.).
* All randomness in construction, resampling and validation is derived from
  BLAKE2b digests of explicit strings rather than the interpreter's salted
  `hash()`, so a rerun reproduces the same files on another machine.
* `protocol.md` records the internally pre-specified margins, decoding settings,
  statistical layers and split sizes; its SHA-256 is written to
  `outputs/stats/protocol_hash.txt`.
* Primary decoding is greedy. Training prompts for reward-free
  methods never include gold answers.
* `python -m dion.evaluation.run_main_eval --save_items` writes the same schema
  the validator requires: `id`, `seed`, `raw_output`, `cluster`,
  `parser_version`, with no `gold*` fields.

## License

Code: Apache-2.0. Derived data products that contain ConceptNet 5.7
material inherit CC BY-SA 4.0 from ConceptNet.
