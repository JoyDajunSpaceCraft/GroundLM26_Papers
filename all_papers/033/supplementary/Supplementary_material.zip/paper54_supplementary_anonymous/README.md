# Anonymous supplementary material for Submission 54

This archive is the single, self-contained supplementary package for the
anonymous submission. It contains aggregate evidence records, their manifest,
and the scripts/data used to reproduce the aggregate tables and accuracy plot.
It contains no manuscript source, author names, affiliations, contact details,
API credentials, or machine-specific paths.

## Contents

- `evidence/`: 80 aggregate JSON summaries plus a hash manifest.
- `reproduce_tables.py`: verifies every evidence hash and prints the aggregate
  main, gate-variant, and trace-budget results.
- `figures/accuracy.csv`, `figures/plot_accuracy.py`, and
  `figures/accuracy.pdf`: plotted values, plotting code, and the rendered plot.
- `MANIFEST.sha256`: SHA-256 checksums for every other file in this archive.

## Offline reproduction

From the extracted top-level directory, run:

```sh
python3 reproduce_tables.py > reproduced_tables.json
```

The command uses only the Python standard library, makes no network or API
calls, verifies the evidence hashes, and prints the recomputed aggregates.

To regenerate the plot, install the optional packages in `requirements.txt`
and use a working LaTeX installation:

```sh
python3 figures/plot_accuracy.py
```

## Scope

The retained evidence consists of aggregate summaries. It supports the paper's
aggregate tables and the included plot, but it does not contain per-question
traces, retained-set intersections, or conditional tutor-accuracy records.
Those quantities therefore cannot be reconstructed from this archive. This
limitation is stated explicitly rather than implying that omitted raw records
are present.

This archive is provided under `REVIEW_ONLY_LICENSE.txt`. It is not a public
open-source release and does not assert that any submission-form open-source
code option was selected.
