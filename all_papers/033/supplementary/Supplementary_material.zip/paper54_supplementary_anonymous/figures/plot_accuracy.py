import csv
from pathlib import Path

import matplotlib

matplotlib.use("pgf")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
COLORS = {"document": "#0F4D92", "no_document": "#CE6B29", "retention": "#277D73"}
plt.rcParams.update({
    "pgf.texsystem": "pdflatex",
    "pgf.rcfonts": False,
    "pgf.preamble": r"\usepackage[T1]{fontenc}\usepackage{times}\usepackage{amsmath}",
    "font.family": "serif",
    "font.size": 9,
    "axes.labelsize": 9,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8,
    "legend.fontsize": 8.5,
    "axes.linewidth": 0.6,
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def main():
    with (ROOT / "accuracy.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    figure, axes = plt.subplots(2, 1, figsize=(3.15, 3.8))
    positions = np.arange(4)
    for axis, benchmark in zip(axes, ("HotpotQA", "MuSiQue")):
        selected = [row for row in rows if row["benchmark"] == benchmark]
        document = np.array([float(row["doc_accuracy"]) for row in selected])
        absent = np.array([float(row["no_doc_accuracy"]) for row in selected])
        document_std = np.array([float(row["doc_std"]) for row in selected])
        absent_std = np.array([float(row["no_doc_std"]) for row in selected])
        axis.fill_between(positions, absent, document, color=COLORS["document"], alpha=0.10)
        axis.errorbar(positions, document, yerr=document_std, color=COLORS["document"], marker="o", markersize=3.8, linewidth=1.2, elinewidth=0.7, capsize=2, label="With document")
        axis.errorbar(positions, absent, yerr=absent_std, color=COLORS["no_document"], marker="s", markersize=3.5, linewidth=1.2, elinewidth=0.7, capsize=2, label="No document")
        axis.set_ylim(-0.005, 0.38)
        axis.set_xlim(-0.2, 3.2)
        axis.set_yticks([0, 0.1, 0.2, 0.3])
        axis.set_xticks(positions, ["Orig.", "Rand.", "Irrel.", "None"])
        axis.set_ylabel("Accuracy")
        axis.set_axisbelow(True)
        axis.grid(axis="y", color="#DFE3E8", linewidth=0.5)
        axis.tick_params(length=2.5, width=0.6)
        axis.text(0, 1.06, benchmark, transform=axis.transAxes, fontsize=9.5, fontweight="bold")
        axis.text(-0.2, -0.29, "Keep", transform=axis.transAxes, color=COLORS["retention"], fontsize=8.5)
        for position, row in zip(positions, selected):
            axis.text(position, -0.29, f"{float(row['keep']):.3f}", transform=axis.get_xaxis_transform(), ha="center", color=COLORS["retention"], fontsize=8.5)
    handles, labels = axes[0].get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.55, 1), ncol=2, frameon=False, handlelength=1.4, columnspacing=1.1)
    figure.subplots_adjust(left=0.20, right=0.97, bottom=0.12, top=0.84, hspace=0.85)
    figure.savefig(ROOT / "accuracy.pdf", bbox_inches="tight", pad_inches=0.03)
    plt.close(figure)


if __name__ == "__main__":
    main()
