from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'


def read_record(record):
    path = EVIDENCE / record['file']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']
    return json.loads(path.read_text())


def format_mean(values):
    mean = sum(Decimal(str(value)) for value in values) / len(values)
    return str(mean.quantize(Decimal('.001'), rounding=ROUND_HALF_UP))


def main():
    manifest = json.loads((EVIDENCE / 'manifest.json').read_text())
    result = {'main': [], 'gate_variants': [], 'trace_budget': []}
    for row in manifest['main']:
        data = [read_record(record) for record in row['files']]
        statistics_by_metric = {}
        for metric in ['in_domain', 'held_out', 'kept_fraction', 'agr_mean', 'conf_mean', 'correct_modal_rate']:
            values = [record[metric] for record in data]
            statistics_by_metric[metric] = {'mean': statistics.mean(values), 'sample_std': statistics.stdev(values)}
        result['main'].append({'dataset': row['dataset'], 'mode': row['mode'], 'values': statistics_by_metric})
    for record in manifest['random_control']:
        assert read_record(record)['kept_fraction'] == .465
    for record in manifest['gate_variants']:
        data = read_record(record)
        result['gate_variants'].append({key: record[key] for key in ['dataset', 'mode', 'method']} | {'kept_fraction': data['kept_fraction']})
    for budget in [4, 8, 16]:
        means = {}
        for mode in ['original', 'randomized', 'irrelevant', 'none']:
            records = [record for record in manifest['trace_budget'] if record['M'] == budget and record['mode'] == mode]
            assert {(record['dataset'], record['seed']) for record in records} == {(dataset, seed) for dataset in ['hotpotqa', 'musique'] for seed in [2, 3]}
            values = [read_record(record)['kept_fraction'] for record in records]
            means[mode] = format_mean(values)
        result['trace_budget'].append({'M': budget, 'means': means})
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
