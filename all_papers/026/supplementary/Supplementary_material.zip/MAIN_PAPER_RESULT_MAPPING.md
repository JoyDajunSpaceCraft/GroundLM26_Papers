# Main-Paper Result Mapping

This file maps every displayed result requested in the camera-ready release
check to a source file in the source package or to a public supplement file.
All paths below are package-relative and contain no local directory names.

## Common provenance

| Field | Main-paper-aligned setting |
|---|---|
| Verifier checkpoint | `cross_encoder_train20000` for cross-encoder rows |
| Verifier seed | `42` |
| Calibration | `platt` for the calibrated cross-encoder run |
| Generators | Qwen2.5-7B-Instruct and Qwen2.5-14B-Instruct |
| Datasets | HotpotQA, MuSiQue, and 2WikiMultiHopQA |
| Matrix identity | `ce20k_s42`; path-free `generation_run_id` values are retained in the CSV |

## Figure 1: calibrated support-ID diagnostic

Source: `figures/calibrated_operating_points.tex`; held-out HotpotQA diagnostic,
sample N = 5,000. The values below are the coordinates encoded in the figure.

| Main-paper location | Dataset | Generator | Policy | Threshold | Verifier checkpoint | Verifier seed | Calibration setting | Sample N | Exact value | Verification status |
|---|---|---|---|---:|---|---:|---|---:|---|---|
| Figure 1, support panel | HotpotQA | calibrated verifier diagnostic | BM25 fixed top-1 (B1) | n/a | n/a | n/a | n/a | 5,000 | coverage 1.000; support 0.820; distractor 0.180 | VERIFIED |
| Figure 1, support panel | HotpotQA | calibrated verifier diagnostic | BM25 fixed top-2 (B2) | n/a | n/a | n/a | n/a | 5,000 | coverage 1.000; support 0.919; distractor 0.999 | VERIFIED |
| Figure 1, both panels | HotpotQA | calibrated verifier diagnostic | BM25 selective (Bs.62) | 0.62 | n/a | n/a | n/a | 5,000 | coverage 0.602; support 0.919; distractor 0.081 | VERIFIED |
| Figure 1, both panels | HotpotQA | calibrated verifier diagnostic | BM25 selective (Bs.37) | 0.37 | n/a | n/a | n/a | 5,000 | coverage 0.800; support 0.880; distractor 0.120 | VERIFIED |
| Figure 1, both panels | HotpotQA | calibrated verifier diagnostic | Cross fixed top-1 (C1) | n/a | cross_encoder_train20000 | 42 | platt | 5,000 | coverage 1.000; support 0.975; distractor 0.025 | VERIFIED |
| Figure 1, both panels | HotpotQA | calibrated verifier diagnostic | Cross fixed top-2 (C2) | n/a | cross_encoder_train20000 | 42 | platt | 5,000 | coverage 1.000; support 0.995; distractor 0.999 | VERIFIED |
| Figure 1, both panels | HotpotQA | calibrated verifier diagnostic | Cross selective (Cs.93) | 0.93 | cross_encoder_train20000 | 42 | platt | 5,000 | coverage 0.811; support 0.989; distractor 0.011 | VERIFIED |

## Figure 2: generated-output absolute levels

Source: `figures/generated_output_summary.tex` and the corresponding rows in
`main_paper_aligned_generated_output_matrix_ce20k_s42.csv`.

| Main-paper location | Dataset | Generator | Policy | Threshold | Verifier checkpoint | Verifier seed | Calibration setting | Sample N | Exact value (support; distractor) | Verification status |
|---|---|---|---|---:|---|---:|---|---:|---|---|
| Figure 2, support/distractor panels | HotpotQA | Qwen2.5-14B-Instruct | Baseline | n/a | n/a | n/a | n/a | 1,000 | 0.692; 0.129 | VERIFIED |
| Figure 2, support/distractor panels | HotpotQA | Qwen2.5-14B-Instruct | BM25 top-2 | n/a | n/a | n/a | n/a | 1,000 | 0.955; 0.996 | VERIFIED |
| Figure 2, support/distractor panels | HotpotQA | Qwen2.5-14B-Instruct | Cross top-2 | 0.40 | cross_encoder_train20000 | 42 | platt | 1,000 | 0.967; 0.194 | VERIFIED |
| Figure 2, support/distractor panels | MuSiQue | Qwen2.5-14B-Instruct | Baseline | n/a | n/a | n/a | n/a | 500 | 0.086; 0.418 | VERIFIED |
| Figure 2, support/distractor panels | MuSiQue | Qwen2.5-14B-Instruct | BM25 top-2 | n/a | n/a | n/a | n/a | 500 | 0.652; 0.922 | VERIFIED |
| Figure 2, support/distractor panels | MuSiQue | Qwen2.5-14B-Instruct | Cross top-2 | 0.40 | cross_encoder_train20000 | 42 | platt | 500 | 0.728; 0.500 | VERIFIED |
| Figure 2, support/distractor panels | 2WikiMultiHopQA | Qwen2.5-14B-Instruct | Baseline | n/a | n/a | n/a | n/a | 500 | 0.518; 0.050 | VERIFIED |
| Figure 2, support/distractor panels | 2WikiMultiHopQA | Qwen2.5-14B-Instruct | BM25 top-2 | n/a | n/a | n/a | n/a | 500 | 0.824; 0.930 | VERIFIED |
| Figure 2, support/distractor panels | 2WikiMultiHopQA | Qwen2.5-14B-Instruct | Cross top-2 | 0.40 | cross_encoder_train20000 | 42 | platt | 500 | 0.856; 0.152 | VERIFIED |

## Figure 3: movement from baseline

Source: `figures/pareto_frontier.tex`. Coordinates are baseline-relative
support gain and distractor increase; the data points are not relocated in the
release.

| Main-paper location | Dataset | Generator | Policy | Threshold | Verifier checkpoint | Verifier seed | Calibration setting | Sample N | Exact value (support gain; distractor increase) | Verification status |
|---|---|---|---|---:|---|---:|---|---:|---|---|
| Figure 3 | HotpotQA | Qwen2.5-14B-Instruct | BM25 (H-B) | n/a | n/a | n/a | n/a | 1,000 | 0.263; 0.867 | VERIFIED |
| Figure 3 | MuSiQue | Qwen2.5-14B-Instruct | BM25 (M-B) | n/a | n/a | n/a | n/a | 500 | 0.566; 0.504 | VERIFIED |
| Figure 3 | 2WikiMultiHopQA | Qwen2.5-14B-Instruct | BM25 (2W-B) | n/a | n/a | n/a | n/a | 500 | 0.306; 0.880 | VERIFIED |
| Figure 3 | HotpotQA | Qwen2.5-14B-Instruct | Cross (H-C) | 0.40 | cross_encoder_train20000 | 42 | platt | 1,000 | 0.275; 0.065 | VERIFIED |
| Figure 3 | MuSiQue | Qwen2.5-14B-Instruct | Cross (M-C) | 0.40 | cross_encoder_train20000 | 42 | platt | 500 | 0.642; 0.082 | VERIFIED |
| Figure 3 | 2WikiMultiHopQA | Qwen2.5-14B-Instruct | Cross (2W-C) | 0.40 | cross_encoder_train20000 | 42 | platt | 500 | 0.338; 0.102 | VERIFIED |

## Table 1: single-author audit

Source: `tables/validation_results.tex`; audit source: the aggregate CSV files
whose names begin with `claim_audit_`. The audit contains 450 unique generated-
output cases and 60 duplicate consistency checks. Duplicate rows do not enter
the rates below.

| Main-paper location | Dataset | Generator | Policy | Threshold | Verifier checkpoint | Verifier seed | Calibration setting | Sample N | Exact value | Verification status |
|---|---|---|---|---:|---|---:|---|---:|---|---|
| Table 1 | HotpotQA, MuSiQue, 2WikiMultiHopQA | Qwen2.5-7B/14B-Instruct | Baseline | n/a | n/a | n/a | n/a | 150 unique rows per policy | Full 0.400; Partial 0.413; Full+Partial 0.813; None 0.187; Distr. 0.293; Ans. 0.520 | VERIFIED |
| Table 1 | HotpotQA, MuSiQue, 2WikiMultiHopQA | Qwen2.5-7B/14B-Instruct | BM25 top-2 | n/a | n/a | n/a | n/a | 150 unique rows | Full 0.400; Partial 0.453; Full+Partial 0.853; None 0.147; Distr. 0.893; Ans. 0.507 | VERIFIED |
| Table 1 | HotpotQA, MuSiQue, 2WikiMultiHopQA | Qwen2.5-7B/14B-Instruct | Cross top-2 | 0.40 | cross_encoder_train20000 | 42 | platt | 150 unique rows | Full 0.507; Partial 0.313; Full+Partial 0.820; None 0.180; Distr. 0.407; Ans. 0.507 | VERIFIED |
| Table 1 | All audit rows | Qwen2.5-7B/14B-Instruct | Duplicate consistency check | n/a | n/a | n/a | n/a | 60 duplicate rows | Exact agreement 55/60; excluded from main rates | VERIFIED |

## Explicit numbers in Results

| Main-paper location | Dataset | Generator | Policy | Threshold | Verifier checkpoint | Verifier seed | Calibration setting | Sample N | Exact value | Verification status |
|---|---|---|---|---:|---|---:|---|---:|---|---|
| Results, controlled stress test | HotpotQA diagnostic | controlled answer-fixed probe | Lexical top-2 | n/a | n/a | n/a | n/a | 100 | All-support 0.770; distractor 1.000 | VERIFIED |
| Results, controlled stress test | HotpotQA diagnostic | controlled answer-fixed probe | Cross top-1 | 0.20 | cross_encoder_train20000 | 42 | platt | 100 | Support 0.710; distractor 0.280 | VERIFIED |
| Results, robustness slice | LLM-generated cases | unspecified illustrative slice | Lexical top-2 | n/a | n/a | n/a | n/a | 28 | All-support 0.071 to 0.607; distractor 1.000 | VERIFIED |
| Results, robustness slice | LLM-generated cases | unspecified illustrative slice | Cross | 0.20 | cross_encoder_train20000 | 42 | platt | 28 | All-support 0.607; distractor 0.464 | VERIFIED |
| Results, audit summary | All audit datasets | Qwen2.5-7B/14B-Instruct | BM25 top-2 | n/a | n/a | n/a | n/a | 450 unique + 60 duplicate | Full+Partial 0.853; distractor 0.893 | VERIFIED |
| Results, audit summary | All audit datasets | Qwen2.5-7B/14B-Instruct | Cross top-2 | 0.40 | cross_encoder_train20000 | 42 | platt | 450 unique + 60 duplicate | Full+Partial 0.820; distractor 0.407; Full 0.507 | VERIFIED |

## Explicit numbers in Analysis

| Main-paper location | Dataset | Generator | Policy | Threshold | Verifier checkpoint | Verifier seed | Calibration setting | Sample N | Exact value | Verification status |
|---|---|---|---|---:|---|---:|---|---:|---|---|
| Analysis, audit break-even | Audit aggregate | Qwen2.5-7B/14B-Instruct | Cross minus BM25 utility view | n/a | cross_encoder_train20000 | 42 | platt | 450 unique | lambda* = (0.853 - 0.820)/(0.893 - 0.407) approximately 0.068 | VERIFIED |
| Analysis, transfer boundary | MuSiQue | Qwen2.5-14B-Instruct | Cross top-2 | 0.20 | cross_encoder_train20000 | 42 | platt | 500 | Support 0.086 to 0.774; distractor 0.524 | VERIFIED |
| Analysis, audit bootstrap | All audit datasets | Qwen2.5-7B/14B-Instruct | Cross minus BM25 | 0.40 | cross_encoder_train20000 | 42 | platt | 450 unique | Distractor difference -0.487 with interval [-0.580, -0.400] | VERIFIED |
| Analysis, audit bootstrap | All audit datasets | Qwen2.5-7B/14B-Instruct | Cross minus BM25 | 0.40 | cross_encoder_train20000 | 42 | platt | 450 unique | Full-or-partial support difference -0.033 with interval [-0.120, 0.053] | VERIFIED |
