# Calibrated Repair Result Summary: cross_encoder_train20000_s42_platt

## Headline

The lowest non-empty selective risk is 0.010 at coverage 0.909 with threshold 0.94.

## Fixed Top-k Baselines

| Policy | Coverage | All-support | Distractor | Strict success | Risk |
|---|---:|---:|---:|---:|---:|
| fixed_top1 | 1.000 | 0.981 | 0.019 | 0.981 | 0.019 |
| fixed_top2 | 1.000 | 0.996 | 1.000 | 0.000 | 1.000 |

## Selective Operating Points

| Minimum coverage | Threshold | Coverage | Selective risk | All-support | Distractor |
|---:|---:|---:|---:|---:|---:|
| 0.2 | 0.94 | 0.909 | 0.010 | 0.990 | 0.010 |
| 0.4 | 0.94 | 0.909 | 0.010 | 0.990 | 0.010 |
| 0.6 | 0.94 | 0.909 | 0.010 | 0.990 | 0.010 |
| 0.8 | 0.94 | 0.909 | 0.010 | 0.990 | 0.010 |

## Calibration Metrics

- `ece`: 0.0204
- `brier_score`: 0.0237
- `log_loss`: 0.1042

## Go / No-Go Read

This run passes the basic feasibility test: selective repair finds a lower-risk region than fixed top-1.
Fixed top-2 shows the expected over-citation failure mode, with very high distractor rate.
