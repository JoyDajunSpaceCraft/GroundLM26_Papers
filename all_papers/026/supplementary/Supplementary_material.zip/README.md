# Supplementary Materials for
# The Citation Expansion Trap: Operating-Point Control for Fixed-Answer Multi-Hop RAG Citation Repair

Author: Jiawei Li  
Affiliation: Nanyang Technological University, Singapore  
Venue: GroundLM 2026, EMNLP 2026 Workshop  
Version: 2026-09-04

This package contains the evidence artifacts referenced in the paper, including
generated-output matrices, proxy-alignment summaries, robustness diagnostics,
qualitative boundary cases, and supplementary figures. These materials
document the paper's operating-point analysis and do not introduce claims
beyond the camera-ready manuscript.

## Contents

1. **Main-paper-aligned results**
   - `main_paper_aligned_generated_output_matrix_ce20k_s42.csv` and its Markdown
     rendering directly correspond to the generated-output values used in the
     paper.
   - `main_paper_calibrated_verifier_result_summary_ce20k_s42_platt.md` records
     the calibrated verifier summary used by the controlled diagnostic.
   - `clean_support_table_20260531.csv` and `.md` provide derived aggregate
     operating-point summaries.
2. **Robustness and seed diagnostics**
   - The matrix includes Qwen2.5-7B-Instruct and Qwen2.5-14B-Instruct rows under
     the path-free `generation_run_id` field.
3. **Claim-audit aggregates**
   - `claim_audit_proxy_alignment_20260531.md` and the four claim-audit CSVs
     summarize proxy alignment and bootstrap contrasts.
4. **MuSiQue boundary cases**
   - `musique_boundary_error_slice_20260531.md` and `.csv` contain selected
     derived diagnostic material from the single-author MuSiQue audit.
5. **Figures**
   - The three PDF/PNG pairs provide supplementary operating-point,
     generated-output, and proxy-calibration visualizations.
6. **License and provenance notes**
   - `PROVENANCE_AND_LICENSES.md` records upstream sources, license boundaries,
     and the status of the derived materials.

## Interpretation Boundary

The generated-output matrix reports support-ID diagnostics over HotpotQA,
MuSiQue, and 2WikiMultiHopQA outputs from Qwen2.5-7B-Instruct and
Qwen2.5-14B-Instruct. These diagnostics are not claim-level faithfulness
judgments.

The MuSiQue slice is qualitative evidence for a harder compositional boundary
condition. It shows selected cases involving distractor pollution, answer
mismatch, and support-ID versus claim-support divergence.

The claim-audit files compare support-ID diagnostics with single-author
claim-support adjudication. They should not be read as multi-annotator
validation or as claim-level faithfulness ground truth.

## Data and Model Provenance

The public matrix contains derived aggregate values only. Dataset and model
provenance, upstream source links, and license boundaries are documented in
`PROVENANCE_AND_LICENSES.md`. No model weights are included.

## File Schema Notes

The main matrix CSV is UTF-8, has one consistent header, and uses
`generation_run_id` as a stable path-free identity tag. It does not include
local run directories. Numeric columns are proportions unless otherwise noted.

## Reproduction Notes

The package is intended to support inspection of the reported operating points
and their diagnostic aggregates. Reproduction should use the named datasets,
models, verifier checkpoint, seed, and calibration setting in the public
provenance notes; upstream access and licensing terms remain applicable.
