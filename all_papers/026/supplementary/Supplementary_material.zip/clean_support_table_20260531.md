# Clean-Support Diagnostic Table

Generated: 2026-05-31

Clean support is reported as support minus distractor for support-ID matrix rows, and as author full/partial support with no distractor for audit rows. Do not mix these as the same metric.

|source|system|n|support_full_or_partial|distractor|clean_support|weighted_utility_lambda_0.5|
|---|---|---|---|---|---|---|
|author_audit|baseline|150|0.813|0.293|0.593|0.460|
|author_audit|bm25_top2|150|0.853|0.893|0.080|0.180|
|author_audit|cross_top2_t04|150|0.820|0.407|0.480|0.460|
|support_id_matrix:hotpot:Qwen2.5-7B|baseline|1000|0.537|0.167|0.370|0.454|
|support_id_matrix:hotpot:Qwen2.5-7B|bm25_top2|1000|0.949|0.996|-0.047|0.451|
|support_id_matrix:hotpot:Qwen2.5-7B|cross_top2_t04|1000|0.980|0.220|0.760|0.870|
|support_id_matrix:hotpot:Qwen2.5-14B|baseline|1000|0.692|0.129|0.563|0.627|
|support_id_matrix:hotpot:Qwen2.5-14B|bm25_top2|1000|0.955|0.996|-0.041|0.457|
|support_id_matrix:hotpot:Qwen2.5-14B|cross_top2_t04|1000|0.987|0.185|0.802|0.894|
|support_id_matrix:musique:Qwen2.5-7B|baseline|500|0.066|0.622|-0.556|-0.245|
|support_id_matrix:musique:Qwen2.5-7B|bm25_top2|500|0.638|0.984|-0.346|0.146|
|support_id_matrix:musique:Qwen2.5-7B|cross_top2_t04|500|0.760|0.692|0.068|0.414|
|support_id_matrix:musique:Qwen2.5-14B|baseline|500|0.086|0.418|-0.332|-0.123|
|support_id_matrix:musique:Qwen2.5-14B|bm25_top2|500|0.652|0.922|-0.270|0.191|
|support_id_matrix:musique:Qwen2.5-14B|cross_top2_t04|500|0.766|0.528|0.238|0.502|
|support_id_matrix:2wiki:Qwen2.5-7B|baseline|500|0.394|0.104|0.290|0.342|
|support_id_matrix:2wiki:Qwen2.5-7B|bm25_top2|500|0.836|0.950|-0.114|0.361|
|support_id_matrix:2wiki:Qwen2.5-7B|cross_top2_t04|500|0.842|0.224|0.618|0.730|
|support_id_matrix:2wiki:Qwen2.5-14B|baseline|500|0.518|0.050|0.468|0.493|
|support_id_matrix:2wiki:Qwen2.5-14B|bm25_top2|500|0.824|0.930|-0.106|0.359|
|support_id_matrix:2wiki:Qwen2.5-14B|cross_top2_t04|500|0.852|0.184|0.668|0.760|
