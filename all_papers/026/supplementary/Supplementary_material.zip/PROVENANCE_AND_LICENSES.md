# Provenance and License Notes

## Scope of this package

This package contains derived aggregate metrics, diagnostic tables, figures,
and a small number of selected derived examples used for reproduction notes
and error analysis. It does not contain model weights or a redistribution of
the upstream datasets. The files cover HotpotQA, MuSiQue, and
2WikiMultiHopQA, and include outputs generated with Qwen2.5-7B-Instruct and
Qwen2.5-14B-Instruct.

## Upstream sources

| Resource | Official source | License or boundary recorded here |
|---|---|---|
| HotpotQA | https://hotpotqa.github.io/ | The official project describes the dataset and processed Wikipedia material as CC BY-SA 4.0. |
| MuSiQue | https://github.com/StonyBrookNLP/musique | The official README states that MuSiQue is distributed under CC BY 4.0. |
| 2WikiMultiHopQA | https://github.com/Alab-NII/2wikimultihop | The official repository exposes an Apache-2.0 repository license for its code; the dataset files remain subject to their upstream terms, which are not redefined here. |
| Qwen2.5-7B-Instruct | https://huggingface.co/Qwen/Qwen2.5-7B-Instruct | The official model card lists Apache-2.0. |
| Qwen2.5-14B-Instruct | https://huggingface.co/Qwen/Qwen2.5-14B-Instruct | The official model card lists Apache-2.0. |

The links above are provided for provenance. The package does not assert new
ownership or relicensing rights over HotpotQA, MuSiQue, 2WikiMultiHopQA, the
Qwen models, or other third-party tools.

## Derived material boundary

The main matrix, audit aggregates, and figures are derived summaries rather
than raw upstream resources. The MuSiQue boundary-case files contain selected
derived diagnostic material from the single-author audit described in the
paper; they are included for academic reproduction, audit explanation, and
error analysis. They should not be interpreted as a new annotation release or
as claim-level faithfulness ground truth.

## License notice

Upstream data, model names, and third-party tools remain subject to the terms
of their respective rights holders. This project does not apply a new package-
wide MIT, Apache, or Creative Commons license to materials that may include
upstream content. Any license for original project code or scripts, if needed,
must be confirmed separately by the author and does not extend to upstream
data or model weights.
