# Main-Paper-Aligned Generated-Output Matrix

This is the MAIN-PAPER MATRIX. It contains the generated-output diagnostics used by the camera-ready manuscript.

- Verifier checkpoint: `cross_encoder_train20000`
- Verifier seed: `42`
- Calibration: `platt`
- Generators: Qwen2.5-7B-Instruct and Qwen2.5-14B-Instruct
- Datasets: HotpotQA, MuSiQue, and 2WikiMultiHopQA
- Sample sizes: 1000 for HotpotQA; 500 for MuSiQue and 2WikiMultiHopQA
- Support and distractor columns are support-ID diagnostics, not claim-level faithfulness judgments.
- `generation_run_id` is a path-free identity tag; no local run directory is included.

The previously supplied full matrix is excluded from this public package because its verifier checkpoint, seed, and calibration could not be established reliably. It is retained only in the release preflight quarantine.

| Tag | Dataset | Model | System | N | Answer Gold | Support | Incomplete | Unsupported | Distractor |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | baseline | 500 | 0.638 | 0.518 | 0.482 | 0.05 | 0.05 |
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | bm25_top1 | 500 | 0.638 | 0.718 | 0.282 | 0.682 | 0.682 |
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | bm25_top2 | 500 | 0.638 | 0.824 | 0.176 | 0.93 | 0.93 |
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | cross_top1_t02 | 500 | 0.638 | 0.748 | 0.252 | 0.15 | 0.15 |
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | cross_top2_t02 | 500 | 0.638 | 0.864 | 0.136 | 0.176 | 0.176 |
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | cross_top1_t04 | 500 | 0.638 | 0.742 | 0.258 | 0.136 | 0.136 |
| qwen25_14b_2wiki_500_24708_5 | 2wiki | Qwen/Qwen2.5-14B-Instruct | cross_top2_t04 | 500 | 0.638 | 0.856 | 0.144 | 0.152 | 0.152 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | baseline | 1000 | 0.756 | 0.692 | 0.308 | 0.129 | 0.129 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | bm25_top1 | 1000 | 0.756 | 0.914 | 0.086 | 0.854 | 0.854 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | bm25_top2 | 1000 | 0.756 | 0.955 | 0.045 | 0.996 | 0.996 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | cross_top1_t02 | 1000 | 0.756 | 0.964 | 0.036 | 0.193 | 0.193 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | cross_top2_t02 | 1000 | 0.756 | 0.975 | 0.025 | 0.209 | 0.209 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | cross_top1_t04 | 1000 | 0.756 | 0.957 | 0.043 | 0.182 | 0.182 |
| qwen25_14b_hotpot_1000_single_24617_2 | hotpot | Qwen/Qwen2.5-14B-Instruct | cross_top2_t04 | 1000 | 0.756 | 0.967 | 0.033 | 0.194 | 0.194 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | baseline | 500 | 0.22 | 0.086 | 0.914 | 0.418 | 0.418 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | bm25_top1 | 500 | 0.22 | 0.392 | 0.608 | 0.626 | 0.626 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | bm25_top2 | 500 | 0.22 | 0.652 | 0.348 | 0.922 | 0.922 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | cross_top1_t02 | 500 | 0.22 | 0.44 | 0.56 | 0.456 | 0.456 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | cross_top2_t02 | 500 | 0.22 | 0.774 | 0.226 | 0.524 | 0.524 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | cross_top1_t04 | 500 | 0.22 | 0.42 | 0.58 | 0.452 | 0.452 |
| qwen25_14b_musique_1000_single_24618_3 | musique | Qwen/Qwen2.5-14B-Instruct | cross_top2_t04 | 500 | 0.22 | 0.728 | 0.272 | 0.5 | 0.5 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | baseline | 500 | 0.646 | 0.394 | 0.606 | 0.104 | 0.104 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | bm25_top1 | 500 | 0.646 | 0.718 | 0.282 | 0.616 | 0.616 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | bm25_top2 | 500 | 0.646 | 0.836 | 0.164 | 0.95 | 0.95 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | cross_top1_t02 | 500 | 0.646 | 0.76 | 0.24 | 0.174 | 0.174 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | cross_top2_t02 | 500 | 0.646 | 0.85 | 0.15 | 0.226 | 0.226 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | cross_top1_t04 | 500 | 0.646 | 0.754 | 0.246 | 0.166 | 0.166 |
| qwen25_7b_2wiki_500_24708_4 | 2wiki | Qwen/Qwen2.5-7B-Instruct | cross_top2_t04 | 500 | 0.646 | 0.844 | 0.156 | 0.204 | 0.204 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | baseline | 1000 | 0.745 | 0.537 | 0.463 | 0.167 | 0.167 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | bm25_top1 | 1000 | 0.745 | 0.881 | 0.119 | 0.734 | 0.734 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | bm25_top2 | 1000 | 0.745 | 0.949 | 0.051 | 0.996 | 0.996 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | cross_top1_t02 | 1000 | 0.745 | 0.943 | 0.057 | 0.215 | 0.215 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | cross_top2_t02 | 1000 | 0.745 | 0.969 | 0.031 | 0.239 | 0.239 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | cross_top1_t04 | 1000 | 0.745 | 0.936 | 0.064 | 0.206 | 0.206 |
| qwen25_7b_hotpot_1000_single_24615_0 | hotpot | Qwen/Qwen2.5-7B-Instruct | cross_top2_t04 | 1000 | 0.745 | 0.959 | 0.041 | 0.226 | 0.226 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | baseline | 500 | 0.216 | 0.066 | 0.934 | 0.622 | 0.622 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | bm25_top1 | 500 | 0.216 | 0.374 | 0.626 | 0.78 | 0.78 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | bm25_top2 | 500 | 0.216 | 0.638 | 0.362 | 0.984 | 0.984 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | cross_top1_t02 | 500 | 0.216 | 0.452 | 0.548 | 0.646 | 0.646 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | cross_top2_t02 | 500 | 0.216 | 0.776 | 0.224 | 0.688 | 0.688 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | cross_top1_t04 | 500 | 0.216 | 0.436 | 0.564 | 0.644 | 0.644 |
| qwen25_7b_musique_1000_single_24616_1 | musique | Qwen/Qwen2.5-7B-Instruct | cross_top2_t04 | 500 | 0.216 | 0.74 | 0.26 | 0.674 | 0.674 |
