# Claim-Audit Proxy Alignment Supplement

This note summarizes a single-author diagnostic audit used to check how support-ID metrics relate to claim-level citation support. It is intended as supplementary transparency material, not as independent multi-annotator human evaluation.

## Scope

- Audit size: 450 unique generated-output rows plus 60 duplicate consistency rows.
- Datasets: HotpotQA, MuSiQue, and 2Wiki.
- Generators: Qwen2.5-7B and Qwen2.5-14B.
- Policies: baseline generated citations, BM25 top-2 expansion, and cross-encoder top-2 at tau = 0.40.
- Author labels: claim support (`yes`, `partial`, `no`), distractor citation (`yes`, `no`), and answer correctness (`yes`, `partial`, `no`, `unclear`).
- External LLM prelabels, where used during workflow, are advisory only and are not treated as ground truth.

## Proxy Alignment

Support-ID full-support coverage is informative but not equivalent to claim-level citation support:

- The support-ID full-support proxy overstates full claim support on 0.242 of unique audited rows.
- The support-ID full-support proxy understates full claim support on 0.111 of unique audited rows.
- The distractor proxy is closer to the author label: false positives are 0.060 and false negatives are 0.027.

This supports the manuscript's conservative wording: support-ID metrics are useful for scalable diagnostics, but stronger faithfulness claims require claim-level auditing.

## BM25 vs Cross Top-2 Audit Contrast

In the single-author audit, BM25 top-2 and cross top-2 have similar full-or-partial claim-support rates, but very different distractor rates.

An independent bootstrap over audited policy rows estimates:

- Cross-minus-BM25 distractor-rate difference: -0.487 [ -0.580, -0.400 ].
- Cross-minus-BM25 full-or-partial support difference: -0.033 [ -0.120, 0.053 ].

Interpretation: the audit supports a cleaner-evidence claim more than a higher-claim-support claim. Cross top-2 reduces author-judged distractor pollution relative to BM25 top-2, while full-or-partial claim support remains statistically similar in this audit.

## Duplicate Consistency

The duplicate rows are a consistency check, not independent annotation. Exact agreement across the three author labels was 55/60. The remaining disagreements are retained as audit uncertainty rather than removed from the record.

## Included Aggregate Files

- `claim_audit_support_proxy_confusion_20260531.csv`
- `claim_audit_distractor_proxy_confusion_20260531.csv`
- `claim_audit_answer_proxy_confusion_20260531.csv`
- `claim_audit_bm25_vs_cross_bootstrap_20260531.csv`

These files contain aggregate diagnostics only. They do not include raw questions, answers, passage text, author notes, or any private credentials.
