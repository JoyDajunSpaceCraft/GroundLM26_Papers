# Supplementary artifact changelog

## 1.0.1 — 2026-09-08

Version-specific DOI: `https://doi.org/10.5281/zenodo.22668710`.

- Added the exact repair and judge prompt templates that were missing from the
  prompt inventory.
- Added the claim-type enum and rules, plus the verifier microbenchmark source,
  so the Gate 4 and performance descriptions can be inspected locally.
- Added deterministic confidence-interval reconciliation and its captured
  output.
- Required the `text` field in `claim_v1.json`, matching the six-field prompt
  and the base-commit runtime parser; added the parser snapshot to make this
  documentation correction auditable.
- Corrected the paper-to-artifact figure mapping and documented the exact
  reproduction boundaries for large-run claims, rater-sample extraction, and
  cost estimates.
- Corrected the paper's Gates 1–3 rater interpretation: the four unanimous
  human-accept/verifier-reject cases mainly reflect exact number-string forms,
  not omitted declared values.
- Documented that the evaluation's lenient parser can skip malformed records
  and that the survival denominator counts parsed-and-retained claims; the
  archived large-run records cannot recover the partial-record drop rate.

The paper-grade result JSON, reported cell totals, Gate 4 reconciliation, and
rater response CSVs are unchanged from version 1.0.0.

## 1.0.0 — 2026-09-07

Initial published artifact: `https://doi.org/10.5281/zenodo.22641534`.
