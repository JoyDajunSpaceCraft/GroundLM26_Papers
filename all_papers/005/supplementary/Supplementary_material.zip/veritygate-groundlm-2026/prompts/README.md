# Prompt inventory

The paper-grade prompt set is split across three files:

- `NarratorPrompts.java` contains the grounded and ungrounded narrator prompts.
- `repair_prompt_template.txt` records the exact repair wrapper. At run time,
  `<GROUNDED_BASE_PROMPT>` is the complete grounded prompt, and
  `<UP_TO_10_VERIFIER_ERROR_LINES>` is replaced by at most ten lines in the
  form `- <verifier error>`.
- `judge_prompt_template.txt` records the exact pairwise-judge template.
  The three angle-bracketed fields are replaced by the optimizer context and
  the two explanations.

The templates preserve the wording and assembly order used by the tagged code
release. Angle-bracketed markers document run-time substitutions; they were
not sent literally to a model.
