# Provenance record

## Paper-grade runs

The raw JSON files record these generation timestamps:

| File | `ranAt` | Repair setting |
|---|---:|---:|
| `explanation_eval_results.large-r0.json` | 2026-05-14T13:20:23.706407Z | r=0 |
| `explanation_eval_results.large-r1.json` | 2026-05-14T20:42:57.214941Z | r=1 |
| `explanation_eval_results.large-r2-sonnet.json` | 2026-05-14T23:42:31.907384Z | Sonnet r=2 |

The r=0 and r=1 files each record three narrator model IDs, GPT-4o as judge,
50 profiles, 150 judge samples, seed 42, and the corresponding grounded
repair-attempt count. `scripts/reconcile_results.py` consumes the per-instance
records rather than trusting the saved summary files.

The authoritative Figure 5 diagnostic is the later standalone
`results/raw/matched_pair_scores.large-r1.json` run. Its 249/300 position-A
votes give 83.0%, and 99/150 pairs flip under order reversal, giving 66.0%.
The `matchedPairScores` block embedded in
`explanation_eval_results.large-r1.json` comes from an earlier GPT-4o judge
run with different rationales (253/300 and 103/150). It is retained for full
provenance but is superseded for all paper claims and figures.

## Source lineage

The main evaluation module was committed as:

```text
c7e6392a791454d2d57b670fe83e352edd8c1928
2026-05-15T00:48:39-07:00
Add yukti-evaluation module for grounded LLM narration evaluation
```

The complete source is released separately through the versioned GitHub tag
recorded in `CODE_POINTER.md`. The commit was recorded after the May 14 data
collection, and the paper-grade JSON files do not embed a Git hash despite the
pre-registration's intent to record one. Therefore it is the committed
evaluation snapshot associated with the run, but the result files do not
provide a cryptographic code-to-run binding. The package makes this provenance
gap explicit rather than inventing a run hash.

For self-contained claim-contract and Gate-4 inspection, `verifier/Claim.java`,
`ClaimSchema.java`, `ClaimVerifier.java`, `ClaimType.java`, and
`ClaimTypeRules.java` are copied byte-for-byte from that base commit. Their
SHA-256 values are, respectively,
`00fc09dbb0ebb26a50fc0676b7148c75a88b672e482ceada8377263d384b9b58`,
`761c1b66ee180c53a69c7f6e0ac9c69e50149e035bb0edb73b878fdb73160342`,
`91a57eed6faaed50df842755267d8f0b9ca58706fd37fc7a452ac660f0d4c500`,
`08b3a2554ab7fd8def8c8a95e6c061e5f7e2c8c4ac29e5af1b69b8d67805b76e`, and
`6745f4618434a12ce9f788b6a04e7a34def13ad425a4e97279983a47f711aa0a`.
`VerifierMicroBench.java` is copied byte-for-byte from the tagged release
(SHA-256 `b97d87083425b7cdb7b41ad6b79896d404ab44be6a7e30ff9d00a2bfd9d9190a`).
The complete buildable source remains in the separate GitHub release.

The six-field `claim_v1.json` records the paper-grade prompt contract. The
runtime parser requires `claimId`, `claimType`, and `text`, but defaults a
missing or non-array citation field to an empty list. The evaluation used its
lenient path, which also skips malformed individual claim records and marks an
instance `schemaFailed` only when no claim remains. Therefore the reported
`totalClaims` denominator is successfully parsed-and-retained claims, not every
record emitted by the model. The large-run files do not retain the pre-parse
arrays, so the partial-record drop rate cannot be recovered. The v1.0.0 code
release's design-schema copy also omitted `text` from its JSON `required` list;
adding it here aligns the documentation schema with the prompt, not with every
leniency of the evaluated parser.

Later code added rater-capture fields and a verifier microbenchmark without
changing the primary verifier rules. Those allowlisted additions are included
and documented in the separate versioned GitHub release; unrelated local files
are excluded.

## Reproduction boundaries

The large-run `perInstance` records contain rendered text, aggregate verifier
reports, and categorized error records. They do not contain every original
structured claim or its evidence graph. `scripts/reconcile_results.py` and
`scripts/reconcile_confidence_intervals.py` therefore reconcile the paper's
reported aggregates and intervals from archived outputs; they do not rerun the
production verifier over all large-run inputs or quantify records skipped by
lenient parsing.

The exact Gates 1–3 rater sample and responses are preserved in the distributed
CSVs. The full merged capture input used by `extract_25_claims.py` to create
that sample was not archived, so the sample selection itself is not
byte-reproducible from this package. The Gate 4 sample and all response CSVs are
preserved. See `protocol/rater-validation/README.md`.

The final r=1 cost estimates are recorded in
`results/derived/cost_estimates.csv`. The provider token-count export used for
the estimate was not archived; only the final estimates and the ratios stated
in the paper are locally auditable.

`results/raw/reproducibility_certificate.json` predates and describes the
deterministic optimizer/backend validation (200 profiles, March 2026), not
the May explanation-evaluation run. It is retained only as supporting
backend provenance and must not be interpreted as the LLM-run certificate.

## Gate-4 units

The main table uses distinct failing claims from
`verifierReport.failuresByGate.TYPE_RULES`. Appendix message totals use
Gate-4 strings from `verifierReport.allErrors`. The code-level reason for the
difference is visible in `verifier/ClaimVerifier.java`: `CAP_SWITCH` checks
`CAP_HIT` on an unconditional single-type path and again inside the guarded
two-type rule, while `ALLOCATION_SEGMENT` is emitted by the latter path.

Counts are distinct within a gate, not across gates. In the grounded Sonnet
`r=1` cell, `verifierReport.failingClaims` sums to 841, while the per-gate
counts are 841 for `TYPE_RULES` and 1 for `NUMBER_BINDING`. The number-binding
failure is on a claim that also fails `TYPE_RULES`, so the two gate columns sum
to 842 claim--gate assignments but represent 841 distinct failing claims.

The derived overlap uses exact inclusion-exclusion because `CAP_HIT` and
`ALLOCATION_SEGMENT` are the only Gate-4 requirements for `CAP_SWITCH`:

```text
both missing = missing CAP_HIT + missing ALLOCATION_SEGMENT
               - distinct CAP_SWITCH claims
```

## Integrity

`MANIFEST.sha256` hashes every distributed file except itself. Regenerating
the derived files with the bundled script and then validating the manifest
checks both the numerical derivation and package bytes.
