# VerityGate GroundLM 2026 supplementary artifact

This is the Zenodo-ready supplementary artifact for **“VERITYGATE: A Four-Gate
Schema-Level Faithfulness Framework and Paired Benchmark for Grounded LLM
Narrations over Structured Evidence.”**
It contains the raw paper-grade result logs, deterministic reconciliation
code, complete prompt/schema materials, and rater-study materials. The editable
implementation is released separately on GitHub; its release identity and
source lineage are recorded in `CODE_POINTER.md`. Paper source and PDFs are
intentionally excluded from this package.

## Result checks

From this directory, run:

```bash
python3 scripts/reconcile_results.py
```

The script uses only the Python standard library. It recomputes all cells in
the main results table and the Gate-4 claim/message reconciliation, writes the
outputs under `results/derived/`, and exits non-zero if a camera-ready value
drifts.

To reproduce the confidence intervals and assert every rounded interval stated
in the paper, run:

```bash
python3 scripts/reconcile_confidence_intervals.py
```

Verify the package bytes on macOS with:

```bash
shasum -a 256 -c MANIFEST.sha256
```

On systems with GNU coreutils, use `sha256sum -c MANIFEST.sha256`.

## Gate-4 reconciliation

`results/derived/gate4_reconciliation.csv` separates two units that were
conflated in the accepted-paper caption:

- `distinct_claims` is the sum of `failuresByGate.TYPE_RULES` and is the
  authoritative unit for the main-table headline (mini 652, Llama 753,
  Sonnet 841).
- `message_total` counts Gate-4 strings in `allErrors` (664, 815, 955).
- `CAP_SWITCH` is the only multi-message claim type. `CAP_HIT` is checked on
  two code paths, so one claim can emit as many as three messages.
- For Sonnet, 106 distinct `CAP_SWITCH` claims produce 220 messages. At claim
  level, 89 omit `CAP_HIT`, 72 omit `ALLOCATION_SEGMENT`, and 55 omit both.
  At message level, the total is 89 unconditional `CAP_HIT` messages, 59
  additional guarded `CAP_HIT` messages, and 72 `ALLOCATION_SEGMENT`
  messages.

This is a caption/description correction. The raw data and main-table per-gate
counts are unchanged. Sonnet has 841 distinct failing claims; all 841 fail
Gate 4, and the sole Gate-3 failure overlaps a Gate-4 failure. Summing the
per-gate columns therefore gives 842 claim--gate assignments, not 842 distinct
claims.

## Contents

- `results/raw/`: paper-grade r=0, r=1, and Sonnet r=2 JSON; summaries;
  matched judge-pair scores; rater-audit logs; verifier microbenchmark.
- `results/derived/`: generated cell metrics, Gate-4 reconciliation,
  confidence-interval output, and the author-recorded cost-estimate ledger.
- `scripts/`: deterministic result and confidence-interval reconciliation.
- `protocol/`: pre-registration and the two rater-study protocols/data.
- `prompts/`, `schemas/`: all four prompt paths and directly inspectable schema
  inputs.
- `verifier/`: exact base-commit snapshots of the claim record, parser,
  verifier, and claim-type rules, plus the tagged microbenchmark source. These
  make the six-field prompt contract, parser behavior, Gate-4 rules, and benchmark interpretation
  locally inspectable without cloning the repository.
- `CODE_POINTER.md`: exact code lineage and the versioned GitHub release
  pointer.
- `PROVENANCE.md`: run and source-lineage details, including the recorded
  limitation on code-hash capture.

## Judge-run provenance

The authoritative r=1 judge diagnostic reported in the paper is
`results/raw/matched_pair_scores.large-r1.json` (83.0% position-A calls and
66.0% pair-level inconsistency). The `matchedPairScores` block embedded in
`results/raw/explanation_eval_results.large-r1.json` is an earlier GPT-4o
judge run retained for provenance; it is superseded for Figure 5 and must not
be used to reproduce the paper's 83%/66% values.

No API keys, `.env` files, model credentials, caches, or unrelated local
files are included.

## Reproduction scope and recorded limitations

The large-run JSON stores per-instance aggregate verifier reports, error
records, and rendered text. It does not retain every original claim object and
evidence graph. The bundled scripts therefore reproduce the paper's numerical
tables and confidence intervals from the archived records; they cannot rerun
the verifier end to end over all benchmark instances. Evaluation used the
lenient parser, so malformed individual records could be skipped and missing
citation arrays could become empty arrays. Reported `totalClaims` therefore
counts parsed-and-retained claims. The pre-parse arrays were not archived, so
the partial-record drop rate cannot be recovered. Claim-level capture is
available for the smaller rater audits.

The exact Gates 1–3 rater CSV is authoritative, but the full merged capture
input used to draw that sample was not archived. See
`protocol/rater-validation/README.md`. The final per-model cost estimates are
also archived, while the underlying provider token-count export is not. These
limits are stated here so the package does not claim a stronger reproduction
path than its files support.

## License and citation

The bundled reconciliation code and supplementary materials are distributed
under Apache-2.0; see `LICENSE`. Citation metadata is in `CITATION.cff`. The
version 1.0.0 record is `https://doi.org/10.5281/zenodo.22641534`. This
corrected version 1.0.1 package is identified by the version-specific DOI
`https://doi.org/10.5281/zenodo.22668710`.
