# Gate 4 Rater Rubric — VerityGate

## The big picture (30 seconds)

An AI was asked to explain a credit-card portfolio optimizer's output. For each sentence it wrote, the AI also pointed to *what kind of data record* it was using as support. Your job is simple:

**Look at what the AI said. Look at what data it pointed to. Decide: does the data it pointed to make sense as support for what it said?**

You don't need to know any "rules." Just use common sense.

## What you'll see in each row

Three pieces of information per row. **Important: `claim_type` and `llm_cited_evidence_types` look similar but describe different things.** Read this carefully:

### Journalist analogy

Imagine a journalist writes a news story and cites their sources:
- `claim_type` = *"This is an opinion piece"* — the kind of **writing**.
- `llm_cited_evidence_types` = *"I cited court records and government data"* — the kinds of **sources** that back up the writing.

Two completely different things. Same idea here:

| Column | What it's the *type of* |
|---|---|
| **`claim_type`** | The kind of **STATEMENT** the AI wrote (e.g., "this is a comparison," "this is an assumption") |
| **`llm_cited_evidence_types`** | The kinds of **DATA RECORDS** the AI pointed to as backup for that statement |

### The three columns

1. **`claim_text`** — A sentence the AI wrote about a credit card optimization result.
   *Example: `"chase-freedom-flex wins DINING with a delta of $58 over amex-gold"`*

2. **`claim_type`** — A category label *for the sentence itself*. The AI chose this.
   *Example: `COMPARISON` (it's a comparison between cards), `FEE_JUSTIFICATION` (something about fees), `ASSUMPTION` (something the optimizer assumed), `CAP_SWITCH` (a card hitting its spending cap).*

3. **`llm_cited_evidence_types`** — A list of *the kinds of records* the AI said back up the sentence. These are **NOT** statement categories — they are **data record types** (see glossary below for what each contains).
   *Example: `[WINNER_BY_CATEGORY]` means the AI is pointing to "winner records." `[RESULT_BREAKDOWN]` means it's pointing to "final money totals records."*

### Putting it together — concrete example

| What the AI wrote (`claim_text`) | The AI's category for it (`claim_type`) | The AI's cited records (`llm_cited_evidence_types`) |
|---|---|---|
| "cap1-savor wins DINING by $58 over citi-strata-elite" | `COMPARISON` | `[RESULT_BREAKDOWN]` |

The AI wrote a comparison (one card winning over another). For backup, it pointed to a money-totals record (`RESULT_BREAKDOWN`). Your job: does that money-totals record actually back up a "who-wins-the-category" claim? (Probably not — a winner record would. So you'd likely say **DISAGREE**.)

## The data records (glossary)

What each data-record kind actually contains:

| Record type | What's in it |
|---|---|
| `WINNER_BY_CATEGORY` | "Card X wins category Y by $Z over card W" |
| `FEE_BREAK_EVEN` | "Card X's $95 annual fee breaks even at $1,267 in spend" |
| `ASSUMPTION` | "Optimizer assumed cash-back is worth $1.0 per point" |
| `CAP_HIT` | "Card X hit its $6,000 GROCERIES cap; $0 spillover" |
| `ALLOCATION_SEGMENT` | "Within GROCERIES, card X gets $4,000, fallback card W gets $2,000" |
| `PORTFOLIO_SUMMARY` | The portfolio's top-line numbers |
| `RESULT_BREAKDOWN` | Final money totals (earn, credits, fees, net) |
| `PORTFOLIO_STOP` | "Optimizer stopped at 3 cards (the max)" |

## Your task — one example walkthrough

**Row says:**
- `claim_text`: `"chase-freedom-flex wins DINING by $200 over amex-gold"`
- `claim_type`: `COMPARISON`
- `llm_cited_evidence_types`: `[RESULT_BREAKDOWN]`

**Think:**
The AI said "card X wins category Y by $Z over card W" — that's a head-to-head comparison. It pointed to `RESULT_BREAKDOWN` which contains final money totals (earn, fees, net). A money-totals record doesn't actually tell you who won DINING. The record that would back this claim is `WINNER_BY_CATEGORY`. So the AI's citation doesn't fit.

**Verdict:** **DISAGREE** — citation doesn't fit the claim.

## Fill in two columns per row

### `rater_verdict` — pick one:

- **AGREE** — Yes, what the AI pointed to makes sense as support for what it said.
- **DISAGREE** — No, what the AI pointed to doesn't fit the claim. It pointed to the wrong kind of data.
- **UNCLEAR** — Can't tell from the text alone. Use sparingly.

### `rater_reason` — optional, one short sentence

A few words. E.g., "winner-type evidence needed, got totals" or "fits naturally" or "claim is just a summary, citation OK."

## More calibration examples (none of these appear in the CSV)

| What the AI wrote | claim_type | What it pointed to | Verdict | Quick reason |
|---|---|---|---|---|
| "Optimizer assumed 1.0¢ per point for cash" | ASSUMPTION | `[ASSUMPTION]` | **AGREE** | An assumption-record backing an assumption-claim — fits perfectly |
| "Final earnings: $948.60, fees $0, net $948.60" | FEE_JUSTIFICATION | `[WINNER_BY_CATEGORY]` | **DISAGREE** | Sentence is a money summary, pointed to a winner record — doesn't fit |
| "Portfolio includes 3 cards" | THRESHOLD | `[PORTFOLIO_STOP]` | **AGREE** | A "stopped at N cards" record backs "portfolio has 3 cards" — fits |
| "amex-bcp hit its ONLINE cap at $6,000" | CAP_SWITCH | `[CAP_HIT]` | **AGREE** | A "cap hit" record backs a "hit the cap" claim — fits |
| "us-bank-altitude-go wins OTHER" | COMPARISON | `[FEE_BREAK_EVEN]` | **DISAGREE** | Says one card wins a category, pointed to fee evidence — doesn't fit |

## Important

1. **Form your own opinion.** Don't try to guess what's "right" — just decide if the AI's citation makes sense.
2. **Time budget:** ~30 seconds per row. ~15 min total for 25 items.
3. **Don't discuss items with other raters until you're done.** Independent judgments matter.

## File

CSV: `gate4_sample.csv` (25 rows). Open in Google Sheets / Excel. Fill in the last two columns.
