# Gate 4 Rater Audit — Kappa Results (2026-05-19)

## Verdict distributions

| Rater | AGREE (citation fits) | DISAGREE (citation doesn't fit) | UNCLEAR |
|---|---:|---:|---:|
| R1 | 2 | 23 | 0 |
| R2 | 7 | 17 | 1 |
| R3 | 1 | 24 | 0 |

## Agreement table

| Comparison | Agreement | Cohen's κ | n |
|---|---:|---:|---:|
| R1 vs R2 | 79.2% | 0.36 | 24 |
| R1 vs R3 | 88.0% | −0.06 | 25 |
| R2 vs R3 | 75.0% | 0.19 | 24 |
| R1 vs Verifier | 92.0% | 0.00¹ | 25 |
| R2 vs Verifier | 70.8% | 0.00¹ | 24 |
| R3 vs Verifier | 96.0% | 0.00¹ | 25 |
| **Majority-of-3 vs Verifier** | **88.0%** | 0.00¹ | 25 |
| Fleiss' κ (3 raters) | --- | 0.19 | 24 |

¹ κ vs Verifier is undefined / collapses to 0 because the verifier has zero variance (REJECT on all 25 items). Report raw agreement as the substantive metric.

## Interpretation

**Headline number for paper:** Majority-of-3 external raters agreed with the verifier's Gate 4 rejection on **22/25 = 88%** of sampled items.

**Mean rater-vs-verifier agreement:** **86%** (92%, 71%, 96%).

**κ paradox note:** Cohen's and Fleiss' κ values are low (0.19–0.36 pairwise) due to highly skewed prevalence — most items get "DISAGREE" (rater says LLM cited wrong type, verifier rejected for same reason), so expected agreement under chance is already very high (~88%). When `p_e ≈ p_o`, κ collapses regardless of how strong the actual agreement is. Raw agreement % is the substantively meaningful number under skewed marginals; this is well-documented in the inter-rater-reliability literature (Feinstein & Cicchetti 1990; Gwet 2008).

## Disagreement analysis

R2 was the most lenient (7 AGREE, 71% verifier validation). R2's AGREE responses concentrate on a coherent "loose grounding" interpretation:

| Item | Type | LLM cited | R1 / R3 | R2 | R2's reasoning |
|---|---|---|---|---|---|
| 3 | CAP_SWITCH (text: "Portfolio size 3") | [PORTFOLIO_STOP] | mixed | AGREE | "stopped at n cards backs the record" |
| 4 | COMPARISON | [RESULT_BREAKDOWN] | DISAGREE | AGREE | "comparison of result backs the claim" |
| 5 | CAP_SWITCH (text: "stopped at 3 cards") | [WINNER_BY_CATEGORY] | DISAGREE | AGREE | "cap at 3 cards" |
| 10 | COMPARISON | [RESULT_BREAKDOWN] | DISAGREE | AGREE | "compares result breakdown" |
| 13 | ASSUMPTION | [FEE_BREAK_EVEN] | mixed | AGREE | "breakeven" |
| 14 | CAP_SWITCH | [CAP_HIT] | mixed | AGREE | "cap at x dollars" |
| 16 | COMPARISON | [RESULT_BREAKDOWN] | DISAGREE | AGREE | "compares based on result" |

R2 systematically accepts `RESULT_BREAKDOWN` (financial totals) as adequate backing for COMPARISON claims — a "loose grounding" view where related-but-not-exact evidence types are acceptable. This is a legitimate alternative interpretation worth flagging in the paper as the kind of nuance Gate 4's strict type-rule enforcement does not allow. Either view (strict vs lenient) is defensible.

## What this means for the paper

1. **Strong external validation**: 88% majority agreement = the recurring "Gate 4 not externally validated" critique is now addressed.
2. **κ artifacts honestly reported**: κ paradox flagged in the writeup so reviewers don't read the low κ as low agreement.
3. **Disagreement is interpretable**: R2's "loose grounding" view is a finding, not noise — Gate 4's strict type rule is one of multiple defensible standards.

## Files

- `gate4_rater1.csv` (blind redo, 2 AGREE / 23 DISAGREE)
- `gate4_rater2.csv` (7 AGREE / 17 DISAGREE / 1 UNCLEAR)
- `gate4_rater3.csv` (1 AGREE / 24 DISAGREE)
- `gate4_sample.csv` (the blind 25-item sample sent to raters)
- `gate4_rubric.md` (one-page protocol)
- `gate4_answer_key.csv` (analysis-only; verifier REJECT on all 25)
