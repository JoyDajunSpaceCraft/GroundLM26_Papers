# Rater-study file provenance

The distributed CSV files are the authoritative records for the two reported
rater studies:

- `rater_sheet_template.csv`, `answer_key.csv`, and `rater{1,2,3}.csv` contain
  the exact 25-item Gates 1–3 sample, verifier labels, and rater responses.
- `gate4_sample.csv`, `gate4_answer_key.csv`, and `gate4_rater{1,2,3}.csv`
  contain the exact 25-item Gate 4 sample, verifier labels, and responses.
- `compute_kappa.py` reproduces the reported agreement statistics from those
  authoritative CSV files.

`extract_25_claims.py` documents the seeded stratified extraction method used
for the Gates 1–3 study. The complete merged capture input used to create the
distributed 25-item CSV was not archived. The two capture JSON files elsewhere
in this package support follow-up audits, but they are not sufficient to
regenerate the exact Gates 1–3 sample. Do not present that extraction as a
byte-for-byte reproduction path.

The Gates 1–3 rater sheet canonicalized number formatting for display. The
production verifier evaluated the structured number strings exactly. This is
why raters could accept values such as `2400` while the verifier rejected the
underlying declared `2400.0` against an allowed `2400.00`.
