"""
Compute inter-rater + rater-vs-verifier agreement statistics for the
VerityGate external-rater study.

Supports both 2-rater and 3-rater workflows.

Usage (2 raters + verifier):
    python3 compute_kappa.py rater1.csv rater2.csv answer_key.csv

Usage (3 raters + verifier):
    python3 compute_kappa.py rater1.csv rater2.csv rater3.csv answer_key.csv

Outputs:
    - Pairwise Cohen's kappa for every rater pair
    - Each rater vs verifier (Cohen's kappa + raw agreement)
    - For 3+ raters: Fleiss' kappa across all raters
    - For 3+ raters: majority-vote vs verifier (kappa + agreement)
    - Markdown table ready for Appendix A

Supported CSV schemas:
    - Gates 1--3: id, decision or verifier_decision
      (YES, NO, UNCLEAR)
    - Gate 4: id, rater_verdict or verifier_verdict
      (AGREE, DISAGREE, UNCLEAR or ACCEPT, REJECT)

All labels are normalized to ACCEPT/REJECT/UNCLEAR before comparison. For the
Gate-4 rubric, DISAGREE means the cited evidence type does not support the
claim and therefore agrees with a verifier REJECT decision.
"""
import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path
from itertools import combinations


def normalize_decision(value: str) -> str:
    normalized = value.strip().upper()
    aliases = {
        "YES": "ACCEPT",
        "AGREE": "ACCEPT",
        "ACCEPT": "ACCEPT",
        "VERIFIED": "ACCEPT",
        "NO": "REJECT",
        "DISAGREE": "REJECT",
        "REJECT": "REJECT",
        "REJECTED": "REJECT",
        "UNCLEAR": "UNCLEAR",
    }
    if normalized not in aliases:
        raise ValueError(f"Unsupported decision label: {value!r}")
    return aliases[normalized]


def load_decisions(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    with path.open() as f:
        for row in csv.DictReader(f):
            raw_decision = (
                row.get("decision")
                or row.get("verifier_decision")
                or row.get("rater_verdict")
                or row.get("verifier_verdict")
                or ""
            )
            if raw_decision.strip():
                out[row["id"]] = normalize_decision(raw_decision)
    return out


def cohens_kappa(a: list[str], b: list[str]) -> float:
    """Cohen's kappa for two parallel label sequences."""
    assert len(a) == len(b)
    n = len(a)
    if n == 0:
        return float("nan")
    labels = sorted(set(a) | set(b))
    po = sum(1 for x, y in zip(a, b) if x == y) / n
    count_a = Counter(a)
    count_b = Counter(b)
    pe = sum((count_a[l] / n) * (count_b[l] / n) for l in labels)
    if pe == 1.0:
        return 1.0
    return (po - pe) / (1 - pe)


def agreement(a: list[str], b: list[str]) -> float:
    if not a:
        return float("nan")
    return sum(1 for x, y in zip(a, b) if x == y) / len(a)


def fleiss_kappa(rater_lists: list[list[str]]) -> tuple[float, int]:
    """Fleiss' kappa for k>=3 raters.

    Each rater_lists[i] is a list of labels (parallel, same length per rater).
    Returns (kappa, N_items_used). Items where any rater value is missing or
    UNCLEAR are excluded.

    Categories considered: ACCEPT and REJECT (excluding UNCLEAR).
    """
    n_items = len(rater_lists[0])
    k = len(rater_lists)
    assert all(len(r) == n_items for r in rater_lists), "All rater lists must have same length"

    # Keep only items where every rater gave YES or NO (drop UNCLEAR)
    keep = []
    for i in range(n_items):
        votes = [r[i] for r in rater_lists]
        if all(v in ("ACCEPT", "REJECT") for v in votes):
            keep.append(i)
    N = len(keep)
    if N == 0:
        return float("nan"), 0

    # Build counts per item per category
    categories = ["ACCEPT", "REJECT"]
    # n_ij[i][j] = count of raters choosing category j on item i
    n_ij = []
    for i in keep:
        votes = [r[i] for r in rater_lists]
        n_ij.append([votes.count(c) for c in categories])

    # Marginal proportions per category
    total_assignments = N * k
    p_j = [sum(row[j] for row in n_ij) / total_assignments for j in range(len(categories))]

    # Per-item agreement P_i
    P_i = []
    for row in n_ij:
        s = sum(c * c for c in row)
        P_i.append((s - k) / (k * (k - 1)))

    P_bar = sum(P_i) / N
    P_e_bar = sum(p * p for p in p_j)

    if P_e_bar == 1.0:
        return 1.0, N
    return (P_bar - P_e_bar) / (1 - P_e_bar), N


def majority_vote(rater_lists: list[list[str]]) -> list[str]:
    """For each item, return the majority decision (ACCEPT/REJECT/TIE).

    UNCLEAR votes are excluded from the count. If after exclusion votes tie,
    return "TIE". If no votes remain, return "TIE".
    """
    n_items = len(rater_lists[0])
    majority = []
    for i in range(n_items):
        votes = [r[i] for r in rater_lists if r[i] in ("ACCEPT", "REJECT")]
        if not votes:
            majority.append("TIE")
            continue
        accept_count = votes.count("ACCEPT")
        reject_count = votes.count("REJECT")
        if accept_count > reject_count:
            majority.append("ACCEPT")
        elif reject_count > accept_count:
            majority.append("REJECT")
        else:
            majority.append("TIE")
    return majority


def aligned(r1: dict[str, str], r2: dict[str, str], drop_unclear: bool = False):
    """Return parallel label sequences for items both raters scored."""
    keys = sorted(set(r1) & set(r2), key=lambda k: int(k) if k.isdigit() else k)
    a = [r1[k] for k in keys]
    b = [r2[k] for k in keys]
    if drop_unclear:
        pairs = [(x, y) for x, y in zip(a, b) if x != "UNCLEAR" and y != "UNCLEAR"]
        a = [p[0] for p in pairs]
        b = [p[1] for p in pairs]
    return a, b


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)

    # Last arg is always the answer key; everything before is rater files
    rater_paths = [Path(p) for p in sys.argv[1:-1]]
    key_path = Path(sys.argv[-1])

    raters = [load_decisions(p) for p in rater_paths]
    key = load_decisions(key_path)

    n_raters = len(raters)
    print(f"# {n_raters} raters, {len(key)} key items")
    for i, r in enumerate(raters, 1):
        ydist = Counter(r.values())
        print(f"  Rater {i}: {dict(ydist)}  ({len(r)} items)")
    print()

    # ============================ Pairwise Cohen's kappa ============================
    print("=== Pairwise Cohen's kappa (UNCLEAR dropped) ===")
    pairwise_results = []
    for (i, ri), (j, rj) in combinations(enumerate(raters, 1), 2):
        a, b = aligned(ri, rj, drop_unclear=True)
        kappa = cohens_kappa(a, b)
        agr = agreement(a, b)
        pairwise_results.append((f"Rater {i} vs Rater {j}", agr, kappa, len(a)))
        print(f"  Rater {i} vs Rater {j}:  agreement = {agr:.3f},  kappa = {kappa:.3f},  n = {len(a)}")

    # ============================ Each rater vs Verifier ============================
    print()
    print("=== Rater vs Verifier (UNCLEAR dropped) ===")
    rv_results = []
    for i, r in enumerate(raters, 1):
        a, b = aligned(r, key, drop_unclear=True)
        kappa = cohens_kappa(a, b)
        agr = agreement(a, b)
        rv_results.append((f"Rater {i} vs Verifier", agr, kappa, len(a)))
        print(f"  Rater {i} vs Verifier:  agreement = {agr:.3f},  kappa = {kappa:.3f},  n = {len(a)}")

    # ============================ Fleiss' kappa (3+ raters) ============================
    fleiss = None
    fleiss_n = 0
    if n_raters >= 3:
        # Build parallel lists across raters
        common_keys = sorted(set.intersection(*[set(r) for r in raters]),
                             key=lambda k: int(k) if k.isdigit() else k)
        rater_lists = [[r[k] for k in common_keys] for r in raters]
        fleiss, fleiss_n = fleiss_kappa(rater_lists)
        print()
        print(f"=== Fleiss' kappa (all {n_raters} raters, UNCLEAR dropped) ===")
        print(f"  Fleiss' kappa = {fleiss:.3f}  (n = {fleiss_n} items)")

    # ============================ Majority vote vs Verifier ============================
    mv_kappa = None
    mv_agr = None
    mv_n = 0
    if n_raters >= 3:
        common_keys = sorted(set.intersection(*[set(r) for r in raters], set(key)),
                             key=lambda k: int(k) if k.isdigit() else k)
        rater_lists = [[r[k] for k in common_keys] for r in raters]
        majority = majority_vote(rater_lists)
        verifier = [key[k] for k in common_keys]
        # Exclude TIE items + items where verifier label is missing/UNCLEAR
        pairs = [(m, v) for m, v in zip(majority, verifier)
                 if m in ("ACCEPT", "REJECT") and v in ("ACCEPT", "REJECT")]
        if pairs:
            mv_list = [p[0] for p in pairs]
            ver_list = [p[1] for p in pairs]
            mv_kappa = cohens_kappa(mv_list, ver_list)
            mv_agr = agreement(mv_list, ver_list)
            mv_n = len(pairs)
            print()
            print(f"=== Majority-vote vs Verifier ({n_raters} raters, ties+UNCLEAR dropped) ===")
            print(f"  Majority vs Verifier:  agreement = {mv_agr:.3f},  kappa = {mv_kappa:.3f},  n = {mv_n}")

    # ============================ Markdown table for Appendix A ============================
    print()
    print("## Paste into Appendix A")
    print()
    print("| Comparison | Agreement | Cohen's $\\kappa$ | $n$ |")
    print("|---|---:|---:|---:|")
    for label, agr, kappa, n in pairwise_results:
        print(f"| {label} | {agr:.1%} | {kappa:.2f} | {n} |")
    for label, agr, kappa, n in rv_results:
        print(f"| {label} | {agr:.1%} | {kappa:.2f} | {n} |")
    if mv_kappa is not None:
        print(f"| Majority-of-{n_raters} vs Verifier | {mv_agr:.1%} | {mv_kappa:.2f} | {mv_n} |")
    if fleiss is not None:
        print(f"| Fleiss' $\\kappa$ ({n_raters} raters) | — | {fleiss:.2f} | {fleiss_n} |")


if __name__ == "__main__":
    main()
