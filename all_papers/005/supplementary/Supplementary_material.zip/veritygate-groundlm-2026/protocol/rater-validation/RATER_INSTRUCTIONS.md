# Rater Instructions — Claim-Evidence Check

Thanks for helping! This should take **15-20 minutes**.

## What you'll do

You'll see 25 short statements ("claims") about credit-card portfolio recommendations. Next to each claim, you'll see an "evidence box" listing the entities (card names + category names) and numbers that the claim is *allowed* to reference. Your job is to decide: **does the claim play by the rules?**

You don't need any background in machine learning or credit cards. This is a careful-reading task with a simple rubric.

---

## The question (the only one)

For each claim, answer:

> **Does this claim reference only entities and numbers that appear in the evidence box?**

Pick one of three options from the dropdown in the **Decision** column:

| Option | When to pick it |
|---|---|
| **YES** | Every named entity AND every number in the claim appears in the evidence box. |
| **NO**  | At least one entity OR one number in the claim is *not* in the evidence box. |
| **UNCLEAR** | The claim is too vague to extract entities/numbers, or an entity name is paraphrased and you genuinely can't tell if it matches. |

In the **Reason** column (optional but helpful), if you marked NO, write one tag:
- `bad_entity` — an entity in the claim isn't in the evidence box
- `bad_number` — a number in the claim isn't in the evidence box
- `both`       — both problems

If you marked UNCLEAR, write a few words about why.

---

## What counts as an "entity" or a "number"

- **Entity** = a named thing. Two kinds appear:
  - **Card identifiers**: e.g., `amex-bcp`, `chase-freedom-flex`, `costco-visa`, `us-bank-altitude-go`, `cap1-venture-x`. These are hyphen-separated, lowercase.
  - **Category names**: e.g., `GROCERIES`, `DINING`, `GAS`, `TRAVEL`, `ONLINE`, `OTHER`. These are all-uppercase.
- **Number** = a specific quantity. Examples: `$197.64`, `6%`, `$2,000`, `3 cards`.

Verbs, adjectives, and generic words ("earns", "good", "portfolio") are not entities.

---

## Calibration examples (read these first)

### Example 1 — YES
- **Claim:** *"chase-freedom-flex earns $197.64 on GROCERIES."*
- **Allowed entities:** `[GROCERIES, DINING, chase-freedom-flex, costco-visa]`
- **Allowed numbers:** `[0, 1, 3, 16.8, 197.64, 988]`
- **Decision:** `YES` — `chase-freedom-flex` is in entities, `GROCERIES` is in entities, `197.64` is in numbers.

### Example 2 — NO (bad entity)
- **Claim:** *"discover-it-cash earns $108 on GAS."*
- **Allowed entities:** `[GROCERIES, GAS, chase-freedom-flex, costco-visa]`
- **Allowed numbers:** `[0, 1, 3, 108, 988]`
- **Decision:** `NO`, reason: `bad_entity` — `discover-it-cash` is NOT in allowed entities, even though `GAS` and `108` are.

### Example 3 — NO (bad number)
- **Claim:** *"amex-bcp earns $250 on GROCERIES."*
- **Allowed entities:** `[GROCERIES, DINING, amex-bcp, chase-freedom-flex]`
- **Allowed numbers:** `[0, 1, 3, 197.64, 760, 855]`
- **Decision:** `NO`, reason: `bad_number` — `250` is NOT in allowed numbers, even though `amex-bcp` and `GROCERIES` are.

### Example 4 — UNCLEAR
- **Claim:** *"Travel cards offer competitive rewards."*
- **Allowed entities:** `[GROCERIES, TRAVEL, cap1-venture-x, chase-freedom-flex]`
- **Allowed numbers:** `[1.5, 2, 3, 95, 395]`
- **Decision:** `UNCLEAR` — "Travel cards" is too vague; could mean `TRAVEL` category or specific travel-oriented cards. No number to check. Too vague.

### Example 5 — NO (derived number doesn't count)
- **Claim:** *"The total net is $246.20 across both cards."*
- **Allowed entities:** `[GROCERIES, amex-bcp, costco-visa]`
- **Allowed numbers:** `[0, 1, 3, 108.00, 138.20]`
- **Decision:** `NO`, reason: `bad_number` — `246.20` doesn't appear in allowed numbers, even though `108.00 + 138.20 = 246.20`. We're checking literal presence, not arithmetic.

---

## Important rules

1. **Be literal.** Match what's in the claim against what's in the evidence box, as text.
2. **Numbers must appear directly.** Sums, ratios, derived percentages all count as NO unless the derived value is itself in the allowed list.
3. **Number-format flexibility.** Treat `2260` and `2260.00` and `2,260` as the same number. Currency symbols (`$`), commas, and trailing zeros don't matter.
4. **Don't use outside knowledge.** If the claim mentions a number not in the evidence box, answer NO, even if you happen to know the number is correct in the real world.
5. **Paraphrases of entity names.** If it's an obvious match (e.g., `amex-bcp` ↔ "Amex BCP" or "American Express Blue Cash Preferred"), accept it. If it's a stretch (e.g., "the cashback card" without a specific identifier), mark UNCLEAR.
6. **Don't judge whether the claim is *useful* or *interesting*** — only whether it follows the entity+number rules.
7. **Trust your first read.** If you find yourself debating an item for more than 60 seconds, mark UNCLEAR and move on.

---

## How to fill the sheet

- For each row in the spreadsheet, pick a value in the **Decision** column.
- Optionally fill the **Reason** column.
- Save (Google Sheets auto-saves).
- That's it. Reply with "done" when you're done.

Thank you!
