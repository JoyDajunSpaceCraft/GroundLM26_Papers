#!/usr/bin/env python3
"""
Extract 25 stratified (claim, evidence) pairs from rater capture JSON(s)
for the rater study. Supports merging multiple capture files (e.g., one
from r=1 and one from r=0 to get a wider failure mix).

Usage:
    python3 extract_25_claims.py rater_capture.smoke.json [more.json ...]

Outputs:
    rater_sheet_template.csv  — 25 rows: id, claim_text, allowed_entities, allowed_numbers, decision, reason
    answer_key.csv            — 25 rows: id, verifier_decision (YES/NO)

Stratification:
    10 VERIFIED claims  (passed all 4 gates)
     5 REJECTED by Gate 1 only  (citedEvidenceId not in graph)
     5 REJECTED by Gate 2 only  (citedEntity not allowed)
     5 REJECTED by Gate 3 only  (citedNumber not allowed)
       (Gate 4 violations skipped — outside rater rubric scope)

If a gate is under-sampled, the script reports the gap and pads with
extra VERIFIED items, capped at 25 total. Sampling: random.seed(42).
"""
import csv
import json
import random
import sys
from collections import defaultdict
from pathlib import Path


def classify_failing_gates(errors):
    """Map each error string to a gate number {1, 2, 3, 4}."""
    gates = set()
    for e in errors:
        if "citedEvidenceId not in graph" in e:
            gates.add(1)
        elif "citedEntity not allowed" in e:
            gates.add(2)
        elif "citedNumber not allowed" in e:
            gates.add(3)
        elif "must cite" in e and "evidence" in e:
            gates.add(4)
    return gates


def primary_bucket(claim):
    """Return one of: 'VERIFIED', 'G1', 'G2', 'G3', 'G4_skip', or 'mixed_skip'.
    A claim with errors ONLY in Gates 1-3 is bucketed by its single failing gate.
    A claim with ONLY Gate 4 errors is skipped.
    A claim with mixed Gates 1-3 + 4 is bucketed by its primary 1-3 gate.
    A claim with errors in multiple of Gates 1-3 is skipped (ambiguous for rubric).
    """
    if claim["verifierPassed"]:
        return "VERIFIED"
    gates = classify_failing_gates(claim["verifierErrors"])
    g123 = gates & {1, 2, 3}
    if not g123:
        return "G4_skip"
    if len(g123) > 1:
        return "mixed_skip"
    return f"G{next(iter(g123))}"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    # Merge across all capture files passed
    capture = []
    for path in sys.argv[1:]:
        loaded = json.loads(Path(path).read_text())
        print(f"Loaded {len(loaded)} instances from {path}")
        capture.extend(loaded)
    print(f"Total instances merged: {len(capture)}")

    # Bucket every claim by its primary failure category. De-duplicate by
    # (text, citedEvidenceIds tuple) so the same claim doesn't appear twice
    # even when r=0 and r=1 captures both contain it.
    buckets = defaultdict(list)
    seen = set()
    for inst in capture:
        for claim in inst["claims"]:
            key = (claim["text"], tuple(claim.get("citedEvidenceIds", [])),
                   tuple(claim.get("citedEntities", [])),
                   tuple(claim.get("citedNumbers", [])))
            if key in seen:
                continue
            seen.add(key)
            buckets[primary_bucket(claim)].append((claim, inst))

    print("=== Bucket counts ===")
    for k in ["VERIFIED", "G1", "G2", "G3", "G4_skip", "mixed_skip"]:
        print(f"  {k:14s}: {len(buckets[k])}")

    # Stratified sample with adaptive padding
    random.seed(42)
    selected = []
    used_keys = set()  # avoid double-sampling same claim

    def sample(bucket, n, label):
        pool = buckets[bucket]
        if not pool:
            print(f"WARNING: {label}: 0 candidates available")
            return []
        if len(pool) < n:
            print(f"WARNING: {label}: only {len(pool)} candidates, wanted {n}")
            n = len(pool)
        # Mark sampled
        picks = random.sample(pool, n)
        for claim, inst in picks:
            used_keys.add(id(claim))
        return [(label, *p) for p in picks]

    # Primary stratified targets
    selected.extend(sample("VERIFIED", 10, "VERIFIED"))
    selected.extend(sample("G1", 5, "Gate1"))
    selected.extend(sample("G2", 5, "Gate2"))
    selected.extend(sample("G3", 5, "Gate3"))

    # Pad to 25 by drawing extras from available REJECTED buckets first,
    # then VERIFIED. Keep the rejected/verified balance close to 60/40.
    target = 25
    if len(selected) < target:
        need = target - len(selected)
        extras = []
        # First: more Gate 3 (typically most plentiful)
        remaining_g3 = [p for p in buckets["G3"] if id(p[0]) not in used_keys]
        for p in random.sample(remaining_g3, min(need, len(remaining_g3))):
            extras.append(("Gate3_extra", *p))
            used_keys.add(id(p[0]))
            if len(extras) == need:
                break
        # Then: extra VERIFIED if still short
        if len(extras) < need:
            remaining_v = [p for p in buckets["VERIFIED"] if id(p[0]) not in used_keys]
            for p in random.sample(remaining_v, min(need - len(extras), len(remaining_v))):
                extras.append(("VERIFIED_extra", *p))
                used_keys.add(id(p[0]))
        selected.extend(extras)
        print(f"Padded {len(extras)} extras to reach {len(selected)} total.")

    print(f"\n=== Selected {len(selected)} items ===")

    # Write rater sheet CSV with light cleanup of the evidence box for readability:
    #   - filter empty strings (artifact of graph building)
    #   - filter "valuation" meta-entity (not a real entity for rater purposes)
    #   - deduplicate numbers by their canonical numeric value (e.g., "2260" and
    #     "2260.00" collapse to "2260"); preserve the canonical form
    META_ENTITIES = {"valuation"}

    def clean_entities(entities):
        return sorted(e for e in entities if e and e not in META_ENTITIES)

    def canonical_number(n):
        try:
            f = float(n)
            if f.is_integer():
                return str(int(f))
            # strip trailing zeros / dots
            return f"{f:g}"
        except (ValueError, TypeError):
            return n

    def clean_numbers(numbers):
        seen = {}  # canonical -> original
        for n in numbers:
            if not n:
                continue
            c = canonical_number(n)
            if c not in seen:
                seen[c] = c  # use canonical form for display
        return sorted(seen.values(), key=lambda s: (float(s) if s.replace(".", "", 1).replace("-", "", 1).isdigit() else float("inf"), s))

    out_csv = Path("rater_sheet_template.csv")
    with out_csv.open("w", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["id", "claim_text", "allowed_entities", "allowed_numbers", "decision", "reason"])
        for i, (label, claim, inst) in enumerate(selected, 1):
            ents = "[" + ", ".join(clean_entities(inst["allowedEntities"])) + "]"
            nums = "[" + ", ".join(clean_numbers(inst["allowedNumbers"])) + "]"
            w.writerow([str(i), claim["text"], ents, nums, "", ""])
    print(f"Wrote: {out_csv}")

    # Write answer key
    out_key = Path("answer_key.csv")
    with out_key.open("w", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        w.writerow(["id", "verifier_decision", "_bucket", "_profileId", "_modelId"])
        for i, (label, claim, inst) in enumerate(selected, 1):
            decision = "YES" if claim["verifierPassed"] else "NO"
            w.writerow([str(i), decision, label, inst["profileId"], inst["modelId"]])
    print(f"Wrote: {out_key}")

    # Audit summary
    print("\n=== Composition audit ===")
    counts = defaultdict(int)
    for (label, _, _) in selected:
        counts[label] += 1
    for k in ["VERIFIED", "Gate1", "Gate2", "Gate3"]:
        print(f"  {k}: {counts[k]}")


if __name__ == "__main__":
    main()
