# Paper-to-artifact ledger

| Paper item | Primary artifact source | Derivation / audit path |
|---|---|---|
| Table 1, four-gate taxonomy | `schemas/`; `verifier/ClaimVerifier.java`; `verifier/ClaimTypeRules.java` | Rule inspection; empirical ranges come from grounded r=0/r=1 per-gate counts. |
| Figure 1, verification traces | `results/raw/rater_capture.smoke-r0.json`; paper caption | Pedagogical reconstructions based on observed claim text. Identifiers and structured declarations are simplified; these are not exact serialized log records. |
| Figure 2, system architecture | Versioned code release in `CODE_POINTER.md` | Conceptual rendering of the evidence-builder, narrator, verifier, repair, and filter flow. |
| Table 2, main results | `results/raw/explanation_eval_results.large-r0.json`; `results/raw/explanation_eval_results.large-r1.json` | `scripts/reconcile_results.py` → `results/derived/cell_metrics.csv`; `total_claims` means parsed-and-retained claims. |
| Figure 3, survival rates | Same r=0/r=1 logs | `scripts/reconcile_confidence_intervals.py`; captured output in `results/derived/confidence_intervals.txt`. |
| Table 3, paired repair effects | Same r=0/r=1 logs | `scripts/reconcile_confidence_intervals.py`; cluster bootstrap by matched instance, 10,000 iterations, seed 42. |
| Figure 4, gate breakdown | `results/raw/explanation_eval_results.large-r1.json` | Distinct `failuresByGate` values; Table 2/figure headline is authoritative at the claim unit. |
| Figure 5, judge diagnostic | `results/raw/matched_pair_scores.large-r1.json` | Authoritative later judge run: counterbalanced 150-pair slice and 300 calls. The embedded block in the r=1 result log is an earlier superseded run retained only for provenance. |
| Cost paragraph | `results/derived/cost_estimates.csv`; Table 2 outputs | The final author-recorded estimates and the 31×/1.86× Llama-baseline ratios are auditable. The underlying provider token-count export was not archived. |
| Verifier microbenchmark | `results/raw/verifier_microbench.txt`; `verifier/VerifierMicroBench.java` | Source and captured output are both local; the output reports observed after-run heap, not sampled peak heap. |
| Table 4, Gates 1–3 rater agreement | `protocol/rater-validation/rater{1,2,3}.csv`; `answer_key.csv` | `protocol/rater-validation/compute_kappa.py`; exact sample CSVs are authoritative. See the local rater-validation README for the extraction-input limitation. |
| Table 5, Gate-4 rater agreement | `protocol/rater-validation/gate4_rater{1,2,3}.csv`; `gate4_answer_key.csv`; `gate4_sample.csv` | `compute_kappa.py`; reported summary in `gate4_kappa_summary.md`. |
| Table 6, claim-type rules | `verifier/ClaimVerifier.java`; `verifier/ClaimType.java`; `verifier/ClaimTypeRules.java` (exact base-commit snapshots) | Direct rule transcription; `CAP_SWITCH` has the two required evidence types. |
| Table 7, Gate-4 message submodes | `results/raw/explanation_eval_results.large-r1.json` | `scripts/reconcile_results.py` → `results/derived/gate4_reconciliation.csv`. |
| Gate-4 type-routing smoke replay | `results/raw/explanation_eval_results.rater-audit-v2.json`; `rater_capture_gate4_audit_v2.json` | Restricted to the 27-instance re-instrumented replay: 138/139 failures had non-empty citations; not generalized to the full benchmark. |
| Prompt appendix | `prompts/NarratorPrompts.java`; `prompts/repair_prompt_template.txt`; `prompts/judge_prompt_template.txt` | Grounded and ungrounded builders plus exact repair and judge templates. Run-time substitutions are documented in `prompts/README.md`. |
| Pre-registration appendix | `protocol/eval_preregistration.md` | Original pre-run decision rules and non-claims. |

The large-run JSON preserves per-instance aggregate verifier reports, error
records, and rendered text, but not every original claim object or evidence
graph. The bundled scripts therefore reproduce the reported aggregate tables
and confidence intervals; they do not rerun `ClaimVerifier` end to end over all
benchmark instances. The evaluated lenient parser could skip malformed
individual records; pre-parse arrays were not archived, so that drop rate is
not recoverable. The rater capture files provide claim-level records only for
the documented smaller audits.

The package manifest supplies byte-level identity for every local row above.
`CODE_POINTER.md` binds code-facing rows to the versioned GitHub release. The
source-lineage qualification in `PROVENANCE.md` applies to all items.
