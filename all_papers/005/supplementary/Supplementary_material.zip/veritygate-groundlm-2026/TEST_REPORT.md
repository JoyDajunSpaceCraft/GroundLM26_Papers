# Verification report

Updated on 2026-09-08 (America/Los_Angeles) for corrected supplement version
1.0.1. Its version-specific Zenodo DOI is
`https://doi.org/10.5281/zenodo.22668710`.

## Clean GitHub-code build

The separated GitHub-ready source tree was tested without a project `.env` or
model credentials:

```bash
./gradlew test --offline --no-daemon
```

Result: **BUILD SUCCESSFUL** in 3m 14s; 34 actionable tasks, 34 executed.

## Numerical reconciliation

From the artifact root:

```bash
python3 scripts/reconcile_results.py
```

Result: **passed**. The generated `cell_metrics.csv` reproduces all r=0/r=1
survival and shipped-volume values, and `gate4_reconciliation.csv` reproduces
the distinct-claim and message counts used by Tables 2 and 7.

```bash
python3 scripts/reconcile_confidence_intervals.py
```

Result: **passed**. It reproduces and asserts the rounded absolute, paired
repair, cross-model, shipped-volume, and Sonnet r=2 confidence intervals stated
in the paper (10,000 instance-cluster bootstrap iterations, seed 42).

The GitHub-side launcher was also tested against this extracted supplement:

```bash
python3 scripts/eval/reconcile_veritygate_results.py \
  --artifact-root /path/to/veritygate-groundlm-2026
```

Result: **passed**, producing files byte-identical to the bundled derived
outputs.

## Supplementary package status

Content checks pass, including schema/data consistency, source-snapshot hashes,
both reconciliation scripts, both rater-statistic runs, and scans for
credentials, personal absolute paths, caches, and excluded files. The final
manifest covers all 60 content files; together with `MANIFEST.sha256`, the
archive contains 61 files under one top-level directory. The final ZIP passes
its integrity test, its external SHA-256 sidecar matches, and a clean extracted
copy passes the manifest and reproduction checks. The archive contains no
paper PDF or TeX source.

`verifier/Claim.java`, `ClaimSchema.java`, `ClaimVerifier.java`,
`ClaimType.java`, and `ClaimTypeRules.java` are byte-identical to the
paper-grade base-commit snapshots. `VerifierMicroBench.java` is byte-identical
to the final tagged release. Exact SHA-256 values are recorded in
`PROVENANCE.md`.

The evidence schema accepts all nine evidence types observed in the included
rater captures and also permits the valid unused `EARN_RATE` type. The claim
schema records the six-field prompt contract. The runtime parser requires the
three scalar fields and defaults absent or non-array citation fields to empty;
its lenient evaluation path may also skip malformed individual records. This
documented behavior means reported `totalClaims` counts parsed-and-retained
claims, and the unarchived pre-parse arrays prevent measuring partial drops.

## Rater-statistic reproduction

The shared rater script was run against both released CSV schemas:

```bash
python3 compute_kappa.py rater1.csv rater2.csv rater3.csv answer_key.csv
python3 compute_kappa.py gate4_rater1.csv gate4_rater2.csv \
  gate4_rater3.csv gate4_answer_key.csv
```

Result: **passed**. The Gates 1--3 run reproduces 74.0% mean pairwise
agreement and Fleiss' kappa 0.48. The Gate-4 run reproduces 88.0%
majority-of-three agreement with the verifier and Fleiss' kappa 0.19.

## Environment

- Paper-grade base commit: `c7e6392a791454d2d57b670fe83e352edd8c1928`
- Code release commit: `756291902724af4b99f78cffa599a10964cb41fe`
- Code release tag: `veritygate-groundlm-2026-v1.0.0`
- Code package: paper-grade base commit plus the documented camera-ready
  additions in `CODE_POINTER.md`
- Gradle wrapper: 9.3.1
- Java target/runtime recorded by the project: 21
- Reconciliation runtime: Python 3, standard library only
- Camera-ready PDF: 16 A4 pages; `aclpubcheck --paper_type long` reports
  **All Clear** on the corrected build
