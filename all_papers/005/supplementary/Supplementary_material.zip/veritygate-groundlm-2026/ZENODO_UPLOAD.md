# Zenodo version 1.0.1 upload metadata

Upload the checksum-locked `veritygate-groundlm-2026-supplementary.zip`, not
the complete camera-ready working directory.

## Recommended metadata

- **Title:** VerityGate GroundLM 2026 Supplementary Artifact
- **Resource type:** Dataset
- **Creator:** Sachin Gupta
- **Affiliation:** Independent Researcher
- **ORCID:** 0009-0009-7422-4967
- **Version:** 1.0.1
- **Previous version DOI:** 10.5281/zenodo.22641534
- **Version-specific DOI:** 10.5281/zenodo.22668710
- **Publication date:** 2026-09-08
- **License:** Apache License 2.0
- **Language:** English
- **Keywords:** faithfulness; grounded language models; structured evidence;
  claim verification; reproducibility; benchmark

## Description

Supplementary evidence for “VERITYGATE: A Four-Gate Schema-Level
Faithfulness Framework and Paired Benchmark for Grounded LLM Narrations over
Structured Evidence.” Includes paper-grade per-instance result logs,
deterministic reconciliation code and derived tables, complete prompts and
schemas, the pre-registration, rater-study materials, and verifier
microbenchmark output. The editable implementation is released separately at
the versioned GitHub release recorded in `CODE_POINTER.md`.

Version 1.0.1 completes the prompt and verifier-source inventory, adds
confidence-interval reconciliation, aligns the claim schema with the six-field
prompt contract, and corrects documentation of the Gates 1--3 rater mismatch.
The paper-grade result logs and reported numerical results are unchanged.

## Related identifiers

- GitHub release:
  `https://github.com/sachinkg12/yukti/releases/tag/veritygate-groundlm-2026-v1.0.0`
  as `isSupplementedBy` or the closest available software relation.
- Paper/OpenReview record: add the final paper URL as `isSupplementTo`.

The version-specific DOI above is recorded in `CITATION.cff`, the README, and
the paper. Do not substitute the all-versions/concept DOI when identifying the
archived bytes used for the reported results.
