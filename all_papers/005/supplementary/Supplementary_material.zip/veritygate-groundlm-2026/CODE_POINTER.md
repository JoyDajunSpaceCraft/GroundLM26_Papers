# Code release pointer

The editable VerityGate implementation is released separately from this
supplementary evidence package.

## Source lineage

- Repository: `https://github.com/sachinkg12/yukti`
- Paper-grade base commit: `c7e6392a791454d2d57b670fe83e352edd8c1928`
- Release tag: `veritygate-groundlm-2026-v1.0.0`
- Versioned release URL:
  `https://github.com/sachinkg12/yukti/releases/tag/veritygate-groundlm-2026-v1.0.0`
- Final release commit:
  `756291902724af4b99f78cffa599a10964cb41fe`

The paper-grade JSON files do not embed a Git hash. The base commit is the
committed evaluation snapshot associated with the runs, not a cryptographic
code-to-run binding. The release also contains documented, additive
camera-ready code for rater capture and the verifier microbenchmark; these
additions did not alter the primary four-gate verifier rules or regenerate the
paper-grade result files.

For local auditability, this supplementary package includes byte-identical
base-commit snapshots of `verifier/Claim.java`, `ClaimSchema.java`,
`ClaimVerifier.java`, `ClaimType.java`, and `ClaimTypeRules.java`. It also includes the tagged
`verifier/VerifierMicroBench.java` source corresponding to the captured
microbenchmark output. These focused snapshots support rule and measurement
inspection; they are not a substitute for the complete buildable code release.

The six-field supplementary `schemas/claim_v1.json` records the prompt
contract. Both parser paths require `claimId`, `claimType`, and `text`, but
default missing or non-array citation fields to empty lists. The evaluated
lenient path also skips malformed individual records. The v1.0.0 design-schema
copy omitted `text` from its JSON `required` list; the supplementary corrects
that documentation defect while separately stating the parser's looser
behavior.

The release URL identifies the annotated tag, and the full commit hash pins
the exact repository tree independently of the moving default branch.
