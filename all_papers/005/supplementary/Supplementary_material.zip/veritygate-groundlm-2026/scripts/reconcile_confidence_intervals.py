#!/usr/bin/env python3
"""Reproduce the paper's paired cluster-bootstrap confidence intervals.

The resampling unit is one matched (profileId, goal) instance. Survival is
recomputed as the ratio of summed passing claims to summed parsed-and-retained claims
inside every resample; shipped volume is the mean passing-claim count. The
script uses 10,000 percentile-bootstrap iterations and seed 42, as specified
in the released protocol. It depends only on the Python standard library.
"""

from __future__ import annotations

import json
import random
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "raw"
ITERS = 10_000
SEED = 42

MODELS = {
    "mini": "OPENAI_GPT4O_MINI",
    "Llama": "TOGETHER_LLAMA_70B",
    "Sonnet": "ANTHROPIC_CLAUDE_SONNET",
}


def load(name: str) -> list[dict]:
    with (RAW / name).open(encoding="utf-8") as handle:
        return json.load(handle)["perInstance"]


def select(rows: list[dict], model: str, variant: str = "GROUNDED") -> list[dict]:
    return [
        row for row in rows
        if row.get("modelId") == model and row.get("variant") == variant
    ]


def key(row: dict) -> tuple[str, str]:
    return row.get("profileId", ""), row.get("goal", "")


def passing(row: dict) -> int:
    if row.get("schemaFailed"):
        return 0
    report = row.get("verifierReport") or {}
    return max(0, int(report.get("totalClaims", 0)) - int(report.get("failingClaims", 0)))


def generated(row: dict) -> int:
    if row.get("schemaFailed"):
        return 0
    return int((row.get("verifierReport") or {}).get("totalClaims", 0))


def aggregate(rows: list[dict], metric: str) -> float:
    if metric == "survival":
        denominator = sum(generated(row) for row in rows)
        return sum(passing(row) for row in rows) / denominator if denominator else 0.0
    if metric == "shipped":
        return sum(passing(row) for row in rows) / len(rows) if rows else 0.0
    raise ValueError(metric)


def percentile(values: list[float]) -> tuple[float, float]:
    values.sort()
    return values[int(0.025 * ITERS)], values[int(0.975 * ITERS) - 1]


def absolute_ci(rows: list[dict], metric: str) -> tuple[float, float, float]:
    rng = random.Random(SEED)
    n = len(rows)
    samples = [
        aggregate([rows[rng.randrange(n)] for _ in range(n)], metric)
        for _ in range(ITERS)
    ]
    low, high = percentile(samples)
    return aggregate(rows, metric), low, high


def paired_ci(
    treatment: list[dict], control: list[dict], metric: str
) -> tuple[float, float, float, int]:
    treatment_by_key = {key(row): row for row in treatment}
    control_by_key = {key(row): row for row in control}
    common = sorted(treatment_by_key.keys() & control_by_key.keys())
    if not common:
        raise RuntimeError("no matched instances")
    pairs = [(treatment_by_key[item], control_by_key[item]) for item in common]
    point = aggregate([pair[0] for pair in pairs], metric) - aggregate(
        [pair[1] for pair in pairs], metric
    )
    rng = random.Random(SEED)
    n = len(pairs)
    samples: list[float] = []
    for _ in range(ITERS):
        selected = [pairs[rng.randrange(n)] for _ in range(n)]
        samples.append(
            aggregate([pair[0] for pair in selected], metric)
            - aggregate([pair[1] for pair in selected], metric)
        )
    low, high = percentile(samples)
    return point, low, high, n


def require_close(actual: float, expected: float, tolerance: float, label: str) -> None:
    if abs(actual - expected) > tolerance:
        raise AssertionError(f"{label}: got {actual}, expected {expected} ± {tolerance}")


def show(label: str, values: tuple[float, float, float, int] | tuple[float, float, float], percent: bool) -> None:
    point, low, high = values[:3]
    scale = 100.0 if percent else 1.0
    unit = " pts" if percent else ""
    suffix = f", n={values[3]}" if len(values) == 4 else ""
    print(f"{label}: {point * scale:+.2f}{unit} [{low * scale:+.2f}, {high * scale:+.2f}]{suffix}")


def main() -> None:
    r0 = load("explanation_eval_results.large-r0.json")
    r1 = load("explanation_eval_results.large-r1.json")
    r2 = load("explanation_eval_results.large-r2-sonnet.json")

    print("Absolute grounded survival CIs")
    for run_name, rows in (("r=0", r0), ("r=1", r1)):
        for short, model in MODELS.items():
            selected = select(rows, model)
            if len(selected) != 150:
                raise AssertionError(f"{run_name} {short}: expected 150 rows, got {len(selected)}")
            show(f"  {run_name} {short}", absolute_ci(selected, "survival"), True)

    expected_repair = {
        "mini": ((8.3, 4.3, 12.5), (0.14, -0.17, 0.47)),
        "Llama": ((1.2, -1.3, 3.6), (-0.71, -1.05, -0.37)),
        "Sonnet": ((2.2, 0.4, 4.1), (-0.47, -0.86, -0.08)),
    }
    print("\nPaired r=1 minus r=0 effects")
    for short, model in MODELS.items():
        survival = paired_ci(select(r1, model), select(r0, model), "survival")
        shipped = paired_ci(select(r1, model), select(r0, model), "shipped")
        show(f"  {short} survival", survival, True)
        show(f"  {short} shipped", shipped, False)
        for actual, expected in zip(survival[:3], expected_repair[short][0]):
            require_close(actual * 100.0, expected, 0.06, f"{short} survival")
        for actual, expected in zip(shipped[:3], expected_repair[short][1]):
            require_close(actual, expected, 0.006, f"{short} shipped")

    expected_cross = {
        "Sonnet-mini": (26.4, 22.6, 30.1),
        "Llama-mini": (13.3, 9.2, 17.4),
        "Sonnet-Llama": (13.0, 10.3, 15.7),
    }
    print("\nPaired cross-model survival effects at r=1")
    contrasts = (
        ("Sonnet-mini", "Sonnet", "mini"),
        ("Llama-mini", "Llama", "mini"),
        ("Sonnet-Llama", "Sonnet", "Llama"),
    )
    for label, treatment_name, control_name in contrasts:
        result = paired_ci(
            select(r1, MODELS[treatment_name]),
            select(r1, MODELS[control_name]),
            "survival",
        )
        show(f"  {label}", result, True)
        for actual, expected in zip(result[:3], expected_cross[label]):
            require_close(actual * 100.0, expected, 0.06, label)

    sonnet_r2 = paired_ci(
        select(r2, MODELS["Sonnet"]), select(r1, MODELS["Sonnet"]), "survival"
    )
    print("\nPaired Sonnet r=2 minus r=1 survival effect")
    show("  Sonnet", sonnet_r2, True)
    for actual, expected in zip(sonnet_r2[:3], (0.77, -1.22, 2.81)):
        require_close(actual * 100.0, expected, 0.06, "Sonnet r=2-r=1")

    print("\nConfidence-interval reconciliation passed.")


if __name__ == "__main__":
    main()
