# Camera-ready supplementary material

Code and constructed data behind *Grounding or Lexical Overlap? A Matched-Pair Study of
Internals-Based Faithfulness Probes* (GroundLM 2026 @ EMNLP).

  MANIFEST.md   every table, figure and quoted number -> the script that produces it
  runs/*.json   every result JSON, so each reported number can be checked without a GPU
  scripts/      analysis pipeline; scripts/cr_final_tables.py produces Tables 1, 4 and 6
  src/groundlm/ the library (construction, probing, confidence purge, Procrustes transfer)
  data/         the constructed CtrlPairs and RAGTruth subsets
  paper/figs/   the figures as generated

Table 2 (no-context / shuffled ablation) comes from scripts/analyze_nocontext.py and
Table 5 (estimator x training domain) from scripts/cr_estimator_domain_control.py; both
are listed in MANIFEST.md with their inputs and outputs.

Not here: runs/*/features.npz, the 2.4 GB of cached residual-stream states the analysis
consumes. `bash reproduce.sh extract` regenerates them on one A100-40G; `bash reproduce.sh`
then recomputes every reported number on CPU. The four 21 KB parametric_belief.npz caches
ARE included.

One file is deliberately not regenerated: runs/transfer_v2.json keeps its `random` entries
under the old max(AUC, 1-AUC) convention (support 0.5439, factuality 0.5994), because those
are the producer of the appendix's statement that the flip inflates a true-chance direction
to ~0.54-0.59. See the note at the end of MANIFEST.md.

Live repository: https://github.com/Beiciccc/GroundLM
