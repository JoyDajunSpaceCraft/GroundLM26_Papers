# Indian SMS Annotation — Fraud vs Marketing vs Legitimate

Thank you for helping with human validation of an Indian SMS classifier.
This work supports a research paper on whether automated systems can
safely filter Indian financial-messaging traffic.

## What you will do

Read each SMS and assign one of four labels: `fraud`, `marketing`,
`legitimate_institution`, or `unclear`. The CSV has 276 messages stratified
across Hindi Devanagari, Hinglish, and English-India.

**Estimated time:** ~30 seconds per message on average (most rows are
clear-cut for a native Indian SMS reader), with a handful of edge cases
that may take 1–2 minutes each. Total: **~2 hours** across one or two
sessions. Plus ~15 minutes to read this instructions file once at the start.

## The four labels

Each row gets exactly one label. Pick the one that best describes the
message's intent.

### `fraud`

The sender is **trying to deceive the recipient** for financial gain,
identity theft, or unauthorized access. Common patterns:

- Fake bank, government, RBI, telecom, or police impersonation
- Asks for OTP, password, PIN, full account number, Aadhaar, PAN, or KYC details
- Promises a prize, lottery, refund, or unclaimed money that requires action
- Demands urgent payment or threatens account suspension
- Uses a suspicious short URL (bit.ly, tinyurl, rebrand.ly) or a domain that
  is *almost* a real institution name
- Asks the recipient to call an unfamiliar number to "verify" identity
- Fake delivery, customs duty, or "your package is held" messages

### `marketing`

The sender is a **real, identifiable company** doing legitimate (if
aggressive) commercial promotion. Common patterns:

- Discount codes, sale announcements ("50% off on Myntra, use code SAVE50")
- Subscription pitches, app install prompts
- Product or service ads from a recognizable brand (Crocs, Aircel, Meru Cabs)
- Newsletter blasts
- These messages may be annoying or unwanted, but they are NOT fraud.

Use this label even if the message looks spammy — the question is whether
it's deceptive, not whether it's wanted.

### `legitimate_institution`

The sender is a **real bank, payment system, telecom, or government body**
sending a transactional, authentication, or service notification. Common
patterns:

- "Rs 500 credited to your account ending in 1234 via UPI from john@okaxis"
- "Your OTP for HDFC NetBanking is 123456. Valid for 5 minutes."
- "Your EMI of Rs 5000 is due on 25th."
- "Aadhaar e-KYC update successful. Reference: ABC123."
- Account balance confirmations, payment receipts, statement summaries
- These are the messages a real Indian bank or fintech actually sends.

### `unclear`

You cannot confidently determine intent from the text alone. Use this
label when:

- The message is too short or ambiguous (e.g., "ok thanks", a phone number with no context)
- Written in a language you cannot fully read
- Could plausibly be `fraud` or `legitimate_institution` depending on context
  the message doesn't provide (e.g., a transaction notification from an
  unfamiliar institution name)
- The text contains personal conversation that isn't institutional at all

When in doubt, prefer `unclear` over guessing.

## Calibration examples (read these before starting)

These 10 worked examples are NOT from your annotation set — they are
illustrative exemplars covering the four labels and the common edge
cases. Read them first so you have a shared mental model with the
other annotators.

---

### Example 1 — `legitimate_institution` (English-India)

> *"Rs 2,500 debited from A/c XX4521 on 12-May via UPI to mohit@okaxis. Avl Bal: Rs 18,742. -HDFC Bank"*

**Why:** Real bank transactional notification. Mentions a specific
institution (HDFC), a real UPI handle format (`@okaxis`), a balance
update, and an account-suffix pattern. This is exactly what an Indian
customer receives after a UPI transfer.

---

### Example 2 — `fraud` (English-India)

> *"URGENT! Your SBI account will be suspended in 24 hours due to KYC failure. Update now: http://sbi-secure.in/verify"*

**Why:** Impersonates SBI, manufactures urgency, asks recipient to
click a suspicious URL (the real SBI domain is `onlinesbi.sbi`, not
`sbi-secure.in`). Classic "kindly update KYC" fraud template.

---

### Example 3 — `marketing` (English-India)

> *"Last day! 60% OFF on Myntra fashion + extra Rs 500 off on prepaid orders. Code: MEGA60. Shop: myntra.com/sale"*

**Why:** Real recognizable brand (Myntra), real domain (`myntra.com`),
aggressive but truthful promotional pitch. Annoying — not deceptive.
**Marketing, not fraud.**

---

### Example 4 — `fraud` (Hinglish)

> *"Congratulations! Aap Kaun Banega Crorepati ke lucky winner hain. Apna bank account number & IFSC code [PHONE] par bhejein."*

**Why:** Fake lottery + asks for sensitive financial information. KBC
fraud is one of the most common Indian scam templates. Even though it
sounds celebratory, it's fraud.

---

### Example 5 — `legitimate_institution` (English-India)

> *"123456 is your OTP for HDFC NetBanking. Valid for 10 mins. Do not share with anyone, including HDFC staff."*

**Why:** Real OTP message from a real bank. The "do not share"
disclaimer is itself a marker of a legitimate institution
(fraudsters wouldn't usually warn you against fraud). 6-digit OTP,
10-minute validity, named institution.

---

### Example 6 — `marketing` (Devanagari Hindi)

> *"वोडाफोन सुपर ऑफर: सिर्फ ₹199 में 1.5GB/day data + Unlimited Calls 28 दिनों के लिए। Recharge करें: vi.in"*

**Why:** Real telecom (Vodafone/Vi), real product pitch, real domain.
Sale-y but not deceptive. Use this label even when the message feels
spammy — the test is "is it trying to deceive me," not "is it wanted."

---

### Example 7 — `fraud` (Devanagari Hindi)

> *"आपका Aadhaar आज ब्लॉक हो जाएगा! तुरंत verify करें: bit.ly/aadhaar-fix या आपका बैंक खाता बंद हो जाएगा।"*

**Why:** Aadhaar impersonation, urgency + threat + suspicious short
URL. Aadhaar is never blocked via SMS, and UIDAI never asks for
verification via bit.ly links.

---

### Example 8 — `legitimate_institution` (Hinglish)

> *"Aapka Airtel postpaid bill Rs 849 generated. Due date: 28-May. Pay at airtel.in/pay ya My Airtel app pe."*

**Why:** Real telecom (Airtel), real bill notification, real domain
(`airtel.in`), reasonable amount. Tonally similar to fraud (urgency
around payment) but it's a real transactional message from a real
institution about a real ongoing service. **Legitimate, not fraud.**

---

### Example 9 — `unclear` (mixed / short)

> *"call me back urgent"*

**Why:** Too short. No institutional context. Could be a personal
message, could be a vishing setup, could be anything. Pick `unclear`
with confidence 1 or 2. **Don't guess.**

---

### Example 10 — `unclear` (Devanagari Hindi)

> *"नमस्ते, मेरी नई नंबर सेव कर लेना। - राहुल"*

**Why:** Personal message ("Hi, save my new number. - Rahul"). No
institutional content, not commercial, not fraud. Could conceivably be
a vishing precursor but there is nothing in the text itself to call it
that. Label `unclear` because the task is about institutional and
commercial SMS — this row falls outside that scope.

---

## Common annotator instincts that mislead

These are the wrong-direction reflexes most annotators have on the
first 20–30 rows. Knowing them helps you calibrate faster.

| Your first instinct | The right answer | Why |
|---|---|---|
| "It's aggressive and uses urgency, so it must be fraud" | Often **marketing** | Real brands (Myntra, Flipkart) and real telecoms (Vi, Airtel) use urgency too. Test: is it deceiving, or just selling? |
| "It mentions a bank, so it must be legitimate" | Often **fraud** | Fraud impersonates banks. Test: is the domain real (`onlinesbi.sbi`) or fake (`sbi-secure.in`, `bit.ly/sbi-fix`)? |
| "It mentions money or payment, so it's institutional" | Sometimes **fraud**, sometimes **marketing** | Money-mentions cut across all three non-`unclear` labels. The label depends on intent, not lexical content. |
| "It's short and weird, so it must be fraud" | Often **unclear** | Short/weird ≠ fraud. If there's no clear institutional signal, label `unclear`. |
| "I don't recognize the brand, so it must be fraud" | Sometimes **marketing** | Indian SMS has a long tail of regional brands (Akkriti Kurta, Meru Cabs, Thyrocare). If the message reads like a sales pitch from a real-sounding company with a real-looking domain, label `marketing`. |
| "It's in a language I don't fully read" | **unclear** with low confidence | Don't guess on language you can't fully parse. |
| "It asks for OTP / PIN / Aadhaar number" | Almost always **fraud** | Real institutions never ask you to send OTPs or full Aadhaar numbers via SMS reply. |

## How to fill the CSV

You will receive `annotation_sample_v2.csv`. For each row, fill in:

| Column | What to enter |
|---|---|
| `human_label` | one of: `fraud`, `marketing`, `legitimate_institution`, `unclear` (exactly this spelling) |
| `confidence` | 1 (very unsure) to 5 (completely sure) |
| `notes` | (optional) any observation about the message, edge case, or doubt |

Leave the other columns (`annotator_sample_id`, `text`, `language`,
`template_bucket`) UNTOUCHED — they identify the row.

## Important rules

1. **Read the full message** before deciding.
2. **Use your judgment as a native Indian SMS reader.** Cultural context,
   recognizable Indian institution names (HDFC, ICICI, Paytm, PhonePe,
   GPay, Airtel, Jio, BSNL, SBI, etc.), and Indian English idioms matter.
3. **Do NOT discuss messages with other annotators during annotation.**
   Independent labels are necessary for inter-annotator agreement to be
   meaningful.
4. **Mark `unclear` over guessing.** If genuinely uncertain, `unclear` +
   confidence=1 or 2 is more useful than a confident wrong guess.
5. **Brand recognition matters.** If the message mentions a real
   recognizable Indian institution (a bank, payment app, retail brand,
   telecom) and the request matches what that institution actually does,
   label `marketing` (commercial promo) or `legitimate_institution`
   (transactional or auth).
6. **URLs and short links are a strong fraud signal** when combined with
   urgency or identity verification asks. Plain links in marketing context
   are NOT alone evidence of fraud.
7. **Aggressive promotion is not fraud.** "Limited time, only today, hurry!"
   from a real Crocs/Myntra/Flipkart is `marketing`, not `fraud`.

## After finishing

1. Save your filled CSV with your name appended, e.g.,
   `annotation_sample_v2_annotator_A.csv`.
2. Send it back to the project lead.
3. Inter-annotator agreement (Fleiss' kappa or Krippendorff's alpha) and
   agreement with the dual-LLM-judge labels will be computed once 2 or 3
   annotators return their labels.

## Worked example: filling one row

CSV row before annotation:

```
H0042,"Aapka SBI account frozen ho gaya hai. Kindly update KYC at bit.ly/sbi-fix",Hinglish,Aadhaar/KYC,,,
```

After annotation:

```
H0042,"Aapka SBI account frozen...",Hinglish,Aadhaar/KYC,fraud,5,classic SBI impersonation + suspicious short URL
```

## Questions

If a message is ambiguous and you really cannot decide between two labels,
note both in the `notes` column and pick the one you'd lean toward, with
a confidence of 2.

Email the project lead with questions before you start, not after.
