# ScamShield GroundLM 2026 camera-ready supplement

This compact supplement contains analyses added after the EMNLP Industry
submission and reported in the GroundLM camera-ready paper.

## Contents

- `results/`: aggregate prompt-ladder, consensus, negative-label,
  human-annotation, label-policy, structural-cluster, and calibration results;
- `predictions/`: text-free per-example API outputs for the prompt ladder
  (`idx`, language, source, template, gold, prediction, sanitized response
  status) plus the aligned eight-system matrix used to regenerate label
  sensitivity;
- `scripts/`: exact prompt definitions and compact-package analysis code; and
- `annotation/`: the annotation instructions and aggregate diagnostics.

## Privacy and redistribution

This upload archive intentionally contains no raw SMS message text. It omits
the source-message-bearing annotation CSVs, negative-audit CSV, calibration
probability CSV, and example-bearing structural-cluster JSON. This prevents
redistribution of IIITD-controlled text and avoids duplicating source data.

Verbatim provider responses are not distributed because a small number echoed
input fragments. The upload uses an explicit `response_status` column
(`safe`, `scam`, or `unparseable`) and removes structural-cluster examples;
neither verbatim field is needed to regenerate the packaged aggregate analyses.

The frozen EMNLP-era artifact, checkpoints, hash-only IIITD rows, predictions,
and environment files are archived at
<https://doi.org/10.5281/zenodo.20480151>. The repository's IIITD workflow
uses hashes and requires the user to obtain the official dataset separately.
The current archive does not contain the official IIITD ZIP or an automated
reconstruction script, despite stale statements in its inherited metadata.

## Runnable compact analyses

From the extracted supplement root, these commands require only Python 3:

```sh
python scripts/llm_fewshot_multilingual.py --analyze
python scripts/rebuttal_fewshot_precision_f1.py
python scripts/rebuttal_consensus_filter.py
python scripts/regenerate_label_policy_sensitivity.py
python scripts/verify_camera_ready_claims.py
```

The verifier recomputes prompt metrics from the parsed per-message decisions
and checks the remaining packaged aggregates. It is an internal-consistency
check, not a substitute for independent construct validation.

## Reproduction boundaries

The per-example prompt predictions are frozen parsed decisions; reproducing the
API calls requires provider credentials plus the controlled test text and may
differ as hosted models change. Scripts requiring raw benchmark/annotation
text (negative audit, structural clustering, annotation diagnostics,
calibration, and human-majority reconstruction) are intentionally omitted from
this upload because their inputs cannot be redistributed. Their aggregate
outputs are included. Full checkpoint re-inference for the 169 hash-only IIITD
rows likewise requires separately obtaining and locally rejoining that source.

The frozen Zenodo archive contains checkpoints and historical source snapshots,
but its training workflow is incomplete (required modules and controlled-source
reconstruction are absent). It must not be described as turnkey training
reproduction.

All reported numerical claims, including the regenerated Table 9 and the
policy-negative provenance split, were checked against the complete local
evidence bundle before this archive was created.
