# R3 rebuttal: template-cluster sensitivity (memorization check)

Test rows: 1393. Structural clusters (digits/accts/amounts/URLs masked): 1219 (12.5% reduction).

## Bank/UPI FPR: full set vs one-row-per-cluster (dedup)

| model | Bank FPR (all) | Bank FPR (dedup) | UPI FPR (all) | UPI FPR (dedup) |
|---|---|---|---|---|
| xlmr | 0.0% (n=163) | 0.0% (n=104) | 0.0% (n=146) | 0.0% (n=124) |
| gpt_4o_mini | 75.5% (n=163) | 61.5% (n=104) | 59.6% (n=146) | 52.4% (n=124) |
| gpt_4o | 31.3% (n=163) | 46.2% (n=104) | 30.8% (n=146) | 21.8% (n=124) |
| gemini_2_5_flash | 24.5% (n=163) | 27.9% (n=104) | 27.4% (n=146) | 14.5% (n=124) |
| claude_haiku_4_5_20251001 | 50.3% (n=163) | 25.0% (n=104) | 39.7% (n=146) | 29.0% (n=124) |
