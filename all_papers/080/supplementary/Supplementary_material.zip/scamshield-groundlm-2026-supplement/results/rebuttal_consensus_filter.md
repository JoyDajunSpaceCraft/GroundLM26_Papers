# R3 rebuttal: dual-judge consensus AS a deployed filter (P2 strong prompt)

n = 1393 test rows. Consensus over GPT-4o + Gemini, P2 few-shot prompt (best-case adapted API path, not zero-shot drop-in).

| system | Bank FPR | UPI FPR | Global FPR | Precision | Recall | F1 | MCC |
|---|---|---|---|---|---|---|---|
| xlmr_local | 0.0% | 0.0% | 0.4% | 0.951 | 98.0% | 0.965 | 0.963 |
| consensus_AND_p2 | 0.0% | 0.0% | 0.6% | 0.904 | 75.8% | 0.824 | 0.816 |
| consensus_OR_p2 | 0.0% | 3.4% | 3.6% | 0.676 | 97.0% | 0.797 | 0.793 |
| gpt_4o_p2_alone | 0.0% | 0.0% | 1.5% | 0.832 | 95.0% | 0.887 | 0.880 |
| gemini_p2_alone | 0.0% | 3.4% | 2.7% | 0.688 | 77.8% | 0.730 | 0.709 |
