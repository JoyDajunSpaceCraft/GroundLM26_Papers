# R3 rebuttal: human-annotation diagnostics

n = 276 full-overlap rows.

## Per-annotator label distribution (all 276 rows)

| label | A | B | C |
|---|---|---|---|
| fraud | 2 | 40 | 46 |
| marketing | 62 | 38 | 39 |
| legitimate_institution | 73 | 72 | 68 |
| unclear | 139 | 126 | 123 |

## Kappa computation

Fleiss kappa=0.821 and Krippendorff alpha=0.821 were computed in compute_iaa.py over ALL 276 full-overlap rows across all 4 categories (fraud, marketing, legitimate_institution, unclear). 'unclear' is a full category, NOT dropped. Only the 87.9% human-vs-LLM agreement is restricted to the 149 rows with a resolved (non-unclear, non-tie) human majority.

## Human vs LLM-consensus agreement

- 4-way majority -> binary: 131 agree / 18 disagree (87.9% on resolved), 127 unclear/tie.
- binary fraud-vs-non-fraud majority (unclear=non-fraud): 252 agree / 24 disagree (91.3%).

## Per-template unclear rate + agreement (the key point)

| template | n | annotator unclear rate | maj unclear/tie | resolved | human-LLM agree % |
|---|---|---|---|---|---|
| Aadhaar/KYC | 1 | 0.0% | 0 | 1 | 100.0% |
| Bank/account | 35 | 0.0% | 0 | 35 | 97.1% |
| EMI/loan | 8 | 12.5% | 1 | 7 | 100.0% |
| Marketing/promo | 11 | 0.0% | 0 | 11 | 90.9% |
| Other | 191 | 64.6% | 121 | 70 | 80.0% |
| Reward/lottery | 9 | 40.7% | 4 | 5 | 80.0% |
| UPI/Payment | 9 | 0.0% | 0 | 9 | 100.0% |
| URL/click | 12 | 11.1% | 1 | 11 | 90.9% |
