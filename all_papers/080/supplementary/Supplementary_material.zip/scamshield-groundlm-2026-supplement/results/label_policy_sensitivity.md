# Label-policy sensitivity (regenerated)

All policies use the same 1,393 rows and frozen predictions. B1-B3 reclassify current policy-positive rows from one source as safe; they do not remove a source and do not retrain a model.

| Policy | n positive | Ours | mini | 4o | Claude | Gemini | Llama | Qwen | EN-only |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A_current | 99 | 0.965 | 0.310 | 0.512 | 0.441 | 0.558 | 0.396 | 0.285 | 0.401 |
| B1_cloveai_positive_to_safe | 45 | 0.585 | 0.154 | 0.270 | 0.226 | 0.299 | 0.202 | 0.141 | 0.198 |
| B2_iiitd_positive_to_safe | 91 | 0.933 | 0.289 | 0.480 | 0.413 | 0.524 | 0.370 | 0.265 | 0.374 |
| B3_vinit9638_positive_to_safe | 64 | 0.759 | 0.212 | 0.364 | 0.313 | 0.400 | 0.275 | 0.194 | 0.288 |

## Untouched source-negative FPR

| Model | false positives / 1,222 | FPR |
|---|---:|---:|
| Ours | 1 / 1222 | 0.08% |
| mini | 381 / 1222 | 31.18% |
| 4o | 155 / 1222 | 12.68% |
| Claude | 195 / 1222 | 15.96% |
| Gemini | 133 / 1222 | 10.88% |
| Llama | 247 / 1222 | 20.21% |
| Qwen | 430 / 1222 | 35.19% |
| EN-only | 228 / 1222 | 18.66% |
