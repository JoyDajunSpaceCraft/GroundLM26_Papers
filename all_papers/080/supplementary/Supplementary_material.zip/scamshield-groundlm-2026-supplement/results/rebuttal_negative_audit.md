# R3 rebuttal: policy-negative audit (dual judge)

n = 1294 policy-negative rows audited. Consensus-fraud rate: 3.25%.

Overall: {'safe': 1111, 'mixed': 141, 'fraud': 42}

## Provenance split

- untouched_source_negative: {'n': 1222, 'safe': 1065, 'mixed': 117, 'fraud': 40}
- source_positive_converted_to_safe: {'n': 72, 'safe': 46, 'mixed': 24, 'fraud': 2}

| template | n | consensus fraud | consensus safe | mixed/unclear |
|---|---|---|---|---|
| Aadhaar/KYC | 1 | 0 | 0 | 1 |
| Bank/account | 163 | 1 | 134 | 28 |
| EMI/loan | 8 | 0 | 5 | 3 |
| Marketing/promo | 6 | 1 | 5 | 0 |
| OTP | 1 | 0 | 1 | 0 |
| Other | 946 | 8 | 890 | 48 |
| Reward/lottery | 2 | 0 | 2 | 0 |
| UPI/Payment | 146 | 32 | 54 | 60 |
| URL/click | 21 | 0 | 20 | 1 |
