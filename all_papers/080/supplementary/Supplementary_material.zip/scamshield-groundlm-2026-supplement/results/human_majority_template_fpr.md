# Human-majority Bank/UPI false-positive check

Each annotator's fraud label maps to 1; marketing, legitimate_institution, and unclear map to 0. The three binary votes are majority-aggregated. FPR denominators contain majority-safe rows only; this is not a unanimous subset.

| Template | Human rows | Majority-safe n | XLM-R FP/FPR | GPT-4o-mini FP/FPR |
|---|---:|---:|---:|---:|
| Bank/account | 35 | 33 | 1/33 (3.0%) | 21/33 (63.6%) |
| UPI/Payment | 9 | 8 | 0/8 (0.0%) | 7/8 (87.5%) |
