"""Rebuttal analysis (EMNLP R3): dual-judge consensus AS a deployed filter.

R3's sharpest point: "If GPT-4o + Gemini consensus is reliable enough to produce
gold labels, why not deploy that consensus as the classifier?" This evaluates
exactly that -- the GPT-4o + Gemini consensus run as a classification filter on
the full 1393-row test set -- using the strong P2 prompt (the same
deployment-grade few-shot prompt from the prompt-sensitivity study), so it is the
best-case adapted API path, not the zero-shot drop-in.

Two consensus rules:
  AND (both say scam -> scam): conservative, minimizes false positives.
  OR  (either says scam -> scam): aggressive, maximizes recall.

Computed from existing per-sample predictions -- NO new API calls.
Reports global/Bank/UPI FPR, recall, precision, F1, and MCC.  It makes no
traffic, price, jurisdiction, or deployment-cost assumptions.

Usage:
    python -m evaluation.rebuttal_consensus_filter
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
PREDICTIONS = ROOT / "predictions"
INPUTS = PREDICTIONS if PREDICTIONS.exists() else RESULTS
OUT_MD = RESULTS / "rebuttal_consensus_filter.md"
OUT_JSON = RESULTS / "rebuttal_consensus_filter.json"

JUDGES = {"gpt_4o": "gpt_4o", "gemini": "gemini_2_5_flash"}
# Upload-safe aligned prediction matrix used for the XLM-R reference.  The
# file contains indices, sources, templates, gold labels, and predictions but
# no message text.
BASE = (PREDICTIONS / "label_policy_base_predictions.csv"
        if (PREDICTIONS / "label_policy_base_predictions.csv").exists()
        else RESULTS / "label_policy_base_predictions.csv")


def load_preds(model_file: str, cond: str) -> dict[int, dict]:
    path = INPUTS / f"llm_fewshot_{model_file}_{cond}.csv"
    out = {}
    with open(path, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out[int(r["idx"])] = {
                "gold": int(r["gold"]), "pred": int(r["pred"]), "template": r["template"],
            }
    return out


def score(pairs: list[tuple[int, int, str]]) -> dict:
    """pairs: (gold, pred, template); pred in {0,1}. FPR on legit by template."""
    tp = fp = tn = fn = 0
    bank_fp = bank_n = upi_fp = upi_n = 0
    for gold, pred, tmpl in pairs:
        if gold == 1:
            tp += pred == 1
            fn += pred == 0
        else:
            if tmpl == "Bank/account":
                bank_n += 1; bank_fp += pred == 1
            elif tmpl == "UPI/Payment":
                upi_n += 1; upi_fp += pred == 1
            fp += pred == 1
            tn += pred == 0
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / denom if denom else 0.0
    return {
        "precision": round(prec, 4), "recall": round(rec, 4), "f1": round(f1, 4),
        "mcc": round(mcc, 4),
        "global_fpr": round(fp / (fp + tn), 4) if (fp + tn) else None,
        "bank_fpr": round(bank_fp / bank_n, 4) if bank_n else None, "bank_n": bank_n,
        "upi_fpr": round(upi_fp / upi_n, 4) if upi_n else None, "upi_n": upi_n,
    }


def main() -> int:
    cond = "p2"  # strong deployment-grade prompt
    g = load_preds(JUDGES["gpt_4o"], cond)
    m = load_preds(JUDGES["gemini"], cond)
    idxs = sorted(set(g) & set(m))

    # XLM-R local reference
    xlmr = {}
    with open(BASE, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            xlmr[int(r["idx"])] = (
                int(r["policy_gold"]), int(r["xlmr_cleaned"]), r["template"]
            )

    results = {}

    def collect(rule):
        pairs = []
        for i in idxs:
            gp, mp = g[i]["pred"], m[i]["pred"]
            if gp == -1 or mp == -1:
                continue  # unparseable from either judge
            pred = (1 if (gp == 1 and mp == 1) else 0) if rule == "AND" \
                else (1 if (gp == 1 or mp == 1) else 0)
            pairs.append((g[i]["gold"], pred, g[i]["template"]))
        return pairs

    results["consensus_AND_p2"] = score(collect("AND"))
    results["consensus_OR_p2"] = score(collect("OR"))
    results["gpt_4o_p2_alone"] = score([(g[i]["gold"], g[i]["pred"], g[i]["template"])
                                        for i in idxs if g[i]["pred"] != -1])
    results["gemini_p2_alone"] = score([(m[i]["gold"], m[i]["pred"], m[i]["template"])
                                        for i in idxs if m[i]["pred"] != -1])
    results["xlmr_local"] = score([xlmr[i] for i in idxs])

    out = {"prompt_condition": cond, "n": len(idxs), "results": results}
    OUT_JSON.write_text(json.dumps(out, indent=2))

    L = ["# R3 rebuttal: dual-judge consensus AS a deployed filter (P2 strong prompt)\n"]
    L.append(f"n = {len(idxs)} test rows. Consensus over GPT-4o + Gemini, P2 few-shot "
             "prompt (best-case adapted API path, not zero-shot drop-in).\n")
    L.append("| system | Bank FPR | UPI FPR | Global FPR | Precision | Recall | F1 | MCC |")
    L.append("|---|---|---|---|---|---|---|---|")
    order = ["xlmr_local", "consensus_AND_p2", "consensus_OR_p2", "gpt_4o_p2_alone", "gemini_p2_alone"]
    for k in order:
        r = results[k]
        def pc(x): return f"{x:.1%}" if x is not None else "-"
        L.append(f"| {k} | {pc(r['bank_fpr'])} | {pc(r['upi_fpr'])} | {pc(r['global_fpr'])} | "
                 f"{r['precision']:.3f} | {pc(r['recall'])} | {r['f1']:.3f} | {r['mcc']:.3f} |")
    OUT_MD.write_text("\n".join(L) + "\n")
    print("\n".join(L))
    print(f"\nWrote {OUT_MD} and {OUT_JSON}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
