"""Rebuttal analysis (EMNLP R2/R3): full few-shot prompt-sensitivity table.

Extends the earlier few-shot FPR/recall table with precision, F1, and MCC per
(model, condition), computed from the saved per-sample CSVs. Marked EXPLORATORY:
exemplars are hand-written, designed knowing the failure mode, so this is a
prompt-sensitivity check, not a clean held-out comparison.

pred column: 1=scam, 0=safe, -1=unparseable (excluded from all metrics).

No API calls. Reads ``predictions/llm_fewshot_<model>_<condition>.csv`` in
the compact supplement, with ``results/`` as the full-workspace fallback.

Usage:
    python -m evaluation.rebuttal_fewshot_precision_f1
"""

from __future__ import annotations

import csv
import glob
import json
import math
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
PREDICTIONS = ROOT / "predictions"
INPUTS = PREDICTIONS if PREDICTIONS.exists() else RESULTS
OUT_MD = RESULTS / "rebuttal_fewshot_full_table.md"
OUT_JSON = RESULTS / "rebuttal_fewshot_full_table.json"

COND_ORDER = ["zeroshot", "p1", "oneshot", "p2", "p3"]


def load_csv(path: Path) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def metrics(rows: list[dict]) -> dict:
    tp = fp = tn = fn = unparse = 0
    bank_fp = bank_n = upi_fp = upi_n = 0
    for r in rows:
        gold = int(r["gold"])
        pred = int(r["pred"])
        tmpl = r["template"]
        if pred == -1:
            unparse += 1
            continue
        if gold == 1:
            if pred == 1:
                tp += 1
            else:
                fn += 1
        else:  # gold == 0 (legit)
            if tmpl == "Bank/account":
                bank_n += 1
                bank_fp += pred == 1
            elif tmpl == "UPI/Payment":
                upi_n += 1
                upi_fp += pred == 1
            if pred == 1:
                fp += 1
            else:
                tn += 1
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = ((tp * tn - fp * fn) / denom) if denom else 0.0
    global_fpr = fp / (fp + tn) if (fp + tn) else 0.0
    return {
        "n": len(rows), "unparseable": unparse,
        "precision": prec, "recall": rec,
        "f1": f1, "mcc": mcc,
        "global_fpr": global_fpr,
        "bank_fpr": bank_fp / bank_n if bank_n else None, "bank_n": bank_n,
        "upi_fpr": upi_fp / upi_n if upi_n else None, "upi_n": upi_n,
    }


def main() -> int:
    by_model: dict[str, dict[str, dict]] = defaultdict(dict)
    for path in glob.glob(str(INPUTS / "llm_fewshot_*_*.csv")):
        name = Path(path).stem[len("llm_fewshot_"):]
        cond = next((c for c in COND_ORDER if name.endswith("_" + c)), None)
        if cond is None:
            continue
        model = name[: -(len(cond) + 1)]
        by_model[model][cond] = metrics(load_csv(Path(path)))

    OUT_JSON.write_text(json.dumps(by_model, indent=2))

    L = ["# Few-shot prompt-sensitivity — full table (EXPLORATORY)\n"]
    L.append("Exemplars are hand-written, designed knowing the failure mode. This is a "
             "prompt-sensitivity check, not a clean held-out comparison. "
             "pred=-1 (unparseable) excluded.\n")
    for model in sorted(by_model):
        L.append(f"## {model}\n")
        L.append("| cond | Bank FPR | UPI FPR | Global FPR | Precision | Recall | F1 | MCC | unparse |")
        L.append("|---|---|---|---|---|---|---|---|---|")
        for cond in COND_ORDER:
            m = by_model[model].get(cond)
            if not m:
                continue
            bf = f"{m['bank_fpr']:.1%}" if m["bank_fpr"] is not None else "-"
            uf = f"{m['upi_fpr']:.1%}" if m["upi_fpr"] is not None else "-"
            L.append(f"| {cond} | {bf} | {uf} | {m['global_fpr']:.1%} | "
                     f"{m['precision']:.3f} | {m['recall']:.1%} | {m['f1']:.3f} | "
                     f"{m['mcc']:.3f} | {m['unparseable']} |")
        L.append("")
    OUT_MD.write_text("\n".join(L) + "\n")
    print("\n".join(L))
    print(f"Wrote {OUT_MD} and {OUT_JSON}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
