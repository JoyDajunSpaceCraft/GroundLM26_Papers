"""Remove source-message echoes from a staged compact supplement.

Usage:
    python sanitize_compact_supplement.py /path/to/scamshield-groundlm-2026-supplement

The full local evidence bundle retains provider responses and cluster examples.
The upload archive does not need those strings: every analysis uses the parsed
prediction and aggregate cluster statistics.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def sanitize_predictions(root: Path) -> None:
    for path in sorted((root / "predictions").glob("llm_fewshot_*.csv")):
        with path.open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            rows = list(reader)
            fieldnames = reader.fieldnames
        if not fieldnames or "pred" not in fieldnames or not ({"raw", "response_status"} & set(fieldnames)):
            raise ValueError(f"unexpected prediction schema: {path}")
        output_fields = ["response_status" if name == "raw" else name for name in fieldnames]
        for row in rows:
            prediction = int(row["pred"])
            row.pop("raw", None)
            row["response_status"] = {1: "scam", 0: "safe", -1: "unparseable"}[prediction]
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=output_fields)
            writer.writeheader()
            writer.writerows(rows)


def sanitize_cluster_summary(root: Path) -> None:
    json_path = root / "results" / "rebuttal_template_cluster_sensitivity.json"
    with json_path.open(encoding="utf-8") as stream:
        result = json.load(stream)
    for cluster in result.get("largest_clusters", []):
        cluster.pop("example", None)
    json_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    markdown_path = root / "results" / "rebuttal_template_cluster_sensitivity.md"
    markdown = markdown_path.read_text(encoding="utf-8")
    marker = "## Largest structural clusters"
    next_section = "## Bank/UPI FPR"
    if marker in markdown:
        prefix, remainder = markdown.split(marker, 1)
        if next_section not in remainder:
            raise ValueError(f"cannot locate aggregate section in {markdown_path}")
        markdown = prefix.rstrip() + "\n\n" + next_section + remainder.split(next_section, 1)[1]
        markdown_path.write_text(markdown, encoding="utf-8")


def sanitize_annotation_summary(root: Path) -> None:
    path = root / "results" / "annotation_iaa_results_3annotator.json"
    if not path.exists():
        return
    with path.open(encoding="utf-8") as stream:
        result = json.load(stream)
    result.pop("top_disagreements", None)
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path, help="Staged compact-supplement root")
    args = parser.parse_args()
    sanitize_predictions(args.root)
    sanitize_cluster_summary(args.root)
    sanitize_annotation_summary(args.root)
    print(f"Sanitized compact supplement at {args.root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
