"""Regenerate the camera-ready label-policy sensitivity table.

The four policies use one aligned 1,393-row prediction matrix:

* A: the camera-ready fraud-blocking policy.
* B1/B2/B3: keep every row in evaluation but reclassify current
  policy-positive rows from one named source as safe.  Models are not
  retrained.  These are label-policy perturbations, not source holdouts.

The upload-safe input contains no message text.  It can be rebuilt from the
frozen artifact with ``--artifact /path/to/scamshield_emnlp_artifact_v4.zip``.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
PREDICTIONS = ROOT / "predictions"
INPUT_NAME = "label_policy_base_predictions.csv"
OUT_JSON = RESULTS / "label_policy_sensitivity.json"
OUT_MD = RESULTS / "label_policy_sensitivity.md"

MODEL_FILES = {
    "xlmr_cleaned": "xlmr_cleaned_aligned_predictions.csv",
    "gpt_4o_mini": "llm_multilingual_gpt_4o_mini_predictions.csv",
    "gpt_4o": "llm_multilingual_gpt_4o_predictions.csv",
    "claude_haiku_4_5": "llm_multilingual_claude_haiku_4_5_20251001_predictions.csv",
    "gemini_2_5_flash": "llm_multilingual_gemini_2_5_flash_predictions.csv",
    "llama_3_3_70b": "llm_multilingual_meta_llama_Llama_3_3_70B_Instruct_Turbo_predictions.csv",
    "qwen_2_5_7b": "llm_multilingual_Qwen_Qwen2_5_7B_Instruct_Turbo_predictions.csv",
    "xlmr_english_only": "xlmr_english_only_predictions.csv",
}

POLICIES = {
    "A_current": None,
    "B1_cloveai_positive_to_safe": "cloveai_india",
    "B2_iiitd_positive_to_safe": "iiitd",
    "B3_vinit9638_positive_to_safe": "vinit9638",
}


def _member_name(names: list[str], suffix: str) -> str:
    matches = [name for name in names if name.endswith(suffix)]
    if len(matches) != 1:
        raise ValueError(f"expected one archive member ending in {suffix!r}, found {matches}")
    return matches[0]


def _read_zip_csv(archive: zipfile.ZipFile, suffix: str) -> list[dict[str, str]]:
    name = _member_name(archive.namelist(), suffix)
    with archive.open(name) as raw:
        return list(csv.DictReader(io.TextIOWrapper(raw, encoding="utf-8")))


def build_upload_safe_input(artifact_path: Path, output_path: Path) -> None:
    """Create the text-free aligned prediction matrix from the frozen artifact."""
    with zipfile.ZipFile(artifact_path) as archive:
        test = _read_zip_csv(archive, "/data/cleaned_test_1393.csv")
        audit = _read_zip_csv(archive, "/data/relabel_audit.csv")
        prediction_rows = {
            model: _read_zip_csv(archive, f"/predictions/{filename}")
            for model, filename in MODEL_FILES.items()
        }

    # Every row in the audit originated in a source-positive class.  IIITD
    # text is already represented as sha256:<hex> in both frozen CSVs.
    source_positive_keys = {(r["source"], r["text"]) for r in audit}
    # API files were produced on the earlier 1,443-row test and therefore
    # retain legacy row indices.  Align by the released source+text key, as in
    # the camera-ready evaluation, rather than silently treating ``idx`` as a
    # shared identifier.
    by_model = {
        model: {(r["source"], r["text"]): r for r in rows}
        for model, rows in prediction_rows.items()
    }

    fieldnames = [
        "idx", "source", "template", "policy_gold", "original_source_positive",
        *MODEL_FILES,
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for test_row in sorted(test, key=lambda row: int(row["idx"])):
            idx = int(test_row["idx"])
            gold = int(test_row["label_cleaned"])
            out = {
                "idx": idx,
                "source": test_row["source"],
                "template": test_row["template_bucket"],
                "policy_gold": gold,
                "original_source_positive": int(
                    (test_row["source"], test_row["text"]) in source_positive_keys
                ),
            }
            for model in MODEL_FILES:
                pred_row = by_model[model].get((test_row["source"], test_row["text"]))
                if pred_row is None:
                    raise ValueError(f"{model}: missing idx={idx}")
                # Several frozen API CSVs retain the pre-conversion ``label``
                # column.  The aligned camera-ready test file is the canonical
                # gold vector; only the frozen ``pred`` column is imported.
                out[model] = int(pred_row["pred"])
            writer.writerow(out)


def locate_input() -> Path:
    candidates = [PREDICTIONS / INPUT_NAME, RESULTS / INPUT_NAME]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"{INPUT_NAME} not found under {PREDICTIONS} or {RESULTS}; "
        "pass --artifact to build it from the frozen artifact"
    )


def score(gold: list[int], pred: list[int]) -> dict[str, float | int]:
    tp = sum(g == 1 and p == 1 for g, p in zip(gold, pred))
    fp = sum(g == 0 and p == 1 for g, p in zip(gold, pred))
    tn = sum(g == 0 and p == 0 for g, p in zip(gold, pred))
    fn = sum(g == 1 and p == 0 for g, p in zip(gold, pred))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / denom if denom else 0.0
    return {
        "n": len(gold), "n_positive": sum(gold),
        "tp": tp, "fp": fp, "tn": tn, "fn": fn,
        "precision": round(precision, 6), "recall": round(recall, 6),
        "f1": round(f1, 6), "mcc": round(mcc, 6),
    }


def regenerate(input_path: Path) -> dict:
    with input_path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 1393:
        raise ValueError(f"expected 1,393 aligned rows, found {len(rows)}")

    policies = {}
    for policy, source_to_flip in POLICIES.items():
        gold = []
        for row in rows:
            value = int(row["policy_gold"])
            if source_to_flip and value == 1 and row["source"] == source_to_flip:
                value = 0
            gold.append(value)
        policies[policy] = {
            "description": (
                "Camera-ready policy labels"
                if source_to_flip is None
                else f"Policy-positive {source_to_flip} rows reclassified safe; no rows removed and no retraining"
            ),
            "n_positive": sum(gold),
            "models": {
                model: score(gold, [int(row[model]) for row in rows])
                for model in MODEL_FILES
            },
        }

    untouched = [row for row in rows if int(row["original_source_positive"]) == 0]
    policy_negatives = [row for row in rows if int(row["policy_gold"]) == 0]
    converted_negatives = [
        row for row in policy_negatives if int(row["original_source_positive"]) == 1
    ]
    untouched_fpr = {}
    for model in MODEL_FILES:
        fp = sum(int(row[model]) == 1 for row in untouched)
        untouched_fpr[model] = {
            "n": len(untouched), "false_positives": fp, "fpr": round(fp / len(untouched), 6)
        }

    result = {
        "input": INPUT_NAME,
        "policy_definitions": POLICIES,
        "row_provenance": {
            "n_total": len(rows),
            "n_policy_positive": sum(int(row["policy_gold"]) for row in rows),
            "n_policy_negative": len(policy_negatives),
            "n_untouched_source_negative": len(untouched),
            "n_source_positive_converted_to_safe": len(converted_negatives),
        },
        "untouched_source_negative_fpr": untouched_fpr,
        "policies": policies,
    }
    OUT_JSON.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    labels = {
        "xlmr_cleaned": "Ours", "gpt_4o_mini": "mini", "gpt_4o": "4o",
        "claude_haiku_4_5": "Claude", "gemini_2_5_flash": "Gemini",
        "llama_3_3_70b": "Llama", "qwen_2_5_7b": "Qwen",
        "xlmr_english_only": "EN-only",
    }
    lines = ["# Label-policy sensitivity (regenerated)", ""]
    lines.append(
        "All policies use the same 1,393 rows and frozen predictions. B1-B3 "
        "reclassify current policy-positive rows from one source as safe; they "
        "do not remove a source and do not retrain a model."
    )
    lines.extend(["", "| Policy | n positive | " + " | ".join(labels.values()) + " |",
                  "|---|---:|" + "---:|" * len(labels)])
    for policy, data in policies.items():
        values = [f"{data['models'][model]['f1']:.3f}" for model in labels]
        lines.append(f"| {policy} | {data['n_positive']} | " + " | ".join(values) + " |")
    lines.extend(["", "## Untouched source-negative FPR", "",
                  "| Model | false positives / 1,222 | FPR |", "|---|---:|---:|"])
    for model, label in labels.items():
        data = untouched_fpr[model]
        lines.append(f"| {label} | {data['false_positives']} / {data['n']} | {data['fpr']:.2%} |")
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=Path, help="Frozen EMNLP artifact ZIP")
    parser.add_argument("--input", type=Path, help="Existing text-free prediction matrix")
    args = parser.parse_args()

    if args.artifact:
        output = RESULTS / INPUT_NAME
        build_upload_safe_input(args.artifact, output)
        input_path = output
    else:
        input_path = args.input or locate_input()
    result = regenerate(input_path)
    print(json.dumps(result["row_provenance"], indent=2))
    print(f"Wrote {OUT_JSON} and {OUT_MD}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
