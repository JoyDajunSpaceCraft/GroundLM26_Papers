"""Few-shot robustness experiment: does strong prompting fix LLM over-flagging
of legitimate Indian institutional SMS?

Answers the EMNLP reviewer objection "you only tested minimal zero-shot
prompting." Runs a prompt ladder (zero-shot -> P1 -> P2 -> P3) on the identical
1,393-message cleaned test set, with a same-session paired zero-shot control,
a strict single-word parser that never silently defaults to "safe", raw-output logging,
and per-(model,condition) row-level resume.

Design + pinned decision rule:
  Papers/emnlp_fewshot_experiment_design.md

Usage:
  # 1. offline exemplar contamination check (no API calls)
  python -m evaluation.llm_fewshot_multilingual --contamination

  # 2. run (resumable, safe to Ctrl-C and rerun)
  python -m evaluation.llm_fewshot_multilingual \
      --models gpt-4o-mini,gpt-4o,gemini-2.5-flash,claude-haiku-4-5-20251001 \
      --conditions zeroshot,p2,p3

  # 3. analyze whatever CSVs exist (works on partial results)
  python -m evaluation.llm_fewshot_multilingual --analyze

Outputs (evaluation/results/):
  llm_fewshot_<model>_<condition>.csv   per-sample preds incl. raw output
  fewshot_vs_zeroshot_summary.json      per-model per-(lang,template) FPR + recall
  fewshot_summary.md                    human-readable comparison for the rebuttal
"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import os
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # Optional convenience; provider keys may be exported directly.
    load_dotenv = lambda: None

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("fewshot")
csv.field_size_limit(min(sys.maxsize, 2**31 - 1))

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"
PREDICTIONS_DIR = ROOT / "predictions"
TEST_CSV = RESULTS_DIR / "xlmr_cleaned_test_probs.csv"  # canonical 1,393-row aligned test set

# ----------------------------------------------------------------------------
# Prompts. Zero-shot is IDENTICAL to the paper's baseline (llm_baseline_multilingual).
# The few-shot exemplars are hand-crafted representative messages; the
# --contamination check verifies they do not overlap the test set.
# ----------------------------------------------------------------------------
ZERO_SHOT = (
    "You are a scam detection classifier. Given a message in any language, "
    "respond with ONLY a single word: 'scam' if the message is a "
    "scam/phishing/fraud attempt, or 'safe' if it is legitimate. No "
    "explanation, just one word."
)

_DEFINITIONS = (
    "You are a scam-SMS filter for Indian financial messaging. Classify each SMS "
    "as 'scam' or 'safe'.\n\n"
    "Definitions:\n"
    "- 'scam' = a message attempting financial fraud: phishing links, fake "
    "account/KYC suspension, impersonation of a bank or UPI app to steal "
    "credentials or money, prize/lottery bait that asks for payment or "
    "personal/bank details, or fake refund/reward hooks.\n"
    "- 'safe' = any legitimate message, INCLUDING real bank transaction/balance "
    "alerts, UPI payment receipts, OTP/verification codes, EMI/bill reminders "
    "from real institutions, and ordinary commercial marketing/promotions from "
    "real companies."
)

_EXEMPLARS = (
    "\n\nExamples:\n"
    "SMS: \"Dear customer, Rs 2,500 credited to your A/c XXXX1234 via UPI ref 4432. -HDFC Bank\" -> safe\n"
    "SMS: \"Your OTP for login is 884120. Do not share with anyone. -ICICI\" -> safe\n"
    "SMS: \"Get 50% off on Myntra fashion. Use code SAVE50. Shop now!\" -> safe\n"
    "SMS: \"EMI of Rs 5,000 for your loan is due on 25th. Pay via the official app.\" -> safe\n"
    "SMS: \"Your account will be BLOCKED. Complete KYC now: http://bit.ly/kyc-verify\" -> scam\n"
    "SMS: \"Congratulations! You won Rs 10,00,000. Pay Rs 999 processing fee to claim.\" -> scam\n"
    "SMS: \"Your SBI account is suspended. Verify PAN and password here: sbi-secure.in/login\" -> scam"
)

_CARVE_OUT = (
    "\n\nImportant: legitimate institutional and transactional SMS frequently "
    "mention banks, UPI, accounts, amounts, and OTPs. These are NOT scams by "
    "themselves; only flag genuine fraud attempts."
)

# One-shot = definitions + exactly ONE demonstration. We use one legitimate
# institutional example (the natural single fix a developer adds when the model
# over-flags bank SMS). Recall is watched for over-correction (single safe
# example can bias the model toward 'safe').
_ONESHOT_EX = (
    "\n\nExample:\n"
    "SMS: \"Dear customer, Rs 2,500 credited to your A/c XXXX1234 via UPI ref 4432. -HDFC Bank\" -> safe"
)

_TAIL = "\n\nRespond with ONLY one word: scam or safe. No explanation."

PROMPTS = {
    "zeroshot": ZERO_SHOT,                               # no examples, minimal (the paper's setup)
    "p1": _DEFINITIONS + _TAIL,                          # definitions only, no examples
    "oneshot": _DEFINITIONS + _ONESHOT_EX + _TAIL,       # definitions + ONE example
    "p2": _DEFINITIONS + _EXEMPLARS + _TAIL,             # HEADLINE: definitions + 7 exemplars
    "p3": _DEFINITIONS + _EXEMPLARS + _CARVE_OUT + _TAIL,  # UPPER BOUND: + explicit carve-out
}

# provider, model, key-env-var
MODEL_REGISTRY = {
    "gpt-4o-mini": ("openai", "gpt-4o-mini", "OPENAI_API_KEY"),
    "gpt-4o": ("openai", "gpt-4o", "OPENAI_API_KEY"),
    "claude-haiku-4-5-20251001": ("anthropic", "claude-haiku-4-5-20251001", "ANTHROPIC_API_KEY"),
    "gemini-2.5-flash": ("google", "gemini-2.5-flash", "GEMINI_API_KEY"),
    "meta-llama/Llama-3.3-70B-Instruct-Turbo": ("together", "meta-llama/Llama-3.3-70B-Instruct-Turbo", "TOGETHER_API_KEY"),
    "Qwen/Qwen2.5-7B-Instruct-Turbo": ("together", "Qwen/Qwen2.5-7B-Instruct-Turbo", "TOGETHER_API_KEY"),
}

MAX_TOKENS = 16  # Noncompliant prose may truncate; such output remains unparseable.


def parse_label(raw: str) -> int:
    """Return 1=scam, 0=safe, -1=UNPARSEABLE under the stated one-word rule."""
    a = (raw or "").strip().lower()
    return {"scam": 1, "safe": 0}.get(a, -1)


def make_client(provider: str):
    if provider == "openai":
        from openai import OpenAI
        return OpenAI()
    if provider == "anthropic":
        import anthropic
        return anthropic.Anthropic()
    if provider == "google":
        from google import genai
        return genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    if provider == "together":
        from openai import OpenAI
        return OpenAI(api_key=os.environ["TOGETHER_API_KEY"], base_url="https://api.together.xyz/v1")
    raise ValueError(provider)


def classify_one(provider, model_name, client, system_prompt, text, retries=2):
    """Return (pred, raw). pred in {1,0,-1}; -1 on unparseable/error. Retries on transient errors."""
    text = text[:2000]
    last_err = ""
    for attempt in range(retries + 1):
        try:
            if provider in ("openai", "together"):
                r = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "system", "content": system_prompt},
                              {"role": "user", "content": text}],
                    max_tokens=MAX_TOKENS, temperature=0.0,
                )
                raw = (r.choices[0].message.content or "").strip()
            elif provider == "anthropic":
                r = client.messages.create(
                    model=model_name, max_tokens=MAX_TOKENS, system=system_prompt,
                    messages=[{"role": "user", "content": text}],
                )
                raw = (r.content[0].text or "").strip()
            elif provider == "google":
                from google.genai import types
                r = client.models.generate_content(
                    model=model_name, contents=text,
                    config=types.GenerateContentConfig(
                        system_instruction=system_prompt, max_output_tokens=MAX_TOKENS,
                        temperature=0.0, thinking_config=types.ThinkingConfig(thinking_budget=0),
                    ),
                )
                raw = (r.text or "").strip()
            else:
                raise ValueError(provider)
            return parse_label(raw), raw
        except Exception as exc:  # noqa: BLE001
            last_err = str(exc)[:200]
            if attempt < retries:
                time.sleep(2 * (attempt + 1))
    return -1, f"<ERROR: {last_err}>"


def load_test():
    if not TEST_CSV.exists():
        raise FileNotFoundError(
            f"{TEST_CSV} is intentionally absent from the compact supplement; "
            "API reruns and contamination checks require the controlled full workspace."
        )
    try:
        sys.path.insert(0, str(ROOT.parent))
        from evaluation.template_taxonomy import classify_template
    except ImportError as exc:
        raise ImportError(
            "evaluation.template_taxonomy is required with the controlled test data"
        ) from exc
    rows = []
    with open(TEST_CSV, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append({
                "idx": r["idx"], "language": r["language"], "source": r["source"],
                "gold": int(r["label_cleaned"]), "text": r["text"],
                "template": classify_template(r["text"]),
            })
    return rows


def safe_name(model_name):
    return model_name.replace("/", "_").replace("-", "_").replace(".", "_")


def run_condition(model_key, condition, test_rows):
    provider, model_name, keyvar = MODEL_REGISTRY[model_key]
    if not os.environ.get(keyvar):
        log.warning("SKIP %s/%s: %s not set", model_key, condition, keyvar)
        return
    out = RESULTS_DIR / f"llm_fewshot_{safe_name(model_name)}_{condition}.csv"
    done = set()
    if out.exists():
        with open(out, encoding="utf-8") as f:
            done = {r["idx"] for r in csv.DictReader(f)}
    todo = [r for r in test_rows if r["idx"] not in done]
    if not todo:
        log.info("DONE (cached) %s/%s: %d rows", model_key, condition, len(test_rows))
        return
    log.info("RUN %s/%s: %d to do (%d cached)", model_key, condition, len(todo), len(done))
    client = make_client(provider)
    system_prompt = PROMPTS[condition]
    write_header = not out.exists()
    with open(out, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(["idx", "language", "source", "template", "gold", "pred", "raw"])
        for i, r in enumerate(todo):
            pred, raw = classify_one(provider, model_name, client, system_prompt, r["text"])
            w.writerow([r["idx"], r["language"], r["source"], r["template"], r["gold"], pred, raw.replace("\n", " ")])
            f.flush()
            if (i + 1) % 100 == 0:
                log.info("  %s/%s %d/%d", model_key, condition, i + 1, len(todo))
    log.info("SAVED %s", out)


def contamination_check(test_rows):
    """Offline: max token-Jaccard overlap of each exemplar vs every test message."""
    exemplars = [
        "Dear customer, Rs 2,500 credited to your A/c XXXX1234 via UPI ref 4432. -HDFC Bank",
        "Your OTP for login is 884120. Do not share with anyone. -ICICI",
        "Get 50% off on Myntra fashion. Use code SAVE50. Shop now!",
        "EMI of Rs 5,000 for your loan is due on 25th. Pay via the official app.",
        "Your account will be BLOCKED. Complete KYC now: http://bit.ly/kyc-verify",
        "Congratulations! You won Rs 10,00,000. Pay Rs 999 processing fee to claim.",
        "Your SBI account is suspended. Verify PAN and password here: sbi-secure.in/login",
    ]
    def toks(s): return set(re.findall(r"\w+", s.lower()))
    test_tok = [(r["text"], toks(r["text"])) for r in test_rows]
    print("Exemplar contamination check (max token-Jaccard vs any test message):")
    worst = 0.0
    for ex in exemplars:
        et = toks(ex)
        best, best_txt = 0.0, ""
        for txt, tt in test_tok:
            u = len(et | tt)
            j = len(et & tt) / u if u else 0.0
            if j > best:
                best, best_txt = j, txt
        worst = max(worst, best)
        print(f"  {best:.2f}  <- {ex[:45]!r}   nearest: {best_txt[:45]!r}")
    print(f"\nWorst overlap across all exemplars: {worst:.2f}  "
          f"({'OK (<0.5, no contamination)' if worst < 0.5 else 'WARNING: review'})")
    return worst


def analyze():
    """Compute per-template + per-(lang,template) FPR, recall, parse/error rates from saved CSVs."""
    input_dir = PREDICTIONS_DIR if PREDICTIONS_DIR.exists() else RESULTS_DIR
    files = sorted(input_dir.glob("llm_fewshot_*.csv"))
    if not files:
        log.warning("No result CSVs yet.")
        return
    # group: model -> condition -> rows
    data = defaultdict(lambda: defaultdict(list))
    for fp in files:
        m = re.match(r"llm_fewshot_(.+)_(zeroshot|p1|oneshot|p2|p3)\.csv", fp.name)
        if not m:
            continue
        model, cond = m.group(1), m.group(2)
        with open(fp, encoding="utf-8") as f:
            data[model][cond] = list(csv.DictReader(f))

    summary = {}
    lines = ["# Few-shot vs zero-shot — per-template FPR + recall\n"]
    for model in sorted(data):
        summary[model] = {}
        lines.append(f"\n## {model}\n")
        lines.append("| condition | Bank FPR | UPI FPR | Other FPR | Global FPR | Recall | parse-fail | err |")
        lines.append("|---|---|---|---|---|---|---|---|")
        for cond in ["zeroshot", "p1", "oneshot", "p2", "p3"]:
            rows = data[model].get(cond)
            if not rows:
                continue
            n = len(rows)
            unpars = sum(1 for r in rows if r["pred"] == "-1")
            errs = sum(1 for r in rows if r.get("raw", "").startswith("<ERROR"))
            def fpr(template=None):
                negs = [r for r in rows if r["gold"] == "0" and r["pred"] in ("0", "1")
                        and (template is None or r["template"] == template)]
                if not negs:
                    return None, 0
                fp = sum(1 for r in negs if r["pred"] == "1")
                return fp / len(negs), len(negs)
            bank, nb = fpr("Bank/account")
            upi, nu = fpr("UPI/Payment")
            other, no = fpr("Other")
            glob, ng = fpr(None)
            pos = [r for r in rows if r["gold"] == "1" and r["pred"] in ("0", "1")]
            recall = (sum(1 for r in pos if r["pred"] == "1") / len(pos)) if pos else None
            def pct(x): return f"{100*x:.1f}%" if x is not None else "n/a"
            summary[model][cond] = {
                "n": n, "bank_fpr": bank, "bank_n": nb, "upi_fpr": upi, "upi_n": nu,
                "other_fpr": other, "global_fpr": glob, "recall": recall,
                "parse_fail": unpars / n, "error_rate": errs / n,
            }
            lines.append(f"| {cond} | {pct(bank)} (n={nb}) | {pct(upi)} (n={nu}) | {pct(other)} | "
                         f"{pct(glob)} | {pct(recall)} | {100*unpars/n:.1f}% | {100*errs/n:.1f}% |")
            # per-language x template for Bank/UPI
            for tmpl in ["Bank/account", "UPI/Payment"]:
                bylang = defaultdict(lambda: [0, 0])
                for r in rows:
                    if r["gold"] == "0" and r["template"] == tmpl and r["pred"] in ("0", "1"):
                        bylang[r["language"]][1] += 1
                        if r["pred"] == "1":
                            bylang[r["language"]][0] += 1
                summary[model][cond].setdefault("by_lang", {})[tmpl] = {
                    lg: {"fpr": fp / tot, "n": tot} for lg, (fp, tot) in bylang.items() if tot
                }
    out_json = RESULTS_DIR / "fewshot_vs_zeroshot_summary.json"
    out_json.write_text(json.dumps(summary, indent=2))
    out_md = RESULTS_DIR / "fewshot_summary.md"
    out_md.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    log.info("Wrote %s and %s", out_json, out_md)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--models", default="gpt-4o-mini,gpt-4o,gemini-2.5-flash,claude-haiku-4-5-20251001")
    ap.add_argument("--conditions", default="zeroshot,p2,p3")
    ap.add_argument("--contamination", action="store_true", help="offline exemplar overlap check only")
    ap.add_argument("--analyze", action="store_true", help="summarize existing CSVs only")
    args = ap.parse_args()

    if args.analyze:
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        analyze()
        return

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    test_rows = load_test()
    log.info("Loaded %d test messages", len(test_rows))

    if args.contamination:
        contamination_check(test_rows)
        return

    # decisive-first ordering; conditions inner loop so each model finishes fully
    models = [m.strip() for m in args.models.split(",") if m.strip()]
    conds = [c.strip() for c in args.conditions.split(",") if c.strip()]
    for model_key in models:
        for cond in conds:
            run_condition(model_key, cond, test_rows)
    analyze()


if __name__ == "__main__":
    main()
