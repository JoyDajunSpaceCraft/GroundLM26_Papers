"""Verify the packaged numerical claims for the GroundLM camera-ready paper.

This script recomputes prompt-ladder metrics from the released parsed decisions
and checks other aggregate result files against the values used in the paper.
It intentionally does not re-run paid API inference. Some audits require
controlled raw-message inputs that are deliberately absent from the compact
upload, so a PASS is a package-consistency check rather than independent
construct or training reproducibility validation.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
PREDICTIONS = ROOT / "predictions"


def load(name: str) -> dict:
    with (RESULTS / name).open(encoding="utf-8") as stream:
        return json.load(stream)


def close(actual: float, expected: float, tolerance: float = 1e-9) -> None:
    if abs(actual - expected) > tolerance:
        raise AssertionError(f"expected {expected}, found {actual}")


def load_baseline_rows() -> list[dict[str, str]]:
    path = PREDICTIONS / "label_policy_base_predictions.csv"
    if not path.exists():
        path = RESULTS / "label_policy_base_predictions.csv"
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 1393:
        raise AssertionError(f"expected 1,393 aligned baseline rows, found {len(rows)}")
    return rows


def binary_metrics(rows: list[dict[str, str]], model: str) -> dict[str, float]:
    pairs = [(int(row["policy_gold"]), int(row[model])) for row in rows]
    tp = sum(g == 1 and p == 1 for g, p in pairs)
    fp = sum(g == 0 and p == 1 for g, p in pairs)
    tn = sum(g == 0 and p == 0 for g, p in pairs)
    fn = sum(g == 1 and p == 0 for g, p in pairs)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / denominator if denominator else 0.0
    return {"f1": f1, "mcc": mcc, "fpr": fp / (fp + tn), "recall": recall}


def check_original_tables_and_figure() -> None:
    """Check Tables 2, 4, 5/8/10, McNemar detail, and Figure 1."""
    rows = load_baseline_rows()
    models = [
        "xlmr_cleaned", "gpt_4o_mini", "gpt_4o", "claude_haiku_4_5",
        "gemini_2_5_flash", "llama_3_3_70b", "qwen_2_5_7b",
        "xlmr_english_only",
    ]
    expected_metrics = {
        "xlmr_cleaned": (0.965, 0.963, 0.004, 0.980),
        "gpt_4o_mini": (0.310, 0.348, 0.340, 1.000),
        "gpt_4o": (0.512, 0.542, 0.146, 1.000),
        "claude_haiku_4_5": (0.441, 0.476, 0.191, 0.990),
        "gemini_2_5_flash": (0.558, 0.583, 0.121, 1.000),
        "llama_3_3_70b": (0.396, 0.435, 0.233, 1.000),
        "qwen_2_5_7b": (0.285, 0.320, 0.383, 1.000),
        "xlmr_english_only": (0.401, 0.433, 0.220, 0.970),
    }
    metrics = {}
    for model in models:
        metrics[model] = binary_metrics(rows, model)
        for key, expected in zip(("f1", "mcc", "fpr", "recall"), expected_metrics[model]):
            close(metrics[model][key], expected, tolerance=0.00055)

    expected_template_fpr = {
        "UPI/Payment": (146, (0.000, 0.569, 0.315, 0.397, 0.274, 0.253, 0.055, 0.486)),
        "Bank/account": (163, (0.000, 0.773, 0.288, 0.491, 0.245, 0.742, 0.656, 0.571)),
        "EMI/loan": (8, (0.000, 0.625, 0.250, 0.375, 0.125, 0.500, 1.000, 0.875)),
        "Marketing/promo": (6, (0.000, 0.833, 0.500, 0.667, 0.500, 0.833, 0.833, 0.833)),
        "URL/click": (21, (0.000, 0.048, 0.048, 0.476, 0.048, 0.048, 0.714, 0.095)),
        "Other": (946, (0.005, 0.232, 0.095, 0.096, 0.076, 0.141, 0.372, 0.110)),
    }
    template_rates: dict[str, dict[str, float]] = {}
    for template, (expected_n, expected_rates) in expected_template_fpr.items():
        safe_rows = [
            row for row in rows
            if int(row["policy_gold"]) == 0 and row["template"] == template
        ]
        if len(safe_rows) != expected_n:
            raise AssertionError(f"{template}: expected n={expected_n}, found {len(safe_rows)}")
        template_rates[template] = {}
        for model, expected in zip(models, expected_rates):
            rate = sum(int(row[model]) == 1 for row in safe_rows) / len(safe_rows)
            template_rates[template][model] = rate
            close(rate, expected, tolerance=0.00055)

    # Figure 1 is the pass/fail rendering of these exact Table 2/Table 4 values.
    for model in models:
        passes = [
            template_rates["UPI/Payment"][model] <= 0.01,
            template_rates["Bank/account"][model] <= 0.01,
            template_rates["EMI/loan"][model] <= 0.01,
            metrics[model]["fpr"] <= 0.01,
            metrics[model]["recall"] >= 0.95,
        ]
        expected = [True] * 5 if model == "xlmr_cleaned" else [False, False, False, False, True]
        if passes != expected:
            raise AssertionError(f"Figure 1 pass/fail cells mismatch for {model}: {passes}")

    expected_mcnemar = {
        "qwen_2_5_7b": (3, 492), "gpt_4o_mini": (4, 437),
        "llama_3_3_70b": (2, 297), "xlmr_english_only": (3, 283),
        "claude_haiku_4_5": (4, 245), "gpt_4o": (4, 186),
        "gemini_2_5_flash": (4, 154),
    }
    for model, expected in expected_mcnemar.items():
        b = sum(
            int(row["xlmr_cleaned"]) != int(row["policy_gold"])
            and int(row[model]) == int(row["policy_gold"])
            for row in rows
        )
        c = sum(
            int(row["xlmr_cleaned"]) == int(row["policy_gold"])
            and int(row[model]) != int(row["policy_gold"])
            for row in rows
        )
        if (b, c) != expected:
            raise AssertionError(f"McNemar counts mismatch for {model}: {(b, c)}")

    sweep = load("xlmr_operating_points.json")["operating_points"]
    expected_sweep = {
        0.3: (1.0000, 0.0054, 0.0063, 76095),
        0.4: (1.0000, 0.0039, 0.0053, 74659),
        0.5: (0.9798, 0.0039, 0.0053, 73223),
        0.6: (0.9798, 0.0023, 0.0032, 71788),
        0.7: (0.9798, 0.0023, 0.0032, 71788),
        0.8: (0.9596, 0.0015, 0.0021, 69634),
        0.9: (0.9293, 0.0015, 0.0021, 67480),
    }
    if len(sweep) != len(expected_sweep):
        raise AssertionError("operating-point row count mismatch")
    for row in sweep:
        threshold = row["threshold"]
        recall, global_fpr, other_fpr, volume = expected_sweep[threshold]
        close(row["recall"], recall)
        close(row["global_fpr"], global_fpr)
        close(row["per_template_safe_fpr"]["Other"], other_fpr)
        if row["projected_flag_per_million_at_test_prevalence"] != volume:
            raise AssertionError(f"threshold {threshold}: Flag/M mismatch")
        for template in ("UPI/Payment", "Bank/account", "EMI/loan", "Marketing/promo"):
            close(row["per_template_safe_fpr"][template], 0.0)


def check_prompt_results() -> None:
    table = load("rebuttal_fewshot_full_table.json")
    expected = {
        ("gpt_4o", "p2"): (0.0147, 0.0, 0.0, 0.9495, 0.8868, 0),
        ("gpt_4o", "p3"): (0.0085, 0.0, 0.0, 0.9091, 0.9000, 0),
        ("claude_haiku_4_5_20251001", "p2"): (
            0.0183,
            0.0,
            0.0068,
            0.9596,
            0.8756,
            40,
        ),
        ("gemini_2_5_flash", "p2"): (0.0271, 0.0, 0.0342, 0.7778, 0.7299, 1),
        ("gpt_4o_mini", "p2"): (0.1584, 0.0, 0.0, 0.9899, 0.4876, 0),
    }
    for (model, condition), values in expected.items():
        row = table[model][condition]
        if row["n"] != 1393:
            raise AssertionError(f"{model}/{condition}: expected n=1393")
        for key, expected_value in zip(
            ("global_fpr", "bank_fpr", "upi_fpr", "recall", "f1"), values[:5]
        ):
            close(row[key], expected_value, tolerance=0.000051)
        if row["unparseable"] != values[5]:
            raise AssertionError(f"{model}/{condition}: unparseable mismatch")

    prediction_dir = PREDICTIONS if PREDICTIONS.exists() else RESULTS
    ladder_summary = load("fewshot_vs_zeroshot_summary.json")
    prediction_files = sorted(prediction_dir.glob("llm_fewshot_*.csv"))
    if len(prediction_files) != 20:
        raise AssertionError(f"expected 20 prompt-ladder prediction files, found {len(prediction_files)}")
    for csv_path in prediction_files:
        with csv_path.open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            response_column = "response_status" if prediction_dir == PREDICTIONS else "raw"
            if reader.fieldnames != [
                "idx", "language", "source", "template", "gold", "pred", response_column
            ]:
                raise AssertionError(f"unexpected columns in {csv_path.name}")
            rows = list(reader)
            if len(rows) != 1393:
                raise AssertionError(f"unexpected row count in {csv_path.name}")
            if prediction_dir == PREDICTIONS:
                allowed = {1: "scam", 0: "safe", -1: "unparseable"}
                for row in rows:
                    if row["response_status"].strip().lower() != allowed[int(row["pred"])]:
                        raise AssertionError(f"unsanitized response text in {csv_path.name}")
            else:
                # The paper states an exact single-word decision rule. Arbitrary
                # prose containing a label word is unresolved, hence -1.
                for row in rows:
                    parsed = {"scam": 1, "safe": 0}.get(row["raw"].strip().lower(), -1)
                    if int(row["pred"]) != parsed:
                        raise AssertionError(
                            f"single-word parser mismatch in {csv_path.name}, idx={row['idx']}"
                        )

        stem = csv_path.stem[len("llm_fewshot_"):]
        condition = next(
            cond for cond in ("zeroshot", "p1", "oneshot", "p2", "p3")
            if stem.endswith("_" + cond)
        )
        model = stem[: -(len(condition) + 1)]

        # Recompute every prompt-table row from the lowest-level released
        # parsed decisions instead of trusting the derived JSON alone.
        tp = fp = tn = fn = unparseable = 0
        bank_fp = bank_n = upi_fp = upi_n = 0
        for row in rows:
            gold, pred = int(row["gold"]), int(row["pred"])
            if pred == -1:
                unparseable += 1
                continue
            if gold == 1:
                tp += pred == 1
                fn += pred == 0
            else:
                fp += pred == 1
                tn += pred == 0
                if row["template"] == "Bank/account":
                    bank_n += 1
                    bank_fp += pred == 1
                elif row["template"] == "UPI/Payment":
                    upi_n += 1
                    upi_fp += pred == 1
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        mcc = (tp * tn - fp * fn) / denominator if denominator else 0.0
        direct = {
            "n": len(rows),
            "unparseable": unparseable,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "mcc": mcc,
            "global_fpr": fp / (fp + tn),
            "bank_fpr": bank_fp / bank_n,
            "bank_n": bank_n,
            "upi_fpr": upi_fp / upi_n,
            "upi_n": upi_n,
        }
        table_row = table[model][condition]
        for key in ("n", "unparseable", "bank_n", "upi_n"):
            if table_row[key] != direct[key]:
                raise AssertionError(f"derived prompt count mismatch for {model}/{condition}/{key}")
        for key in ("precision", "recall", "f1", "mcc", "global_fpr", "bank_fpr", "upi_fpr"):
            close(table_row[key], direct[key], tolerance=1e-12)
        summary_row = ladder_summary[model][condition]
        for key in ("global_fpr", "bank_fpr", "upi_fpr", "recall"):
            close(summary_row[key], direct[key], tolerance=0.00005)
        if round(summary_row["parse_fail"] * len(rows)) != unparseable:
            raise AssertionError(f"parse-fail count mismatch for {model}/{condition}")


def check_consensus() -> None:
    rows = load("rebuttal_consensus_filter.json")["results"]
    expected = {
        "consensus_AND_p2": (0.0062, 0.0, 0.0, 0.7576, 0.8242),
        "consensus_OR_p2": (0.0356, 0.0, 0.0342, 0.9697, 0.7967),
        "xlmr_local": (0.0039, 0.0, 0.0, 0.9798, 0.9652),
    }
    for name, values in expected.items():
        row = rows[name]
        for key, expected_value in zip(
            ("global_fpr", "bank_fpr", "upi_fpr", "recall", "f1"), values
        ):
            close(row[key], expected_value)


def check_negative_audit_and_deduplication() -> None:
    audit = load("rebuttal_negative_audit.json")
    if audit["n"] != 1294 or audit["consensus_overall"] != {
        "safe": 1111,
        "mixed": 141,
        "fraud": 42,
    }:
        raise AssertionError("negative-label audit counts do not match the paper")
    if audit["per_template"]["UPI/Payment"]["fraud"] != 32:
        raise AssertionError("expected 32 consensus-fraud synthetic UPI negatives")
    if audit["provenance_breakdown"] != {
        "untouched_source_negative": {"n": 1222, "safe": 1065, "mixed": 117, "fraud": 40},
        "source_positive_converted_to_safe": {"n": 72, "safe": 46, "mixed": 24, "fraud": 2},
    }:
        raise AssertionError("policy-negative provenance split does not match the paper")

    dedup = load("rebuttal_template_cluster_sensitivity.json")
    if PREDICTIONS.exists() and any("example" in row for row in dedup.get("largest_clusters", [])):
        raise AssertionError("compact structural-cluster result contains message examples")
    if PREDICTIONS.exists():
        cluster_markdown = (RESULTS / "rebuttal_template_cluster_sensitivity.md").read_text(
            encoding="utf-8"
        )
        if "## Largest structural clusters" in cluster_markdown or "| example |" in cluster_markdown:
            raise AssertionError("compact structural-cluster Markdown contains message examples")
    if (dedup["n_rows"], dedup["n_structural_clusters"]) != (1393, 1219):
        raise AssertionError("structural-cluster counts do not match the paper")
    mini = dedup["models"]["gpt_4o_mini"]
    close(mini["Bank/account"]["fpr_dedup"], 0.6154)
    close(mini["UPI/Payment"]["fpr_dedup"], 0.5242)


def check_human_annotation() -> None:
    iaa_path = (
        ROOT.parent
        / "annotation-study"
        / "returned-labels"
        / "annotation_iaa_results_3annotator.json"
    )
    if not iaa_path.exists():
        # The upload-safe supplement ships this aggregate-only copy without
        # the raw-text ``top_disagreements`` field.
        iaa_path = RESULTS / "annotation_iaa_results_3annotator.json"
    with iaa_path.open(encoding="utf-8") as stream:
        iaa = json.load(stream)
    if PREDICTIONS.exists() and "top_disagreements" in iaa:
        raise AssertionError("compact annotation result contains message-bearing disagreements")
    if iaa["n_full_overlap_rows"] != 276:
        raise AssertionError("human-study denominator does not match the paper")
    close(iaa["fleiss_kappa"], 0.8210139946304199)
    close(iaa["krippendorff_alpha"], 0.8212301613035715)
    if iaa["human_vs_llm_agreement"] != {
        "agree": 131,
        "disagree": 18,
        "human_unclear_or_tie": 127,
    }:
        raise AssertionError("human-versus-LLM counts do not match the paper")

    diagnostics = load("rebuttal_annotation_diagnostics.json")
    if diagnostics["per_template"]["Bank/account"]["n_rows"] != 35:
        raise AssertionError("human Bank/account subset should contain 35 rows")
    if diagnostics["per_template"]["UPI/Payment"]["n_rows"] != 9:
        raise AssertionError("human UPI/Payment subset should contain 9 rows")

    human_fpr = load("human_majority_template_fpr.json")["templates"]
    if human_fpr["Bank/account"]["n_majority_safe"] != 33:
        raise AssertionError("human-majority-safe Bank denominator should be 33")
    if human_fpr["Bank/account"]["gpt_4o_mini_false_positive"] != 21:
        raise AssertionError("human-majority Bank GPT-4o-mini false-positive count should be 21")
    if human_fpr["UPI/Payment"]["n_majority_safe"] != 8:
        raise AssertionError("human-majority-safe UPI denominator should be 8")
    if human_fpr["UPI/Payment"]["gpt_4o_mini_false_positive"] != 7:
        raise AssertionError("human-majority UPI GPT-4o-mini false-positive count should be 7")


def check_label_policy_sensitivity() -> None:
    result = load("label_policy_sensitivity.json")
    if result["row_provenance"] != {
        "n_total": 1393,
        "n_policy_positive": 99,
        "n_policy_negative": 1294,
        "n_untouched_source_negative": 1222,
        "n_source_positive_converted_to_safe": 72,
    }:
        raise AssertionError("label-policy row provenance does not match the paper")
    expected = {
        "A_current": (99, 0.965, 0.310, 0.512, 0.441, 0.558, 0.396, 0.285, 0.401),
        "B1_cloveai_positive_to_safe": (45, 0.585, 0.154, 0.270, 0.226, 0.299, 0.202, 0.141, 0.198),
        "B2_iiitd_positive_to_safe": (91, 0.933, 0.289, 0.480, 0.413, 0.524, 0.370, 0.265, 0.374),
        "B3_vinit9638_positive_to_safe": (64, 0.759, 0.212, 0.364, 0.313, 0.400, 0.275, 0.194, 0.288),
    }
    models = [
        "xlmr_cleaned", "gpt_4o_mini", "gpt_4o", "claude_haiku_4_5",
        "gemini_2_5_flash", "llama_3_3_70b", "qwen_2_5_7b", "xlmr_english_only",
    ]
    for policy, values in expected.items():
        row = result["policies"][policy]
        if row["n_positive"] != values[0]:
            raise AssertionError(f"{policy}: positive denominator mismatch")
        for model, expected_f1 in zip(models, values[1:]):
            close(row["models"][model]["f1"], expected_f1, tolerance=0.0005)

    untouched = result["untouched_source_negative_fpr"]
    close(untouched["xlmr_cleaned"]["fpr"], 0.000818, tolerance=0.0000005)
    close(untouched["gemini_2_5_flash"]["fpr"], 0.108838, tolerance=0.0000005)
    close(untouched["qwen_2_5_7b"]["fpr"], 0.351882, tolerance=0.0000005)


def check_calibration() -> None:
    calibration = load("xlmr_cleaned_test_calibration.json")
    if calibration["n"] != 1393 or calibration["ece_bins"] != 10:
        raise AssertionError("calibration setup does not match the paper")
    close(calibration["ece"], 0.006613621679827715)
    close(calibration["brier_score"], 0.0031611933250559943)


def main() -> None:
    check_original_tables_and_figure()
    check_prompt_results()
    check_consensus()
    check_negative_audit_and_deduplication()
    check_human_annotation()
    check_label_policy_sensitivity()
    check_calibration()
    print("PASS: packaged GroundLM camera-ready claims are internally consistent")


if __name__ == "__main__":
    main()
