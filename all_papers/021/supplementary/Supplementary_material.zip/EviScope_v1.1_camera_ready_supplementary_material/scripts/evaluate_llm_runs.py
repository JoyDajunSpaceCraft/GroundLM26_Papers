#!/usr/bin/env python3
"""Evaluate provider-based EviScope LLM runs and export a paper table."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from evaluate import evaluate, normalize
from model_pricing import MODEL_PRICING_USD_PER_MILLION, estimate_cost_usd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATASET = ROOT / "data" / "eviscope_v1_1.jsonl"
DEFAULT_TABLE = ROOT / "results" / "llm_results_table.md"

def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def latest_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep the last attempt for each logical example/model/policy key."""
    latest: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for row in rows:
        key = (
            str(row.get("example_id", "")),
            str(row.get("provider", "")),
            str(row.get("model", "")),
            str(row.get("policy", "")),
        )
        latest[key] = row
    return list(latest.values())


def quote_spans(example: dict[str, Any], quotes: list[str]) -> list[dict[str, str]]:
    spans = []
    for quote in quotes:
        normalized_quote = normalize(quote)
        if not normalized_quote:
            continue
        matches = [
            doc["doc_id"]
            for doc in example["documents"]
            if normalized_quote in normalize(doc["text"])
        ]
        if len(matches) == 1:
            spans.append({"doc_id": matches[0], "text": quote})
    return spans


def adapt_prediction(row: dict[str, Any], example: dict[str, Any]) -> dict[str, Any]:
    prediction = row.get("prediction") or {}
    action = prediction.get("action", "abstain")
    internal_action = "flag_conflict" if action == "conflict" else action
    if internal_action not in {"answer", "abstain", "flag_conflict"}:
        internal_action = "abstain"
    answer = prediction.get("answer")
    quotes = prediction.get("supporting_quotes") or []
    return {
        "id": row["example_id"],
        "answer": answer if isinstance(answer, str) else "",
        "citations": prediction.get("cited_doc_ids") or [],
        "support_spans": quote_spans(example, quotes),
        "action": internal_action,
        "abstained": internal_action != "answer",
        "token_count": int(row.get("total_tokens", 0) or 0),
        "latency_ms": float(row.get("latency_ms", 0) or 0),
        "calls": int(row.get("calls", 0) or 0),
        "mode": row.get("policy", ""),
    }


def metric_row(group: dict[str, Any]) -> str:
    metrics = group["metrics"]
    return (
        f"| {group['model']} | {group['policy']} | "
        f"{metrics['answer_accuracy_on_answerable']:.2f} | "
        f"{metrics['joint_success_rate']:.2f} | "
        f"{metrics['evidence_removal_sensitivity']:.2f} | "
        f"{metrics['noise_robustness']:.2f} | "
        f"{metrics['conflict_sensitivity']:.2f} | "
        f"{metrics['quartet_consistency_score']:.2f} | "
        f"{metrics['unsupported_answer_rate_insufficient']:.2f} | "
        f"{metrics['conflict_blind_answer_rate']:.2f} | "
        f"{metrics['avg_calls']:.2f} | {metrics['avg_token_count']:.2f} |"
    )


def write_table(path: Path, groups: list[dict[str, Any]]) -> None:
    lines = [
        "| Model | Policy | Ans | Joint | ERS | NR | CS | QCS | Insuff.Ans | Conf.Ans | Calls | Tokens |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    lines.extend(metric_row(group) for group in groups)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def usage_summary(rows: list[dict[str, Any]], model: str) -> dict[str, Any]:
    input_tokens = sum(int(row.get("input_tokens", 0) or 0) for row in rows)
    output_tokens = sum(int(row.get("output_tokens", 0) or 0) for row in rows)
    thinking_tokens = sum(int(row.get("thinking_tokens", 0) or 0) for row in rows)
    total_tokens = sum(int(row.get("total_tokens", 0) or 0) for row in rows)
    calls = sum(int(row.get("calls", 0) or 0) for row in rows)
    latency_ms = sum(float(row.get("latency_ms", 0) or 0) for row in rows)
    pricing = MODEL_PRICING_USD_PER_MILLION.get(model)
    estimated_cost_usd = estimate_cost_usd(model, input_tokens, output_tokens, thinking_tokens)
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "thinking_tokens": thinking_tokens,
        "total_tokens": total_tokens,
        "calls": calls,
        "latency_ms": latency_ms,
        "estimated_cost_usd": estimated_cost_usd,
        "pricing": pricing,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--predictions", type=Path, nargs="+", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--table-out", type=Path, default=DEFAULT_TABLE)
    args = parser.parse_args()

    dataset = load_jsonl(args.dataset)
    dataset_hash = hashlib.sha256(args.dataset.read_bytes()).hexdigest()
    dataset_version = dataset[0].get("dataset_version", "unversioned") if dataset else "unversioned"
    examples = {row["id"]: row for row in dataset}
    rows = latest_rows([
        row
        for prediction_path in args.predictions
        for row in load_jsonl(prediction_path)
    ])
    if dataset_version != "unversioned":
        mismatched = [
            row.get("example_id", "")
            for row in rows
            if row.get("dataset_sha256") != dataset_hash
        ]
        if mismatched:
            raise SystemExit(
                f"Prediction file contains {len(mismatched)} rows from a different or missing dataset hash"
            )
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row.get("provider", ""), row.get("model", ""), row.get("policy", ""))].append(row)

    results = []
    for (provider, model, policy), group_rows in sorted(grouped.items()):
        covered_rows = [row for row in group_rows if row.get("example_id") in examples]
        covered_ids = {row["example_id"] for row in covered_rows}
        covered_data = [row for row in dataset if row["id"] in covered_ids]
        predictions = [adapt_prediction(row, examples[row["example_id"]]) for row in covered_rows]
        metrics = evaluate(covered_data, predictions)
        parse_errors = sum(bool(row.get("parse_error")) for row in covered_rows)
        results.append({
            "provider": provider,
            "model": model,
            "policy": policy,
            "n_dataset_examples": len(dataset),
            "n_evaluated_examples": len(covered_data),
            "coverage": len(covered_data) / len(dataset) if dataset else 0.0,
            "parse_error_count": parse_errors,
            "parse_error_rate": parse_errors / len(covered_rows) if covered_rows else 0.0,
            "usage": usage_summary(covered_rows, model),
            "metrics": metrics,
        })

    output = {
        "dataset": str(args.dataset),
        "dataset_version": dataset_version,
        "dataset_sha256": dataset_hash,
        "predictions": [str(path) for path in args.predictions],
        "groups": results,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_table(args.table_out, results)
    print(f"Wrote {len(results)} metric groups to {args.out}")
    print(f"Wrote paper table to {args.table_out}")


if __name__ == "__main__":
    main()
