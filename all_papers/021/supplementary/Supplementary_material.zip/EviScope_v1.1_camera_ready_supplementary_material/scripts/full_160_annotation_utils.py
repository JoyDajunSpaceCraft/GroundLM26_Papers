#!/usr/bin/env python3
"""Shared helpers for full-160 EviScope human annotation workflows."""

from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


CONDITIONS = ("sufficient", "noisy", "insufficient", "conflicting")
DOC_ALIASES = ("A", "B", "C", "D")
ANNOTATOR_LABELS = ("A", "B")

HUMAN_EVIDENCE_STATUS = {"", "sufficient", "insufficient", "conflicting", "ambiguous"}
HUMAN_EXPECTED_BEHAVIOR = {"", "answer", "abstain", "flag_conflict"}
HUMAN_ANSWER_VALID = {"", "yes", "no", "unclear"}
HUMAN_CITATION_VALID = {"", "yes", "no", "not_applicable", "unclear"}
HUMAN_CONFLICT_PRESENT = {"", "yes", "no", "unclear"}

VISIBLE_FIELDS = [
    "annotation_id",
    "sample_id",
    "quartet_id",
    "question",
    "doc_a_id",
    "doc_a_text",
    "doc_b_id",
    "doc_b_text",
    "doc_c_id",
    "doc_c_text",
    "doc_d_id",
    "doc_d_text",
    "human_evidence_status",
    "human_expected_behavior",
    "human_answer_valid",
    "human_citation_valid",
    "human_conflict_present",
    "human_notes",
]

GOLD_FIELDS = [
    "annotation_id",
    "sample_id",
    "quartet_id",
    "raw_sample_id",
    "raw_base_id",
    "condition",
    "expected_answer",
    "expected_behavior",
    "expected_support_doc_ids",
    "expected_conflict_doc_ids",
    "expected_support_span",
    "dataset_version",
    "validation_status",
    "document_randomization_mapping",
]

AUDIT_FIELDS = [
    "annotation_id",
    "sample_id",
    "quartet_id",
    "raw_sample_id",
    "raw_base_id",
    "condition",
    "question",
    "expected_answer",
    "expected_behavior",
    "expected_support_doc_ids",
    "expected_conflict_doc_ids",
    "expected_support_span",
    "documents_json",
    "dataset_version",
    "validation_status",
]

COMPLETED_REQUIRED_FIELDS = [
    "human_evidence_status",
    "human_expected_behavior",
    "human_answer_valid",
    "human_citation_valid",
    "human_conflict_present",
]

FORBIDDEN_VISIBLE_COLUMNS = {
    "condition",
    "expected_answer",
    "expected_behavior",
    "expected_action",
    "expected_support_doc_ids",
    "expected_conflict_doc_ids",
    "expected_support_span",
    "gold_answer",
    "gold_expected_action",
    "gold_support_doc_ids",
    "gold_conflict_doc_ids",
    "source_type",
    "raw_sample_id",
    "raw_base_id",
}


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def load_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def dataset_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize_behavior(action: str) -> str:
    return "flag_conflict" if action == "flag_conflict" else action


def join_ids(values: list[str]) -> str:
    return "|".join(values)


def split_ids(value: str) -> set[str]:
    return {item.strip() for item in re.split(r"[|,;\\s]+", value or "") if item.strip()}


def join_spans(values: list[dict[str, str]]) -> str:
    return " || ".join(span.get("text", "") for span in values if span.get("text"))


def grouped_quartets(dataset: list[dict[str, Any]]) -> dict[str, dict[str, dict[str, Any]]]:
    grouped: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for example in dataset:
        grouped[example["base_id"]][example["condition"]] = example
    return dict(grouped)


def benchmark_completeness(dataset: list[dict[str, Any]]) -> dict[str, Any]:
    grouped = grouped_quartets(dataset)
    ids = [row["id"] for row in dataset]
    issues: list[str] = []
    if len(dataset) != 160:
        issues.append(f"expected 160 samples, found {len(dataset)}")
    if len(grouped) != 40:
        issues.append(f"expected 40 quartets, found {len(grouped)}")
    duplicates = sorted(item for item, count in Counter(ids).items() if count > 1)
    if duplicates:
        issues.append(f"duplicate sample ids: {duplicates}")
    malformed_quartets = {}
    for base_id, variants in grouped.items():
        observed = sorted(variants)
        if observed != sorted(CONDITIONS):
            malformed_quartets[base_id] = observed
    if malformed_quartets:
        issues.append(f"malformed quartets: {malformed_quartets}")
    top_schema_count = len({tuple(sorted(row.keys())) for row in dataset})
    gold_schema_count = len({tuple(sorted(row.get("gold", {}).keys())) for row in dataset})
    if top_schema_count != 1:
        issues.append(f"inconsistent top-level schemas: {top_schema_count}")
    if gold_schema_count != 1:
        issues.append(f"inconsistent gold schemas: {gold_schema_count}")
    for row in dataset:
        if row.get("condition") not in CONDITIONS:
            issues.append(f"{row.get('id')} has invalid condition {row.get('condition')}")
        if len(row.get("documents", [])) > len(DOC_ALIASES):
            issues.append(f"{row.get('id')} has more than {len(DOC_ALIASES)} documents")
        if not row.get("question"):
            issues.append(f"{row.get('id')} has empty question")
        if not row.get("gold", {}).get("expected_action"):
            issues.append(f"{row.get('id')} has no gold expected_action")
    last40 = dataset[-40:]
    return {
        "n_samples": len(dataset),
        "n_quartets": len(grouped),
        "condition_counts": dict(Counter(row.get("condition") for row in dataset)),
        "doc_count_distribution": dict(Counter(len(row.get("documents", [])) for row in dataset)),
        "top_schema_count": top_schema_count,
        "gold_schema_count": gold_schema_count,
        "duplicate_sample_ids": duplicates,
        "malformed_quartets": malformed_quartets,
        "last_40": {
            "n_samples": len(last40),
            "condition_counts": dict(Counter(row.get("condition") for row in last40)),
            "doc_count_distribution": dict(Counter(len(row.get("documents", [])) for row in last40)),
            "sample_ids": [row["id"] for row in last40],
            "base_ids": sorted({row["base_id"] for row in last40}),
        },
        "issues": issues,
        "clean": not issues,
    }


def gold_index(path: Path) -> dict[str, dict[str, str]]:
    rows = load_csv_rows(path)
    seen: dict[str, dict[str, str]] = {}
    for row in rows:
        annotation_id = row.get("annotation_id", "").strip()
        if not annotation_id or annotation_id in seen:
            raise ValueError(f"Missing or duplicate annotation_id={annotation_id!r} in {path}")
        seen[annotation_id] = row
    return seen


def cohens_kappa(first: list[str], second: list[str]) -> float:
    if len(first) != len(second) or not first:
        return 0.0
    observed = sum(a == b for a, b in zip(first, second)) / len(first)
    first_counts = Counter(first)
    second_counts = Counter(second)
    labels = set(first_counts) | set(second_counts)
    expected = sum(first_counts[label] * second_counts[label] for label in labels) / (len(first) ** 2)
    if expected == 1.0:
        return 1.0 if observed == 1.0 else 0.0
    return (observed - expected) / (1 - expected)

