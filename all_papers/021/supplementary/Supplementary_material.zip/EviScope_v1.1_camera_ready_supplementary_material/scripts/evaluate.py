#!/usr/bin/env python3
"""Evaluate EviScope predictions."""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path


def normalize(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def load_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def exact_or_alias(answer: str, aliases: list[str]) -> bool:
    norm_answer = normalize(answer)
    return any(normalize(alias) == norm_answer or normalize(alias) in norm_answer for alias in aliases)


def f1(precision: float, recall: float) -> float:
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def infer_action(pred: dict) -> str:
    action = pred.get("action")
    if action in {"answer", "abstain", "flag_conflict"}:
        return action
    if pred.get("abstained", False):
        return "abstain"
    return "answer"


def span_match(pred_span: dict, gold_span: dict) -> bool:
    if pred_span.get("doc_id") != gold_span.get("doc_id"):
        return False
    p_text = normalize(pred_span.get("text", ""))
    g_text = normalize(gold_span.get("text", ""))
    if not p_text or not g_text:
        return False
    return p_text in g_text or g_text in p_text


def span_scores(pred_spans: list[dict], gold_spans: list[dict]) -> tuple[int, int, int]:
    if not pred_spans and not gold_spans:
        return 0, 0, 0
    matched_gold = set()
    true_positive = 0
    for pred in pred_spans:
        for i, gold in enumerate(gold_spans):
            if i in matched_gold:
                continue
            if span_match(pred, gold):
                matched_gold.add(i)
                true_positive += 1
                break
    return true_positive, len(pred_spans), len(gold_spans)


def safe_div(num: float, denom: float) -> float:
    return num / denom if denom else 0.0


def paired_metrics(rows: list[dict]) -> dict:
    """Compute metrics that depend on paired evidence interventions."""
    grouped: dict[str, dict[str, dict]] = defaultdict(dict)
    for row in rows:
        base_id = row.get("base_id")
        condition = row.get("condition")
        if base_id and condition:
            grouped[base_id][condition] = row

    complete = {
        base_id: variants
        for base_id, variants in grouped.items()
        if {"sufficient", "noisy", "insufficient", "conflicting"}.issubset(variants)
    }
    n = len(complete)
    if n == 0:
        return {
            "n_quartets": 0,
            "evidence_removal_sensitivity": 0.0,
            "noise_robustness": 0.0,
            "noise_source_robustness": 0.0,
            "conflict_sensitivity": 0.0,
            "quartet_consistency_score": 0.0,
            "answer_to_abstain_after_removal": 0.0,
            "answer_to_conflict_after_insertion": 0.0,
            "answer_stability_after_distractor": 0.0,
        }

    counts = Counter()
    for variants in complete.values():
        sufficient = variants["sufficient"]
        noisy = variants["noisy"]
        insufficient = variants["insufficient"]
        conflicting = variants["conflicting"]

        s_success = sufficient["correct_answer"] and sufficient["source_correct"]
        n_success = noisy["correct_answer"] and noisy["source_correct"]
        i_success = insufficient["action"] == "abstain"
        c_success = conflicting["action"] == "flag_conflict"

        counts["evidence_removal_sensitivity"] += int(s_success and i_success)
        counts["noise_robustness"] += int(sufficient["correct_answer"] and noisy["correct_answer"])
        counts["noise_source_robustness"] += int(sufficient["source_correct"] and noisy["source_correct"])
        counts["conflict_sensitivity"] += int(s_success and c_success)
        counts["quartet_consistency_score"] += int(s_success and n_success and i_success and c_success)
        if sufficient["action"] == "answer":
            counts["sufficient_answer_actions"] += 1
            counts["answer_to_abstain_after_removal"] += int(insufficient["action"] == "abstain")
            counts["answer_to_conflict_after_insertion"] += int(conflicting["action"] == "flag_conflict")
            counts["answer_stability_after_distractor"] += int(noisy["action"] == "answer")

    return {
        "n_quartets": n,
        "evidence_removal_sensitivity": counts["evidence_removal_sensitivity"] / n,
        "noise_robustness": counts["noise_robustness"] / n,
        "noise_source_robustness": counts["noise_source_robustness"] / n,
        "conflict_sensitivity": counts["conflict_sensitivity"] / n,
        "quartet_consistency_score": counts["quartet_consistency_score"] / n,
        "answer_to_abstain_after_removal": safe_div(
            counts["answer_to_abstain_after_removal"], counts["sufficient_answer_actions"]
        ),
        "answer_to_conflict_after_insertion": safe_div(
            counts["answer_to_conflict_after_insertion"], counts["sufficient_answer_actions"]
        ),
        "answer_stability_after_distractor": safe_div(
            counts["answer_stability_after_distractor"], counts["sufficient_answer_actions"]
        ),
    }


def evaluate(data: list[dict], predictions: list[dict], strict_spans: bool = False) -> dict:
    pred_by_id = {p["id"]: p for p in predictions}
    totals = Counter()
    by_condition = defaultdict(Counter)
    missing = []
    paired_rows = []

    for ex in data:
        ex_id = ex["id"]
        gold = ex["gold"]
        pred = pred_by_id.get(ex_id)
        if pred is None:
            missing.append(ex_id)
            pred = {
                "answer": "",
                "citations": [],
                "support_spans": [],
                "abstained": True,
                "action": "abstain",
                "token_count": 0,
                "latency_ms": 0,
                "calls": 0,
            }

        condition = ex["condition"]
        answerable = gold["answerable_from_context"]
        expected_action = gold.get("expected_action") or ("answer" if answerable else "abstain")
        expected_abstain = gold.get("expected_abstain", expected_action in {"abstain", "flag_conflict"})
        action = infer_action(pred)
        abstained = action in {"abstain", "flag_conflict"} or bool(pred.get("abstained", False))
        citations = set(pred.get("citations", []))
        support = set(gold.get("supporting_doc_ids", []))
        conflicts = set(gold.get("conflicting_doc_ids", []))
        allowed_evidence = support | conflicts

        correct_answer = expected_action == "answer" and (action == "answer") and exact_or_alias(pred.get("answer", ""), gold["aliases"])
        source_correct = False
        if expected_action == "answer" and action == "answer":
            source_correct = bool(support) and support.issubset(citations)

        correct_abstain = expected_action == "abstain" and action == "abstain"
        correct_flag_conflict = expected_action == "flag_conflict" and action == "flag_conflict"
        hallucinated = expected_abstain and action == "answer"
        joint_success = (expected_action == "answer" and correct_answer and source_correct) or correct_abstain or correct_flag_conflict
        right_answer_wrong_source = correct_answer and not source_correct
        right_source_wrong_answer = source_correct and not correct_answer
        unsupported_citation = bool(citations - allowed_evidence) if citations else False
        cited_conflict = bool(conflicts & citations)
        span_tp, span_pred, span_gold = span_scores(pred.get("support_spans", []), gold.get("support_spans", []))

        totals["n"] += 1
        totals["answerable"] += int(expected_action == "answer")
        totals["expected_abstain"] += int(expected_abstain)
        totals["expected_conflict"] += int(expected_action == "flag_conflict")
        totals["abstained"] += int(abstained)
        totals["correct_answer"] += int(correct_answer)
        totals["source_correct"] += int(source_correct)
        totals["correct_abstain"] += int(correct_abstain)
        totals["correct_flag_conflict"] += int(correct_flag_conflict)
        totals["hallucinated_when_should_abstain"] += int(hallucinated)
        totals["unsupported_answer_insufficient"] += int(condition == "insufficient" and action == "answer")
        totals["conflict_blind_answer"] += int(condition == "conflicting" and action == "answer")
        totals["joint_success"] += int(joint_success)
        totals["right_answer_wrong_source"] += int(right_answer_wrong_source)
        totals["right_source_wrong_answer"] += int(right_source_wrong_answer)
        totals["unsupported_citation"] += int(unsupported_citation)
        totals["span_tp"] += span_tp
        totals["span_pred"] += span_pred
        totals["span_gold"] += span_gold
        totals["token_count"] += int(pred.get("token_count", 0) or 0)
        totals["calls"] += int(pred.get("calls", 0) or 0)
        totals["latency_ms"] += float(pred.get("latency_ms", 0) or 0)
        totals["cited_conflict_doc"] += int(cited_conflict)
        paired_rows.append(
            {
                "id": ex_id,
                "base_id": ex.get("base_id"),
                "condition": condition,
                "action": action,
                "correct_answer": correct_answer,
                "source_correct": source_correct,
                "correct_abstain": correct_abstain,
                "correct_flag_conflict": correct_flag_conflict,
                "joint_success": joint_success,
            }
        )

        by_condition[condition]["n"] += 1
        by_condition[condition]["answerable"] += int(expected_action == "answer")
        by_condition[condition]["expected_abstain"] += int(expected_abstain)
        by_condition[condition]["expected_conflict"] += int(expected_action == "flag_conflict")
        by_condition[condition]["abstained"] += int(abstained)
        by_condition[condition]["correct_answer"] += int(correct_answer)
        by_condition[condition]["source_correct"] += int(source_correct)
        by_condition[condition]["correct_abstain"] += int(correct_abstain)
        by_condition[condition]["correct_flag_conflict"] += int(correct_flag_conflict)
        by_condition[condition]["hallucinated_when_should_abstain"] += int(hallucinated)
        by_condition[condition]["unsupported_answer_insufficient"] += int(
            condition == "insufficient" and action == "answer"
        )
        by_condition[condition]["conflict_blind_answer"] += int(
            condition == "conflicting" and action == "answer"
        )
        by_condition[condition]["joint_success"] += int(joint_success)
        by_condition[condition]["right_answer_wrong_source"] += int(right_answer_wrong_source)
        by_condition[condition]["right_source_wrong_answer"] += int(right_source_wrong_answer)
        by_condition[condition]["unsupported_citation"] += int(unsupported_citation)
        by_condition[condition]["span_tp"] += span_tp
        by_condition[condition]["span_pred"] += span_pred
        by_condition[condition]["span_gold"] += span_gold

    n = totals["n"] or 1
    answerable_n = totals["answerable"] or 1
    abstain_gold = totals["expected_abstain"] or 1
    abstain_pred = totals["abstained"] or 1

    abstain_precision = totals["correct_abstain"] / abstain_pred
    abstain_recall = totals["correct_abstain"] / abstain_gold
    conflict_gold = totals["expected_conflict"] or 1
    conflict_handling_accuracy = totals["correct_flag_conflict"] / conflict_gold
    span_precision = totals["span_tp"] / (totals["span_pred"] or 1)
    span_recall = totals["span_tp"] / (totals["span_gold"] or 1)
    avg_calls = totals["calls"] / n
    avg_tokens = totals["token_count"] / n
    joint_success_rate = totals["joint_success"] / n
    paired = paired_metrics(paired_rows)

    result = {
        "n_examples": totals["n"],
        **paired,
        "missing_predictions": missing,
        "answer_accuracy_on_answerable": totals["correct_answer"] / answerable_n,
        "source_accuracy_on_answerable": totals["source_correct"] / answerable_n,
        "abstention_precision": abstain_precision,
        "abstention_recall": abstain_recall,
        "abstention_f1": f1(abstain_precision, abstain_recall),
        "conflict_handling_accuracy": conflict_handling_accuracy,
        "hallucination_rate_when_should_abstain": totals["hallucinated_when_should_abstain"] / abstain_gold,
        "unsupported_answer_rate_insufficient": safe_div(
            totals["unsupported_answer_insufficient"], by_condition["insufficient"]["n"]
        ),
        "conflict_blind_answer_rate": safe_div(
            totals["conflict_blind_answer"], by_condition["conflicting"]["n"]
        ),
        "joint_success_rate": joint_success_rate,
        "right_answer_wrong_source_rate": totals["right_answer_wrong_source"] / answerable_n,
        "right_source_wrong_answer_rate": totals["right_source_wrong_answer"] / answerable_n,
        "unsupported_citation_rate": totals["unsupported_citation"] / n,
        "span_support_precision": span_precision,
        "span_support_recall": span_recall,
        "span_support_f1": f1(span_precision, span_recall),
        "grounded_utility_per_call": safe_div(joint_success_rate, avg_calls),
        "quartet_utility_per_call": safe_div(paired["quartet_consistency_score"], avg_calls),
        "cost_adjusted_joint_success_log_tokens": safe_div(joint_success_rate, math.log1p(avg_tokens)),
        "strict_spans": strict_spans,
        "avg_token_count": avg_tokens,
        "avg_calls": avg_calls,
        "avg_latency_ms": totals["latency_ms"] / n,
        "cited_conflict_doc_count": totals["cited_conflict_doc"],
        "by_condition": {},
    }

    for condition, c in sorted(by_condition.items()):
        cn = c["n"] or 1
        ca = c["answerable"] or 1
        cg = c["expected_abstain"] or 1
        cc = c["expected_conflict"] or 1
        cp = c["span_tp"] / (c["span_pred"] or 1)
        cr = c["span_tp"] / (c["span_gold"] or 1)
        result["by_condition"][condition] = {
            "n": c["n"],
            "answer_accuracy_on_answerable": c["correct_answer"] / ca,
            "source_accuracy_on_answerable": c["source_correct"] / ca,
            "correct_abstention_rate": c["correct_abstain"] / cg,
            "conflict_handling_accuracy": c["correct_flag_conflict"] / cc,
            "hallucination_rate_when_should_abstain": c["hallucinated_when_should_abstain"] / cg,
            "unsupported_answer_rate_insufficient": c["unsupported_answer_insufficient"] / cn,
            "conflict_blind_answer_rate": c["conflict_blind_answer"] / cn,
            "joint_success_rate": c["joint_success"] / cn,
            "right_answer_wrong_source_rate": c["right_answer_wrong_source"] / ca,
            "right_source_wrong_answer_rate": c["right_source_wrong_answer"] / ca,
            "unsupported_citation_rate": c["unsupported_citation"] / cn,
            "span_support_precision": cp,
            "span_support_recall": cr,
            "span_support_f1": f1(cp, cr),
        }

    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "eviscope_v0.jsonl")
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--strict-spans", action="store_true")
    args = parser.parse_args()

    data = load_jsonl(args.data)
    preds = load_jsonl(args.predictions)
    result = evaluate(data, preds, strict_spans=args.strict_spans)
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text + "\n", encoding="utf-8")


ROOT = Path(__file__).resolve().parents[1]


if __name__ == "__main__":
    main()
