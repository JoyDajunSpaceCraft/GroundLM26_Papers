#!/usr/bin/env python3
"""Compute A/B agreement for full-160 EviScope human annotations."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

from full_160_annotation_utils import (
    COMPLETED_REQUIRED_FIELDS,
    cohens_kappa,
    gold_index,
    load_csv_rows,
    split_ids,
)


CATEGORICAL_FIELDS = [
    "human_evidence_status",
    "human_expected_behavior",
    "human_answer_valid",
    "human_citation_valid",
    "human_conflict_present",
]

FIELD_LABELS = {
    "human_evidence_status": "Evidence status",
    "human_expected_behavior": "Expected behavior",
    "human_answer_valid": "Answer valid",
    "human_citation_valid": "Citation valid",
    "human_conflict_present": "Conflict present",
}


def gold_evidence_status(gold_row: dict[str, str]) -> str:
    if gold_row["condition"] in {"sufficient", "noisy"}:
        return "sufficient"
    if gold_row["condition"] == "insufficient":
        return "insufficient"
    if gold_row["condition"] == "conflicting":
        return "conflicting"
    return ""


def rows_by_id(path: Path) -> dict[str, dict[str, str]]:
    rows = {}
    for row in load_csv_rows(path):
        annotation_id = row.get("annotation_id", "").strip()
        if not annotation_id or annotation_id in rows:
            raise SystemExit(f"{path} has missing or duplicate annotation_id={annotation_id!r}")
        rows[annotation_id] = row
    return rows


def annotator_label(path: Path, index: int) -> str:
    stem = path.stem.lower()
    if "annotator_a" in stem or stem.endswith("_a") or stem.endswith("_a_completed"):
        return "A"
    if "annotator_b" in stem or stem.endswith("_b") or stem.endswith("_b_completed"):
        return "B"
    return ("A", "B")[index]


def load_mapping(gold_row: dict[str, str], label: str) -> dict[str, str]:
    mapping = json.loads(gold_row["document_randomization_mapping"])
    return {alias.upper(): doc_id for alias, doc_id in mapping[label].items()}


def canonical_doc_set(value: str, gold_row: dict[str, str], label: str) -> set[str]:
    aliases = {item.upper() for item in split_ids(value)}
    mapping = load_mapping(gold_row, label)
    invalid = sorted(aliases - set(mapping))
    if invalid:
        raise SystemExit(f"{gold_row['annotation_id']} annotator {label} uses unknown doc aliases {invalid}")
    return {mapping[alias] for alias in aliases}


def rate(matches: int, total: int) -> float:
    return matches / total if total else 0.0


def field_agreement(rows_a: dict[str, dict[str, str]], rows_b: dict[str, dict[str, str]], ids: list[str], field: str) -> dict[str, Any]:
    values_a = [rows_a[item].get(field, "").strip() for item in ids]
    values_b = [rows_b[item].get(field, "").strip() for item in ids]
    return {
        "percent_agreement": rate(sum(a == b for a, b in zip(values_a, values_b)), len(ids)),
        "cohens_kappa": cohens_kappa(values_a, values_b),
    }


def gold_alignment(
    *,
    gold_rows: dict[str, dict[str, str]],
    rows: dict[str, dict[str, str]],
    ids: list[str],
) -> dict[str, Any]:
    behavior_gold = [gold_rows[item]["expected_behavior"] for item in ids]
    behavior_pred = [rows[item].get("human_expected_behavior", "").strip() for item in ids]
    evidence_gold = [gold_evidence_status(gold_rows[item]) for item in ids]
    evidence_pred = [rows[item].get("human_evidence_status", "").strip() for item in ids]
    conflict_ids = [item for item in ids if gold_rows[item]["condition"] == "conflicting"]
    conflict_gold = ["yes" for _ in conflict_ids]
    conflict_pred = [rows[item].get("human_conflict_present", "").strip() for item in conflict_ids]
    all_conflict_gold = ["yes" if gold_rows[item]["condition"] == "conflicting" else "no" for item in ids]
    all_conflict_pred = [rows[item].get("human_conflict_present", "").strip() for item in ids]
    return {
        "expected_behavior": {
            "percent_agreement": rate(sum(a == b for a, b in zip(behavior_gold, behavior_pred)), len(ids)),
            "cohens_kappa": cohens_kappa(behavior_gold, behavior_pred),
        },
        "evidence_status": {
            "percent_agreement": rate(sum(a == b for a, b in zip(evidence_gold, evidence_pred)), len(ids)),
            "cohens_kappa": cohens_kappa(evidence_gold, evidence_pred),
        },
        "conflict_present_on_conflict_rows": {
            "percent_agreement": rate(sum(a == b for a, b in zip(conflict_gold, conflict_pred)), len(conflict_ids)),
            "n": len(conflict_ids),
        },
        "conflict_present_all_rows": {
            "percent_agreement": rate(sum(a == b for a, b in zip(all_conflict_gold, all_conflict_pred)), len(ids)),
            "cohens_kappa": cohens_kappa(all_conflict_gold, all_conflict_pred),
        },
    }


def doc_agreement(
    *,
    gold_rows: dict[str, dict[str, str]],
    rows_a: dict[str, dict[str, str]],
    rows_b: dict[str, dict[str, str]],
    ids: list[str],
    field: str,
    label_a: str,
    label_b: str,
) -> float:
    matches = 0
    for annotation_id in ids:
        docs_a = canonical_doc_set(rows_a[annotation_id].get(field, ""), gold_rows[annotation_id], label_a)
        docs_b = canonical_doc_set(rows_b[annotation_id].get(field, ""), gold_rows[annotation_id], label_b)
        matches += int(docs_a == docs_b)
    return rate(matches, len(ids))


def disagreement_rows(
    *,
    gold_rows: dict[str, dict[str, str]],
    rows_a: dict[str, dict[str, str]],
    rows_b: dict[str, dict[str, str]],
    ids: list[str],
    label_a: str,
    label_b: str,
) -> list[dict[str, str]]:
    rows = []
    for annotation_id in ids:
        gold = gold_rows[annotation_id]
        a = rows_a[annotation_id]
        b = rows_b[annotation_id]
        fields = []
        for field in CATEGORICAL_FIELDS:
            if a.get(field, "").strip() != b.get(field, "").strip():
                fields.append(field)
        if fields:
            rows.append({
                "annotation_id": annotation_id,
                "sample_id": gold["sample_id"],
                "quartet_id": gold["quartet_id"],
                "raw_sample_id": gold["raw_sample_id"],
                "raw_base_id": gold["raw_base_id"],
                "condition": gold["condition"],
                "question": a.get("question", ""),
                "disagreement_fields": "|".join(fields),
                "annotator_A_values": json.dumps({field: a.get(field, "") for field in fields}, sort_keys=True),
                "annotator_B_values": json.dumps({field: b.get(field, "") for field in fields}, sort_keys=True),
                "gold_expected_behavior": gold["expected_behavior"],
                "adjudicated_human_evidence_status": "",
                "adjudicated_human_expected_behavior": "",
                "adjudicated_human_answer_valid": "",
                "adjudicated_human_citation_valid": "",
                "adjudicated_human_conflict_present": "",
                "adjudication_notes": "",
            })
    return rows


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    fields = [
        "annotation_id",
        "sample_id",
        "quartet_id",
        "raw_sample_id",
        "raw_base_id",
        "condition",
        "question",
        "disagreement_fields",
        "annotator_A_values",
        "annotator_B_values",
        "gold_expected_behavior",
        "adjudicated_human_evidence_status",
        "adjudicated_human_expected_behavior",
        "adjudicated_human_answer_valid",
        "adjudicated_human_citation_valid",
        "adjudicated_human_conflict_present",
        "adjudication_notes",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_adjudication_template(
    path: Path,
    *,
    gold_rows: dict[str, dict[str, str]],
    rows_a: dict[str, dict[str, str]],
    rows_b: dict[str, dict[str, str]],
    ids: list[str],
) -> None:
    fields = [
        "annotation_id",
        "sample_id",
        "quartet_id",
        "raw_sample_id",
        "raw_base_id",
        "condition",
        "question",
        "disagreement_fields",
        "annotator_A_values",
        "annotator_B_values",
        "gold_expected_behavior",
        "adjudicated_human_evidence_status",
        "adjudicated_human_expected_behavior",
        "adjudicated_human_answer_valid",
        "adjudicated_human_citation_valid",
        "adjudicated_human_conflict_present",
        "adjudication_notes",
    ]
    output = []
    for annotation_id in ids:
        gold = gold_rows[annotation_id]
        a = rows_a[annotation_id]
        b = rows_b[annotation_id]
        disagreement_fields = [
            field for field in CATEGORICAL_FIELDS
            if a.get(field, "").strip() != b.get(field, "").strip()
        ]
        agreed = not disagreement_fields
        output.append({
            "annotation_id": annotation_id,
            "sample_id": gold["sample_id"],
            "quartet_id": gold["quartet_id"],
            "raw_sample_id": gold["raw_sample_id"],
            "raw_base_id": gold["raw_base_id"],
            "condition": gold["condition"],
            "question": a.get("question", ""),
            "disagreement_fields": "|".join(disagreement_fields),
            "annotator_A_values": json.dumps({field: a.get(field, "") for field in CATEGORICAL_FIELDS}, sort_keys=True),
            "annotator_B_values": json.dumps({field: b.get(field, "") for field in CATEGORICAL_FIELDS}, sort_keys=True),
            "gold_expected_behavior": gold["expected_behavior"],
            "adjudicated_human_evidence_status": a.get("human_evidence_status", "").strip() if agreed else "",
            "adjudicated_human_expected_behavior": a.get("human_expected_behavior", "").strip() if agreed else "",
            "adjudicated_human_answer_valid": a.get("human_answer_valid", "").strip() if agreed else "",
            "adjudicated_human_citation_valid": a.get("human_citation_valid", "").strip() if agreed else "",
            "adjudicated_human_conflict_present": a.get("human_conflict_present", "").strip() if agreed else "",
            "adjudication_notes": "prefilled_agreement" if agreed else "",
        })
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(output)


def write_tables(path_md: Path, path_tex: Path, output: dict[str, Any]) -> None:
    field = output["field_agreement"]
    gold = output["gold_alignment"]
    lines = [
        "| Validation set | Annotators | Evidence agr. | Behavior agr. | Conflict-present agr. | Gold behavior agr. | Gold evidence agr. |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
        (
            f"| Full EviScope-v1.1 (160 rows) | 2 | "
            f"{field['human_evidence_status']['percent_agreement']:.3f} | "
            f"{field['human_expected_behavior']['percent_agreement']:.3f} | "
            f"{field['human_conflict_present']['percent_agreement']:.3f} | "
            f"{gold['average']['expected_behavior']['percent_agreement']:.3f} | "
            f"{gold['average']['evidence_status']['percent_agreement']:.3f} |"
        ),
    ]
    path_md.parent.mkdir(parents=True, exist_ok=True)
    path_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    tex = (
        "% Generated by evaluate_full_160_agreement.py; do not edit manually.\n"
        "\\begin{table}[t]\n"
        "\\centering\n"
        "\\small\n"
        "\\begin{tabular}{lrrrr}\n"
        "\\toprule\n"
        "Set & Evidence & Behavior & Conflict & Gold behavior \\\\\n"
        "\\midrule\n"
        f"Full 160 & {field['human_evidence_status']['percent_agreement']:.3f} & "
        f"{field['human_expected_behavior']['percent_agreement']:.3f} & "
        f"{field['human_conflict_present']['percent_agreement']:.3f} & "
        f"{gold['average']['expected_behavior']['percent_agreement']:.3f} \\\\\n"
        "\\bottomrule\n"
        "\\end{tabular}\n"
        "\\caption{Full-dataset human validation agreement for EviScope-v1.1.}\n"
        "\\label{tab:human-validation}\n"
        "\\end{table}\n"
    )
    path_tex.write_text(tex, encoding="utf-8")


def average_gold_alignment(reports: dict[str, dict[str, Any]]) -> dict[str, Any]:
    keys = ("expected_behavior", "evidence_status", "conflict_present_on_conflict_rows", "conflict_present_all_rows")
    averaged: dict[str, Any] = {}
    for key in keys:
        values = [report[key]["percent_agreement"] for report in reports.values()]
        averaged[key] = {"percent_agreement": sum(values) / len(values) if values else 0.0}
        if all("cohens_kappa" in report[key] for report in reports.values()):
            kappas = [report[key]["cohens_kappa"] for report in reports.values()]
            averaged[key]["cohens_kappa"] = sum(kappas) / len(kappas) if kappas else 0.0
        if all("n" in report[key] for report in reports.values()):
            averaged[key]["n"] = reports[next(iter(reports))][key]["n"] if reports else 0
    return averaged


def evaluate(gold_path: Path, annotation_paths: list[Path], out: Path, disagreements: Path, table_out: Path | None = None, tex_out: Path | None = None) -> dict[str, Any]:
    if len(annotation_paths) != 2:
        raise SystemExit("Full-160 agreement currently expects exactly two annotator files")
    gold_rows = gold_index(gold_path)
    labels = [annotator_label(path, index) for index, path in enumerate(annotation_paths)]
    rows_a, rows_b = [rows_by_id(path) for path in annotation_paths]
    ids = sorted(set(gold_rows) & set(rows_a) & set(rows_b))
    missing = {
        labels[0]: sorted(set(gold_rows) - set(rows_a)),
        labels[1]: sorted(set(gold_rows) - set(rows_b)),
    }
    extra = {
        labels[0]: sorted(set(rows_a) - set(gold_rows)),
        labels[1]: sorted(set(rows_b) - set(gold_rows)),
    }
    field_scores = {
        field: field_agreement(rows_a, rows_b, ids, field)
        for field in CATEGORICAL_FIELDS
    }
    gold_reports = {
        labels[0]: gold_alignment(gold_rows=gold_rows, rows=rows_a, ids=ids),
        labels[1]: gold_alignment(gold_rows=gold_rows, rows=rows_b, ids=ids),
    }
    gold_reports["average"] = average_gold_alignment(gold_reports)
    support_ids = [item for item in ids if gold_rows[item]["condition"] in {"sufficient", "noisy"}]
    conflict_ids = [item for item in ids if gold_rows[item]["condition"] == "conflicting"]
    rows = disagreement_rows(
        gold_rows=gold_rows,
        rows_a=rows_a,
        rows_b=rows_b,
        ids=ids,
        label_a=labels[0],
        label_b=labels[1],
    )
    output = {
        "n_gold_rows": len(gold_rows),
        "n_common_rows": len(ids),
        "annotation_files": [str(path) for path in annotation_paths],
        "missing_annotation_ids": missing,
        "extra_annotation_ids": extra,
        "field_agreement": field_scores,
        "gold_alignment": gold_reports,
        "support_row_count": len(support_ids),
        "conflict_row_count": len(conflict_ids),
        "disagreement_count": len(rows),
        "note": (
            "Document-source agreement is represented by human_citation_valid in this full-160 schema. "
            "If future completed sheets add explicit human_support_doc_ids/human_conflict_doc_ids, "
            "extend this evaluator to canonicalize aliases against the hidden mapping."
        ),
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_csv(disagreements, rows)
    write_tables(
        table_out or out.with_name("agreement_table.md"),
        tex_out or out.with_name("agreement_table.tex"),
        output,
    )
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gold", type=Path, required=True)
    parser.add_argument("--annotations", type=Path, nargs=2, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--disagreements", type=Path, required=True)
    parser.add_argument("--adjudication-template", type=Path)
    parser.add_argument("--table-out", type=Path)
    parser.add_argument("--tex-out", type=Path)
    args = parser.parse_args()
    result = evaluate(args.gold, args.annotations, args.out, args.disagreements, args.table_out, args.tex_out)
    if args.adjudication_template:
        gold_rows = gold_index(args.gold)
        annotation_sets = [rows_by_id(path) for path in args.annotations]
        ids = sorted(set(gold_rows) & set(annotation_sets[0]) & set(annotation_sets[1]))
        write_adjudication_template(
            args.adjudication_template,
            gold_rows=gold_rows,
            rows_a=annotation_sets[0],
            rows_b=annotation_sets[1],
            ids=ids,
        )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
