#!/usr/bin/env python3
"""Validate full-160 EviScope annotation templates or completed sheets."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from full_160_annotation_utils import (
    COMPLETED_REQUIRED_FIELDS,
    CONDITIONS,
    FORBIDDEN_VISIBLE_COLUMNS,
    HUMAN_ANSWER_VALID,
    HUMAN_CITATION_VALID,
    HUMAN_CONFLICT_PRESENT,
    HUMAN_EVIDENCE_STATUS,
    HUMAN_EXPECTED_BEHAVIOR,
    VISIBLE_FIELDS,
    benchmark_completeness,
    gold_index,
    load_csv_rows,
    load_jsonl,
)


ALLOWED_BY_FIELD = {
    "human_evidence_status": HUMAN_EVIDENCE_STATUS,
    "human_expected_behavior": HUMAN_EXPECTED_BEHAVIOR,
    "human_answer_valid": HUMAN_ANSWER_VALID,
    "human_citation_valid": HUMAN_CITATION_VALID,
    "human_conflict_present": HUMAN_CONFLICT_PRESENT,
}


def validate_dataset(dataset: Path | None) -> dict:
    if dataset is None:
        return {}
    report = benchmark_completeness(load_jsonl(dataset))
    if report["issues"]:
        raise SystemExit("Dataset validation failed: " + "; ".join(report["issues"]))
    return report


def validate_gold(gold: Path) -> dict[str, dict[str, str]]:
    rows = gold_index(gold)
    if len(rows) != 160:
        raise SystemExit(f"{gold} must contain exactly 160 rows; found {len(rows)}")
    by_quartet: dict[str, list[str]] = defaultdict(list)
    for row in rows.values():
        by_quartet[row["quartet_id"]].append(row["condition"])
    if len(by_quartet) != 40:
        raise SystemExit(f"{gold} must contain 40 quartets; found {len(by_quartet)}")
    bad = {
        quartet: sorted(conditions)
        for quartet, conditions in by_quartet.items()
        if sorted(conditions) != sorted(CONDITIONS)
    }
    if bad:
        raise SystemExit(f"{gold} has malformed quartets: {bad}")
    return rows


def validate_annotation_file(path: Path, gold_rows: dict[str, dict[str, str]], require_complete: bool) -> dict:
    rows = load_csv_rows(path)
    errors: list[str] = []
    if len(rows) != 160:
        errors.append(f"expected 160 rows, found {len(rows)}")
    if not rows:
        errors.append("file has no rows")
        raise SystemExit(f"{path}: " + "; ".join(errors))
    missing_columns = sorted(set(VISIBLE_FIELDS) - set(rows[0]))
    if missing_columns:
        errors.append(f"missing required columns {missing_columns}")
    forbidden = sorted(FORBIDDEN_VISIBLE_COLUMNS & set(rows[0]))
    if forbidden:
        errors.append(f"contains forbidden gold/role columns {forbidden}")
    annotation_ids = [row.get("annotation_id", "").strip() for row in rows]
    duplicate_ids = sorted(item for item, count in Counter(annotation_ids).items() if count > 1)
    if duplicate_ids:
        errors.append(f"duplicate annotation_id values {duplicate_ids}")
    if set(annotation_ids) != set(gold_rows):
        missing = sorted(set(gold_rows) - set(annotation_ids))[:10]
        extra = sorted(set(annotation_ids) - set(gold_rows))[:10]
        errors.append(f"annotation IDs do not match gold; missing={missing}, extra={extra}")
    invalid_labels = []
    missing_required = []
    for row in rows:
        annotation_id = row.get("annotation_id", "").strip()
        for field, allowed in ALLOWED_BY_FIELD.items():
            value = row.get(field, "").strip()
            if value not in allowed:
                invalid_labels.append({"annotation_id": annotation_id, "field": field, "value": value})
        if require_complete:
            for field in COMPLETED_REQUIRED_FIELDS:
                if not row.get(field, "").strip():
                    missing_required.append({"annotation_id": annotation_id, "field": field})
        for alias in ("a", "b", "c", "d"):
            doc_id = row.get(f"doc_{alias}_id", "")
            if doc_id and doc_id not in {"A", "B", "C", "D"}:
                errors.append(f"{annotation_id} has non-neutral doc_{alias}_id={doc_id!r}")
    if invalid_labels:
        errors.append(f"invalid labels: {invalid_labels[:20]}")
    if missing_required:
        errors.append(f"missing required completed labels: {missing_required[:20]}")
    if errors:
        raise SystemExit(f"{path}: " + "; ".join(errors))
    return {
        "path": str(path),
        "rows": len(rows),
        "require_complete": require_complete,
        "valid": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path)
    parser.add_argument("--gold", type=Path, required=True)
    parser.add_argument("--annotations", type=Path, nargs="+", required=True)
    parser.add_argument("--require-complete", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    dataset_report = validate_dataset(args.dataset)
    gold_rows = validate_gold(args.gold)
    annotation_reports = [
        validate_annotation_file(path, gold_rows, args.require_complete)
        for path in args.annotations
    ]
    report = {
        "dataset": dataset_report,
        "gold_rows": len(gold_rows),
        "annotations": annotation_reports,
        "valid": True,
    }
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()

