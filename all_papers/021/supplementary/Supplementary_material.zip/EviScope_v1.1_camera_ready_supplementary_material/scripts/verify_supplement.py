#!/usr/bin/env python3
"""Validate the EviScope supplementary run files."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


EXPECTATIONS = {
    "qwen_vanilla.jsonl": ("qwen2.5:7b-instruct", "vanilla_rag"),
    "qwen_gate.jsonl": ("qwen2.5:7b-instruct", "evidence_action_gate"),
    "llama_vanilla.jsonl": ("llama3.1:8b", "vanilla_rag"),
    "llama_gate.jsonl": ("llama3.1:8b", "evidence_action_gate"),
    "gemini_vanilla.jsonl": ("gemini-3.5-flash", "vanilla_rag"),
    "gemini_gate.jsonl": ("gemini-3.5-flash", "evidence_action_gate"),
}

FORBIDDEN_ROW_KEYS = {
    "expected_action",
    "source_type",
    "gold",
    "gold_answer",
    "gold_support_docs",
    "gold_conflict_docs",
    "support_spans",
}

SECRET_MARKERS = ("AQ." + "Ab", "AI" + "za")


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    dataset_hash = hashlib.sha256(args.dataset.read_bytes()).hexdigest()
    report = {"dataset_sha256": dataset_hash, "runs": []}
    failures = []

    for path in args.runs:
        expected = EXPECTATIONS.get(path.name)
        if expected is None:
            failures.append(f"{path}: unexpected run filename")
            continue

        text = path.read_text(encoding="utf-8")
        rows = load_jsonl(path)
        models = sorted({row.get("model") for row in rows})
        policies = sorted({row.get("policy") for row in rows})
        providers = sorted({row.get("provider") for row in rows})
        hashes = sorted({row.get("dataset_sha256") for row in rows})
        parse_errors = sum(bool(row.get("parse_error")) for row in rows)
        forbidden_keys = sorted({key for row in rows for key in FORBIDDEN_ROW_KEYS if key in row})
        secret_marker_count = sum(text.count(marker) for marker in SECRET_MARKERS)

        run_report = {
            "path": str(path),
            "rows": len(rows),
            "models": models,
            "policies": policies,
            "providers": providers,
            "dataset_hashes": hashes,
            "parse_errors": parse_errors,
            "forbidden_top_level_keys": forbidden_keys,
            "secret_marker_count": secret_marker_count,
        }
        report["runs"].append(run_report)

        expected_model, expected_policy = expected
        if len(rows) != 160:
            failures.append(f"{path}: expected 160 rows, found {len(rows)}")
        if models != [expected_model] or policies != [expected_policy]:
            failures.append(f"{path}: unexpected model or policy")
        if hashes != [dataset_hash]:
            failures.append(f"{path}: dataset hash mismatch")
        if parse_errors or forbidden_keys or secret_marker_count:
            failures.append(f"{path}: integrity or privacy checks failed")

    report["passed"] = not failures
    report["failures"] = failures
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("; ".join(failures))
    print(f"Verified {len(args.runs)} supplementary run files into {args.out}")


if __name__ == "__main__":
    main()
