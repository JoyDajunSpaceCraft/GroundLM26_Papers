#!/usr/bin/env python3
"""Paired quartet statistics and qualitative failures for EviScope LLM runs."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
from collections import defaultdict
from pathlib import Path
from typing import Any

from evaluate import exact_or_alias
from evaluate_llm_runs import adapt_prediction, latest_rows, load_jsonl


ROOT = Path(__file__).resolve().parents[1]
CONDITIONS = ("sufficient", "noisy", "insufficient", "conflicting")
METRICS = ("ers", "nr", "cs", "qcs")


def example_outcome(example: dict[str, Any], prediction: dict[str, Any]) -> dict[str, Any]:
    action = prediction["action"]
    answer_correct = action == "answer" and exact_or_alias(
        prediction.get("answer", ""), example["gold"]["aliases"]
    )
    citations = set(prediction.get("citations", []))
    support = set(example["gold"].get("supporting_doc_ids", []))
    source_correct = bool(support) and support.issubset(citations) if action == "answer" else False
    return {
        "action": action,
        "answer": prediction.get("answer", ""),
        "citations": sorted(citations),
        "answer_correct": answer_correct,
        "source_correct": source_correct,
        "grounded_answer": answer_correct and source_correct,
    }


def quartet_outcomes(variants: dict[str, dict[str, Any]]) -> dict[str, int]:
    sufficient = variants["sufficient"]
    noisy = variants["noisy"]
    insufficient = variants["insufficient"]
    conflicting = variants["conflicting"]
    s = sufficient["grounded_answer"]
    n = noisy["grounded_answer"]
    i = insufficient["action"] == "abstain"
    c = conflicting["action"] == "flag_conflict"
    return {
        "ers": int(s and i),
        "nr": int(sufficient["answer_correct"] and noisy["answer_correct"]),
        "cs": int(s and c),
        "qcs": int(s and n and i and c),
    }


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    position = probability * (len(ordered) - 1)
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight


def bootstrap_difference(
    first: list[int],
    second: list[int],
    *,
    samples: int,
    seed: int,
) -> tuple[float, float, float]:
    differences = [b - a for a, b in zip(first, second)]
    if not differences:
        return 0.0, 0.0, 0.0
    observed = sum(differences) / len(differences) if differences else 0.0
    rng = random.Random(seed)
    bootstrapped = []
    for _ in range(samples):
        draw = [differences[rng.randrange(len(differences))] for _ in differences]
        bootstrapped.append(sum(draw) / len(draw))
    return observed, percentile(bootstrapped, 0.025), percentile(bootstrapped, 0.975)


def exact_mcnemar(first: list[int], second: list[int]) -> dict[str, Any]:
    first_only = sum(a == 1 and b == 0 for a, b in zip(first, second))
    second_only = sum(a == 0 and b == 1 for a, b in zip(first, second))
    discordant = first_only + second_only
    if discordant == 0:
        p_value = 1.0
    else:
        tail = sum(math.comb(discordant, k) for k in range(min(first_only, second_only) + 1))
        p_value = min(1.0, 2 * tail / (2**discordant))
    return {
        "first_only_successes": first_only,
        "second_only_successes": second_only,
        "discordant_quartets": discordant,
        "two_sided_exact_p": p_value,
    }


def render_failures(
    examples: dict[str, dict[str, Any]],
    predictions: dict[str, dict[str, dict[str, Any]]],
    policies: tuple[str, str],
) -> str:
    categories: dict[str, tuple[str, str, dict[str, Any], dict[str, Any]]] = {}
    for base_id in sorted(predictions):
        for policy in policies:
            variants = predictions[base_id].get(policy, {})
            if not set(CONDITIONS).issubset(variants):
                continue
            s, n = variants["sufficient"], variants["noisy"]
            i, c = variants["insufficient"], variants["conflicting"]
            if s["grounded_answer"] and i["action"] != "abstain":
                categories.setdefault("Evidence-removal failure", (base_id, policy, s, i))
            if s["grounded_answer"] and (not n["grounded_answer"] or s["citations"] != n["citations"]):
                categories.setdefault("Noise-induced grounding change", (base_id, policy, s, n))
            if s["grounded_answer"] and c["action"] != "flag_conflict":
                categories.setdefault("Conflict blindness", (base_id, policy, s, c))
            if s["action"] != "answer":
                categories.setdefault("Over-abstention with sufficient evidence", (base_id, policy, s, s))

    lines = ["# Paired Failure Cases", ""]
    for category in (
        "Evidence-removal failure",
        "Noise-induced grounding change",
        "Conflict blindness",
        "Over-abstention with sufficient evidence",
    ):
        item = categories.get(category)
        if item is None:
            lines.extend([f"## {category}", "", "No matching failure found.", ""])
            continue
        base_id, policy, first, second = item
        question = next(
            example["question"] for example in examples.values() if example.get("base_id") == base_id
        )
        lines.extend([
            f"## {category}",
            "",
            f"- Base ID: `{base_id}`",
            f"- Policy: `{policy}`",
            f"- Question: {question}",
            f"- First behavior: action=`{first['action']}`, answer={json.dumps(first['answer'])}, citations={first['citations']}",
            f"- Changed behavior: action=`{second['action']}`, answer={json.dumps(second['answer'])}, citations={second['citations']}",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=ROOT / "data" / "eviscope_v1_1.jsonl")
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--failures-out", type=Path, required=True)
    parser.add_argument("--provider", default="gemini")
    parser.add_argument("--model", default="gemini-2.5-flash-lite")
    parser.add_argument("--policy-a", default="vanilla_rag")
    parser.add_argument("--policy-b", default="evidence_action_gate")
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    dataset = load_jsonl(args.dataset)
    dataset_hash = hashlib.sha256(args.dataset.read_bytes()).hexdigest()
    examples = {example["id"]: example for example in dataset}
    all_rows = latest_rows(load_jsonl(args.predictions))
    mismatched = [
        row.get("example_id", "") for row in all_rows
        if row.get("dataset_sha256") != dataset_hash
    ]
    if mismatched:
        raise SystemExit(
            f"Prediction file contains {len(mismatched)} rows from a different or missing dataset hash"
        )
    selected_rows = [
        row for row in all_rows
        if row.get("provider") == args.provider
        and row.get("model") == args.model
        and row.get("policy") in {args.policy_a, args.policy_b}
        and row.get("example_id") in examples
    ]

    predictions: dict[str, dict[str, dict[str, dict[str, Any]]]] = defaultdict(lambda: defaultdict(dict))
    for row in selected_rows:
        example = examples[row["example_id"]]
        adapted = adapt_prediction(row, example)
        predictions[example["base_id"]][row["policy"]][example["condition"]] = example_outcome(example, adapted)

    complete_base_ids = [
        base_id for base_id, by_policy in predictions.items()
        if all(set(CONDITIONS).issubset(by_policy.get(policy, {})) for policy in (args.policy_a, args.policy_b))
    ]
    if not complete_base_ids:
        raise SystemExit("No complete quartets shared by both requested policies")
    paired: dict[str, dict[str, list[int]]] = {metric: {} for metric in METRICS}
    for policy in (args.policy_a, args.policy_b):
        outcomes = [quartet_outcomes(predictions[base_id][policy]) for base_id in complete_base_ids]
        for metric in METRICS:
            paired[metric][policy] = [outcome[metric] for outcome in outcomes]

    comparisons = {}
    for index, metric in enumerate(METRICS):
        first = paired[metric][args.policy_a]
        second = paired[metric][args.policy_b]
        difference, low, high = bootstrap_difference(
            first,
            second,
            samples=args.bootstrap_samples,
            seed=args.seed + index,
        )
        comparisons[metric] = {
            args.policy_a: sum(first) / len(first) if first else 0.0,
            args.policy_b: sum(second) / len(second) if second else 0.0,
            "difference_policy_b_minus_policy_a": difference,
            "bootstrap_95_ci": [low, high],
        }
    comparisons["qcs"]["mcnemar"] = exact_mcnemar(
        paired["qcs"][args.policy_a], paired["qcs"][args.policy_b]
    )

    output = {
        "dataset": str(args.dataset),
        "dataset_sha256": dataset_hash,
        "provider": args.provider,
        "model": args.model,
        "policy_a": args.policy_a,
        "policy_b": args.policy_b,
        "n_complete_paired_quartets": len(complete_base_ids),
        "bootstrap_samples": args.bootstrap_samples,
        "seed": args.seed,
        "comparisons": comparisons,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.failures_out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.failures_out.write_text(
        render_failures(examples, predictions, (args.policy_a, args.policy_b)),
        encoding="utf-8",
    )
    print(f"Analyzed {len(complete_base_ids)} paired quartets into {args.out}")
    print(f"Wrote qualitative failures to {args.failures_out}")


if __name__ == "__main__":
    main()
