"""Traceable model pricing used for experiment cost estimates."""

from __future__ import annotations

from typing import Any


MODEL_PRICING_USD_PER_MILLION: dict[str, dict[str, Any]] = {
    "gemini-2.5-flash-lite": {
        "input": 0.10,
        "output_including_thinking": 0.40,
        "source": "https://ai.google.dev/gemini-api/docs/pricing",
        "checked_on": "2026-06-23",
    },
    "gemini-2.5-flash": {
        "input": 0.30,
        "output_including_thinking": 2.50,
        "source": "https://ai.google.dev/gemini-api/docs/pricing",
        "checked_on": "2026-06-23",
    },
    "gemini-3.5-flash": {
        "input": 1.50,
        "output_including_thinking": 9.00,
        "source": "https://ai.google.dev/gemini-api/docs/pricing",
        "checked_on": "2026-06-23",
    },
}


def estimate_cost_usd(model: str, input_tokens: int, output_tokens: int, thinking_tokens: int) -> float | None:
    pricing = MODEL_PRICING_USD_PER_MILLION.get(model)
    if pricing is None:
        return None
    return (
        input_tokens * pricing["input"]
        + (output_tokens + thinking_tokens) * pricing["output_including_thinking"]
    ) / 1_000_000
