| Validation set | Annotators | Evidence agr. | Behavior agr. | Conflict-present agr. | Gold behavior agr. | Gold evidence agr. |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Full EviScope-v1.1 (160 rows) | 2 | 0.994 | 0.994 | 1.000 | 0.997 | 0.997 |
