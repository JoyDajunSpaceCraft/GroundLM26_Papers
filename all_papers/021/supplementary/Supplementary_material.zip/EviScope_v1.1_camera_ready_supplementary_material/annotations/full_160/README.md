# Full-160 Human Validation

This folder contains the completed two-annotator validation records for
EviScope v1.1. Annotators saw randomized document aliases and did not see
source roles, model outputs, expected actions, answer aliases, or gold spans.

Files:

- `annotator_A_completed.csv` and `annotator_B_completed.csv`: completed
  validation sheets.
- `gold_key.csv`: hidden gold labels and mapping information used for scoring.
- `completed_validation_report.json`: validation report for the completed
  sheets.
- `agreement_summary.json`, `agreement_table.md`, and `agreement_table.tex`:
  agreement metrics.
- `disagreements_for_adjudication.csv` and `adjudication_template.csv`:
  disagreement-review support files.
