# EviScope v1.1 Supplementary Material

This package accompanies the paper "EviScope: Paired Counterfactual
Evidence Diagnostics for Faithful and Efficient Grounded Language Models." It
contains the benchmark, prompts, prediction schema, retained model outputs,
human-validation records, result tables, and reproduction scripts.

Author: Suryadeep Singh Deswal  
Indian Institute of Technology Roorkee, Roorkee, India  
Contact: suryadeep_sd@ma.iitr.ac.in

This is the camera-ready supplement for GroundLM 2026. Human annotators
remain identified only as A and B. The package contains no credentials,
private annotator identities, or local filesystem paths.

## Requirements

Use Python 3.10 or later (verified with Python 3.12). All included evaluation
scripts use only the Python standard library. Run the commands below from
the extracted package root. No model downloads, API keys, or inference calls
are required. Recomputed reports use separate filenames.

The dataset, annotations, retained outputs, and evaluation results are
unchanged from the corrected submission supplement. See `DATA_SOURCES.md`
for upstream attribution and reuse terms.

## Contents

- `data/eviscope_v1_1.jsonl`: paired counterfactual benchmark with 40 quartets
  and 160 examples.
- `prompts/`: prompt templates for the vanilla RAG and evidence-action gate
  policies.
- `schemas/prediction_schema.json`: structured prediction contract.
- `runs/`: retained logical model outputs, split by model and policy. Each file
  has 160 rows and no unresolved parse failures.
- `results/`: model metrics, policy comparisons, failure summaries, and
  provenance metadata.
- `annotations/full_160/`: completed anonymized human-validation sheets,
  gold key, agreement reports, and adjudication template.
- `scripts/`: deterministic evaluation and validation scripts.
- `MANIFEST.json`: file sizes and SHA-256 checksums.

## Exact Model Identifiers

- Qwen2.5 7B via Ollama: `qwen2.5:7b-instruct`
- Llama 3.1 8B via Ollama: `llama3.1:8b`
- Gemini 3.5 Flash via Gemini API: `gemini-3.5-flash`

## Reproduce Main Metrics

Run from the package root:

```bash
python scripts/evaluate_llm_runs.py \
  --dataset data/eviscope_v1_1.jsonl \
  --predictions runs/qwen_vanilla.jsonl runs/qwen_gate.jsonl runs/llama_vanilla.jsonl runs/llama_gate.jsonl runs/gemini_vanilla.jsonl runs/gemini_gate.jsonl \
  --out results/recomputed_model_matrix_metrics.json \
  --table-out results/recomputed_model_matrix_table.md
```

## Check Supplement Integrity

```bash
python scripts/verify_supplement.py \
  --dataset data/eviscope_v1_1.jsonl \
  --runs runs/qwen_vanilla.jsonl runs/qwen_gate.jsonl runs/llama_vanilla.jsonl runs/llama_gate.jsonl runs/gemini_vanilla.jsonl runs/gemini_gate.jsonl \
  --out results/recomputed_supplement_integrity.json
```

## Reproduce Human-Validation Agreement

```bash
python scripts/evaluate_full_160_agreement.py \
  --gold annotations/full_160/gold_key.csv \
  --annotations annotations/full_160/annotator_A_completed.csv annotations/full_160/annotator_B_completed.csv \
  --out results/recomputed_annotation_agreement.json \
  --disagreements results/recomputed_disagreements_for_adjudication.csv \
  --adjudication-template results/recomputed_adjudication_template.csv \
  --table-out results/recomputed_annotation_agreement_table.md
```


## Validate Completed Annotation Sheets

```bash
python scripts/validate_full_160_annotations.py \
  --gold annotations/full_160/gold_key.csv \
  --annotations annotations/full_160/annotator_A_completed.csv annotations/full_160/annotator_B_completed.csv \
  --require-complete \
  --out results/recomputed_completed_validation.json
```

The adjudication template records unresolved judgments; it is not a replacement
gold dataset. The paper reports observed agreement without treating unresolved
disagreements as adjudicated labels.
