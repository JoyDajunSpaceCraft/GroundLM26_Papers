# Data Sources and Reuse

EviScope v1.1 derives question/context records from SQuAD:

Pranav Rajpurkar, Jian Zhang, Konstantin Lopyrev, and Percy Liang. 2016.
SQuAD: 100,000+ Questions for Machine Comprehension of Text.
https://aclanthology.org/D16-1264/

The SQuAD distribution identifies its license as CC BY-SA 4.0:
https://rajpurkar.github.io/SQuAD-explorer/
https://creativecommons.org/licenses/by-sa/4.0/

EviScope selects records and constructs sufficient, noisy, insufficient, and
counterfactual conflicting variants. Modified claims are synthetic evidence
interventions, not corrections to the source facts. Preserve upstream attribution,
indicate modifications, and observe the applicable ShareAlike terms when reusing
or redistributing the derived text, including copies in annotation sheets.

Model weights are not included. Model identifiers, prompts, and recorded outputs
document the experiments; inclusion does not grant rights to third-party models
or services. This notice records upstream terms and does not introduce a blanket
software or artifact license. Contact the author for permissions not specified
by the applicable upstream terms or the publication license.
