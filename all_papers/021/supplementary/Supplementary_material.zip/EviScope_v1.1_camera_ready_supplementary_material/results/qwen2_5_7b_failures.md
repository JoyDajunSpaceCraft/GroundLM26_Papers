# Paired Failure Cases

## Evidence-removal failure

- Base ID: `squad_2008_sichuan_earthquake_030`
- Policy: `evidence_action_gate`
- Question: In what year did the earthquake in Sichuan occur?
- First behavior: action=`answer`, answer="2008", citations=['squad_2008_sichuan_earthquake_030_support']
- Changed behavior: action=`flag_conflict`, answer="", citations=[]

## Noise-induced grounding change

- Base ID: `squad_2008_sichuan_earthquake_032`
- Policy: `vanilla_rag`
- Question: How many people were confirmed dead?
- First behavior: action=`answer`, answer="The number of confirmed dead was 69,197.", citations=['squad_2008_sichuan_earthquake_032_support']
- Changed behavior: action=`answer`, answer="", citations=['squad_2008_sichuan_earthquake_032_support']

## Conflict blindness

- Base ID: `squad_beyonc_003`
- Policy: `vanilla_rag`
- Question: When did Beyonce start becoming popular?
- First behavior: action=`answer`, answer="Beyonce started becoming popular in the late 1990s as lead singer of R&B girl-group Destiny's Child.", citations=['squad_beyonc_003_support']
- Changed behavior: action=`answer`, answer="Beyonc\u00e9 started becoming popular in the late 1990s as lead singer of R&B girl-group Destiny's Child.", citations=['squad_beyonc_003_support']

## Over-abstention with sufficient evidence

- Base ID: `squad_beyonc_005`
- Policy: `vanilla_rag`
- Question: In her music, what are some recurring elements in them?
- First behavior: action=`abstain`, answer="", citations=[]
- Changed behavior: action=`abstain`, answer="", citations=[]
