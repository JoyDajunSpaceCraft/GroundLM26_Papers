# Paired Failure Cases

## Evidence-removal failure

No matching failure found.

## Noise-induced grounding change

- Base ID: `squad_beyonc_005`
- Policy: `vanilla_rag`
- Question: In her music, what are some recurring elements in them?
- First behavior: action=`answer`, answer="In her music, Beyonc\u00e9's songs are frequently characterized by recurring themes of love, relationships, and monogamy, alongside female sexuality and empowerment.", citations=['squad_beyonc_005_support']
- Changed behavior: action=`answer`, answer="In her music, Beyonc\u00e9's songs are frequently characterized by recurring themes of love, relationships, monogamy, female sexuality, and empowerment.", citations=['squad_beyonc_005_support']

## Conflict blindness

- Base ID: `squad_genocide_009`
- Policy: `vanilla_rag`
- Question: In the judgement, it is stated that the aim of the Genocide Convention, at its most simplest, is preventing the destruction of which victims?
- First behavior: action=`answer`, answer="The aim of the Genocide Convention is to prevent the intentional destruction of \"entire human groups\" (or a significant/substantial part of that group).", citations=['squad_genocide_009_support']
- Changed behavior: action=`answer`, answer="According to the judgement, the aim of the Genocide Convention is to prevent the intentional destruction of \"entire human groups\" (or a significant enough part of them to impact the group as a whole).", citations=['squad_genocide_009_support']

## Over-abstention with sufficient evidence

No matching failure found.
