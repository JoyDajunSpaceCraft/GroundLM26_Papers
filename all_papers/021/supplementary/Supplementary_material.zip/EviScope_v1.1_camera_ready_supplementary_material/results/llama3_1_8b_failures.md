# Paired Failure Cases

## Evidence-removal failure

- Base ID: `squad_2008_sichuan_earthquake_030`
- Policy: `evidence_action_gate`
- Question: In what year did the earthquake in Sichuan occur?
- First behavior: action=`answer`, answer="2008", citations=['squad_2008_sichuan_earthquake_030_support']
- Changed behavior: action=`answer`, answer="", citations=[]

## Noise-induced grounding change

- Base ID: `squad_beyonc_004`
- Policy: `evidence_action_gate`
- Question: After her second solo album, what other entertainment venture did Beyonce explore?
- First behavior: action=`answer`, answer="acting", citations=['squad_beyonc_004_support']
- Changed behavior: action=`abstain`, answer="", citations=[]

## Conflict blindness

- Base ID: `squad_2008_sichuan_earthquake_030`
- Policy: `vanilla_rag`
- Question: In what year did the earthquake in Sichuan occur?
- First behavior: action=`answer`, answer="2008", citations=['squad_2008_sichuan_earthquake_030_support']
- Changed behavior: action=`answer`, answer="2008", citations=['squad_2008_sichuan_earthquake_030_support']

## Over-abstention with sufficient evidence

- Base ID: `squad_beyonc_004`
- Policy: `vanilla_rag`
- Question: After her second solo album, what other entertainment venture did Beyonce explore?
- First behavior: action=`abstain`, answer="", citations=[]
- Changed behavior: action=`abstain`, answer="", citations=[]
