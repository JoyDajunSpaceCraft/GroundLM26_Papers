| Model | Policy | Ans | Joint | ERS | NR | CS | QCS | Insuff.Ans | Conf.Ans | Calls | Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| gemini-3.5-flash | evidence_action_gate | 0.91 | 0.94 | 0.90 | 0.90 | 0.88 | 0.88 | 0.00 | 0.05 | 2.09 | 653.03 |
| gemini-3.5-flash | vanilla_rag | 0.91 | 0.94 | 0.93 | 0.90 | 0.88 | 0.85 | 0.00 | 0.05 | 1.81 | 662.56 |
| llama3.1:8b | evidence_action_gate | 0.85 | 0.71 | 0.80 | 0.78 | 0.17 | 0.10 | 0.10 | 0.78 | 1.00 | 644.86 |
| llama3.1:8b | vanilla_rag | 0.70 | 0.78 | 0.82 | 0.57 | 0.55 | 0.38 | 0.00 | 0.28 | 1.00 | 632.66 |
| qwen2.5:7b-instruct | evidence_action_gate | 0.74 | 0.64 | 0.15 | 0.68 | 0.62 | 0.15 | 0.00 | 0.10 | 1.00 | 687.45 |
| qwen2.5:7b-instruct | vanilla_rag | 0.74 | 0.82 | 0.75 | 0.68 | 0.57 | 0.50 | 0.00 | 0.20 | 1.00 | 678.83 |
