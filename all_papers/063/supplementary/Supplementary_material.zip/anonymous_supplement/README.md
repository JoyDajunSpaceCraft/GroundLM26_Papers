# Anonymous Supplement: Evidence-Anchor Query Rewriting

This supplement documents the submission-time prompts, configuration fields, and planned artifact schema for the GroundLM 2026 anonymous review build.

It intentionally does not contain author-identifying paths, accounts, or raw logs. The camera-ready artifact should add the full per-query release: sampled query IDs, rewrite logs, detected anchors, validation decisions, fallback indicators, retrieval outputs, and scripts for nDCG, harm-rate, paired bootstrap, McNemar, accepted-versus-fallback, and anchor-drop analyses.

Files:

- `prompts.md`: prompt templates used for direct rewriting, HyDE, Query2doc, constrained variants, and append-only retrieval input construction.
- `release_schema.json`: field-level schema for the per-query artifact expected in the camera-ready release.

