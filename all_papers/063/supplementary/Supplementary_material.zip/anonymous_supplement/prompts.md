# Prompt Templates

All prompts use the model's default chat template and greedy decoding unless otherwise specified.

## Direct Rewrite

```text
Rewrite the query to improve document retrieval. Preserve the user's intent and return only the rewritten query.

Query: {query}
```

## Constrained Direct Rewrite

```text
Rewrite the query to improve document retrieval. Preserve the user's intent and return only the rewritten query.
The following evidence anchors must appear verbatim in your output: {anchors}. Do not remove or paraphrase them.

Query: {query}
```

## HyDE

```text
Write one concise hypothetical passage that would answer the query and contain terms useful for retrieval. Return only the passage.

Query: {query}
```

## Constrained HyDE

```text
Write one concise hypothetical passage that would answer the query and contain terms useful for retrieval. Return only the passage.
The following evidence anchors must appear verbatim in your output: {anchors}. Do not remove or paraphrase them.

Query: {query}
```

## Query2doc

```text
Generate a short pseudo-document containing likely relevant terms for retrieving documents about the query. Return only the pseudo-document.

Query: {query}
```

## Constrained Query2doc

```text
Generate a short pseudo-document containing likely relevant terms for retrieving documents about the query. Return only the pseudo-document.
The following evidence anchors must appear verbatim in your output: {anchors}. Do not remove or paraphrase them.

Query: {query}
```

## Append-Only

Append-only uses the direct rewrite prompt. The final retrieval input is:

```text
{original_query} || {rewrite}
```

## Decoding Caps

- Direct rewrite: 100 new tokens.
- Append-only rewrite: 100 new tokens.
- HyDE: 256 new tokens.
- Query2doc: 256 new tokens.

