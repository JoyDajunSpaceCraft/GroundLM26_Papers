# SkillNav — Supplementary Code

This archive contains the source code for **SkillNav**, a multi-agent system for
zero-shot object navigation in Habitat. SkillNav layers a decoupled multi-agent
controller (Memory / Safe / Exploration agents) on top of a C++/ROS planner core
(mapping, frontier exploration, trajectory generation), driven by a two-prompt dual
ValueMap (semantic-relevance **SR** + information-gain **IG**).

The multi-agent controller, dual ValueMap fusion, Voronoi topology bus, and the
LLM/VLM-driven agents on top of a frontier-exploration planner core are the
contribution of this work.

> **Anonymized for review.** Author names, absolute home paths, and version-control
> history have been removed. Absolute paths have been replaced with the environment
> variables `${SKILLNAV_ROOT}` (this directory) and `${CONDA_PREFIX}` (the active
> conda env).

---

## What is and isn't included

**Included:** all first-party source code.

| Path | Contents |
|---|---|
| `src/planner/` | C++/ROS planner: mapping, frontier exploration, dual ValueMap, Voronoi topology, Memory/Exploration agents, trajectory + path search |
| `habitat_evaluation.py`, `habitat_*_control.py` | Habitat-side eval loop, manual/velocity control |
| `vlm/` | VLM servers (grounding_dino, blip2_itm, sam, yolov7) and the ITM dual-prompt scoring |
| `llm/` | LLM prompts and cached answers (Ollama / qwen3 / deepseek) |
| `config/` | Habitat eval configs + per-target two-prompt YAMLs |
| `habitat2ros/`, `basic_utils/`, `scripts/` | ROS bridge, shared utilities, run/analysis scripts |

**NOT included** (size / third-party license / not needed to read the method):

- **Dataset** — HM3D-v2 scene + episode data. Download from the official Habitat
  sources and place under `data/`.
- **Model weights** — `traced_model.pt` (BLIP-2 trace) and detector checkpoints.
- **Third-party repos** — `habitat-lab/`, `GroundingDINO/`, `yolov7/`. Clone the
  upstream projects; `vlm/detector/{groundingdino,yolov7}` are expected to symlink to them.
- Build artifacts (`build/`, `devel/`), videos, and version-control history.

---

## Environment

Ubuntu 20.04 + ROS Noetic + Python 3.9. Create the conda env:

```bash
conda env create -f skillnav_environment.yaml   # creates env `skillnav`
conda activate skillnav
```

Keep `numpy==1.23.5` and `numba==0.60.0` (other versions break the numba kernels).

## Build (catkin)

```bash
export SKILLNAV_ROOT=$(pwd)
catkin_make -DPYTHON_EXECUTABLE=/usr/bin/python3
source ${SKILLNAV_ROOT}/devel/setup.bash
```

## Run (3 terminals, order matters)

1. **VLM servers** (ports 12181 grounding_dino, 12182 blip2_itm, 12183 sam, 12184 yolov7):
   ```bash
   ./scripts/start_vlm_servers.sh start    # {start|status|stop|restart}
   ```
2. **RViz + roscore:**
   ```bash
   roslaunch exploration_manager rviz.launch
   ```
3. **Habitat evaluator** (the wrapper sets `LD_PRELOAD` to resolve an HDF5 conflict
   between ROS and h5py — always launch through it):
   ```bash
   ./run_habitat.sh --dataset hm3dv2                  # full run
   ./run_habitat.sh --dataset hm3dv2 test_epi_num=10  # 10 episodes
   ```
   Dataset: `hm3dv2`. Config in `config/habitat_eval_hm3dv2.yaml`.

A per-episode planner restart (`habitat_evaluation.py::restart_planner`) relaunches the
ROS planner between episodes.

## Architecture (brief)

```
Habitat (habitat_evaluation.py)
  ├─ dual ITM cosines  →  /blip2_itm/scores  ([SR, IG])
  └─ /target_object, /target_room  (rosparam)
                  │
                  ▼
  C++ planner (exploration_manager)
    MapROS → MultiValueMapManager
      ├─ ValueMap_SR (semantic relevance) → ObjectMap.confidence
      ├─ ValueMap_IG (information gain)
      └─ combined = w_sr·SR + w_ig·IG  →  Voronoi base_value + frontier scoring
    Memory Agent:  candidate targets + multi-frame VLM verification + FP tracking
    Safe Agent:    adaptive escape + VLM dead-zone analysis
    Exploration Agent: coverage-tiered SR/IG fusion weights
```

The Voronoi topology (`src/planner/plan_env/src/voronoi_topology.cpp`) is the shared
bus across agents; nodes carry a read-only `base_value` from the ValueMap plus
per-agent additive/multiplier terms.

## License

See `LICENSE`.
